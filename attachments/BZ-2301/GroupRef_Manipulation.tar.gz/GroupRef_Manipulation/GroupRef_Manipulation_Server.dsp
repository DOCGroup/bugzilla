# Microsoft Developer Studio Project File - Name="GroupRef_Manipulation_Server" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=GroupRef_Manipulation_Server - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE run the tool that generated this project file and specify the
!MESSAGE nmake output type.  You can then use the following command:
!MESSAGE
!MESSAGE NMAKE.
!MESSAGE
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE
!MESSAGE NMAKE CFG="GroupRef_Manipulation_Server - Win32 Debug"
!MESSAGE
!MESSAGE Possible choices for configuration are:
!MESSAGE
!MESSAGE "GroupRef_Manipulation_Server - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE "GroupRef_Manipulation_Server - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "GroupRef_Manipulation_Server - Win32 Debug"

# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "."
# PROP Intermediate_Dir "Debug\GroupRef_Manipulation_Server"
# PROP Target_Dir ""
# ADD CPP /nologo /Ob0 /W3 /Gm /GX /Zi /MDd /GR /Gy /Fd"Debug\GroupRef_Manipulation_Server/" /I "$(ACE_ROOT)" /I "$(TAO_ROOT)" /I "$(TAO_ROOT)\orbsvcs" /D _DEBUG /D WIN32 /D _CONSOLE /FD /c
# SUBTRACT CPP /YX

# ADD MTL /D "_DEBUG" /nologo /mktyplib203 /win32
# ADD RSC /l 0x409 /d _DEBUG /i "$(ACE_ROOT)" /i "$(TAO_ROOT)" /i "$(TAO_ROOT)\orbsvcs"
BSC32=bscmake.exe
# ADD BSC32 /nologo 
LINK32=link.exe
# ADD LINK32 advapi32.lib user32.lib /INCREMENTAL:NO ACEd.lib TAOd.lib TAO_AnyTypeCoded.lib TAO_PortableServerd.lib TAO_IORManipd.lib TAO_CodecFactoryd.lib TAO_PId.lib TAO_PI_Serverd.lib TAO_CosNamingd.lib TAO_Valuetyped.lib TAO_Messagingd.lib TAO_PortableGroupd.lib TAO_FTORB_Utilsd.lib TAO_FT_ClientORBd.lib TAO_FT_ServerORBd.lib /libpath:"." /libpath:"$(ACE_ROOT)\lib" /nologo /subsystem:console /pdb:".\server.pdb" /debug /machine:I386 /out:".\server.exe"

!ELSEIF  "$(CFG)" == "GroupRef_Manipulation_Server - Win32 Release"

# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release\GroupRef_Manipulation_Server"
# PROP Target_Dir ""
# ADD CPP /nologo /O2 /W3 /GX /MD /GR /I "$(ACE_ROOT)" /I "$(TAO_ROOT)" /I "$(TAO_ROOT)\orbsvcs" /D NDEBUG /D WIN32 /D _CONSOLE /FD /c
# SUBTRACT CPP /YX

# ADD MTL /D "NDEBUG" /nologo /mktyplib203 /win32
# ADD RSC /l 0x409 /d NDEBUG /i "$(ACE_ROOT)" /i "$(TAO_ROOT)" /i "$(TAO_ROOT)\orbsvcs"
BSC32=bscmake.exe
# ADD BSC32 /nologo 
LINK32=link.exe
# ADD LINK32 advapi32.lib user32.lib /INCREMENTAL:NO ACE.lib TAO.lib TAO_AnyTypeCode.lib TAO_PortableServer.lib TAO_IORManip.lib TAO_CodecFactory.lib TAO_PI.lib TAO_PI_Server.lib TAO_CosNaming.lib TAO_Valuetype.lib TAO_Messaging.lib TAO_PortableGroup.lib TAO_FTORB_Utils.lib TAO_FT_ClientORB.lib TAO_FT_ServerORB.lib /libpath:"." /libpath:"$(ACE_ROOT)\lib" /nologo /subsystem:console /pdb:none  /machine:I386 /out:"Release\server.exe"

!ENDIF

# Begin Target

# Name "GroupRef_Manipulation_Server - Win32 Debug"
# Name "GroupRef_Manipulation_Server - Win32 Release"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;cxx;c"
# Begin Source File

SOURCE="server.cpp"
# End Source File
# Begin Source File

SOURCE="Server_ORBInitializer.cpp"
# End Source File
# Begin Source File

SOURCE="Server_Request_Interceptor.cpp"
# End Source File
# Begin Source File

SOURCE="test_i.cpp"
# End Source File
# Begin Source File

SOURCE="testC.cpp"
# End Source File
# Begin Source File

SOURCE="testS.cpp"
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hh"
# Begin Source File

SOURCE="Server_ORBInitializer.h"
# End Source File
# Begin Source File

SOURCE="Server_Request_Interceptor.h"
# End Source File
# Begin Source File

SOURCE="test_i.h"
# End Source File
# Begin Source File

SOURCE="testC.h"
# End Source File
# Begin Source File

SOURCE="testS.h"
# End Source File
# End Group
# Begin Group "Inline Files"

# PROP Default_Filter "i;inl"
# Begin Source File

SOURCE="testC.inl"
# End Source File
# Begin Source File

SOURCE="testS.inl"
# End Source File
# End Group
# Begin Group "Template Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE="testS_T.cpp"
# PROP Exclude_From_Build 1
# End Source File
# End Group
# Begin Group "Documentation"

# PROP Default_Filter ""
# Begin Source File

SOURCE="README"
# End Source File
# End Group
# End Target
# End Project
