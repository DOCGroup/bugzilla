# Microsoft Developer Studio Generated NMAKE File
!IF "$(CFG)" == ""
CFG=Win32 Debug
!MESSAGE No configuration specified. Defaulting to Win32 Debug.
!ENDIF

!IF "$(CFG)" == "Win32 Debug" || "$(CFG)" == "Win32 Release" || "$(CFG)" == "Win32 Static Debug" || "$(CFG)" == "Win32 Static Release"
!ELSE
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE
!MESSAGE NMAKE /f "Makefile.GroupRef_Manipulation_Idl.mak" CFG="Win32 Debug"
!MESSAGE
!MESSAGE Possible choices for configuration are:
!MESSAGE
!MESSAGE "Win32 Debug" (based on "Win32 (x86) Dynamic-Lynk Library")
!MESSAGE "Win32 Release" (based on "Win32 (x86) Dynamic-Lynk Library")
!MESSAGE "Win32 Static Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "Win32 Static Release" (based on "Win32 (x86) Static Library")
!MESSAGE
!ERROR An invalid configuration was specified.
!ENDIF

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE
NULL=nul
!ENDIF

!IF "$(DEPGEN)" == ""
!IF EXISTS("$(DEPGEN_ROOT)/depgen.pl")
DEPGEN=perl $(DEPGEN_ROOT)/depgen.pl -t nmake
!ELSEIF EXISTS("$(ACE_ROOT)/bin/depgen.pl")
DEPGEN=perl $(ACE_ROOT)/bin/depgen.pl -t nmake
!ENDIF
!ENDIF

GENERATED_DIRTY = "testS_T.inl" "testS.inl" "testC.inl" "testC.h" "testS.h" "testS_T.h" "testC.cpp" "testS.cpp" "testS_T.cpp"

!IF  "$(CFG)" == "Win32 Debug"

OUTDIR=.
INTDIR=Debug\GroupRef_Manipulation_Idl\I386

ALL : DEPENDCHECK $(GENERATED_DIRTY)

DEPEND :
!IF "$(DEPGEN)" == ""
	@echo No suitable dependency generator could be found.
	@echo You can check one out from OCI using the following cvs command:
	@echo cvs -d :pserver:anonymous@anoncvs.ociweb.com:/cvs co Depgen
	@echo Then set the DEPGEN_ROOT environment variable to the full path of Depgen.
!ELSE
	-@rem
!ENDIF

REALCLEAN : CLEAN
        -@del /f/q "$(OUTDIR)\d.lib"
        -@del /f/q "$(OUTDIR)\d.exp"
        -@del /f/q "$(OUTDIR)\d.ilk"
        -@del /f/q "testS_T.inl"
        -@del /f/q "testS.inl"
        -@del /f/q "testC.inl"
        -@del /f/q "testC.h"
        -@del /f/q "testS.h"
        -@del /f/q "testS_T.h"
        -@del /f/q "testC.cpp"
        -@del /f/q "testS.cpp"
        -@del /f/q "testS_T.cpp"

"$(INTDIR)" :
    if not exist "Debug\$(NULL)" mkdir "Debug"
    if not exist "Debug\GroupRef_Manipulation_Idl\$(NULL)" mkdir "Debug\GroupRef_Manipulation_Idl"
    if not exist "$(INTDIR)\$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /Ob0 /W3 /Gm /EHs /Zi /MDd /GR /Gy /Fd"$(INTDIR)/" /D _DEBUG /D WIN32 /D _WINDOWS /Fo"$(INTDIR)\\" /FD /c

RSC=rc.exe


!ELSEIF  "$(CFG)" == "Win32 Release"

OUTDIR=.
INTDIR=Release\GroupRef_Manipulation_Idl\I386

ALL : DEPENDCHECK $(GENERATED_DIRTY)

DEPEND :
!IF "$(DEPGEN)" == ""
	@echo No suitable dependency generator could be found.
	@echo You can check one out from OCI using the following cvs command:
	@echo cvs -d :pserver:anonymous@anoncvs.ociweb.com:/cvs co Depgen
	@echo Then set the DEPGEN_ROOT environment variable to the full path of Depgen.
!ELSE
	-@rem
!ENDIF

REALCLEAN : CLEAN
        -@del /f/q "$(OUTDIR)\.lib"
        -@del /f/q "$(OUTDIR)\.exp"
        -@del /f/q "$(OUTDIR)\.ilk"
        -@del /f/q "testS_T.inl"
        -@del /f/q "testS.inl"
        -@del /f/q "testC.inl"
        -@del /f/q "testC.h"
        -@del /f/q "testS.h"
        -@del /f/q "testS_T.h"
        -@del /f/q "testC.cpp"
        -@del /f/q "testS.cpp"
        -@del /f/q "testS_T.cpp"

"$(INTDIR)" :
    if not exist "Release\$(NULL)" mkdir "Release"
    if not exist "Release\GroupRef_Manipulation_Idl\$(NULL)" mkdir "Release\GroupRef_Manipulation_Idl"
    if not exist "$(INTDIR)\$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /O2 /W3 /EHs /MD /GR /D NDEBUG /D WIN32 /D _WINDOWS /Fo"$(INTDIR)\\" /FD /c

RSC=rc.exe


!ELSEIF  "$(CFG)" == "Win32 Static Debug"

OUTDIR=.
INTDIR=Static_Debug\GroupRef_Manipulation_Idl\I386

ALL : DEPENDCHECK $(GENERATED_DIRTY)

DEPEND :
!IF "$(DEPGEN)" == ""
	@echo No suitable dependency generator could be found.
	@echo You can check one out from OCI using the following cvs command:
	@echo cvs -d :pserver:anonymous@anoncvs.ociweb.com:/cvs co Depgen
	@echo Then set the DEPGEN_ROOT environment variable to the full path of Depgen.
!ELSE
	-@rem
!ENDIF

REALCLEAN : CLEAN
	-@del /f/q ".\sd.pdb"
        -@del /f/q "testS_T.inl"
        -@del /f/q "testS.inl"
        -@del /f/q "testC.inl"
        -@del /f/q "testC.h"
        -@del /f/q "testS.h"
        -@del /f/q "testS_T.h"
        -@del /f/q "testC.cpp"
        -@del /f/q "testS.cpp"
        -@del /f/q "testS_T.cpp"

"$(INTDIR)" :
    if not exist "Static_Debug\$(NULL)" mkdir "Static_Debug"
    if not exist "Static_Debug\GroupRef_Manipulation_Idl\$(NULL)" mkdir "Static_Debug\GroupRef_Manipulation_Idl"
    if not exist "$(INTDIR)\$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /Ob0 /W3 /Gm /EHs /Zi /GR /Gy /MDd /Fd".\sd.pdb" /D _DEBUG /D WIN32 /D _WINDOWS /Fo"$(INTDIR)\\" /FD /c



!ELSEIF  "$(CFG)" == "Win32 Static Release"

OUTDIR=.
INTDIR=Static_Release\GroupRef_Manipulation_Idl\I386

ALL : DEPENDCHECK $(GENERATED_DIRTY)

DEPEND :
!IF "$(DEPGEN)" == ""
	@echo No suitable dependency generator could be found.
	@echo You can check one out from OCI using the following cvs command:
	@echo cvs -d :pserver:anonymous@anoncvs.ociweb.com:/cvs co Depgen
	@echo Then set the DEPGEN_ROOT environment variable to the full path of Depgen.
!ELSE
	-@rem
!ENDIF

REALCLEAN : CLEAN
        -@del /f/q "testS_T.inl"
        -@del /f/q "testS.inl"
        -@del /f/q "testC.inl"
        -@del /f/q "testC.h"
        -@del /f/q "testS.h"
        -@del /f/q "testS_T.h"
        -@del /f/q "testC.cpp"
        -@del /f/q "testS.cpp"
        -@del /f/q "testS_T.cpp"

"$(INTDIR)" :
    if not exist "Static_Release\$(NULL)" mkdir "Static_Release"
    if not exist "Static_Release\GroupRef_Manipulation_Idl\$(NULL)" mkdir "Static_Release\GroupRef_Manipulation_Idl"
    if not exist "$(INTDIR)\$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /O2 /W3 /EHs /MD /GR /D NDEBUG /D WIN32 /D _WINDOWS /Fo"$(INTDIR)\\" /FD /c



!ENDIF

CLEAN :
	-@del /f/s/q "$(INTDIR)"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)\$(NULL)" mkdir "$(OUTDIR)"

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $<
<<

!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("Makefile.GroupRef_Manipulation_Idl.dep")
!INCLUDE "Makefile.GroupRef_Manipulation_Idl.dep"
!ENDIF
!ENDIF

!IF "$(CFG)" == "Win32 Debug" || "$(CFG)" == "Win32 Release" || "$(CFG)" == "Win32 Static Debug" || "$(CFG)" == "Win32 Static Release" 
SOURCE="test.idl"

InputPath=test.idl

"testS_T.inl" "testS.inl" "testC.inl" "testC.h" "testS.h" "testS_T.h" "testC.cpp" "testS.cpp" "testS_T.cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat
	@echo off
	PATH=%PATH%;..\..\..\..\..\lib
	..\..\..\..\..\bin\tao_idl -Ge 1 -Wb,pre_include=ace\pre.h -Wb,post_include=ace\post.h -I..\..\..\.. -Sa -St -DCORBA3 "$(InputPath)"
<<


!ENDIF

GENERATED : $(GENERATED_DIRTY)
	-@rem

DEPENDCHECK :
!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("Makefile.GroupRef_Manipulation_Idl.dep")
	@echo Using "Makefile.GroupRef_Manipulation_Idl.dep"
!ELSE
	@echo Warning: cannot find "Makefile.GroupRef_Manipulation_Idl.dep"
!ENDIF
!ENDIF

