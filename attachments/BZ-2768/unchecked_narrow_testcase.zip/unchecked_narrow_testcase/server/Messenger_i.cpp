#include "Messenger_i.h"
#include <stdio.h>

void Messenger_i::Send ( ::SimpleMessenger::ulong uiData)
      ACE_THROW_SPEC ((
        ::CORBA::SystemException
      ))
{
	printf("data=%d\n", uiData);
}

