#ifndef __MESSENGER_I_H__
#define __MESSENGER_I_H__

#include "MessengerS.h"



class Messenger_i : public POA_SimpleMessenger::Messenger
{
public:
   virtual void Send ( ::SimpleMessenger::ulong uiData)
      ACE_THROW_SPEC ((
        ::CORBA::SystemException
      ));
};

#endif
