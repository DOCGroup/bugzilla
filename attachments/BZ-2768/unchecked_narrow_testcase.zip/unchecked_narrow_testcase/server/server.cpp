
#ifdef WIN32
	#ifdef _DEBUG
		#define _DO_POSTFIX(a) a##"d"
	#else
		#define _DO_POSTFIX(a) a
	#endif

	#pragma comment(lib, _DO_POSTFIX("TAO")) 
	#pragma comment(lib, _DO_POSTFIX("ACE")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_PortableServer")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_AnyTypeCode")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_IORTable"))
	#pragma comment(lib, _DO_POSTFIX("TAO_Messaging")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_Valuetype"))

	#undef _DO_POSTFIX
#endif

#include <string>
#include "tao/IORTable/IORTable.h"
#include "Messenger_i.h"

int main(int argc, char * argv[])
{
	try {
		char * fake_argv[]={"-ORBEndPoint", "iiop://localhost:10000", "-OrbDebugLevel", "10" };
		int fake_argc=sizeof(fake_argv)/sizeof(char*);

		//init the orb
		CORBA::ORB_var orb=CORBA::ORB_init( fake_argc, fake_argv);

		//get the root poa
		CORBA::Object_var poa_object = orb->resolve_initial_references ("RootPOA");
		PortableServer::POA_var poa = PortableServer::POA::_narrow (poa_object.in ());

		PortableServer::POAManager_var poa_manager = poa->the_POAManager ();
		poa_manager->activate ();

		// Get a reference to the IOR Table 
		CORBA::Object_var tobj = orb->resolve_initial_references("IORTable");
		IORTable::Table_var table = IORTable::Table::_narrow(tobj.in());

		//get an object id for the name 
		PortableServer::ObjectId_var oid = PortableServer::string_to_ObjectId ("Messenger");

		//activate the object for the given id
		Messenger_i messenger;
		poa->activate_object_with_id(oid.in (), &messenger);
		CORBA::Object_var messenger_obj = poa->id_to_reference (oid.in ());
		
		//bind the ior string to the name
		CORBA::String_var messenger_ior_string = orb->object_to_string(messenger_obj.in());
		table->bind("Messenger", messenger_ior_string.in());


		while (true)
		{
			orb->perform_work();
		}
		

	} catch (CORBA::Exception & ex)
	{
		printf(ex._name());
	} catch (std::exception & ex)
	{
		printf(ex.what());
	} catch (...)
	{
		printf("unspecified exception");
	}

	return 0;
}

