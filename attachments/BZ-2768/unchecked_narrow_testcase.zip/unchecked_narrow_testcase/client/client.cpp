
#ifdef WIN32
	#ifdef _DEBUG
		#define _DO_POSTFIX(a) a##"d"
	#else
		#define _DO_POSTFIX(a) a
	#endif
	#pragma comment(lib, _DO_POSTFIX("TAO")) 
	#pragma comment(lib, _DO_POSTFIX("ACE")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_PortableServer")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_AnyTypeCode")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_IORTable"))
	#pragma comment(lib, _DO_POSTFIX("TAO_Messaging")) 
	#pragma comment(lib, _DO_POSTFIX("TAO_Valuetype"))
	#pragma comment(lib, _DO_POSTFIX("Messenger"))
	#undef _DO_POSTFIX
#endif
#include "MessengerC.h"


int main(int argc, char* argv[])
{
	char * fake_argv[]={"-ORBEndPoint", "iiop://localhost:10001", "-OrbDebugLevel", "10" };
	int fake_argc=sizeof(fake_argv)/sizeof(char*);

	try {
		//init the orb
		CORBA::ORB_var orb=CORBA::ORB_init( fake_argc, fake_argv);

		CORBA::Object_var object_temp = orb->string_to_object("corbaloc:iiop:localhost:10000/Messenger");

		SimpleMessenger::Messenger_var messenger=SimpleMessenger::Messenger::_unchecked_narrow( object_temp.in ());

		CORBA::PolicyList_var unused;
		messenger->_validate_connection(unused);

		messenger->Send(0);		

		orb->destroy();

	} catch (CORBA::Exception & ex)
	{
		printf(ex._name());
	} catch (std::exception & ex)
	{
		printf(ex.what());
	} catch (...)
	{
		printf("unspecified exception");
	}

	return 0;
}

