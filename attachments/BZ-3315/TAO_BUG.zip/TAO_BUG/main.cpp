#include <pthread.h>
#include "FooS.h"

int argcc;
char** argvv;

void* main_orb(void* ptr)
{
  try
  {
    CORBA::ORB_var orb = CORBA::ORB_init (argcc, argvv);

    CORBA::Object_var poa_object = orb->resolve_initial_references("RootPOA");

    PortableServer::POA_var root_poa = PortableServer::POA::_narrow (poa_object.in ());

    if (CORBA::is_nil (poa_object.in ()))
      ACE_ERROR_RETURN ((LM_ERROR, " (%P|%t) Panic got a nil RootPOA\n"), 0);

    PortableServer::POAManager_var poa_manager = root_poa->the_POAManager ();
  }
  catch(...)
  {
    ACE_ERROR_RETURN ((LM_ERROR, " (%P|%t) Unknown error\n"), 0);
  }

  return 0;
}

int main(int argc, char* argv[])
{
  argcc = argc;
  argvv = argv;

  pthread_t thread1;
  pthread_create(&thread1, 0, main_orb, 0);
  pthread_join( thread1, 0);

  return 0;
}
