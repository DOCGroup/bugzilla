#include "orbsvcs/Event/ECG_CDR_Message_Receiver.h"

#include <iostream>
#include <limits>

bool success = true;

#define check_equals(a, b) \
  do if ((a) != (b)) { \
    success = false; \
    std::cerr << "CHECK EQUALS FAILURE (" << __FILE__ << ':' << __LINE__ \
              << "): " << #a << " != " << #b \
              << " - expected=<" << a \
              << "> - got=<" << b << ">" << std::endl; \
  } while(0)

#define check_not_equals(a, b) \
  do if ((a) == (b)) { \
    success = false; \
    std::cerr << "CHECK NOT EQUALS FAILURE (" << __FILE__ << ':' << __LINE__ \
              << "): " << #a << " != " << #b \
              << " - expected=<" << (a) \
              << "> - got=<" << (b) << ">" << std::endl; \
  } while(0)

#define check_compare(a, cmp, b) \
  do if (!((a) cmp (b))) { \
    success = false; \
    std::cerr << "CHECK COMPARE (" << __FILE__ << ':' << __LINE__ \
              << "): " << #a << ' ' << #cmp << ' ' << #b \
              << " - " << #a << "=<" << (a) \
              << ">, " << #b << "=<" << (b) << '>' << std::endl; \
  } while(0)

#define check_condition(a) \
  do if (!(a)) { \
    success = false; \
    std::cerr << "CHECK CONDITION (" << __FILE__ << ':' << __LINE__ \
              << "): " << #a << std::endl; \
  } while(0)

void test_normal_advance();
void test_edges();
void test_refetch();
void test_wrap();

int
main(int, char * [])
{
  test_normal_advance();
  test_edges();
  test_refetch();
  test_wrap();

  return !success;
}

typedef TAO_ECG_UDP_Request_Entry * Entry;

void test_normal_advance()
{
  TAO_ECG_CDR_Message_Receiver::Requests requests;

  size_t const range = 16;
  requests.init(range, 4);

  CORBA::ULong request_id = 384;

  for (size_t i = 0; i != 4 * range; ++i)
  {
    Entry * entry = requests.get_request(request_id);
    check_not_equals(0, entry);
    check_compare(request_id, >=, requests.id_range_low());
    check_compare(request_id, <, requests.id_range_high());

    request_id++;
  }

  request_id = request_id - range - 1;
  Entry * entry = requests.get_request(request_id);
  check_equals(0, entry);

  request_id = request_id - 5 * range;
  entry = requests.get_request(request_id);
  check_not_equals(0, entry);
  check_equals(request_id, requests.id_range_low());
}

void test_refetch()
{
  TAO_ECG_CDR_Message_Receiver::Requests requests;

  size_t const range = 16;
  requests.init(range, 4);

  CORBA::ULong start_id = 500;

  Entry * start_entry = requests.get_request(start_id);

  CORBA::ULong request_id = start_id;
  int match_count = 0;
  for (size_t i = 0; i != 4 * range; ++i)
  {
    Entry * entry = requests.get_request(request_id);
    check_not_equals(0, entry);

    Entry * s = requests.get_request(start_id);
    if (s == 0)
    {
      check_compare(start_id, <, requests.id_range_low());
      break;
    }
    match_count++;
    check_equals(start_entry, s);
  }
  check_not_equals(0, match_count);
}

void test_edges()
{
  TAO_ECG_CDR_Message_Receiver::Requests requests;

  size_t const range = 1024;
  requests.init(range, 4);

  CORBA::ULong request_id = range;
  for (size_t i = 0; i != 4 * range; ++i)
  {
    Entry * entry = requests.get_request(request_id);
    check_not_equals(0, entry);
    check_compare(request_id, >=, requests.id_range_low());
    check_compare(request_id, <, requests.id_range_high());

    request_id++;
  }
  

  Entry * max_entry = requests.get_request(
      std::numeric_limits<CORBA::ULong>::max());
  check_not_equals(0, max_entry);
  Entry * min_entry = requests.get_request(
      std::numeric_limits<CORBA::ULong>::min());
  check_not_equals(0, min_entry);

  check_not_equals(max_entry, min_entry);

  Entry * old = requests.get_request(
      std::numeric_limits<CORBA::ULong>::max() - 3 * range);
  check_not_equals(0, old);
}

void test_wrap()
{
  TAO_ECG_CDR_Message_Receiver::Requests requests;

  size_t const range = 1024;
  requests.init(range, 4);

  CORBA::ULong request_id =
    std::numeric_limits<CORBA::ULong>::max() - 2 * range;

  CORBA::ULong offset = 5 * range;

  for (size_t i = 0; i != 4 * range; ++i)
  {
    Entry * entry = requests.get_request(request_id);
    check_not_equals(0, entry);

    check_compare(request_id + offset, >=, requests.id_range_low() + offset);
    check_compare(request_id + offset, <, requests.id_range_high() + offset);

    request_id++;
  }
}
