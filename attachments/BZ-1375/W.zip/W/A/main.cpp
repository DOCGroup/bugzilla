#include "aC.h"

int main (int argc, char *argv[])
{
	W::A my_a;
	return 0;
}