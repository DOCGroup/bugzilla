#include "bI.h"

int main (int argc, char *argv[])
{
	W_B_i my_b;
	return 0;
}