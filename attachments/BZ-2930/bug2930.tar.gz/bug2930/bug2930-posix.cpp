#include <unistd.h>
#include <stdio.h>

int c;
extern char *optarg;
extern int optind, optopt, opterr;

int main(int argc, char ** argv)
{

  while ((c = getopt(argc, argv, ":hvc:")) != -1)
  {
    switch(c) {
      case 'h':
        break;
      case 'v':
        break;
      case 'c':
        printf("optarg='%s'\n", optarg);
        break;
      case ':':
        printf("option '%c' needs an argument\n", optopt);
        break;
      case '?':
        printf("unknown arg '%c'\n", optopt);
        break;
    }
  }
  return 0;
}
