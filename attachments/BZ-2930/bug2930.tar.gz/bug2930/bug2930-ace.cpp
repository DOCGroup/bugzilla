
#include "ace/OS.h"
#include "ace/Get_Opt.h"


int main(int argc, char ** argv)
{
  // parse cmdline options
  ACE_Get_Opt cmdOpts(
    argc,
    argv,
    ":hvc:"
  );
  
  int option;
  while((option = cmdOpts()) != EOF)
  {
    switch (option)
    {
      case 'h':
        break;
      case 'v':
        break;
      case 'c':
          ACE_DEBUG((
            LM_DEBUG,
            ACE_TEXT ("optarg='%s'\n"),
            cmdOpts.opt_arg()
          ));
        break;
      case ':':
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("option '%c' needs an argument\n"),
          static_cast<char>(cmdOpts.opt_opt())
        ));
        break;
      case '\?':
      default:
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("unknown arg '%c'\n"),
          static_cast<char>(cmdOpts.opt_opt())
        ));
        break;
    } /* end of switch */
  } /* end of while */
  
  return 0;
}
