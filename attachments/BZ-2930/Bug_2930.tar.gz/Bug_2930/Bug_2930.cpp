#include <vector>

#include "ace/OS_main.h"
#if defined (ACE_HAS_WINCE)
#  include "ace/ACE.h"
#endif /* ACE_HAS_WINCE */
#include "ace/ARGV.h"
#include "ace/OS.h"
#include "ace/Get_Opt.h"


void ace_getopt(std::vector < ACE_TCHAR > & r_unrecognized)
{
  ACE_ARGV args;
  args.add("dummy");
  args.add("-badflags");
  args.add("-c");
  
  int argc= args.argc();
  ACE_TCHAR ** argv = args.argv();
  
  // parse cmdline options
  ACE_Get_Opt cmdOpts(
    argc,
    argv,
    ":hvc:"
  );
  
  int option;
  while((option = cmdOpts()) != EOF)
  {
    switch (option)
    {
      case 'h':
        break;
      case 'v':
        break;
      case 'c':
          ACE_DEBUG((
            LM_DEBUG,
            ACE_TEXT ("optarg='%s'\n"),
            cmdOpts.opt_arg()
          ));
        break;
      case ':':
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("option '%c' needs an argument\n"),
          cmdOpts.opt_opt()
        ));
        break;
      case '\?':
      default:
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("unknown arg '%c'\n"),
          cmdOpts.opt_opt()
        ));
        r_unrecognized.push_back(cmdOpts.opt_opt());
        break;
    } /* end of switch */
  } /* end of while */
}


void posix_getopt(std::vector < ACE_TCHAR > & r_unrecognized)
{
  ACE_ARGV args;
  args.add("dummy");
  args.add("-badflags");
  args.add("-c");
  
  int argc= args.argc();
  ACE_TCHAR ** argv = args.argv();
  
  int option;
  while ((option = getopt(argc, argv, ":hvc:")) != -1)
  {
    switch (option)
    {
      case 'h':
        break;
      case 'v':
        break;
      case 'c':
          ACE_DEBUG((
            LM_DEBUG,
            ACE_TEXT ("optarg='%s'\n"),
            optarg
          ));
        break;
      case ':':
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("option '%c' needs an argument\n"),
          optopt
        ));
        break;
      case '\?':
      default:
        ACE_DEBUG((
          LM_DEBUG,
          ACE_TEXT ("unknown arg '%c'\n"),
          optopt
        ));
        r_unrecognized.push_back(optopt);
        break;
    } /* end of switch */
  }
}


int
ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  ACE_UNUSED_ARG(argc);
  ACE_UNUSED_ARG(argv);
  
  std::vector < ACE_TCHAR > unrecognized_ace;
  std::vector < ACE_TCHAR > unrecognized_posix;
  
  ace_getopt(unrecognized_ace);
  posix_getopt(unrecognized_posix);
  ACE_DEBUG((
    LM_DEBUG,
    ACE_TEXT ("unrecognized_ace.size() '%d'\n"),
    unrecognized_ace.size()
  ));
  ACE_DEBUG((
    LM_DEBUG,
    ACE_TEXT ("unrecognized_posix.size() '%d'\n"),
    unrecognized_posix.size()
  ));
  
  int result = 0;
  if(unrecognized_posix.size() != unrecognized_ace.size())
  {
    ACE_DEBUG((
      LM_ERROR,
      ACE_TEXT ("Size differs\n")
    ));
    result = 1;
  }
  else
  {
    for (
      size_t idx = 0,
      max = std::min(unrecognized_posix.size(), unrecognized_ace.size());
      idx < max;
      ++idx
    )
    {
      if(unrecognized_posix[idx] != unrecognized_ace[idx])
      {
        ACE_DEBUG((
          LM_ERROR,
          ACE_TEXT ("Index %d differs\n"),
          idx
        ));
        result = 1;
        break;
      }
    } /* end of for */
  }
  
  return result;
}
