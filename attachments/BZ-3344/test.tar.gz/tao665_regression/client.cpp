// $Id: client.cpp,v 1.1.1.1 2008/03/11 15:47:49 vz Exp $
#include "TestC.h"
#include "ace/Get_Opt.h"

const char *ior = "file://test.ior";

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "k:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'k':
        ior = get_opts.optarg;
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-k <ior> "
                           "\n",
                           argv [0]),
                          -1);
      }

  // Indicates sucessful parsing of the command line
  return 0;
}

int
ACE_TMAIN (int argc, char *argv[])
{
  try
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "");

      if (parse_args (argc, argv) != 0)
        return 1;

      // Create factory.

      // Obtain reference to the server object
      CORBA::Object_var tmp =
        orb->string_to_object (ior);

      Test::XYZ_var test =
        Test::XYZ::_narrow (tmp.in ());

      if (CORBA::is_nil (test.in ()))
      {
        ACE_ERROR_RETURN ((LM_DEBUG,
                           "Nil OBV_FactoryTest::Test reference <%s>\n",
                           ior),
                          1);
      }

      Test::C_var c_value = new OBV_Test::C ();
      c_value->l (10L);
      Test::B_var b_struct = new Test::B ();
      b_struct->s = 1;
      b_struct->c_value = c_value;
      Test::A_var a_value = new OBV_Test::A ();
      a_value->b_struct (b_struct.in ());

      // Send the value type to the server
      try
        {
          test->foo (a_value);
          ACE_DEBUG ((LM_DEBUG,
                      "Value type successfully sent to server from client !!\n"));
        }
      catch (const CORBA::MARSHAL &)
        {
          ACE_DEBUG ((LM_DEBUG,
                      "CORBA::MARSHAL was thrown to client as expected !!\n"));
        }

      test->shutdown ();

      orb->destroy ();
    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("Exception caught in client:");
      return 1;
    }

  return 0;
}
