#include "XYZImpl.h"

XYZImpl::XYZImpl (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

void
XYZImpl::foo (Test::A *)
{
  ACE_DEBUG((LM_DEBUG, "Success ! Value type containing nil object ref received from client !!\n"));
}

void
XYZImpl::shutdown (void)
{
  this->orb_->shutdown ();
}
