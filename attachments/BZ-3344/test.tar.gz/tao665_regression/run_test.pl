eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
     & eval 'exec perl -S $0 $argv:q'
     if 0;

# -*- perl -*-
# $Id: run_test.pl,v 1.1.1.1 2008/03/11 15:47:49 vz Exp $

use lib "$ENV{'ACE_ROOT'}/bin";
use PerlACE::Run_Test;

# The server IOR file
$server_ior_file = PerlACE::LocalFile ("server.ior");
unlink $server_ior_file;

# The client and server processes
$SERVER = new PerlACE::Process (PerlACE::LocalFile ("server"), "-o $server_ior_file");
$CLIENT = new PerlACE::Process (PerlACE::LocalFile ("client"), "-k file://$server_ior_file");

# Fire up the server
$SERVER->Spawn ();

# We can wait on the IOR file
if (PerlACE::waitforfile_timed ($server_ior_file, 15) == -1) {
   print STDERR "ERROR: cannot find $server_ior_file\n";
   $SERVER->Kill();
   exit 1;
}

$CLIENT->SpawnWaitKill (30);

# Clean up and return
$SERVER->TerminateWaitKill (5);

unlink $server_ior_file;

exit 0;
