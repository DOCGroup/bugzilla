#include "TestS.h"

class XYZImpl : public POA_Test::XYZ
{
public:
  XYZImpl (CORBA::ORB_ptr orb);

  virtual void foo (Test::A *a_value);

  virtual void shutdown (void);

private:
  CORBA::ORB_var orb_;
};
