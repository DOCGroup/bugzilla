#include "tao/Corba.h"
#include "tao/IFR_Client/IFR_BasicC.h"

void list_interface(CORBA::InterfaceDef_var the_interface)
{ 
  CORBA::ContainedSeq_var operations = the_interface->contents (CORBA::dk_Operation,
                                                                0  
                                                                ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;
  
  // There could be many :-(
  CORBA::ULong n_operations = operations->length ();
  ACE_DEBUG ((LM_DEBUG, "... it has %d operations on it.\n", n_operations));
  
  // List the operations
  CORBA::String_var operation_name;
  for (CORBA::ULong i = 0; i < n_operations; ++i)
    {
      operation_name = operations[i]->name (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
      ACE_DEBUG ((LM_DEBUG, "Operation %d is called: %s\n", (i + 1), operation_name));
    }
}

int main(int argc, char** argv)
{   
  ACE_TRY
  {
    // Get the repository
    CORBA::ORB_var orb = CORBA::ORB_init (argc, argv, 0);
    ACE_TRY_CHECK;
    CORBA::Object_var object =
    orb->resolve_initial_references ("InterfaceRepository" ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;
    CORBA::Repository_var repo = CORBA::Repository::_narrow (object.in ()
                                  ACE_ENV_ARG_PARAMETER);
    
    ACE_TRY_CHECK;
    
    // Get the interface(s) contained at the top level in the repo
    CORBA::ContainedSeq_var interfaces = repo->contents (CORBA::dk_Interface,
                                                          1    
                                                          ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;
    
    // This will be 1...
    CORBA::ULong n_interfaces = interfaces->length();
    ACE_TRY_CHECK;
    CORBA::ULong ZERO = 0;
    CORBA::String_var name = interfaces[ZERO]->name (ACE_ENV_SINGLE_ARG_PARAMETER);
    ACE_TRY_CHECK;
    
    // Prove it
    ACE_DEBUG ((LM_DEBUG, "There is %d interface called: %s at the top level of the repository...\n", n_interfaces, name));
    
    list_interface(CORBA::InterfaceDef::_narrow (interfaces[ZERO].in () ACE_ENV_ARG_PARAMETER));
    ACE_TRY_CHECK;
    
    // Get the module at the top level
    CORBA::ContainedSeq_var modules = repo->contents (CORBA::dk_Module,
                                                      1    
                                                      ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;

    CORBA::ModuleDef_var the_module = CORBA::ModuleDef::_narrow (modules[ZERO].in () ACE_ENV_ARG_PARAMETER);

    // Confirm there's only one
    ACE_DEBUG ((LM_DEBUG, "There is %d module called: %s at the top level of the repository...\n", 
                          modules->length(), 
                          modules[ZERO]->name(ACE_ENV_SINGLE_ARG_PARAMETER)));
    ACE_TRY_CHECK;
    
    // Get the interface off the module
    interfaces = the_module->contents (CORBA::dk_Interface,
                                       1    
                                       ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;
    
    // This will be 1...
    n_interfaces = interfaces->length();
    ACE_TRY_CHECK;
    name = interfaces[ZERO]->name (ACE_ENV_SINGLE_ARG_PARAMETER);
    ACE_TRY_CHECK;
    
    // Prove it
    ACE_DEBUG ((LM_DEBUG, "There is %d interface called: %s under the module called: %s...\n", 
                            n_interfaces, 
                            name, 
                            modules[ZERO]->name(ACE_ENV_SINGLE_ARG_PARAMETER)));
    ACE_TRY_CHECK;
    
    list_interface(CORBA::InterfaceDef::_narrow (interfaces[ZERO].in () ACE_ENV_ARG_PARAMETER));
    ACE_TRY_CHECK;


  }
  ACE_CATCHANY
  {
    ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
    return 1;
  }
  ACE_ENDTRY;
  return 0;
}


   