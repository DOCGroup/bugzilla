#include "MyServantLocator.h"
#include "test_i.h"

MyServantLocator::MyServantLocator()
	: _failed (false)
{
}

PortableServer::Servant MyServantLocator::preinvoke (
	const PortableServer::ObjectId& /*oid*/,
	PortableServer::POA_ptr /*adapter*/,
	const char* /*operation*/, void*& /*cookie*/)
	ACE_THROW_SPEC((CORBA::SystemException,
			PortableServer::ForwardRequest))
{
	ACE_DEBUG ((LM_DEBUG,
		    "MyServantLocator::preinvoke()\n"));
	throw CORBA::OBJECT_NOT_EXIST();
}

void MyServantLocator::postinvoke (
	const PortableServer::ObjectId& /*oid*/,
	PortableServer::POA_ptr /*adapter*/,
	const char* /*operation*/,
	PortableServer::ServantLocator::Cookie /*the_cookie*/,
	PortableServer::Servant the_servant)
	ACE_THROW_SPEC ((CORBA::SystemException))
{
	if (!the_servant)
	{
	    ACE_DEBUG((
		LM_DEBUG,
		"ERROR: MyServantLocator::postinvoke(), the_servant==0\n"));
	    _failed = true;
	}
	else
	{
	    ACE_DEBUG((LM_DEBUG,
		       "MyServantLocator::postinvoke(), the_servant==%@\n",
		       the_servant));
	    the_servant->_remove_ref();
	}
}

bool MyServantLocator::addServant (const char* oid,
				   PortableServer::Servant servant)
{
	Children::iterator it = _children.find (oid);
	if (it != _children.end())
	{
		return false;
	}
	_children[oid] = servant;
	servant->_add_ref();
	return true;
}

void MyServantLocator::removeServant (const char* oid)
{
	ACE_DEBUG ((LM_DEBUG, "MyServantLocator> executing removeServant()\n"));
	Children::iterator it = _children.find (oid);
	if (it != _children.end())
	{
		it->second->_remove_ref ();
		_children.erase (it);
	}
}
