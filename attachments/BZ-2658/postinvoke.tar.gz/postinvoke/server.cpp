#include <iostream>
#include "MyServantLocator.h"
#include "test_i.h"

/// Execute the test case
/// @return false if test passes, true if fails
bool invoke_ops (CORBA::Object_ptr obj, MyServantLocator* servantLocator)
{
	MyFactory_var factory = MyFactory::_narrow (obj);
	MyServer_var server = factory->createObject("my_object_id");
	//server->ping();

	//servantLocator->removeServant ("my_object_id");
	try
	{
		server->ping();
	}
	catch (CORBA::OBJECT_NOT_EXIST&)
	{
		ACE_DEBUG ((LM_DEBUG, "Caught OBJECT_NOT_EXIST\n"));
	}
	return servantLocator->failed();
}

int main (int argc, char* argv[])
{
	CORBA::ORB_var orb = CORBA::ORB_init (argc, argv, "myorb");

	CORBA::Object_var root_poa_o =
		orb->resolve_initial_references ("RootPOA");
	PortableServer::POA_var rootPoa =
		PortableServer::POA::_narrow (root_poa_o.in ());
	if (CORBA::is_nil (rootPoa.in()))
	{
		return -1;
	}
	PortableServer::POAManager_var poaMgr =
		rootPoa->the_POAManager ();
	poaMgr->activate ();

	CORBA::PolicyList policies (5);
	policies.length (3);
	policies[0] = rootPoa->create_id_assignment_policy (
		PortableServer::USER_ID);
	policies[1] = rootPoa->create_implicit_activation_policy (
		PortableServer::NO_IMPLICIT_ACTIVATION);
	policies[2] = rootPoa->create_lifespan_policy (
		PortableServer::PERSISTENT);

	PortableServer::POA_var factoryPoa = rootPoa->create_POA (
		"Factory_POA", poaMgr.in (), policies);

	// for MyServer objects, keep default TRANSIENT
	policies[2]->destroy ();
	policies.length (5);
	policies[2] = rootPoa->create_lifespan_policy (
		PortableServer::TRANSIENT);
	policies[3] = rootPoa->create_servant_retention_policy (
		PortableServer::NON_RETAIN);
	policies[4] = rootPoa->create_request_processing_policy (
		PortableServer::USE_SERVANT_MANAGER);
	PortableServer::POA_var vmsPoa = factoryPoa->create_POA (
		"Server_POA", poaMgr.in(), policies);

	for (CORBA::ULong i = 0; i < policies.length (); ++i)
	{
		policies[i]->destroy ();
	}

	MyServantLocator* servantLocator = new MyServantLocator;
	vmsPoa->set_servant_manager (servantLocator);

	MyFactory_i* factoryServant = new MyFactory_i (
		vmsPoa.in (), servantLocator);

	PortableServer::ObjectId_var id =
		PortableServer::string_to_ObjectId ("factory_id");

	factoryPoa->activate_object_with_id (id.in(), factoryServant);

	CORBA::Object_var obj = factoryPoa->id_to_reference (id.in ());
	CORBA::String_var str = orb->object_to_string (obj.in ());
	std::cout << str << std::endl;

	poaMgr->activate ();

	bool failed = invoke_ops (obj.in(), servantLocator);
	if (failed)
	{
		std::cerr << "FAILED: postinvoke with the_servant==0"
			  << std::endl;
	}
	return failed;
}
