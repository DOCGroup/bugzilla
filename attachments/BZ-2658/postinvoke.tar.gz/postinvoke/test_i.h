#ifndef _test_i_h
#define _test_i_h

#include "testS.h"

class MyServantLocator;

class MyServer_i : public POA_MyServer
{
public:
	MyServer_i ();

	void ping (ACE_ENV_SINGLE_ARG_DECL_NOT_USED)
		ACE_THROW_SPEC ((CORBA::SystemException));

private:
	CORBA::ORB_var orb_;
	CORBA::String_var _key;
};

class MyFactory_i : public POA_MyFactory
{
public:
	MyFactory_i (PortableServer::POA_ptr childrenPoa,
		     MyServantLocator* servantLocator);
	MyServer_ptr createObject (const char* str_oid)
		ACE_THROW_SPEC ((CORBA::SystemException));

private:
	PortableServer::POA_var _childrenPoa;
	MyServantLocator* _servantLocator;
};

#endif
