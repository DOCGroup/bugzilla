#include "test_i.h"
#include "MyServantLocator.h"


MyServer_i::MyServer_i ()
{
}

void MyServer_i::ping (ACE_ENV_SINGLE_ARG_DECL_NOT_USED)
	ACE_THROW_SPEC ((CORBA::SystemException))
{
	ACE_DEBUG ((LM_DEBUG, "MyServer_i> executing ping()\n"));
}

MyFactory_i::MyFactory_i (PortableServer::POA_ptr childrenPoa,
			  MyServantLocator* servantLocator)
	: _childrenPoa (childrenPoa)
	, _servantLocator (servantLocator)
{
}

MyServer_ptr MyFactory_i::createObject (const char* str_oid)
	ACE_THROW_SPEC ((CORBA::SystemException))
{
	ACE_DEBUG ((LM_DEBUG, "MyFactory_i> executing createServer()\n"));
	MyServer_i* vms = new MyServer_i();;
	// line bellow makes sure we call _remove_ref when we scope out
	PortableServer::ServantBase_var servant (vms);

	PortableServer::ObjectId_var oid =
		PortableServer::string_to_ObjectId (str_oid);

	CORBA::Object_var vms_o =
		_childrenPoa->create_reference_with_id (
			oid.in(),
			"IDL:MyServer:1.0");
	MyServer_var ref = MyServer::_narrow (vms_o.in());

	_servantLocator->addServant (str_oid, vms);
	return ref._retn();
}

