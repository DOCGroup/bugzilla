#ifndef _MyServantLocator_h
#define _MyServantLocator_h

#include <string>
#include <map>
#include <tao/PortableServer/PortableServer.h>
#include <tao/PortableServer/ServantLocatorC.h>

class MyServantLocator : public virtual PortableServer::ServantLocator
{
public:
	MyServantLocator ();

	PortableServer::Servant preinvoke (
		const PortableServer::ObjectId& oid,
		PortableServer::POA_ptr adapter,
		const char* operation,
		void*& cookie)
		ACE_THROW_SPEC((CORBA::SystemException,
				PortableServer::ForwardRequest));

	void postinvoke (
		const PortableServer::ObjectId & oid,
		PortableServer::POA_ptr adapter,
		const char* operation,
		PortableServer::ServantLocator::Cookie the_cookie,
		PortableServer::Servant the_servant)
		ACE_THROW_SPEC ((CORBA::SystemException));

	bool addServant (const char* oid, PortableServer::Servant servant);
	void removeServant (const char* oid);

	bool failed () const { return _failed; }
private:
	// Declared but not implemented.
	MyServantLocator (const MyServantLocator&);
	MyServantLocator& operator= (const MyServantLocator&);

	typedef std::map<std::string, PortableServer::Servant> Children;
	Children _children;

	bool _failed; // indicate if the test failed.
};

#endif
