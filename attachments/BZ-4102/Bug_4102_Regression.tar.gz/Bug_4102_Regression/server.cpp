
// $Id$

#include "ace/OS_NS_stdio.h"
#include "ace/OS_NS_unistd.h"
#include "TestS.h"

/***************************/
/*** Servant Declaration ***/

class Foo_AMH_Servant
  : public virtual POA_Test::AMH_Foo
{
public:
  Foo_AMH_Servant (CORBA::ORB_ptr orb);

  void description (Test::AMH_FooResponseHandler_ptr, const char *);
  void description (Test::AMH_FooResponseHandler_ptr);
  void shutdown    (Test::AMH_FooResponseHandler_ptr);
  void _cxx_export (Test::AMH_FooResponseHandler_ptr) {}
  void _cxx_class  (Test::AMH_FooResponseHandler_ptr, const char *) {}
  void _cxx_class  (Test::AMH_FooResponseHandler_ptr) {}

protected:
  CORBA::ORB_var orb_;
  CORBA::String_var desc_;
};


/***************************/
/*** Servant Definition ***/
Foo_AMH_Servant::Foo_AMH_Servant (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb)), desc_("")
{
}

void Foo_AMH_Servant::description (Test::AMH_FooResponseHandler_ptr handler,
                                   const char * desc)
{
  desc_ = CORBA::string_dup(desc);
  handler->set_description();
}

void Foo_AMH_Servant::description (Test::AMH_FooResponseHandler_ptr handler)
{
  handler->get_description(desc_.in());
}

void
Foo_AMH_Servant::shutdown (Test::AMH_FooResponseHandler_ptr)
{
  orb_->shutdown();
}


int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  try
    {
      CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA");

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in ());

      Foo_AMH_Servant* servant = new Foo_AMH_Servant(orb.in());
      Test::Foo_var foo = servant->_this();

      PortableServer::POAManager_var mgr = root_poa->the_POAManager();
      mgr->activate();

      CORBA::String_var ior =
        orb->object_to_string (foo.in ());

      FILE *output_file= ACE_OS::fopen ("test.ior", "w");
      if (output_file == 0)
        {
          ACE_ERROR ((LM_ERROR,
                      "Cannot open <test.ior> for writing IOR."));
          return -1;
        }

      ACE_OS::fprintf (output_file, "%s", ior.in ());
      ACE_OS::fclose (output_file);

      orb->run();
      orb->destroy();

    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("Exception caught:");
      return 1;
    }

  return 0;
}
