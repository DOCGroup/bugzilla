// $Id$

#include "TestC.h"
#include "ace/OS_NS_unistd.h"

const ACE_TCHAR *ior = ACE_TEXT("file://test.ior");

int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  int retval = 0;
  try
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv);

      CORBA::Object_var object =
        orb->string_to_object (ior);

      Test::Foo_var foo =
        Test::Foo::_narrow (object.in ());

      if (CORBA::is_nil (foo.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Nil Test::Foo reference <%s>\n",
                             ior),
                            1);
        }

      const char * msg = "Hello World";
      foo->description(msg);
      CORBA::String_var str = foo->description();
      retval = ACE_OS::strcmp(str.in(), msg);

      foo->shutdown();
      orb->destroy();
    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("");
      return 1;
    }

  return retval;
}
