// -*- C++ -*-
// $Id: Echo_i.h,v 1.8 2001/03/12 18:42:55 bala Exp $

// ============================================================================
//
// = LIBRARY
//    TAO/tests/Simple/echo
//
// = FILENAME
//    Echo_i.h
//
// = DESCRIPTION
//    This class implements the Echo IDL interface.
//
// = AUTHOR
//    Kirthika Parameswaran <kirthika@cs.wustl.edu>
//
// ============================================================================

#ifndef ECHO_I_H
#define ECHO_I_H

#include "EchoS.h"
#include "ace/Message_Queue.h"

class Echo_i : public POA_Echo
{
  // = TITLE
  //    Echo Object Implementation
  //
  // = DESCRIPTION
  //    The object implementation  performs teh following functions:
  //   -- To return the string which needs to be displayed
  //      from the server.
  //   -- shuts down the server
public:
  // = Initialization and termination methods.
  Echo_i (void);
  // Constructor.

  Echo_i (Echo_i &);
  // Copy constructor for old gcc.

  ~Echo_i (void);
  // Destructor.

  virtual Echo::List *echo_list (const char *mesg,
                                 CORBA::Environment &env)
    ACE_THROW_SPEC ((CORBA::SystemException));
  // Return the mesg string back from the server.

  virtual void echo_string (const Echo::tableOctetSeq & message,
							CORBA::Environment &ACE_TRY_ENV)
    ACE_THROW_SPEC ((CORBA::SystemException));
  // Return the mesg string back from the server.

 virtual void shutdown (CORBA::Environment &env)
   ACE_THROW_SPEC ((CORBA::SystemException));
  // Shutdown the server.

  void orb (CORBA::ORB_ptr o);
  // Set the ORB pointer.

  short Echo_i::recv(void);

private:
  CORBA::ORB_var orb_;
  // ORB pointer.

  ACE_Message_Queue<ACE_MT_SYNCH> *messageQueue;


  ACE_UNIMPLEMENTED_FUNC (void operator= (const Echo_i&))
  // Keeping g++ 2.7.2 happy..
};

#endif /* ECHO_I_H */
