//$Id: client.cpp,v 1.3 1999/02/11 23:29:11 bala Exp $

# include "Echo_Client_i.h"


// Artificial cpu-consuming thread
/*void miamThread(void* ptr) {
	ACE_DEBUG((LM_TRACE, "=> miamThread"));
	long counter = 0;

	for (;;) {
		counter++;
		ACE_OS::sleep(ACE_Time_Value(1));
	};

	ACE_DEBUG((LM_TRACE, "<= miamThread"));
};*/

// The client program for the application.

int
main (int argc, char **argv)
{
  Echo_Client_i client;
  

  ACE_DEBUG ((LM_DEBUG,
              "\nEcho client\n\n"));

	//Starting articifial cpu-consuming thread
	//ACE_Thread::spawn((ACE_THR_FUNC) miamThread, NULL);


  if (client.run ("Echo",
                  argc, 
                  argv) == -1)
    return -1; 
  else
    return 0;
   
}

                                 
