//$Id: Echo_Client_i.cpp,v 1.4 1999/06/07 17:43:17 schmidt Exp $

#include "Echo_Client_i.h"
#include "ace/Get_Opt.h"
#include "ace/Read_Buffer.h"

// This is the interface program that accesses the remote object

// Constructor.
Echo_Client_i::Echo_Client_i (void)
{
  //no-op
}

//Destructor.
Echo_Client_i::~Echo_Client_i (void)
{
  //no-op
}

int
Echo_Client_i::run (const char *name,
                    int argc,
                    char *argv[])
{
  // Initialize the client.
  if (client.init (name,argc, argv) == -1)
    return -1;

  ACE_DECLARE_NEW_CORBA_ENV;

  ACE_TRY
    {
      Echo::tableOctetSeq test;
	  test.length(600);

      while (1)
        {
          
		  for (;;) {
			  client->echo_string (test, ACE_TRY_ENV);
			  ACE_TRY_CHECK;

			  ACE_DEBUG((LM_DEBUG, "*"));

			  ACE_OS::sleep(ACE_Time_Value(0, 40000));

		  }
			
        }

      if (client.shutdown () == 1)
        client->shutdown (ACE_TRY_ENV);
      
      ACE_TRY_CHECK;
       
    }
  ACE_CATCHANY 
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,"\n Exception in RMI");
      return -1;
    }
  ACE_ENDTRY;
  ACE_CHECK_RETURN (-1);

  return 0;
}


#if defined (ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION)
template class Client<Echo,Echo_var>;
#elif defined (ACE_HAS_TEMPLATE_INSTANTIATION_PRAGMA)
#pragma instantiate Client<Echo,Echo_var>
#endif /* ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION */
