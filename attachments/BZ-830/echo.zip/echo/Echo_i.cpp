// $Id: Echo_i.cpp,v 1.19 2001/03/12 20:09:53 coryan Exp $
//#define ACE_NLOGGING

#include "Echo_i.h"


ACE_RCSID(Echo, Echo_i, "$Id: Echo_i.cpp,v 1.19 2001/03/12 20:09:53 coryan Exp $")

// Constructor.

Echo_i::Echo_i (void)
{
	//Creation of a message queue
	messageQueue = new ACE_Message_Queue<ACE_MT_SYNCH>(100);
}

// Old g++ fooler.
Echo_i::Echo_i (Echo_i &foo)
  : POA_Echo (foo)
{
}

// Destructor.

Echo_i::~Echo_i (void)
{
	delete messageQueue;
}

// Set the ORB pointer.

void
Echo_i::orb (CORBA::ORB_ptr o)
{
  this->orb_ = CORBA::ORB::_duplicate (o);
}

// Return a list of object references.

Echo::List *
Echo_i::echo_list (const char *,
                   CORBA::Environment &ACE_TRY_ENV)
 ACE_THROW_SPEC ((CORBA::SystemException))
{
  Echo::List_var list;

  {
    Echo::List *tmp;
    ACE_NEW_RETURN (tmp,
                    Echo::List (3),
                    0);
    // Pass ownership to the _var, pitty that ACE_NEW_RETURN cannot
    // assign to T_vars directly.
    list = tmp;
  }

  list->length (3);

  // Just do something to get a list of object references.
  list[CORBA::ULong(0)] =
    orb_->resolve_initial_references ("NameService",
                                      ACE_TRY_ENV);
  ACE_CHECK_RETURN (0);

  list[CORBA::ULong(1)] =
    orb_->resolve_initial_references ("NameService",
                                      ACE_TRY_ENV);;
  ACE_CHECK_RETURN (0);

  list[CORBA::ULong(2)] =
    orb_->resolve_initial_references ("NameService",
                                      ACE_TRY_ENV);
  ACE_CHECK_RETURN (0);

  return list._retn ();
}

// Return the mesg string from the server
void Echo_i::echo_string (const Echo::tableOctetSeq & message,
							CORBA::Environment &ACE_TRY_ENV)
    ACE_THROW_SPEC ((CORBA::SystemException))
{

    ACE_DEBUG((LM_DEBUG, "*"));
	//copying message to avoid deref
	/*Echo::StructTest* messageCopy = new Echo::StructTest(message);

	//Enqueing message...
	//Building message bloc
	ACE_Message_Block* mb;
	mb = new ACE_Message_Block((char*) messageCopy, sizeof(messageCopy));
	
	if (!messageQueue->is_full()) {
		//Sending in the queue
		messageQueue->enqueue_prio(mb);
	}
	else {
		//Loss of messages !  Not good...
		cerr << "[L]";
	}
    ACE_DEBUG((LM_DEBUG, "-"));*/
}

// Shutdown the server application.

void
Echo_i::shutdown (CORBA::Environment &)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  ACE_DEBUG ((LM_DEBUG,
              "\n%s\n",
              "The echo server is shutting down"));

  // Instruct the ORB to shutdown.
  this->orb_->shutdown ();
}


// Reading messages in the queue
short Echo_i::recv(void) {
	//ACE_DEBUG((LM_TRACE,"=> Echo_i::recv\n"));
	
	ACE_Message_Block *mb;
	Echo::StructTest* rcvStructTest;
	short result;

	//Wait until something is in the queue
	messageQueue->dequeue(mb);
	rcvStructTest = (Echo::StructTest*) mb->rd_ptr();

	ACE_DEBUG((LM_DEBUG, "r"));
	result = rcvStructTest->s;

	//Cleaning up
	delete rcvStructTest;
	mb->release();

	//ACE_DEBUG((LM_TRACE,"<= Echo_i::recv\n"));
	return result;
}