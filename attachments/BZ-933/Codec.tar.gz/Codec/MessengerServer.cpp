
#include "Messenger_i.h"
#include <ace/streams.h>

int
main( int argc, char *argv[] )
{
  try {
    // Initialize orb
    CORBA::ORB_var orb = CORBA::ORB_init( argc, argv );

    //Get reference to Root POA
    CORBA::Object_var obj = orb->resolve_initial_references( "RootPOA" );
    PortableServer::POA_var poa = PortableServer::POA::_narrow( obj.in() );

    // Activate POA Manager
    PortableServer::POAManager_var mgr = poa->the_POAManager();
    mgr->activate();

    // Create an object
    Messenger_i messenger_servant;

    // Register the servant with the RootPOA, obtain its object
    // reference, stringify it, and write it to a file.
    PortableServer::ObjectId_var oid = 
      poa->activate_object( &messenger_servant );
    CORBA::Object_var messenger_obj = poa->id_to_reference( oid.in() );
    CORBA::String_var str = orb->object_to_string( messenger_obj.in() );
    ofstream iorFile( "Messenger.ior" );
    iorFile << str.in() << endl;
    iorFile.close();
    cout << "IOR written to file Messenger.ior" << endl;   

    // Accept requests
    orb->run();
    orb->destroy();
  }

  catch( const CORBA::Exception & ) {
    cerr << "Uncaught CORBA exception" << endl;
    return 1;
    }

  return 0;
}
