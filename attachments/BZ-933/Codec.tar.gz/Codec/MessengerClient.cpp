#include "MessengerC.h"
#include <ace/streams.h>

int
main( int argc, char *argv[] )
{
  try {
    // Initialize orb
    CORBA::ORB_var orb = CORBA::ORB_init( argc, argv );

    // Destringify ior
    CORBA::Object_var obj = orb->string_to_object( "file://Messenger.ior" );
    if( CORBA::is_nil( obj.in() ) ) {
      cerr << "Nil Messenger reference" << endl;
      throw 0;
      }

    // Narrow
    Messenger_var messenger = Messenger::_narrow( obj.in() );
    if( CORBA::is_nil( messenger.in() ) ) {
      cerr << "Argument is not a Messenger reference" << endl;
      throw 0;
      }

    // Obtain a reference to the CodecFactory.
    CORBA::Object_var obj2 =
    	orb->resolve_initial_references ("CodecFactory");

    IOP::CodecFactory_var codec_factory =
      IOP::CodecFactory::_narrow (obj2.in ());

    // Set up a structure that contains information necessary to
    // create a GIOP 1.2 CDR encapsulation Codec.
    IOP::Encoding encoding;
    encoding.format = IOP::ENCODING_CDR_ENCAPS;
    encoding.major_version = 1;
    encoding.minor_version = 2;

    // Obtain the CDR encapsulation Codec.
    IOP::Codec_var codec =
       codec_factory->create_codec (encoding);
    
	const char * user_name = "Ru";

    CORBA::Any user_name_as_any;
    user_name_as_any <<= user_name;

    CORBA::OctetSeq client_user_name = (*codec->encode (user_name_as_any))[0];
    
    messenger->send_message( client_user_name );
  }

  catch( const CORBA::SystemException &ex ) {
    cerr << "Caught CORBA exception: " << ex << endl;
    ex._tao_print_exception ("");
    return 1;
  }

  catch( ... ) {
    return 1;
  }

  cout << "message was sent" << endl;
  return 0;
}
