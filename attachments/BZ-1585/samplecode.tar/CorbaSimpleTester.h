/**
*@file
* little program for testing the module "BaseProcess" in connection with C++.
*/

#define CORBA_BASE_PROCESS_TESTER   "CorbaBasePrcTesterObj"
#define USE_NAME_SERVICE            0
#define REF_FILE_NAME               "ref.txt"
#define CLIENT_THREADS_TO_START     10
#define SERVER_THREADS_TO_START     10
