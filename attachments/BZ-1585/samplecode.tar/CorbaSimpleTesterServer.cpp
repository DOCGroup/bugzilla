/**
* CORBA server implementing one servant
*/

#include "CorbaSimpleTester.h"
#include "ace/ACE.h"
#include <list>
#include <iostream>

#include "tao/corba.h"
#include "tao/Version.h"
#include "orbsvcs/CosNamingC.h"


using std::string;
using std::list;

#include "mmsS.h"
#if !USE_NAME_SERVICE
#   include <fstream>
#endif

#include <memory>
#include "ace/Task.h"

class CCorbaBaseProcessTester_Impl : 
	public POA_Materna::BaseProcess::CorbaBaseProcessTester
{
public:
    CCorbaBaseProcessTester_Impl() {}

    /**
    * handle echo request with out-argument
    * @see "Advanced CORBA Programming with C++, p. 358
    */
    void handleEchoOutReq (CORBA::Long len, 
	  Materna::BaseProcess::Message_out message)
    {
	static int iCount = 0;
        message = new Materna::BaseProcess::Message;
        message->mPayload.length(len);
        printf("Thread %d called at %d\n", ACE_Thread::self(), ++iCount);
        ACE_OS::sleep(ACE_Time_Value(0, 200000));
    }
};

class CCorbaWorker : public ACE_Task<ACE_MT_SYNCH>
{
public:
    CCorbaWorker() {}
    CCorbaWorker(CORBA::ORB_ptr orb)
        : mOrb(CORBA::ORB::_duplicate(orb)) {}

    void Init(CORBA::ORB_ptr orb) { mOrb = CORBA::ORB::_duplicate(orb); }
    int svc(void) 
    { 
        printf("Thread %d started\n", ACE_Thread::self()); 
        mOrb->run(); 
        printf("Thread %d terminated\n", ACE_Thread::self()); 
        return 0; 
    }

private:
    CORBA::ORB_var mOrb;
};


int main(int argc, char* argv[])
{
    try
    {
        // Initialize the ORB
        CORBA::ORB_var mOrb = CORBA::ORB_init(
				argc 
				, argv 
				, CORBA_BASE_PROCESS_TESTER
				);

        if (CORBA::is_nil(mOrb.in()))
        {
            printf("ERROR: ORB init failed\n");
            return -1;
        }

#if USE_NAME_SERVICE
        // Get a reference to the Naming Service root context
        CORBA::Object_var helper_var = 
		mOrb->resolve_initial_references("NameService");
        if (CORBA::is_nil(helper_var.in()))
        {
            printf("ERROR: getting NameService failed\n");
            return -1;
        }
        
        CosNaming::NamingContext_var mRootNContext = 
		CosNaming::NamingContext::_narrow(helper_var.in());
        if (CORBA::is_nil(mRootNContext.in()))
        {
            printf("ERROR: narrowing NameService failed\n");
            return -1;
        }
#endif

        // Get a reference to the root POA
        CORBA::Object_var poa_obj = mOrb->resolve_initial_references("RootPOA");
        PortableServer::POA_var mRootPOA = 
		PortableServer::POA::_narrow(poa_obj.in());

        PortableServer::POAManager_var mRootPOAManager_var = 
		    mRootPOA->the_POAManager();
        mRootPOAManager_var->activate();

        // Register servant
        CCorbaBaseProcessTester_Impl* mpServerImpl = new CCorbaBaseProcessTester_Impl();

        // Create and initialize the name.
        CosNaming::Name nname;

        CORBA::Object_var object_var = mpServerImpl->_this();

#if USE_NAME_SERVICE
        nname.length(1);
        nname[0].id = CORBA::string_dup(CORBA_BASE_PROCESS_TESTER);

        try 
        {
            // Bind the object
            mRootNContext->bind(nname, object_var.in());
        }
        catch(const CosNaming::NamingContext::AlreadyBound&) 
        {
            printf("RegisterObject() caught AlreadyBound exception\n");
	    mRootNContext->rebind(nname, object_var.in());
        }
#else
	CORBA::String_var s = mOrb->object_to_string(object_var.in());
	ofstream out(REF_FILE_NAME);
	out << s << endl;
	out.close();
#endif

        // Start server threads
/*
        CCorbaWorker* mpWorkers = new CCorbaWorker[SERVER_THREADS_TO_START];
	for (int ii = 0; ii < SERVER_THREADS_TO_START; ++ii)
	{
            mpWorkers[ii].Init(mOrb.in());
	    int rc1 = mpWorkers[ii].activate(THR_NEW_LWP | THR_JOINABLE, 1);
	    if (rc1 != 0)
	    {
                printf("ERROR: could not start CORBA worker threads, rc = %d\n", rc1);
                return -1;
	    }
	}//for

	for (int i = 0; i < SERVER_THREADS_TO_START; ++i)
            mpWorkers[i].wait();
*/

        CCorbaWorker* mpWorker = new CCorbaWorker(mOrb.in());
        int rc = mpWorker->activate(THR_NEW_LWP | THR_JOINABLE, SERVER_THREADS_TO_START);
        if(rc != 0)
        {
            printf("ERROR: could not start CORBA worker threads, rc = %d\n", 
		rc);
            return -1;
        }

        mpWorker->wait();
    }
    catch (const CORBA::Exception& ) 
    {
        printf("ERROR: caught CORBA::Exception, NameService not running?\n");
        return -1;
    }
    catch (...) 
    {
        printf("ERROR: Unknown exception caught\n");
    }
    return 0;
}
