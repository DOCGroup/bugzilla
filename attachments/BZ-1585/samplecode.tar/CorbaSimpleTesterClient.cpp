/**
*@file
* little program for testing the module "BaseProcess" in connection with C++.
*/

#include "CorbaSimpleTester.h"
#if CLIENT_THREADS_TO_START > 1
#   include "ace/OS.h"
#endif
#include <list>
#include <string>
#include <map>
#if CLIENT_THREADS_TO_START > 1
#   include "ace/Task.h"
#endif

#include "tao/corba.h"
#include "orbsvcs/CosNamingC.h"
#include "tao/Messaging/Messaging.h"

using std::string;
using std::list;


#if !USE_NAME_SERVICE
#   include <fstream>
#endif
#include "mmsC.h"

void
sendRequests(Materna::BaseProcess::CorbaBaseProcessTester_ptr pServer)
{
    int i=0;
    while(true)
    {
        try
        {
	    Materna::BaseProcess::Message_var msgOut;
	    pServer->handleEchoOutReq(1024, msgOut);
        }
        catch(const CORBA::TIMEOUT&)
        {
	    printf("Thread %d, %d. CORBA TIMEOUT caught\n", ACE_Thread::self(), i++);
        }
        catch(const CORBA::Exception&)
        {
	    printf("Thread %d, CORBA Exception caught\n", ACE_Thread::self());
        }

	printf("Thread %d, successfully called server %d\n", ACE_Thread::self(), i++);
    }
}

#if CLIENT_THREADS_TO_START > 1
//
//  class CSenderTask
//
class CSenderTask : public ACE_Task<ACE_MT_SYNCH>
{
public:
    CSenderTask(Materna::BaseProcess::CorbaBaseProcessTester_ptr pServer)
        : mpServer(pServer)
	{}

    // call server's servant repeatedly
    int svc(void)
    {
	sendRequests(mpServer);	    
	return 0;
    }//svc

private:
    Materna::BaseProcess::CorbaBaseProcessTester_ptr mpServer;
};
#endif

//
//  main
//

int main(int argc, char** argv)
{
    char    **ppszArgv1 = new char*[argc+1];
    int     argc1 = argc;

    // Add muxing parameters to arguments
    memcpy(ppszArgv1, argv, sizeof(char*) * argc);

    ppszArgv1[argc1++] = "-ORBSvcConfDirective static Client_Strategy_Factory"
		   " \"-ORBTransportMuxStrategy EXCLUSIVE -ORBClientConnectionHandler RW\"";

    try
    {
        CORBA::ORB_var mOrb = CORBA::ORB_init(argc1
			, ppszArgv1
			, CORBA_BASE_PROCESS_TESTER
			);

        if (CORBA::is_nil(mOrb.in()))
        {
            printf("ERROR: ORB init failed\n");
            return -1;
        }

#if USE_NAME_SERVICE
        // Get a reference to the Naming Service root context
        CORBA::Object_var helper_var = mOrb->resolve_initial_references(
					    "NameService");
        if (CORBA::is_nil(helper_var.in()))
        {
            printf("ERROR: getting NameService failed\n");
            return -1;
        }
        
        CosNaming::NamingContext_var mRootNContext = 
			    CosNaming::NamingContext::_narrow(helper_var.in());
        if (CORBA::is_nil(mRootNContext.in()))
        {
            printf("ERROR: narrowing NameService failed\n");
            return -1;
        }

        // Get registered object
        CosNaming::Name nname;
        nname.length(1);
        nname[0].id = CORBA::string_dup(CORBA_BASE_PROCESS_TESTER);
        CORBA::Object_var obj = mRootNContext->resolve(nname);
        if (CORBA::is_nil(obj.in()))
        {
            printf("ERROR: getting server object\n");
            return -1;
        }
#else
	ifstream in(REF_FILE_NAME);
	char s[2048];
	in >> s;
        CORBA::Object_var obj = mOrb->string_to_object(s);
#endif
        printf("Got registered server object: %s\n", 
		    mOrb->object_to_string(obj.in()));

        // Narrow the reference
        Materna::BaseProcess::CorbaBaseProcessTester_var server_var = 
	    Materna::BaseProcess::CorbaBaseProcessTester::_narrow(obj._retn());
        if(CORBA::is_nil(server_var.in()))
        {
            printf("_narrow() got NULL object\n");
            return -1;
        }
        printf("Narrowing was successful\n");

        // Set CORBA invocation timeout to 100 msec, in order to force CORBA timeouts to occur
        try
        {
	    CORBA::PolicyManager_var policy_manager;
	    CORBA::PolicyList     policy_list;

	    // get the ORBPolicyManager object
	    CORBA::Object_var     object = mOrb->resolve_initial_references (
	   				"ORBPolicyManager");        

	    policy_manager =    CORBA::PolicyManager::_narrow (object.in());


	    // disable all default policies
	    policy_list.length (0);
	    policy_manager->set_policy_overrides ( 
	   		        policy_list, CORBA::SET_OVERRIDE );
	    
	    CORBA::Any  object_timeout;
 
	    // Set timeout        
	    TimeBase::TimeT timeout = 100; // 100 msec
	    timeout *= 10000;//TimeT has 100 nanosecond resolution
	    object_timeout <<= timeout;

	    // set the RelativeRoundtripTimeout policy
	    policy_list.length (1);
	    policy_list[0] = mOrb->create_policy (
				    Messaging::RELATIVE_RT_TIMEOUT_POLICY_TYPE, 
				    object_timeout );

	    policy_manager->set_policy_overrides ( 
				    policy_list, 
				    CORBA::SET_OVERRIDE );

            printf("Setting invocation timeout was successful\n");
        }
        catch(...)
        {
            printf("ERROR: Setting invocation timeout failed\n");
            return -1;
        }

#if CLIENT_THREADS_TO_START > 1
        // Create and start tasks
        CSenderTask* pSenderTask = new CSenderTask(server_var.in());
        pSenderTask->activate(THR_NEW_LWP, CLIENT_THREADS_TO_START);
        printf("Task creation was successful\n");
            
        // Wait for thread termination
        printf("waiting for thread-termination\n");
        pSenderTask->wait();
#else
	sendRequests(server_var.in());
#endif
        printf("successfully finished\n");
    }
    catch (const CORBA::Exception&) 
    {
        printf("ERROR: caught CORBA::Exception\n");
        return -1;
    }
    catch(...) {
        printf("ERROR: Unknown exception\n");
        return -1;
    }
}
