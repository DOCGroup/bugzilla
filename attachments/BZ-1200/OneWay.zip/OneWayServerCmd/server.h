#include "..\OneWayServer_s.hh"
#include "..\OneWayClient_c.hh"

#define MAX_CLIENTS 50

class OneWayServer: public POA_TestServer::OneWayTestServer
{
public:
	OneWayServer();
	virtual void register_Client(TestClient::OneWayTestClient_ptr _Client);
	void SendToClient();
	static UINT _TestThread( LPVOID pParam )
	{
		((OneWayServer*)pParam)->TestThread();
		return 0;
	};
	void TestThread();
protected:
	TestClient::OneWayTestClient_var	m_Client[MAX_CLIENTS];
};


