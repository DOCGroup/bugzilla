#include "server.h"

extern CORBA::ORB_var m_Orb;

void OneWayServer::register_Client(TestClient::OneWayTestClient_ptr Client)
{
	static int clientident = 0;
	try
	{
		m_Client[clientident] = TestClient::OneWayTestClient::_duplicate(Client);
		printf("Client connected.\n");
		clientident++;
		if ( clientident >= MAX_CLIENTS )
			clientident = 0;
	}
	catch(CORBA::Exception&)
	{
		printf("CORBA::Exception during connect.\n");
	}
}

void OneWayServer::SendToClient()
{
	static int Counter=0;
	Counter++;
	for (int i=0; i<MAX_CLIENTS; i++)
	{
		try
		{
			if ( ! CORBA::is_nil(m_Client[i]))
			{
				char msg[250];
				TestClient::a_seq_var my_seq;
				CORBA::Long a_long;

				sprintf(msg,"Send Message %u to %d",Counter,i);
				my_seq = m_Client[i]->CallTest(msg);
				printf("Send Message %u\r",Counter);
			}
			//	if (Counter%500 == 0)
			//		m_Client = NULL;
		}
		catch(CORBA::Exception& e)
		{
			printf("CORBA Excpetion on sending: %s\n",e._id());
			m_Client[i] = NULL;
		}
		catch(...)
		{
			printf("catch all\n");
			m_Client[i] = NULL;
		}
	}
}

OneWayServer::OneWayServer(): POA_TestServer::OneWayTestServer()
{
}

void OneWayServer::TestThread()
{
	for(;;)
	{
		::Sleep(1000);
		for (int i=0; i<MAX_CLIENTS; i++)
		{
			TestClient::OneWayTestClient_var client = m_Client[i]->_duplicate(m_Client[i]);
			if ( CORBA::is_nil(client) )
				continue;
			try
			{
				if ( client->_non_existent() )
					continue;
				printf("test successfull\n");
			}
			catch(CORBA::Exception& e)
			{
				printf("CORBA Excpetion on testing: %s\n",e._id());
				//m_Client = NULL;
			}
			catch(...)
			{
				printf("catch all on testing\n");
				//m_Client = NULL;
			}
		}
	}
}

int __cdecl _purecall(
        void
        )
{
	printf("Pure virtual function called. - Do nothing; that's OK !\n");
	return 0;
}
