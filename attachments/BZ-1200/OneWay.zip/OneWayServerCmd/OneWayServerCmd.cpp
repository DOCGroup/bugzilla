// OneWayServerCmd.cpp : Defines the entry point for the console application.
//
#include "server.h"
#include "time.h"
#include "conio.h"

CORBA::ORB_var m_Orb;
PortableServer::POA_var		rootPOA;
PortableServer::POA_var		poa;

OneWayServer* m_Server;

/* Pauses for a specified number of milliseconds. */
void sleep( clock_t wait )
{
#if 0
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() )
      ;
#else
	//::Sleep(wait);
    ACE_Time_Value tv (0, 1);
    m_Orb->run (tv);
#endif
}


int main(int argc, char* argv[])
{
	m_Orb = CORBA::ORB_init(argc,argv,"");
	
	CORBA::Object_var obj = m_Orb->resolve_initial_references("RootPOA");
	rootPOA = PortableServer::POA::_narrow(obj);

	m_Server = new OneWayServer();
	
	PortableServer::ObjectId_var serverId =
		rootPOA->activate_object(m_Server);

	printf("Ready on ORB\n");

	FILE *out = fopen("tao_OneWay.ior","w+");
	CORBA_String_var ior = m_Orb->object_to_string(m_Server->_this());
	fprintf(out,"%s",ior);
	fclose(out);

//	m_Server->_remove_ref();

	PortableServer::POAManager_var pman = rootPOA->the_POAManager();
	pman->activate();

	AfxBeginThread(m_Server->_TestThread,m_Server,THREAD_PRIORITY_NORMAL);

	for (;;)
	{
		sleep(20);
		m_Server->SendToClient();
		if (_kbhit())
			return 0;
	}

	m_Orb->destroy();
	return 0;
}
