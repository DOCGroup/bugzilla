#include "..\OneWayClient_s.hh"

class OneWayClient: public POA_TestClient::OneWayTestClient
{
public:
	OneWayClient();
	virtual TestClient::a_seq* CallTest(const char* Text);
};

