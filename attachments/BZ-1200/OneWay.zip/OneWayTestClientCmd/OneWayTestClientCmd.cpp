// OneWayTestClientCmd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "client.h"
#include "..\OneWayServer_c.hh"
#include "..\OneWayClient_s.hh"
#include "time.h"
#include "conio.h"

CORBA::ORB_var  m_Orb;
PortableServer::POA_var		rootPOA;
PortableServer::POA_var		poa;

TestServer::OneWayTestServer_var	m_Server;
OneWayClient*       m_Client;

/* Pauses for a specified number of milliseconds. */
void sleep( clock_t wait )
{
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() )
      ;
}

int main(int argc, char* argv[])
{
	m_Orb = CORBA::ORB_init(argc,argv,"");
	
	CORBA::Object_var obj = m_Orb->resolve_initial_references("RootPOA");
	rootPOA = PortableServer::POA::_narrow(obj);

	FILE *in = fopen("tao_OneWay.ior","r");
	char ior[2000];
	fscanf(in,"%s",ior);
	{
		obj = m_Orb->string_to_object(ior);
		m_Server = TestServer::OneWayTestServer::_narrow(obj);
	}
	fclose(in);

	if (CORBA::is_nil(m_Server))
	{
		return 1;
	}

	m_Client = new OneWayClient();

	PortableServer::ObjectId_var clientId =
		rootPOA->activate_object(m_Client);
//	m_Client->_remove_ref();
	
	PortableServer::POAManager_var pman = rootPOA->the_POAManager();
	pman->activate();

	try
	{
		TestClient::OneWayTestClient_var foo = m_Client->_this ();
		//if ( !m_Server->_non_existent() )
			m_Server->register_Client (foo.in ());
	}
	catch(CORBA::Exception& e)
	{
		printf("CORBA Exception on register: %s\n",e._id());
	}
	catch(...)
	{
		printf("general Exception on register\n");
	}
	printf("Ready - ORB is running\n");

	//ACE_Time_Value tv(10,0);
	//m_Orb->run(tv);
	//::Sleep(10000);
	//char*p=NULL;
	//(*p)++;
	m_Orb->run();
	m_Orb->destroy();

	return 0;
}
