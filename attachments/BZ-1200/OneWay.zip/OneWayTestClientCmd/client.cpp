#include "client.h"

TestClient::a_seq* OneWayClient::CallTest(const char* Text)
{
	TestClient::a_seq_var my_seq = new TestClient::a_seq;
	my_seq->length(0);
	printf("%s\r",Text);

	return my_seq._retn();
}

OneWayClient::OneWayClient()
{
}

