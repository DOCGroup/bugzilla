tao_imr -ORBInitRef ImplRepoService=corbaloc::localhost:7000/ImplRepoService add Test -c "imr_server.exe -ORBUseIMR 1"
