#include <tao\corba.h>
#include <tao\PortableServer\POA.h>
#include <iostream>
#include <string>
#include "IMR_TestS.h"

class Test_impl : public POA_IMRTest::Test
{
public:
  void ping();
};

void 
Test_impl::ping()
{ 
  std::cout << "Test_impl::ping()" << std::endl; 
}

int 
main(int argc, char* argv[])
{
  CORBA::Object_var obj;

  try {    
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

    // Create Test POA under root POA

    obj = orb->resolve_initial_references("RootPOA");
    PortableServer::POA_var rootPOA = PortableServer::POA::_narrow(obj.in());
    PortableServer::POAManager_var poaMgr = rootPOA->the_POAManager();
    poaMgr->activate();

    PortableServer::LifespanPolicy_var lifespan = 
      rootPOA->create_lifespan_policy(PortableServer::PERSISTENT);
    PortableServer::IdAssignmentPolicy_var id_assign = 
      rootPOA->create_id_assignment_policy(PortableServer::USER_ID);

    CORBA::PolicyList policies;
    policies.length(2);
    policies[0] = PortableServer::LifespanPolicy::_duplicate(lifespan);
    policies[1] = PortableServer::IdAssignmentPolicy::_duplicate(id_assign);
    PortableServer::POA_var testPOA = rootPOA->create_POA("Test", poaMgr.in(), policies);

    lifespan->destroy();
    id_assign->destroy();

    // start implementation 

    Test_impl testImpl;

    PortableServer::ObjectId_var oid = PortableServer::string_to_ObjectId("TestObject");
    testPOA->activate_object_with_id(oid.in(), &testImpl);
    obj = testPOA->servant_to_reference(&testImpl);

    CORBA::String_var ior = orb->object_to_string(obj);
    ofstream iorFile("server.ior");
    if (iorFile) {
      iorFile << ior.in();
      iorFile.close();
    } else {
      std::cerr << "Could not open file: server.ior" << std::endl;
      exit(1);
    }

    orb->run();

  } catch (const CORBA::Exception& ex) {
    std::cout << ex << std::endl;
    exit(1);
  }

  return 0;
}
