
To build the example, run "make.bat".

Once built, start the IMR by running "imr.bat" then set-up the IMR by running "setup_imr.bat".

Then generate the IMRified IOR by running the server:

imr_server -ORBInitRef ImplRepoService=corbaloc::localhost:7000/ImplRepoService -ORBUseIMR 1

which creates the server.ior file.

Terminate the server and then run the client as follows:

imr_client file://server.ior

Hit any key to contact the activated server.

Shutdown the activated server using:

tao_imr -ORBInitRef ImplRepoService=corbaloc::localhost:7000/ImplRepoService shutdown Test

Then use the running client to attempt a call on the server - a CORBA::COMM_FAILURE should
result from the first attempt, then the server should re-activate after that.

If you retry the test but shutdown the server by killing its process, the server will
reactivate first time with no exception.
