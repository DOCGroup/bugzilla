#include <tao\corba.h>
#include <tao\PortableServer\POA.h>
#include <iostream>
#include "IMR_TestC.h"

int 
main(int argc, char* argv[])
{
  try {
    
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

    if (argc < 2) {
      std::cerr << "Usage: imr_client [ior]" << std::endl;
      exit(1);
    }

    CORBA::Object_var obj = orb->string_to_object(argv[1]);
    IMRTest::Test_var test = IMRTest::Test::_narrow(obj);

    if (CORBA::is_nil(test)) {
      std::cerr << "Supplied IOR does not narrow to IMRTest::Test" << std::endl;
      exit(1);
    }


    char key;

    do {
      std::cout << "Press any key to call ping(), 'q' to quit" << std::endl;
      key = getchar();
      if (key != 'q') {
        try {
          std::cout << "Calling ping() ... ";
          test->ping();
          std::cout << "called." << std::endl;
        } catch (const CORBA::Exception& ex) {
          std::cerr << "exception: " << ex << std::endl;
        }
      }
    } while (key != 'q');

  } catch (const CORBA::Exception& ex) {
    std::cerr << ex << std::endl;
    exit(1);
  }

  return 0;
}
