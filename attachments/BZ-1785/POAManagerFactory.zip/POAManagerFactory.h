// -*- C++ -*-

//=============================================================================
/**
 *  @file    POAManagerFactory.h
 *
 *  $Id: POAManager.h,v 1.16 2005/02/18 09:07:12 jwillemsen Exp $
 *
 *   POAManagerFactory
 *
 *  @author  Johnny Willemsen  <jwillemsen@remedy.nl>
 */
//=============================================================================

#ifndef TAO_POAMANAGERFACTORY_H
#define TAO_POAMANAGERFACTORY_H
#include /**/ "ace/pre.h"

#include "portableserver_export.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#include "POAManagerFactoryC.h"
#include "Object_Adapter.h"
#include "tao/LocalObject.h"
#include "ace/Unbounded_Set.h"

// This is to remove "inherits via dominance" warnings from MSVC.
// MSVC is being a little too paranoid.
#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4250)
#endif /* _MSC_VER */

namespace TAO
{
  namespace Portable_Server
  {
    class TAO_PortableServer_Export POAManager_Factory :
      public ::PortableServer::POAManagerFactory,
      public TAO_Local_RefCounted_Object
    {
    public:
      POAManager_Factory (TAO_Object_Adapter &object_adapter);

      virtual ~POAManager_Factory (void);

      virtual ::PortableServer::POAManager_ptr create_POAManager (
          const char * id,
          const ::CORBA::PolicyList & policies
          ACE_ENV_ARG_DECL)
        ACE_THROW_SPEC ((CORBA::SystemException,
                         ::PortableServer::POAManagerFactory::ManagerAlreadyExists,
                         ::CORBA::PolicyError));

      virtual ::PortableServer::POAManagerFactory::POAManagerSeq * list (
          ACE_ENV_SINGLE_ARG_DECL)
        ACE_THROW_SPEC ((CORBA::SystemException));

      virtual ::PortableServer::POAManager_ptr find (
          const char * id ACE_ENV_ARG_DECL)
      ACE_THROW_SPEC ((CORBA::SystemException));

      int remove_poamanager (::PortableServer::POAManager_ptr poamanager);

      int register_poamanager (::PortableServer::POAManager_ptr poamanager);

    private:
      TAO_Object_Adapter &object_adapter_;

      typedef ACE_Unbounded_Set < ::PortableServer::POAManager_ptr> POAMANAGERSET;

      POAMANAGERSET poamanager_set_;
    };
  }
}

#if defined(_MSC_VER)
#pragma warning(pop)
#endif /* _MSC_VER */

#include /**/ "ace/post.h"
#endif /* TAO_POAMANAGERFACTORY_H */
