// $Id: POAManager.cpp,v 1.13 2005/02/18 09:07:12 jwillemsen Exp $

#include "POAManagerFactory.h"
#include "POAManager.h"
#include "ace/OS_NS_string.h"

ACE_RCSID (PortableServer,
           POAManagerFactory,
           "$Id: POAManager.cpp,v 1.13 2005/02/18 09:07:12 jwillemsen Exp $")

namespace TAO
{
  namespace Portable_Server
  {
    POAManager_Factory::POAManager_Factory (TAO_Object_Adapter &object_adapter) :
      object_adapter_ (object_adapter)
    {
    }

    POAManager_Factory::~POAManager_Factory (void)
    {
      for (POAMANAGERSET::iterator iterator = this->poamanager_set_.begin ();
           iterator != this->poamanager_set_.end ();
           ++iterator)
        {
          ::PortableServer::POAManager_ptr poamanager = (*iterator);
          CORBA::release (poamanager);
        }
    }

    ::PortableServer::POAManager_ptr
    POAManager_Factory::create_POAManager (
      const char * id,
      const ::CORBA::PolicyList &
      ACE_ENV_ARG_DECL)
        ACE_THROW_SPEC ((CORBA::SystemException,
                         ::PortableServer::POAManagerFactory::ManagerAlreadyExists,
                         ::CORBA::PolicyError))
    {
      PortableServer::POAManager_ptr poamanager =
        this->find (id ACE_ENV_ARG_PARAMETER)
      ACE_CHECK_RETURN (::PortableServer::POAManager::_nil ());

      // If we already have a manager with the same name throw an exception
      if (!CORBA::is_nil (poamanager))
        {
          ACE_THROW_RETURN (
            ::PortableServer::POAManagerFactory::ManagerAlreadyExists (),
            ::PortableServer::POAManager::_nil ());
        }

      ACE_NEW_THROW_EX (poamanager,
                        TAO_POA_Manager (object_adapter_, id, this),
                        CORBA::NO_MEMORY (
                          CORBA::SystemException::_tao_minor_code (0,
                                                                   ENOMEM),
                          CORBA::COMPLETED_NO));
      ACE_CHECK_RETURN (::PortableServer::POAManager::_nil ());

      this->register_poamanager (poamanager);

      return poamanager;
    }

    ::PortableServer::POAManagerFactory::POAManagerSeq *
    POAManager_Factory::list (
      ACE_ENV_SINGLE_ARG_DECL)
        ACE_THROW_SPEC ((CORBA::SystemException))
    {
      ::PortableServer::POAManagerFactory::POAManagerSeq_var poamanagers;
      CORBA::ULong number_of_poamanagers = static_cast <CORBA::ULong>
                                                  (this->poamanager_set_.size ());
      ACE_NEW_THROW_EX (poamanagers,
                        PortableServer::POAManagerFactory::POAManagerSeq (
                          number_of_poamanagers),
                        CORBA::NO_MEMORY ());
      ACE_CHECK_RETURN (0);

      poamanagers->length (number_of_poamanagers);

      CORBA::ULong index = 0;
      for (POAMANAGERSET::iterator iterator = this->poamanager_set_.begin ();
           iterator != this->poamanager_set_.end ();
           ++iterator, ++index)
        {
          ::PortableServer::POAManager_ptr poamanager = (*iterator);
          poamanagers[index] =
            PortableServer::POAManager::_duplicate (poamanager);
        }

      return poamanagers._retn ();
    }

    ::PortableServer::POAManager_ptr
    POAManager_Factory::find (
      const char * id ACE_ENV_ARG_DECL)
      ACE_THROW_SPEC ((CORBA::SystemException))
    {
      ::PortableServer::POAManager_ptr poamanager =
        ::PortableServer::POAManager::_nil();

      for (POAMANAGERSET::iterator iterator = this->poamanager_set_.begin ();
           iterator != this->poamanager_set_.end ();
           ++iterator)
        {
          CORBA::String_var poamanagerid =
            (*iterator)->get_id (ACE_ENV_SINGLE_ARG_PARAMETER);
          ACE_CHECK_RETURN (::PortableServer::POAManager::_nil());

          if (ACE_OS::strcmp (id, poamanagerid))
            {
              poamanager = PortableServer::POAManager::_duplicate (*iterator);
              break;
            }
        }

      return poamanager;
    }

    int
    POAManager_Factory::remove_poamanager (
      ::PortableServer::POAManager_ptr poamanager)
    {
      int retval = 0;
      retval = this->poamanager_set_.remove (PortableServer::POAManager::_duplicate (poamanager));

      if (retval == 0)
        {
          CORBA::release (poamanager);
        }

      return retval;
    }

    int
    POAManager_Factory::register_poamanager (
      ::PortableServer::POAManager_ptr poamanager)
    {
      return this->poamanager_set_.insert (
        PortableServer::POAManager::_duplicate (poamanager));
    }
  }
}

