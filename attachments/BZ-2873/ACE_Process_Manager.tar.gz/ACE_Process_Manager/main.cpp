// $Id$

#include "ace/Process_Manager.h"
#include "ace/Reactor.h"

#ifdef _WIN32
static BOOL __stdcall ConsoleHandler (DWORD ctrlType)
{
	ACE_UNUSED_ARG (ctrlType);
	ACE_DEBUG ((LM_WARNING,
		ACE_TEXT ("Application is terminated by user.\n")));
	ACE_Reactor::end_event_loop ();
	return TRUE;
}
#endif // _WIN32

class Exit_Handler : public ACE_Event_Handler
{
public:
	~Exit_Handler ()
	{
		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Exit_Handler::~Exit_Handler\n")));
	}

	virtual int handle_exit (ACE_Process* proc)
	{
		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Exit_Handler::handle_exit\n")));
		return 0;
	}

	virtual int handle_close (
		ACE_HANDLE handle = ACE_INVALID_HANDLE,
		ACE_Reactor_Mask = ACE_Event_Handler::ALL_EVENTS_MASK)
	{
		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Exit_Handler::handle_close\n")));
		delete this;
		return 0;
	}
};

int ACE_TMAIN (int argc, ACE_TCHAR* argv[])
{
#ifdef _WIN32
	::SetConsoleCtrlHandler (ConsoleHandler, TRUE);
#endif
	ACE_Process_Manager::instance ()->open (ACE_Process_Manager::DEFAULT_SIZE,
		ACE_Reactor::instance ());
	Exit_Handler* exit_handler;
	ACE_NEW_RETURN (exit_handler, Exit_Handler, 1);
	ACE_Process_Options opts;
	opts.command_line (ACE_TEXT ("notepad"));
	pid_t pid = ACE_Process_Manager::instance ()->spawn (opts, exit_handler);
	if (pid < 0) {
		delete exit_handler;
		ACE_ERROR_RETURN ((LM_ERROR,
			ACE_TEXT ("%p\n"),
			ACE_TEXT ("Unable to spawn 'notepad'")),
			1);
	}

	ACE_Reactor::run_event_loop ();
	return 0;
}
