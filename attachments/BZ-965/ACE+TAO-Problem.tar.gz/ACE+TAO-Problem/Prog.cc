#ifndef NO_IDENT_DIRECTIVE
#ident "$Id: Prog.cc,v 1.1.1.1 2001/07/02 15:46:51 cvm Exp $"
#endif

#ifdef __GNUG__
#  pragma implementation
#endif /* __GNUG__ */

#include "InterfacesS.h"
#include "CiServer_impl.h"
#include "ace/Task.h"

int rec_level;

class Worker : public ACE_Task_Base
{
  // = TITLE
  //   Run a server thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run server threads
  //
public:
  Worker (CORBA::ORB_ptr orb);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

Worker::Worker (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
Worker::svc (void)
{
  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      cerr << "Starting thread." << endl;
      this->orb_->run (ACE_TRY_ENV);
      cerr << "Stopping thread." << endl;
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
    }
  ACE_ENDTRY;
  return 0;
}





int main( int argc, char **argv )
{

  const char *ior_string = 0;
  int value = 0;
  
  if( argc == 3 )
    {
      ior_string = argv[1];
      value = atoi( argv[2] );
    }
  

  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      PortableServer::POA_var root_poa;
  
      CORBA::ORB_var orb_var =
        CORBA::ORB_init ( argc, argv, NULL, ACE_TRY_ENV );

      cerr << "Resolving RootPOA ...";
      CORBA::Object_var obj_var = 
        orb_var->resolve_initial_references ( "RootPOA" );
      root_poa = PortableServer::POA::_narrow ( obj_var.in(), ACE_TRY_ENV );
      ACE_TRY_CHECK;
      
      assert ( !CORBA::is_nil ( root_poa.in() ) );
      root_poa->the_POAManager()->activate ();
      cerr << " ok." << endl;

      //# instantiate and activate servant
      CiServer_impl *server_impl = new CiServer_impl( root_poa.in() );
      CiServer_var ci_server = server_impl->_this();
      
      if( ior_string == 0 )
        {
          cerr << orb_var->object_to_string( ci_server.in() ) << endl;
        }
      
      Worker worker (orb_var.in ());
      if (worker.activate (THR_NEW_LWP | THR_JOINABLE, 4) != 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);
      
      if( ior_string )
        {
          CORBA::Object_var obj_var = orb_var->string_to_object( ior_string );
          CiServer_var server_var = CiServer::_narrow( obj_var.in() );
          while( 1 )
            {
              cerr << "Lets call the server ... " << endl;
              server_var->getName( ci_server.in(), value-1, ACE_TRY_ENV );
              ACE_TRY_CHECK;
            }
        }
      
      worker.thr_mgr ()->wait ();
    }
  ACE_CATCHANY
    {
      cerr << " failed." << endl;
      return 0;
    }
  ACE_ENDTRY;

}


