#ifndef NO_IDENT_DIRECTIVE
#ident "$Id: CiServer_impl.cc,v 1.1.1.1 2001/07/02 15:46:51 cvm Exp $"
#endif

#ifdef __GNUG__
#  pragma implementation
#endif /* __GNUG__ */

#include "CiServer_impl.h"


#if 0
char *
CiServlet_impl::getNameOf ( CiServlet_ptr servlet,
                            CORBA::Environment &ACE_TRY_ENV )
{
  CORBA::String_var name;
  
  ACE_TRY
    {
      name = servlet->getName();
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      cerr << "Servlet::getName() returned with an exception!" << endl;
      exit( 0 );
    }
  ACE_ENDTRY;

  cerr << "[getNameOf()] i got name '" << name << "'." << endl;

  return( CORBA::string_dup( name.in() ) );
}

#endif

