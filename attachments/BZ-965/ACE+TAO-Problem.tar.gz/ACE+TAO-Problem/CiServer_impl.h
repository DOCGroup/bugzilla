/** 


    @author $Id: CiServer_impl.h,v 1.1.1.1 2001/07/02 15:46:51 cvm Exp $
*/

#ifndef CISERVER_IMPL_H
#  define CISERVER_IMPL_H
#  ifdef __GNUG__
#    pragma interface
#  endif /* __GNUG__ */

#  ifndef NO_IDENT_DIRECTIVE
#    ident "$Id: CiServer_impl.h,v 1.1.1.1 2001/07/02 15:46:51 cvm Exp $"
#  endif

#include "InterfacesS.h"

/** 

*/
class CiServer_impl: public POA_CiServer
{
private:

  PortableServer::POA_ptr  mp_poa;

  
public:

  inline CiServer_impl( PortableServer::POA_ptr poa )
    : POA_CiServer(),
      mp_poa( PortableServer::POA::_duplicate( poa ) )
  {}

  inline virtual ~CiServer_impl()
  {
    CORBA::release( mp_poa );
  }

  virtual PortableServer::POA_ptr _default_POA()
  {
    return( PortableServer::POA::_duplicate( mp_poa ) );
  }

  inline virtual char * getName( CiServer_ptr server, CORBA::Long level,
                                 CORBA::Environment &ACE_TRY_ENV = TAO_default_environment () )
  ACE_THROW_SPEC (( CORBA::SystemException ))
  {
    if( level == 0 )
      {
        cerr << "me" << endl;
        //sleep( 3 );
      }
    else
      {
        cerr << "Level " << level << endl;
        server->getName( _this(), CORBA::Long( level-1 ) );
      }
    
    return( CORBA::string_dup( "Server" ) );
  }
 
};




#endif /* CISERVER_IMPL_H */
