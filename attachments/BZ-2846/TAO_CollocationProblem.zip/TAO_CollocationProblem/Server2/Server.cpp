// Server.cpp : Defines the entry point for the console application.
//
int serverSupport(int argc, char* argv[], bool primary, const char* hostname2 = "");

int main(int argc, char* argv[])
{
	serverSupport(argc, argv, false);
	return 0;
}
