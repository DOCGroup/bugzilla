// Client1.cpp : Defines the entry point for the console application.
//

#include <iostream.h>
#include "../IDL/TestC.h"

const char* PRIMARY_PORT   = "5122";

int main(int argc, char* argv[])
{
	try
	{
		cerr << "Initializing ORB... " << endl;
		CORBA::ORB_var orb = CORBA::ORB_init (argc, argv, "");

		char corbaLoc[MAX_PATH*2];
		sprintf(corbaLoc, "corbaloc::localhost:%s/Test", PRIMARY_PORT);
		cerr << "URL: " << corbaLoc << endl;

		CORBA::Object_var obj = orb->string_to_object(corbaLoc);
		Test_var test = Test::_narrow(obj.in());
		if (CORBA::is_nil(test.in()))
		{
			cerr << "Initialization FAILED.  EXITING." << endl;
			return 0;
		}

		cerr << "Invoking operationA on Primary Server..." << endl;
		test->operationA();

		cerr << "Exiting..." << endl;
		orb->destroy();
    }
	catch (const CORBA::Exception& ex)
	{
		cerr << "CAUGHT A CORBA EXCEPTION!" << endl;
		cerr << "  " << ex << endl;
	}
	catch (...)
    {
		cerr << "CAUGHT AN UNKNOWN EXCEPTION!" << endl;
    }

	return 0;
}
