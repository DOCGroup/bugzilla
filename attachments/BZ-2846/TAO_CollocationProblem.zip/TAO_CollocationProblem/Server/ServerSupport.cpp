// Server.cpp : Defines the entry point for the console application.
//
#include <iostream.h>
#include "ace/task.h"
#include "tao/IORTable/IORTable.h"
#include "tao/PortableServer/POA_Current.h"
#include "tao/PortableServer/PortableServer.h"
#include "tao/PortableServer/Servant_Base.h"
#include "../IDL/TestS.h"

static CORBA::ORB_var orb;

const char* PRIMARY_PORT   = "5122";
const char* SECONDARY_PORT = "5122";


//*************************************************************************
// FakeArgVector allows any number of "command line" options to be
// supplied programmatically to the ORB at initialization.
//*************************************************************************
class FakeArgVector
{
public:
	FakeArgVector(int argc, char* argv[])
	{
		fakeArgc = argc;
		for (int i = 0; i < argc; i++)
		{
			fakeArgv[i] = new char[strlen(argv[i])+1];
			strcpy(fakeArgv[i], argv[i]);
		}
	}

	~FakeArgVector()
	{
		for (int i = 0; i < fakeArgc; i++)
			delete [] fakeArgv[i];
	}

	void add(const char *arg)
	{
		fakeArgv[fakeArgc] = new char[strlen(arg)+1];
		strcpy(fakeArgv[fakeArgc], arg);
		fakeArgc++;
	}

	int& argc() { return fakeArgc; }
	char** argv() { return fakeArgv; }

	int fakeArgc;
	char* fakeArgv[256];
};

//*************************************************************************
/// Implementation for the test interface.
//*************************************************************************
class Test_impl : public virtual POA_Test, public virtual PortableServer::RefCountServantBase
{
public:

	//
	// "primary" is used to distinguish the Primary from the Secondary
	// instance of the server.  For purposes of this test, one server
	// needs to call the other.
	//
	Test_impl(bool primary, const char* hostname) { m_primary = primary; m_hostname = hostname; }

    virtual void operationA() throw(CORBA::SystemException)
	{
		if (m_primary)
		{
			cerr << "operationA has been invoked on the Primary Server" << endl;
			cerr << "Attempting to invoke operationA on the Secondary Server..." << endl;
			try
			{
				char corbaLoc[MAX_PATH*2];
				sprintf(corbaLoc, "corbaloc::%s:%s/Test", m_hostname, SECONDARY_PORT);
				cerr << "URL: " << corbaLoc << endl;

				CORBA::Object_var obj = orb->string_to_object(corbaLoc);
				Test_var test = Test::_narrow(obj.in());
				if (CORBA::is_nil(test.in()))
				{
					cerr << "Initialization FAILED.  EXITING." << endl;
					return;
				}

				cerr << "Invoking 'operationA' on Secondary Server..." << endl;
				test->operationA();

				cerr << "operationA has been invoked on the Secondary Server" << endl;
				cerr << "THE TEST HAS COMPLETED SUCCESSFULLY!" << endl;
			}
			catch (const CORBA::Exception& ex)
			{
				cerr << "CAUGHT A CORBA EXCEPTION!" << endl;
				cerr << "  " << ex << endl;
			}
			catch (...)
			{
				cerr << "CAUGHT AN UNKNOWN EXCEPTION!" << endl;
			}
		}
		else // this is the Secondary Server
		{
			cerr << "operationA has been invoked on the Secondary Server" << endl;
			cerr << "THE TEST HAS COMPLETED SUCCESSFULLY!" << endl;
		}
	}

private:

	bool m_primary;
	const char* m_hostname;

};

//*************************************************************************
// Set up everything and run the ORB.
//*************************************************************************
int serverSupport(int argc, char* argv[], bool primary, const char* hostname2)
{
	cerr << "Initializing " << (primary? "Primary" : "Secondary") << " Server..." << endl;
	try
	{
		WSADATA wsaData;
		WSAStartup(MAKEWORD(1, 0), &wsaData);
		char hostname[MAX_PATH];
		if (gethostname(hostname, MAX_PATH) != 0)
		{
			cerr << "GETHOSTNAME FAILED!" << endl;
			cerr << "Exiting..." << endl;
			return 0;
		}

		//
		// Set up a fake argument vector with an endpoint for this test.
		// The key to this problem is the use of more than one endpoint.
		// One will be based on the actual computer name, the other on
		// "localhost".
		//
		FakeArgVector fakeArgs(argc, argv);
		char endpoint[MAX_PATH*2];
		const char* port = (primary)? PRIMARY_PORT : SECONDARY_PORT;

		fakeArgs.add("-ORBEndpoint");

		sprintf(endpoint, "iiop://%s:%s", hostname, port);
		fakeArgs.add(endpoint);
		cerr << "Endpoint: " << endpoint << endl;

		fakeArgs.add("-ORBEndpoint");

		sprintf(endpoint, "iiop://localhost:%s", port);
		fakeArgs.add(endpoint);
		cerr << "Endpoint: " << endpoint << endl;

		//
		// Initialize the ORB.
		//
		orb = CORBA::ORB_init(fakeArgs.argc(), fakeArgs.argv());

		//
		// Resolve Root POA and activate the POA manager
		//
		CORBA::Object_var poaObj = orb->resolve_initial_references("RootPOA");
		PortableServer::POA_var rootPoa = PortableServer::POA::_narrow(poaObj.in());
		PortableServer::POAManager_var poaManager = rootPoa->the_POAManager();
		poaManager->activate();

		//
		// Create a servant.
		//
		Test_impl* impl = new Test_impl(primary, hostname2);
		PortableServer::ServantBase_var servant = impl;

		//
		// Create CORBA object and activate it.
		//
		PortableServer::ObjectId_var id = PortableServer::string_to_ObjectId("Test");
		rootPoa->activate_object_with_id(id, servant.in());

		//
		// Get a reference to the IOR Table.
		//
		CORBA::Object_var iorObj = orb->resolve_initial_references("IORTable");
		IORTable::Table_var table = IORTable::Table::_narrow(iorObj.in());

		//
		// Turn object reference into an IOR string and put it in the IOR Table.
		//
		CORBA::Object_var testObject = rootPoa->id_to_reference(id);
		CORBA::String_var testString = orb->object_to_string(testObject);
		table->bind("Test", testString.in());

		//
		// Run the ORB.  This is the simplest possible configuration.
		//
		cerr << "Run the ORB..." << endl;
		orb->run();

		//
		// Clean up before shutting down
		//
		rootPoa->destroy(1, 1);
		orb->destroy();
	}
	catch (const CORBA::Exception& ex)
	{
		cerr << "CAUGHT A CORBA EXCEPTION!" << endl;
		cerr << "  " << ex << endl;
	}
	catch (...)
    {
		cerr << "CAUGHT AN UNKNOWN EXCEPTION!" << endl;
    }

	cerr << "Exiting..." << endl;
	return 0;
}
