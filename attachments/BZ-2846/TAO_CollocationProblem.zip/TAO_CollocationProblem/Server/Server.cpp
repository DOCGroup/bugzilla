// Server.cpp : Defines the entry point for the console application.
//
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
int serverSupport(int argc, char* argv[], bool primary, const char* hostname2 = "");

int main(int argc, char* argv[])
{
	cerr << "*** Enter the name of the secondary server >";
	char hostname[81];
	gets(hostname);
	serverSupport(argc, argv, true, hostname);
	return 0;
}
