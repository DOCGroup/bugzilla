#include "test_config.h"
#include "ace/Process_Manager.h"
#include "ace/Event_Handler.h"
#include "ace/Process.h"
#include "ace/Reactor.h"
#include "ace/Log_Msg.h"


class Notify: public ACE_Event_Handler
{
    virtual int handle_exit(ACE_Process*)
    {
      ACE_DEBUG ((LM_DEBUG,
                  ACE_TEXT ("Elvis has left the building!\n")));
        ACE_Reactor::instance()->end_event_loop();
        return 0;
    };
};


int
ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  ACE_START_TEST (ACE_TEXT ("Process_Manager_Attach_Test"));
  ACE_UNUSED_ARG(argc);
  ACE_UNUSED_ARG(argv);

  ACE_Process process;
  ACE_Process_Options options;

  // sleep is used here because it
  // is widely avaible across platforms
  // and the process lifetime can be easily
  // defined.
  options.command_line("sleep 10");
  pid_t pid = process.spawn(options);

  if (ACE_INVALID_PID != pid)
  {
    ACE_DEBUG ((LM_DEBUG,
                ACE_TEXT ("Spawned Process \"sleep 10\"\n")));

    Notify* notify = new Notify();
    
    ACE_Process_Manager::instance()->open(1,ACE_Reactor::instance());
    ACE_Process_Manager::instance()->register_handler(notify);

    if (ACE_INVALID_PID == ACE_Process_Manager::instance()->attach(pid))
    {
      ACE_ERROR_RETURN ((LM_ERROR,
                 ACE_TEXT ("Could not attach to process: %d\n"),
                 pid),
                 1);
    }
    else
    {
	    
      if (ACE_Process_Manager::instance()->is_managed(pid))
      {
        ACE_Reactor::instance()->run_event_loop();
      }
      else
      {
        ACE_ERROR_RETURN ((LM_ERROR,
                   ACE_TEXT ("process is not managed: %d\n"),
                   pid),
                   1);
      }
      
    }
    
    ACE_Process_Manager::instance()->close();
  }
  else
  {
        ACE_ERROR_RETURN ((LM_ERROR,
                   ACE_TEXT ("Could not spawn process \"sleep 20\"\n")),
                   1);
  }

  ACE_END_TEST;
  return 0;
}
