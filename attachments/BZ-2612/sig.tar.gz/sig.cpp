#include <iostream>
#include <iomanip>


#include "ace/OS.h"
#include "ace/Service_Config.h"


#include "log4cplus/configurator.h"
#include "log4cplus/logger.h"

log4cplus::Logger s_logger = log4cplus::Logger::getInstance("sig");


char const * const scpc_orbId = "testORB";

char const * const scpc_loadOrb = ACE_DYNAMIC_SERVICE_DIRECTIVE(
  "testDllOrb",
  "tradescape",
  "_make_DllOrb",
  "testDllOrb -ORBDebugLevel 30 -ORBId testORB -ORBInitRef NameService=file:///tmp/test-ns.ior -ORBDottedDecimalAddresses 1"
);

char const * const scpc_unloadOrb = ACE_REMOVE_SERVICE_DIRECTIVE("testDllOrb");


char const * const scpc_namingServiceIorFileName = "/tmp/test-ns.ior";

char const * const scpc_loadNamingService = ACE_DYNAMIC_SERVICE_DIRECTIVE(
  "testNamingService",
  "TAO_CosNaming_Serv",
  "_make_TAO_Naming_Loader",
  "testNameService -m 0 -o /tmp/test-ns.ior -ORBId testORB"
);

char const * const scpc_unloadNamingService = ACE_REMOVE_SERVICE_DIRECTIVE("testNamingService");



int main(int argc, char ** argv)
{
	int result;

	log4cplus::BasicConfigurator config;
	config.configure();

	log4cplus::Logger doLogger = log4cplus::Logger::getInstance("tradescape.utility.DllOrb");
//	doLogger.setLogLevel(log4cplus::TRACE_LOG_LEVEL);
	doLogger.setLogLevel(log4cplus::DEBUG_LOG_LEVEL);

	// do not use the default svc.conf file
	ACE_Service_Config::open (
	argv[0],
	ACE_DEFAULT_LOGGER_KEY,
	1,
	1,
	0
	);

	result = ACE_Service_Config::process_directive(scpc_loadOrb);
	LOG4CPLUS_TRACE(s_logger, "loading ORB done");

//	result = ACE_Service_Config::process_directive(scpc_loadNamingService);
//	LOG4CPLUS_TRACE(s_logger, "loading NamingService done");
	
	ACE_OS::sleep(1);

//	result = ACE_Service_Config::process_directive(scpc_unloadNamingService);
//	LOG4CPLUS_TRACE(s_logger, "unloading NamingService done");

	result = ACE_Service_Config::process_directive(scpc_unloadOrb);
	LOG4CPLUS_TRACE(s_logger, "unloading ORB done");

	ACE_OS::sleep(1);

	result = ACE_Service_Config::process_directive(scpc_loadOrb);
	LOG4CPLUS_TRACE(s_logger, "loading ORB done");
	
//	result = ACE_Service_Config::process_directive(scpc_loadNamingService);
//	LOG4CPLUS_TRACE(s_logger, "loading NamingService done");
	
	ACE_OS::sleep(1);

//	result = ACE_Service_Config::process_directive(scpc_unloadNamingService);
//	LOG4CPLUS_TRACE(s_logger, "unloading NamingService done");

	result = ACE_Service_Config::process_directive(scpc_unloadOrb);
	LOG4CPLUS_TRACE(s_logger, "unloading ORB done");

	LOG4CPLUS_INFO(s_logger, "sig done, exiting");

	return 0;
}
