#!/bin/bash

set -e
set -v


GXX=/opt2/linux/ix86/x86_64-pc-linux-gnu/bin/g++

ACE_ROOT=/opt2/linux/x86_64/ACE/1.5.2/ACE_wrappers

LOG4CPLUS_INCLUDE=/opt2/linux/x86_64/include
LOG4CPLUS_LIB=/opt2/linux/x86_64/lib


$GXX -g -m64 -fPIC -I$ACE_ROOT -I$ACE_ROOT/TAO -I$LOG4CPLUS_INCLUDE -DTRADESCAPE_BUILD_DLL -O0 -c -o DllOrb.o DllOrb.cpp

$GXX -g -m64 -fPIC -I$ACE_ROOT -I$ACE_ROOT/TAO -I$LOG4CPLUS_INCLUDE -O0 -c -o sig.o sig.cpp

$GXX -g -m64 -L$ACE_ROOT/lib -L$LOG4CPLUS_LIB -shared -lTAO_PortableServer -lTAO -lACE -o libtradescape.so DllOrb.o

$GXX -g -m64 -L$ACE_ROOT/lib -L$LOG4CPLUS_LIB -lACE -llog4cplus -o sig sig.o


LD_LIBRARY_PATH=.:$ACE_ROOT/lib:$LOG4CPLUS_LIB
export LD_LIBRARY_PATH

./sig
#gdb ./sig
