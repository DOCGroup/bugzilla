#include <orbsvcs/orbsvcs/CosNamingC.h>
#include "ECConsumer.h"
#include <tao/PortableServer/PS_CurrentC.h>
#include <iostream>
/**
 * Constructor
 *    Call base class constructor, then initialize local data
 */

ECConsumer::ECConsumer(CORBA::ORB_ptr orb, int event_limit)
  : orb_(CORBA::ORB::_duplicate(orb))
  , event_limit_(event_limit)
{
}

// Override the push() operation.
void ECConsumer::push(const CORBA::Any & data)
 throw(CORBA::SystemException)
{
  // Extract event data from the any.
  const char* eventData;
  if (data >>= eventData)
  {
    std::cout << "EchoEventConsumer_i::push(): Received event: " 
         << eventData << std::endl;
  }
  if (--event_limit_ <= 0) {
    //orb_->shutdown(0);
  }
}

// Override the disconnect_push_consumer() operation.
void ECConsumer::disconnect_push_consumer()
 throw(CORBA::SystemException)
{
  // Deactivate this object.
  CORBA::Object_var obj = orb_->resolve_initial_references("POACurrent");
  PortableServer::Current_var current = PortableServer::Current::_narrow(obj.in());
  PortableServer::POA_var poa = current->get_POA();
  PortableServer::ObjectId_var objectId = current->get_object_id();
  poa->deactivate_object(objectId.in());
}
