// Event Channel Main
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <sys/sem.h>
#include <errno.h>
#include <pthread.h>
#include "ECConsumer.h"

#include "orbsvcs/orbsvcs/CosEvent/CEC_Default_Factory.h"
#include "PortableServer/POAManagerC.h"
#include "tao/PortableServer/PortableServerC.h"
#include <tao/IOPC.h>
#include "ace/Thread_Manager.h"
#include "orbsvcs/orbsvcs/CosNamingC.h"
#include "orbsvcs/orbsvcs/CosEvent/CEC_EventChannel.h"
#include "orbsvcs/orbsvcs/CosEvent/CEC_Default_Factory.h"
#include "orbsvcs/orbsvcs/CosEvent/CEC_Event_Loader.h"
#include "orbsvcs/orbsvcs/CosEvent/CEC_EventChannel.h"
#include "orbsvcs/orbsvcs/CosEvent/CEC_Default_Factory.h"
#include <orbsvcs/orbsvcs/CosEventCommC.h>
#include <orbsvcs/orbsvcs/CosEventChannelAdminC.h>
#include <orbsvcs/orbsvcs/CosNamingC.h>

// Must include this file to get a static initializer
#include "tao/Valuetype/Valuetype_Adapter_Impl.h"

#include "ace/Get_Opt.h"
#include "ace/Argv_Type_Converter.h"
#include "ace/OS_main.h"

std::string sECName;

CORBA::ORB_var The_orb;
CosNaming::NamingContextExt_var root_context;
PortableServer::POA_var The_root_poa;
PortableServer::POAManager_var The_poa_manager;

void *run_orb(void *pArg)
{
	The_orb->run();
}

void *supplierThread(void *pArg)
{
int number = *(int *)(pArg);
	try{
	
	//*********************************Supplier setup*********************************************
	
	CosEventChannelAdmin::EventChannel_var echoEC;
    ACE_DECLARE_NEW_CORBA_ENV;
    
    TAO_CEC_EventChannel_Attributes attr(The_root_poa.in(), The_root_poa.in());
    TAO_CEC_EventChannel* ec = new TAO_CEC_EventChannel(attr);
    ec->activate();
    PortableServer::ObjectId_var oid = The_root_poa->activate_object(ec);
    CORBA::Object_var ec_obj = The_root_poa->id_to_reference(oid.in());
    echoEC = CosEventChannelAdmin::EventChannel::_narrow(ec_obj.in());
    
    // Bind the EventChannel.
    CosNaming::Name_var name = root_context->to_name("SampleChannel");
    root_context->rebind(name.in(), echoEC.in());
    
    // Get a SupplierAdmin object from the EventChannel.
    CosEventChannelAdmin::SupplierAdmin_var supplierAdmin =
      echoEC->for_suppliers();
    
    // Get a ProxyPushConsumer from the SupplierAdmin.
    CosEventChannelAdmin::ProxyPushConsumer_var consumer =
      supplierAdmin->obtain_push_consumer();
    
    // Connect to the ProxyPushConsumer as a PushSupplier
    // (passing a nil PushSupplier object reference to it because
    // we don't care to be notified about disconnects).
    consumer->connect_push_supplier(CosEventComm::PushSupplier::_nil());
		
		CORBA::Object_var obj = root_context->resolve_str("SampleChannel");

    // Downcast the object reference to an EventChannel reference.
    CosEventChannelAdmin::EventChannel_var echoEC2 = 
      CosEventChannelAdmin::EventChannel::_narrow(obj.in());
    if (CORBA::is_nil(echoEC2.in())) {
      std::cerr << "Could not narrow EchoEventChannel." << std::endl;
      return 0;
    }
    std::cout << "Found the EchoEventChannel." << std::endl;
		
		ECConsumer oConsumer(The_orb.in(), 0);
		
    PortableServer::ObjectId_var oid2 = The_root_poa->activate_object(&oConsumer);
    CORBA::Object_var consumer_obj = The_root_poa->id_to_reference(oid2.in());
    CosEventComm::PushConsumer_var consumer2 =
      CosEventComm::PushConsumer::_narrow(consumer_obj.in());

    // Get a ConsumerAdmin object from the EventChannel.
    CosEventChannelAdmin::ConsumerAdmin_var consumerAdmin =
      echoEC->for_consumers();

    // Get a ProxyPushSupplier from the ConsumerAdmin.
    CosEventChannelAdmin::ProxyPushSupplier_var supplier =
      consumerAdmin->obtain_push_supplier();

    // Connect to the ProxyPushSupplier, passing our PushConsumer object
    // reference to it.
    supplier->connect_push_consumer(consumer2.in());

    The_poa_manager->activate();		
		
		const CORBA::String_var eventData = CORBA::string_dup("Hello, world.");
    int x = 20;
    while (--x > 0) {
      // Insert the event data into an any.
      CORBA::Any any;
      any <<= eventData;
      
      // Now push the event to the consumer
      consumer->push(any);
			std::cout << "Push from thread " << number << std::endl;
      
      //ACE_Time_Value tv(0, 1000 * EVENT_DELAY_MS);
      //orb->run(tv);
    }
	return 0;
	//*****************************************************************************************

  // Create Consumer
 

  int sampleMessage;
  int msgCount = 0;
  int delay=0;
  CORBA::Any any;
  
  
  std::cout << "##################### thread exiting ##########################" << std::endl;
  }
	catch (CORBA::Exception& exc) 
  {
    std::cerr << "Caught unknown CORBA::Exception exception" << std::endl << exc << std::endl;
  }
	catch(...){}
  ACE_OS::sleep(1);
   return NULL;
}


int main(int argc, char *argv[])
{
	TAO_CEC_Default_Factory::init_svcs ();
	
	
	
  bool bArgError = false;
  int nArg;
  std::string sOutFile, sFileSize, sIOR, sAltIOR;
  ACE_Thread_Manager     oThrdMgr;
	
	

  // Create corba processing
  //=====================================================================================
  The_orb = CORBA::ORB_init(argc, argv);

    // Find the Naming Service.
    CORBA::Object_var obj = The_orb->resolve_initial_references("NameService");
    root_context = CosNaming::NamingContextExt::_narrow(obj.in());
		
		// Get the root POA
    CORBA::Object_var poa_object = The_orb->resolve_initial_references("RootPOA");
    if (CORBA::is_nil (poa_object.in ()))
      ACE_ERROR_RETURN ((LM_ERROR,
      " (%P|%t) Unable to initialize the POA.\n"),
      -1);
    The_root_poa = PortableServer::POA::_narrow (poa_object.in ());
    The_poa_manager = The_root_poa->the_POAManager ();
    The_poa_manager->activate ();
  	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
		TAO_CEC_EventChannel_Attributes attributes(The_root_poa.in (),The_root_poa.in ());
      TAO_CEC_Factory *factory_ = 0;
		int terminate_flag_ = 0;
      TAO_CEC_EventChannel ec_impl_(attributes,factory_,terminate_flag_);

      ec_impl_.activate (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      CosEventChannelAdmin::EventChannel_var event_channel =
        ec_impl_._this (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
			CosNaming::Name channel_name_;
			channel_name_.length (1);
      channel_name_[0].id = CORBA::string_dup ("SampleChannel");

          
     root_context->rebind (channel_name_,event_channel.in ()ACE_ENV_ARG_PARAMETER);
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
		ACE_Thread::spawn(run_orb,0);
		ACE_OS::sleep(1);
		int thrCount=0;
	for (int ii=0; ii < 3; ii++)
  	{
			int result;
    	result = oThrdMgr.spawn(supplierThread, (void *)&ii);
    	if (result == -1)
    	{
      	std::cout << "ECTest: Cannot spawn any more threads" << std::endl;
      	break;
    	}
    	std::cout << "ECTest: Created thread " << ii << std::endl;
    	thrCount++;
    	//ACE_OS::sleep(oTv);
  	}
		oThrdMgr.wait(); 
  	std::cout << "ECTest: All " << thrCount << " threads finished" << std::endl;
		The_orb->destroy ();
  
  
  return 0;
}
//#endif
