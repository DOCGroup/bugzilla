#ifndef ECConsumer_H
#define ECConsumer_H
#include <orbsvcs/orbsvcs/CosEventCommS.h>


class ECConsumer :  public virtual POA_CosEventComm::PushConsumer
{
   
public:

   /**
    * Constructor
    *
    */

   ECConsumer(CORBA::ORB_ptr orb, int event_limit);

    // Override operations from PushConsumer interface.
    virtual void push(
      const CORBA::Any & data) 
     throw(CORBA::SystemException);

    virtual void disconnect_push_consumer()
     throw(CORBA::SystemException);

  private:
    CORBA::ORB_var orb_;
    int event_limit_;

};

#endif



