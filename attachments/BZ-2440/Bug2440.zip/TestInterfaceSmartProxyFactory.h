#include "TestInterfaceC.h"

class TestInterfaceSmartProxy : public TAO_TestInterface_Smart_Proxy_Base
{

public:

   TestInterfaceSmartProxy( TestInterface_ptr proxy ) :
      TAO_Smart_Proxy_Base( proxy )
//   ,m_dumbProxy( TestInterface::_duplicate( proxy ) )  // suggested workaround
      { cout << "TestInterfaceSmartProxy::ctor." << endl; }

   ~TestInterfaceSmartProxy()
      { cout << "TestInterfaceSmartProxy::dtor." << endl; }

/*                                          // suggested workaround - start
   CORBA::Boolean _non_existent()
   {
      CORBA::Boolean retVal;
      try
      {
         retVal = m_dumbProxy->_non_existent();
         return retVal;
      }
      catch (CORBA::SystemException)
      {
         // _non_existent() throws OBJECT_NOT_EXIST in some TAO versions (1.4a)
         return true;
      }
   }
   
   TestInterface_ptr m_dumbProxy;
*/                                          // suggested workaround - end

};


class TestInterfaceSmartProxyFactory : 
   public TAO_TestInterface_Default_Proxy_Factory
{

public:

   TestInterfaceSmartProxyFactory()
      { cout << "TestInterfaceSmartProxyFactory::ctor." << endl; }
   
   ~TestInterfaceSmartProxyFactory()
      { cout << "TestInterfaceSmartProxyFactory::dtor." << endl; }

   TestInterface_ptr create_proxy( TestInterface_ptr proxy )
   {
      cout << "TestInterfaceSmartProxyFactory::create_proxy." << endl;
      
      TestInterface_ptr smartProxy = 0;
      if ( !CORBA::is_nil ( proxy ) ) 
      {
         smartProxy = new TestInterfaceSmartProxy( proxy );
      }
      return smartProxy;
   }

};
