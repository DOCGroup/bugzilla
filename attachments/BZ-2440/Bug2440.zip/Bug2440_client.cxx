#include <iostream.h>         // cout, cerr, endl
#include <unistd.h>           // sleep()

#include <orbsvcs/CosNamingC.h>
#include "TestInterfaceC.h"
#include "TestInterfaceSmartProxyFactory.h"


//------------------------------------------------------------------------------
// Bug2440_client
//------------------------------------------------------------------------------

int main (int argc, char* argv[]) throw()
{

   TestInterface_var testObj;
   
   try
   {
      CORBA::Object_var obj;
   
      //----------------
      // INITIALISE ORB
      //----------------
      
      CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
      
      cout << "Enter 's' for smart proxy; any other character for dumb" << endl;
      char s;
      cin >> s;
      
      if (s=='s')
      {
         // Create the TestInterface Smart Proxy Factory on the heap
         // (includes registration, but otherwise unused here)
         new TestInterfaceSmartProxyFactory( );
      }
      
      //----------------
      // NAMING CONTEXT
      //----------------
      
      obj = orb->resolve_initial_references( "NameService" );
      CosNaming::NamingContext_var rootContext;
      rootContext = CosNaming::NamingContext::_narrow( obj.in() );
      if (CORBA::is_nil( rootContext.in() ))
      {
         cerr << "Nil Naming Context reference" << endl;
         throw 0;
      }
      
      // Resolve the TestInterface object
      CosNaming::Name name;
      name.length(2);
      name[0].id = CORBA::string_dup( "Test" );
      name[1].id = CORBA::string_dup( "testObject" );
      try
      {      
         obj = rootContext->resolve( name );
      }
      catch (CosNaming::NamingContext::NotFound &ne)
      {
         cerr << "Attempt to resolve unbound name - exiting" << endl;
         throw 0;
      }
      catch (CosNaming::NamingContext::InvalidName &ne)
      {
         cerr << "Attempt to resolve invalid name - exiting" << endl;
         throw 0;
      }
      catch (CORBA::INV_OBJREF)
      {
         cerr << "Invalid object reference from resolve - exiting" << endl;
         throw 0;
      }

      //-------------
      // TEST OBJECT
      //-------------   

      testObj = TestInterface::_narrow( obj.in() );
      if (CORBA::is_nil( testObj.in() ))
      {
         cerr << "narrow to TestInterface object failed" << endl;
         throw 0;
      }

//    Enable following to provoke MARSHAL exception with smart proxy
//    cout << "orb->object_to_string( testObj ) = " 
//         << orb->object_to_string( testObj ) 
//         << endl;

      // Try the test object periodically for 30 seconds
      for (unsigned int i = 0; i<10; i++)
      {
         cout << " testObj->_non_existent() = " 
              << (int) testObj->_non_existent() 
              << endl;
         sleep(3);
      }

      // Throw an OBJECT_NOT_EXIST to check it has really gone     
      cout << "about to call count()" << endl;
      testObj->count(666);
      cout << "returned from count()" << endl;
            
   }
   catch (CORBA::SystemException &se)
   {
      cerr << "CORBA::SystemException:" << endl << &se << endl;
      throw 0;
   }

   return 0;
}
