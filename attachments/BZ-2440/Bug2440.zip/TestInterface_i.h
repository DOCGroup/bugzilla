
#include <iostream.h>
#include "TestInterfaceS.h"


class TestInterface_i : public POA_TestInterface
{

public:

   //---------------------------------------------------------------------------
   // Public constructor and destructor
   //---------------------------------------------------------------------------

   TestInterface_i ()
      { cout << "TestInterface_i::ctor." << endl; m_count = 123; }
   
   ~TestInterface_i ()
      { cout << "TestInterface_i::dtor." << endl; }

   //---------------------------------------------------------------------------
   // Public CORBA interface
   //---------------------------------------------------------------------------

   CORBA::Short count ()
      throw (CORBA::SystemException) 
      { return m_count; }

   void count (CORBA::Short value)
      throw (CORBA::SystemException)
      { m_count = value; }

private:

   //---------------------------------------------------------------------------
   // Private data members
   //---------------------------------------------------------------------------

   CORBA::Short m_count;

};
