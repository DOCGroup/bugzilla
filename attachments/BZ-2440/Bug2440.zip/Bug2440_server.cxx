#include <iostream.h>                   // cout, cerr, endl
#include <time.h>                       // timespec, nanosleep()

#include "orbsvcs/CosNamingC.h"
#include "TestInterface_i.h"


//------------------------------------------------------------------------------
// Bug2440_server
//------------------------------------------------------------------------------

int main (int argc, char* argv[]) throw()
{
   try
   {
      CORBA::Object_var obj;
   
      //----------------
      // INITIALISE ORB
      //----------------

      // Initialise the ORB      
      CORBA::ORB_var orb = CORBA::ORB_init( argc, argv );
     
      // Get a reference to the Root POA
      obj = orb->resolve_initial_references( "RootPOA" );
      PortableServer::POA_var rootPOA = PortableServer::POA::_narrow( obj );
      
      // Get a reference to the Root POA manager
      PortableServer::POAManager_var poaManager = rootPOA->the_POAManager();

      // Activate the POA
      poaManager->activate();
      {

         //--------------
         // TEST SERVANT
         //--------------   

         TestInterface_i testServant;
     
         //---------
         // PUBLISH
         //---------
     
         // Find the Naming Service
         obj = orb->resolve_initial_references( "NameService" );
         CosNaming::NamingContext_var rootContext;
         rootContext = CosNaming::NamingContext::_narrow( obj.in() );
         if (CORBA::is_nil( rootContext.in() ))
         {
            cerr << "Nil root Naming Context reference" << endl;
            throw 0;
         }

         // Bind the Test Naming Context, if not already bound
         CosNaming::Name name;
         name.length(1);
         name[0].id   = CORBA::string_dup("Test");
         try
         {
            obj = rootContext->resolve(name);
            cout << "Test Naming Context already bound in Naming Service" 
                 << endl;
         }
         catch (const CosNaming::NamingContext::NotFound& ne)
         {   
            cout << "Binding Test Naming Context in Naming Service" << endl;
            CosNaming::NamingContext_var tmp = 
               rootContext->bind_new_context( name );
         }
         catch (...)
         {
            cerr << "Unhandled exception from rootContext->resolve(name)" 
                 << endl;
            throw 0;
         }

         // Activate the TestInterface object on the root POA
         PortableServer::ObjectId_var objId = 
            rootPOA->activate_object( &testServant );
         
         // Rebind the TestInterface object reference in the Test Naming Context
         name.length(2);
         name[1].id = CORBA::string_dup( "testObject" );
         obj = rootPOA->id_to_reference( objId.in() );
         rootContext->rebind( name, obj.in() );
         cout << "TestInterface object bound in Naming Service" << endl;

         //----------------
         // PROCESS EVENTS
         //----------------
       
         ACE_Time_Value tv(20);    // run for 10 seconds
         cout << "calling run for 20 seconds" << endl;
         orb->run( &tv );
         rootPOA->deactivate_object( objId );
         cout << "object deactivated" << endl;
         orb->run();
//       orb->destroy();
      }
      {   
         orb->run();
      }
      
   }
   catch (const CORBA::SystemException &se)
   {
      cerr << "Unexpected CORBA::SystemExpection caught in main " << &se << endl;
      throw 0;
   }
   catch (...)
   {
      cerr << "Unexpected non-CORBA exception caught in main " << endl;
      throw 0;
   }

   return 0;
}
