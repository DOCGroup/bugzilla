// client.cpp,v 1.13 2001/03/29 18:17:52 coryan Exp

#include "testC.h"
#include "tao/debug.h"
#include "ace/Get_Opt.h"
#include "ace/Task.h"
#include "tao/Messaging/Messaging.h"

ACE_RCSID(MT_Client, client, "client.cpp,v 1.13 2001/03/29 18:17:52 coryan Exp")

const char *ior = "file://test.ior";
int nthreads = 5;
int niterations = 5;
int server_shutdown = 0;
int act_like_server = 0;
int validate_attempts = 1000;
double timeout = 0.0;

#if defined (ACE_HAS_PURIFY)
#include "/net/mum/opt/pure/purify-2002.05/releases/purify.sol.2002a.06.00.Proto.0038/purify.h"
#endif

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "k:n:i:xsv:t:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'k':
        ior = get_opts.optarg;
        break;
      case 'n':
        nthreads = ACE_OS::atoi (get_opts.optarg);
        break;
      case 'i':
        niterations = ACE_OS::atoi (get_opts.optarg);
        break;
      case 'v':
        validate_attempts = ACE_OS::atoi (get_opts.optarg);
        break;
      case 't':
        timeout = ACE_OS::strtod (get_opts.optarg, 0);
        break;
      case 'x':
        server_shutdown = 1;
        break;
      case 's':
        act_like_server = 0;
        break;
      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-k <ior> "
                           "-n <nthreads> "
                           "-i <niterations> "
						   "-t <timeout> "
						   "-s <niterations> "
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}
class Worker : public ACE_Task_Base
{
  // = TITLE
  //   Run a server thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run server threads
  //
public:
  Worker (CORBA::ORB_ptr orb, ACE_Thread_Manager *mgr = 0);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

class Client : public ACE_Task_Base
{
  // = TITLE
  //   Run the client thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run the client threads.
  //
public:
  Client (Simple_Server_ptr server, ACE_Thread_Manager *mgr = 0, int niterations = 100);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  void validate_connection (ACE_ENV_SINGLE_ARG_DECL_NOT_USED);
  // Validate the connection

private:
  Simple_Server_var server_;
  // The server.

  int niterations_;
  // The number of iterations on each client thread.
};

int
main (int argc, char *argv[])
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "" ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      CORBA::Object_var object =
        orb->string_to_object (ior ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      Simple_Server_var server =
        Simple_Server::_narrow (object.in () ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (server.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Object reference <%s> is nil\n",
                             ior),
                            1);
        }

	  // Set CORBA timeouts
	  if (timeout > 0) {
                CORBA::Object_var OrbPolicyObj =
                    orb->resolve_initial_references("ORBPolicyManager");
                CORBA::PolicyManager_var policy_manager =
                    CORBA::PolicyManager::_narrow (OrbPolicyObj.in ());
                if (CORBA::is_nil (policy_manager.in () )) {
                }
				else
				{
					
					// Set Default TimeOut For all calls to be quite high
					// units are (100 nanoseconds) * 60 seconds/min * 2 minutes
					TimeBase::TimeT value(timeout*(1.0e7));
					CORBA::Any timeout_useconds;
					timeout_useconds <<= value;

                	CORBA::PolicyList policies(1);
					policies.length (1);
					
					policies[0] =
						orb->create_policy (Messaging::RELATIVE_RT_TIMEOUT_POLICY_TYPE,
											  timeout_useconds);

                	policy_manager->set_policy_overrides(policies, CORBA::SET_OVERRIDE);
				}
	  }

	  ACE_Thread_Manager worker_mgr;
      Worker worker (orb.in (), &worker_mgr);
	  if (act_like_server) {
		  if (worker.activate (THR_NEW_LWP | THR_JOINABLE,
							   nthreads) != 0)
			  ACE_ERROR_RETURN ((LM_ERROR,
								 "Cannot activate client threads\n"),
								1);
	  }

	  ACE_Thread_Manager client_mgr;
      Client client (server.in (), &client_mgr, niterations);
      if (client.activate (THR_NEW_LWP | THR_JOINABLE,
                           nthreads) != 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);

      client.thr_mgr ()->wait ();

      if (server_shutdown)
        {
          server->shutdown (ACE_ENV_SINGLE_ARG_PARAMETER);
          ACE_TRY_CHECK;
        }
      orb->shutdown(1);
      ACE_DEBUG ((LM_DEBUG, "threads finished\n"));
	  if (act_like_server) {
		  worker.thr_mgr ()->wait ();
		  ACE_DEBUG ((LM_DEBUG, "event loop finished\n"));
	  }

      orb->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Caught exception:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

// ****************************************************************

Client::Client (Simple_Server_ptr server,
				ACE_Thread_Manager *mgr,
                int niterations)
  :  ACE_Task_Base(mgr),
	 server_ (Simple_Server::_duplicate (server)),
     niterations_ (niterations)
{
}

void
Client::validate_connection (ACE_ENV_SINGLE_ARG_DECL)
{
  // Ping the object 100 times, ignoring all exceptions.
  // It would be better to use validate_connection() but the test must
  // run on minimum CORBA builds too!
	int failed = 0;
  for (int j = 0; j != validate_attempts; ++j)
    {
      ACE_TRY
        {
			//this->server_->test_method (j ACE_ENV_ARG_PARAMETER);
			//ACE_TRY_CHECK;
		  CORBA::String_var buf;
          this->server_->test_method_2 (j, buf.out() ACE_ENV_ARG_PARAMETER);
          ACE_TRY_CHECK;
		  if (failed && (TAO_debug_level > 0)) {
			  ACE_DEBUG ((LM_DEBUG, "(%P|%t) success after failure\n",
						  j));
			  failed = 0;
		  }
        }
      ACE_CATCHANY {
		  failed = 1;
	  } ACE_ENDTRY;
    }
}

int
Client::svc (void)
{
  ACE_TRY_NEW_ENV
    {
      this->validate_connection (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;


      for (int i = 0; i < this->niterations_; ++i)
        {
			//this->server_->test_method (i ACE_ENV_ARG_PARAMETER);
			//ACE_TRY_CHECK;

				CORBA::String_var buf;
				this->server_->test_method_2 (i, buf.out() ACE_ENV_ARG_PARAMETER);

				if (TAO_debug_level > 0 && i % 100 == 0)
					ACE_DEBUG ((LM_DEBUG, "(%P|%t) iteration = %d\n",
								i));
        }
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "MT_Client: exception raised");
    }
  ACE_ENDTRY;
  return 0;
}

Worker::Worker (CORBA::ORB_ptr orb, ACE_Thread_Manager *mgr)
	
  : ACE_Task_Base(mgr), orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
Worker::svc (void)
{
  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      this->orb_->run (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
    }
  ACE_ENDTRY;
  return 0;
}
