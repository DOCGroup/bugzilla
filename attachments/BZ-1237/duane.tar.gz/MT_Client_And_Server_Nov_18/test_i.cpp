// test_i.cpp,v 1.4 2001/05/20 15:46:57 bala Exp

#include "test_i.h"
#include "tao/debug.h"

#if !defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

ACE_RCSID(MT_Server, test_i, "test_i.cpp,v 1.4 2001/05/20 15:46:57 bala Exp")

CORBA::Long
Simple_Server_i::test_method (CORBA::Long x ACE_ENV_ARG_DECL_NOT_USED)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (TAO_debug_level > 0)
    ACE_DEBUG ((LM_DEBUG, "Request in thread %t\n"));
  ACE_Time_Value tv (0, 0);
  ACE_OS::sleep (tv);
  return x;
}
CORBA::Long
Simple_Server_i::test_method_2(CORBA::Long x, CORBA_String_out buf ACE_ENV_ARG_DECL_NOT_USED)
	ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (TAO_debug_level > 0)
    ACE_DEBUG ((LM_DEBUG, "Request in thread %t\n"));
  ACE_Time_Value tv (0, 0);
  ACE_OS::sleep (tv);
  int j = ACE_OS::rand() % 40000;
  buf = new char[j];
  memset(buf, 'x', j);
  buf[j-1] = 0;
  
  return x;
}

void
Simple_Server_i::shutdown (ACE_ENV_SINGLE_ARG_DECL)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0  ACE_ENV_ARG_PARAMETER);
}
