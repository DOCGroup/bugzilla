eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
  & eval 'exec perl -S $0 $argv:q'
  if 0;

# run_test.pl,v 1.9 2001/08/28 13:25:54 oci Exp
# -*- perl -*-

use strict;
use Getopt::Long;
use lib '../../../bin';
use PerlACE::Run_Test;

$ENV{"PURIFYOPTIONS"}='-report-pmrs=no -leaks-at-exit=no -fds-inuse-at-exit=no -inuse-at-exit=no -thread-report-at-exit=no -search-mmaps -max_threads=200 -chain-length=20 -free-queue-length=500 -freeze-on-error=no -windows=yes -log-file=./%v-%p.pure.log -output-limit=20000000000 -show-directory -add-suppression-files=/home/dbinder/work/PURIFY-MT-SUPPRESSIONS';

my $verbose = 1;
my $status = 0;
my $threads = '8';
my $iorfile = PerlACE::LocalFile ("test.ior");
my $sv_conf = PerlACE::LocalFile ("server.conf");
my $client_conf = PerlACE::LocalFile ("client.conf"); # "";
my $logfile = PerlACE::LocalFile("orb.client.log");
my $sv_logfile = PerlACE::LocalFile("orb.server.log");
my $serverthreads = 7;
my $clientthreads = 8;
my $debuglevel = 2;
my $basevalidations = 100;
my $iterations = 100;
my $clientrequesttimeout = 0.0;
my $port = PerlACE::uniqueid () + 10001 + $$; # This can't be 10000 for Chorus 4.0
my $endpoint = "localhost:$port";
my $useiorfile = 0;

my $result = GetOptions( "timeout=f" => \$clientrequesttimeout,
			 "useiorfile!" => \$useiorfile,
			 "debuglevel=i" => \$debuglevel,
			 "iterations=i" => \$iterations
);

if ($result == 0) {
  exit 1;
}


for(1..$iterations) {
  
  unlink $iorfile;
  unlink $logfile;
  unlink $sv_logfile;
  
  my $SV = new PerlACE::Process ("server", "-ORBEndpoint iiop://localhost:$port -ORBsvcconf $sv_conf -ORBLogFile $sv_logfile -o $iorfile -n $serverthreads");
  my $validations = $basevalidations + int ( rand() * 1000);

  # by default, use corbaloc:iiop....
  my $koption = "corbaloc:iiop:localhost:$port/Simple_Server";
  if ($useiorfile) {
    $koption = "file://$iorfile";
  }

  my $CL1 = new PerlACE::Process ("client", "-t $clientrequesttimeout -n $clientthreads -k $koption -ORBDebugLevel $debuglevel -ORBsvcconf $client_conf -ORBLogFile $logfile -i 100 -v $validations");
  
  print STDERR $SV->CommandLine(), "\n" if $verbose;
  
  $SV->Spawn ();
  
  if (PerlACE::waitforfile_timed ($iorfile, 10) == -1) {
    print STDERR "ERROR: cannot find file <$iorfile>\n";
    $SV->Kill ();
    exit 1;
  }
  print STDERR $CL1->CommandLine(), "\n" if $verbose;
  
  $CL1->Spawn ();
  system("ksh -xc 'renice 19 $CL1->{PROCESS}'");
  
  # sleep a random amount of time before killing the server
  my $j = int(rand(10)) + 2;
  
  print STDERR "sleep $j\n" if $verbose;
  
  # keep starting and stopping server until client completes
  my $client;
  my $server;
  while ( -1 == ($client = $CL1->TimedWait($j)) ) {
    
    $server = $SV->Kill();
    
    print "restarting server\n" if $verbose;
    
    unlink $iorfile;
    unlink $sv_logfile;
    
    $SV->Spawn();
    if (PerlACE::waitforfile_timed ($iorfile, 30 ) == -1) {
      print STDERR "ERROR: cannot find file <$iorfile>\n";
      $SV->Kill ();
    }
    $j = 2;
  }
  
  # quiet warnings about it still running at Destruction
  $CL1->{RUNNING} = 0;
  
  $server = $SV->Kill();
  
  if ( -f "core" ) 
    {
      rename( 'core', "core.$_");
      rename( $logfile, "$logfile.$_");
      print STDERR "ERROR: client ($_ of $iterations) dumped core\n";
    }
  unlink $logfile;
  unlink $iorfile;
  unlink $sv_logfile;

}

exit $status;
