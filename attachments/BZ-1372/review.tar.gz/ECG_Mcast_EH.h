/* -*- C++ -*- */
/**
 * @file ECG_Mcast_EH.h
 *
 * $Id: ECG_Mcast_EH.h,v 1.3 2002/01/29 20:20:48 okellogg Exp $
 *
 * @author Carlos O'Ryan <coryan@uci.edu>
 * @author Jaiganesh Balasubramanian <jai@doc.ece.uci.edu>
 *
 * http://doc.ece.uci.edu/~coryan/EC/index.html
 *
 */
#ifndef TAO_ECG_MCAST_EH_H
#define TAO_ECG_MCAST_EH_H
#include "ace/pre.h"

#include "orbsvcs/Event/ECG_Mcast_EH_T.h"

// @@ Don: This is all nice and cool! But how would you do this if you
// want to have a TAO_ECG_MCast_EH with a null lock?
typedef TAO_ECG_Mcast_EH_T<ACE_SYNCH_MUTEX> TAO_ECG_Mcast_EH;

#if defined(__ACE_INLINE__)
#include "ECG_Mcast_EH.i"
#endif /* __ACE_INLINE__ */

#include "ace/post.h"
#endif /* TAO_ECG_Mcast_EH_H */
