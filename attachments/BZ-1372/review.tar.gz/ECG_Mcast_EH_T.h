/* -*- C++ -*- */
/**
 * @file ECG_Mcast_EH_T.h
 *
 * $Id$
 *
 * @author Carlos O'Ryan <coryan@uci.edu>
 * @author Jaiganesh Balasubramanian <jai@doc.ece.uci.edu>
 * @author and Don Hinton <dhinton@ieee.org> refactored the original code into
 *         templatized version found here.
 *
 * http://doc.ece.uci.edu/~coryan/EC/index.html
 *
 */
#ifndef TAO_ECG_MCAST_EH_T_H
#define TAO_ECG_MCAST_EH_T_H
#include "ace/pre.h"

#include "orbsvcs/Event/event_export.h"
// @@ Don:These can go after the pragma..
#include "orbsvcs/RtecEventChannelAdminS.h"
#include "ace/Event_Handler.h"
#include "ace/Hash_Map_Manager.h"
#include "ace/Array_Base.h"
#include "ace/SOCK_Dgram_Mcast.h"
#include "ace/Synch.h"
#include "ace/Atomic_Op.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

// @@ Don: Why are we adding plain classes in *_T.h file? You could
// just leave parametrized classes  alone here..
/**
 * @class TAO_Mcast_Socket
 *
 * @brief Refcounted wrapper for ACE_SOCK_Dgram_Mcast>
 *
 * This class is a simple refcounted wrapper around ACE_SOCK_Dgram_Mcast that
 * makes takes care of deleting itself if the refcount drops to zero.
 */
class TAO_Mcast_Socket : public ACE_SOCK_Dgram_Mcast
{
  // @@Don: Why dont you use the TAO_Synch_Refcountable class instead
  // of doing all this here? The TAO class also uses the ACE_Lock*
  // that allows you to set the lock to null if needed in a ST
  // application.
public:
  /// Default Constructor
  TAO_Mcast_Socket (ACE_SOCK_Dgram_Mcast::options opts =
                    ACE_SOCK_Dgram_Mcast::DEFOPTS);

  /// Increment the refcount, count_.
  long add_ref (void);

  /// decrement the refcount, count_.  Deletes this when count_ reaches 0.
  long int remove_ref (void);

private:
  /// We need a friend so that we have a private dtor>
  friend class ACE_SOCK_Dgram_Mcast;

  /// Destructor.  Force it on the Heap, so we can call delete this in
  /// remove_ref().
  ~TAO_Mcast_Socket (void);

  /// Reference count>
  ACE_Atomic_Op<ACE_SYNCH_MUTEX, long> count_;
};

class TAO_ECG_UDP_Receiver;
class Observer;

/**
 * @class TAO_ECG_Mcast_EH_Base
 *
 * @brief Pure virtual base class for TAO_ECG_Mcast_EH_T.
 *
 * This class is needed in order to provide a polymorphic type to pass to the
 * Observerver class.  The previous implementation made Observer a nested
 * class, but that technique won't work on Windows when the Containing class
 * is a template and needs to pass it's type to methods of the nested type.
 */
// @@ Don: Exactly. Why do you want all this when you could do simple
// stuff as I mention below.
class TAO_ECG_Mcast_EH_Base : public ACE_Event_Handler
{
public:
   /// The Observer methods
  virtual void update_consumer (const RtecEventChannelAdmin::ConsumerQOS& sub
                        ACE_ENV_ARG_DECL_WITH_DEFAULTS)
      ACE_THROW_SPEC ((CORBA::SystemException)) = 0;
  virtual void update_supplier (const RtecEventChannelAdmin::SupplierQOS& pub
                        ACE_ENV_ARG_DECL_WITH_DEFAULTS)
      ACE_THROW_SPEC ((CORBA::SystemException)) = 0;
};



/**
 * @class TAO_ECG_Mcast_EH_T
 *
 * @brief Event Handler for UDP messages.
 *
 * This object receives callbacks from the Reactor when data is
 * available on the mcast socket, it forwards to the UDP_Receive
 * gateway which reads the events and transform it into an event.
 */
// @@ Don: I would as well prefer this class to have a ACE_Lock* as a
// member of the class and create the type of lock on demand. Just
// leave some hooks out there, so that people who want to configure
// this could use them at will. Please see how we do for
// TAO_Synch_Refcountable class for details.. Moreover, I am not sure
// what you buy by parametriing by the type of lock when you are using
// an ACE_Lock underneath. Remember that ACE_Lock itself is a
// parametric class :-)
template <class ACE_LOCK>
class TAO_ECG_Mcast_EH_T : public TAO_ECG_Mcast_EH_Base
{
public:

  /// Convenient typedef of our refcounted socket abstraction>
  //typedef TAO_Mcast_Socket_T<ACE_LOCK> SOCKET;

  /**
   * Constructor, the messages received by this EH are forwarded to
   * the <recv>.
   * It is possible to select the NIC where the multicast messages are
   * expected using <net_if>
   */
  TAO_ECG_Mcast_EH_T (TAO_ECG_UDP_Receiver *recv,
                      const ACE_TCHAR *net_if = 0);

  /// Destructor
  virtual ~TAO_ECG_Mcast_EH_T (void);

  /**
   * Register for changes in the EC subscription list.
   * When the subscription list becomes non-empty we join the proper
   * multicast groups (using the receiver to translate between event
   * types and mcast groups) and the class registers itself with the
   * reactor.
   */
  int open (RtecEventChannelAdmin::EventChannel_ptr ec
            ACE_ENV_ARG_DECL_WITH_DEFAULTS);

  /**
   * Remove ourselves from the event channel, unsubscribe from the
   * multicast groups, close the sockets and unsubscribe from the
   * reactor.
   */
  int close (ACE_ENV_SINGLE_ARG_DECL_WITH_DEFAULTS);

  /// Reactor callbacks
  virtual int handle_input (ACE_HANDLE fd = ACE_INVALID_HANDLE);

  virtual int handle_close (ACE_HANDLE fd,
                            ACE_Reactor_Mask close_mask);

  /// The Observer methods
  void update_consumer (const RtecEventChannelAdmin::ConsumerQOS& sub
                        ACE_ENV_ARG_DECL_WITH_DEFAULTS)
      ACE_THROW_SPEC ((CORBA::SystemException));
  void update_supplier (const RtecEventChannelAdmin::SupplierQOS& pub
                        ACE_ENV_ARG_DECL_WITH_DEFAULTS)
      ACE_THROW_SPEC ((CORBA::SystemException));

private:
  /// Find the SOCKET mapped to a particular fd.  find() holds a lock and calls
  /// add_ref() on SOCKET, if found, and returns a pointer to it.
  TAO_Mcast_Socket *find (ACE_HANDLE fd);

  typedef ACE_Unbounded_Set<ACE_INET_Addr> Address_Set;

  /// Compute the list of multicast addresses that we need to be
  /// subscribed to, in order to receive the events described in the
  /// ConsumerQOS parameter.
  /**
   * @param sub The list of event types that our event channel
   *        consumers are interested into.
   * @param multicast_addresses Returns the list of multicast
   *        addresses that we need to subscribe to.
   * @param env Used to raise CORBA exceptions when there is no
   *        support for native C++ exceptions.
   *
   * @throw CORBA::SystemException This method needs to perform
   *        several CORBA invocations and propagates any exceptions
   *        back to the caller.
   */

  void compute_required_subscriptions (
        const RtecEventChannelAdmin::ConsumerQOS& sub,
              Address_Set& multicast_addresses
              ACE_ENV_ARG_DECL)
              ACE_THROW_SPEC ((CORBA::SystemException));

  /// Delete the list of multicast addresses that we need not
  /// subscribe to, in order to receive the events described in the
  /// ConsumerQOS parameter.
  /**
   * @param multicast_addresses Returns the list of multicast
   *        addresses that we need to subscribe to.
   */

  int delete_unwanted_subscriptions (
              Address_Set& multicast_addresses);

  /// Add the list of new multicast addresses that we need to
  /// subscribe to, in order to receive the events described in the
  /// ConsumerQOS parameter.
  /**
   * @param multicast_addresses Returns the list of multicast
   *        addresses that we need to subscribe to.
   */

  void add_new_subscriptions (
              Address_Set& multicast_addresses);

  /// Subscribe an existing socket to a multicast group.
  /**
   * @param multicast_group Returns the multicast
   *        address that we need to subscribe to.
   */
  int subscribe_to_existing_socket (ACE_INET_Addr& multicast_group);

  /// Subscribe a new socket to a multicast group.
  /**
   * @param multicast_group Returns the multicast
   *        address that we need to subscribe to.
   */
  void subscribe_to_new_socket (ACE_INET_Addr& multicast_group);

private:
  /// The NIC name used to subscribe for multicast traffic.
  ACE_TCHAR *net_if_;

  /// Define the collection used to keep the iterator
  typedef ACE_Hash_Map_Manager<ACE_INET_Addr, TAO_Mcast_Socket *, ACE_Null_Mutex>
          Subscriptions_Map;
  typedef ACE_Hash_Map_Iterator<ACE_INET_Addr, TAO_Mcast_Socket *, ACE_Null_Mutex>
          Subscriptions_Iterator;

  /// Map of multicast address to SOCKETs, used to manage the subscription
  /// to multicast address by the update_{consumer|supplier} () methods.
  Subscriptions_Map subscriptions_;

  typedef ACE_Hash_Map_Manager<ACE_HANDLE, TAO_Mcast_Socket *, ACE_Null_Mutex>
          Handle_Map;
  typedef ACE_Hash_Map_Iterator<ACE_HANDLE, TAO_Mcast_Socket *, ACE_Null_Mutex>
          Handle_Iterator;

  /// Map of ACE_HANDLEs to SOCKETs.  Used to find the appropriate SOCKET in
  /// calls to handle_input ().
  Handle_Map handles_;

  /// The lock used to protect the lists.
  ACE_LOCK lock_;

  /// We callback to this object when a message arrives.
  TAO_ECG_UDP_Receiver* receiver_;

  /// This object will call us back when the subscription list
  /// changes.
  Observer observer_;

  /// Keep the handle of the observer so we can unregister later.
  RtecEventChannelAdmin::Observer_Handle handle_;

  /// The Event Channel.
  RtecEventChannelAdmin::EventChannel_var ec_;
};

/**
 * @class Observer
 *
 * @brief Observe changes in the EC subscriptions.
 *
 * As the subscriptions on the EC change we also change the
 * mcast groups that we join.
 * We could use the TIE classes, but they don't work in all
 * compilers.
 */
class Observer : public POA_RtecEventChannelAdmin::Observer
{
public:
  /// We report changes in the EC subscriptions to the event
  /// handler.
  Observer (TAO_ECG_Mcast_EH_Base* eh);

  // The Observer methods
  virtual void update_consumer (const RtecEventChannelAdmin::ConsumerQOS& sub
                                ACE_ENV_ARG_DECL_WITH_DEFAULTS)
    ACE_THROW_SPEC ((CORBA::SystemException));
  virtual void update_supplier (const RtecEventChannelAdmin::SupplierQOS& pub
                                ACE_ENV_ARG_DECL_WITH_DEFAULTS)
    ACE_THROW_SPEC ((CORBA::SystemException));

private:
  /// Our callback object.
  TAO_ECG_Mcast_EH_Base *eh_;
};

// @@ Don: Make it an inl file.
#if defined(__ACE_INLINE__)
#include "ECG_Mcast_EH_T.i"
#endif /* __ACE_INLINE__ */

#if defined (ACE_TEMPLATES_REQUIRE_SOURCE)
#include "ECG_Mcast_EH_T.cpp"
#endif /* ACE_TEMPLATES_REQUIRE_SOURCE */

#if defined (ACE_TEMPLATES_REQUIRE_PRAGMA)
#pragma implementation ("ECG_Mcast_EH_T.cpp")
#endif /* ACE_TEMPLATES_REQUIRE_PRAGMA */

#include "ace/post.h"
#endif /* TAO_ECG_Mcast_EH_T_H */
