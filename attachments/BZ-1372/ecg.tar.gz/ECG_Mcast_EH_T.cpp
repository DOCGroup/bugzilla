#ifndef TAO_ECG_MCAST_EH_T_C
#define TAO_ECG_MCAST_EH_T_C

#include "orbsvcs/Event/ECG_Mcast_EH.h"

#if !defined(__ACE_INLINE__)
#include "ECG_Mcast_EH_T.i"
#endif /* __ACE_INLINE__ */

#include "orbsvcs/Event/EC_Gateway_UDP.h"
#include "orbsvcs/Event_Service_Constants.h"

#include "ace/Reactor.h"

ACE_RCSID(Event, ECG_UDP_EH_T, "$Id$")

TAO_Mcast_Socket::TAO_Mcast_Socket (
    ACE_SOCK_Dgram_Mcast::options opts)
  : ACE_SOCK_Dgram_Mcast (opts),
    count_ (1)
{
}

TAO_Mcast_Socket::~TAO_Mcast_Socket (void)
{
  this->close ();
}
  
long
TAO_Mcast_Socket::add_ref (void)
{
  return ++this->count_;
}

long
TAO_Mcast_Socket::remove_ref (void)
{
  long count = --this->count_;
  if (count == 0)
    {
      this->close ();
      delete this;
    }
  return count;
}


template <class ACE_LOCK>
TAO_ECG_Mcast_EH_T<ACE_LOCK>::TAO_ECG_Mcast_EH_T (TAO_ECG_UDP_Receiver *recv,
                                                  const ACE_TCHAR *net_if)
  : net_if_ (ACE::strnew (net_if))
  , receiver_ (recv)
  , observer_ (this)
  , handle_ (0)
{
}

template <class ACE_LOCK>
TAO_ECG_Mcast_EH_T<ACE_LOCK>::~TAO_ECG_Mcast_EH_T (void)
{
  if (this->handle_)
    this->close ();
  ACE::strdelete (this->net_if_);
}

// @@ TODO Why have a return code *and* exceptions?  Only one would do!

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::open (RtecEventChannelAdmin::EventChannel_ptr ec
                                    ACE_ENV_ARG_DECL)
{
  ACE_MT (ACE_GUARD_RETURN (ACE_LOCK, ace_mon, this->lock_, -1));

  // Have we already been opened?
  if (this->handle_)
    return -1;

  // @@ TODO Think about the exception safety (or lack thereof) of
  // this code, what if the following operations fail?

  this->ec_ = RtecEventChannelAdmin::EventChannel::_duplicate (ec);

  // @@ TODO This activation should be configured by the application,
  // it is too much policy to use _this().
  // @@ TODO Using a full instance instead of a pointer makes memory
  // management complex.  The observer_ object should derive from
  // PortableServer::RefCountServantBase and use the POA to control
  // its lifetime.

  RtecEventChannelAdmin::Observer_var obs =
    this->observer_._this (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_CHECK_RETURN (-1);

  ACE_TRY
    {
      this->handle_ =
        this->ec_->append_observer (obs.in () ACE_ENV_ARG_PARAMETER);
      ACE_CHECK_RETURN (-1);
    }
  ACE_CATCH(CORBA::SystemException, ex)
    {
      // @@ TODO This code is tedious and error prone, plus its
      // exceptions should be ignored (no way to recover from them),
      // we should encapsulate it in a Deactivator.

      PortableServer::POA_var poa =
        this->observer_._default_POA (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_CHECK_RETURN (-1);
      PortableServer::ObjectId_var id =
        poa->servant_to_id (&this->observer_ ACE_ENV_ARG_PARAMETER);
      ACE_CHECK_RETURN (-1);
      poa->deactivate_object (id.in () ACE_ENV_ARG_PARAMETER);
      ACE_CHECK_RETURN (-1);

      ACE_RE_THROW;
    }
  ACE_ENDTRY;
  ACE_CHECK_RETURN (-1);

  return 0;
}

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::close (ACE_ENV_SINGLE_ARG_DECL)
{
  // handle_ is the Observer_Handle.
  if (this->handle_ == 0)
    return 0;

  ACE_MT (ACE_GUARD_RETURN (ACE_LOCK, ace_mon, this->lock_, -1));

  // Double check they we're open.
  if (this->handle_ == 0)
    return 0;

  Handle_Iterator h_iter = this->handles_.begin ();
  while (h_iter != this->handles_.end ())
    {
      TAO_Mcast_Socket *socket = (*h_iter).int_id_;
      ACE_HANDLE handle = (*h_iter).ext_id_;
      this->handles_.unbind (handle);
      if (this->reactor ()->remove_handler (handle,
                                            ACE_Event_Handler::ALL_EVENTS_MASK 
                                            | ACE_Event_Handler::DONT_CALL) == -1)
        ACE_ERROR ((LM_ERROR, 
                    ACE_TEXT ("failed to remove mcast handler from ")
                    ACE_TEXT ("reactor.\n")));
      socket->remove_ref ();
      ++h_iter;
    }
  
  // Once all the sockets are closed they no longer are subscribed for
  // anything
  this->subscriptions_.unbind_all ();

  RtecEventChannelAdmin::Observer_Handle h = this->handle_;
  this->handle_ = 0;
  this->ec_->remove_observer (h ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN (-1);

  // @@ TODO If the first operation raises an exception then the
  // second one never executes!!!
  {
    PortableServer::POA_var poa =
      this->observer_._default_POA (ACE_ENV_SINGLE_ARG_PARAMETER);
    ACE_CHECK_RETURN (-1);
    PortableServer::ObjectId_var id =
      poa->servant_to_id (&this->observer_ ACE_ENV_ARG_PARAMETER);
    ACE_CHECK_RETURN (-1);
    poa->deactivate_object (id.in () ACE_ENV_ARG_PARAMETER);
    ACE_CHECK_RETURN (-1);
  }

  return 0;
}

template <class ACE_LOCK> TAO_Mcast_Socket*
TAO_ECG_Mcast_EH_T<ACE_LOCK>::find (ACE_HANDLE fd)
{
  TAO_Mcast_Socket *socket = 0;

  ACE_MT (ACE_GUARD_RETURN (ACE_LOCK, ace_mon, this->lock_, 0));
  if (this->handles_.find (fd, socket) == 0)
    socket->add_ref ();
  return socket;
}

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::handle_input (ACE_HANDLE fd)
{
  long refcount = 0;
  TAO_Mcast_Socket *socket = this->find (fd);
  if (socket)
    {
      if (this->receiver_->handle_input (*socket) == -1)
	{
	  // Since we are working with UDP multicast sockets here, there aren't 
          // a whole lot of errors we can get that will make us want to close 
          // the close the socket, but if we return -1 to the reactor, that's
	  // exactly what will happend.  Or, more precisely, the reactor will
	  // remove us from it's handle set and call back our handle_close()
	  // method.  Since that's not what we generally want, we just log
	  // the message and always return 0.
	  ACE_DEBUG ((LM_DEBUG, 
		      ACE_TEXT ("handle_input() returned an error (%p)\n")));
	}

      // No matter what happened, we need to decrement the ref_count that
      // find() incremented.
      refcount = socket->remove_ref ();
    }
	       
  return 0;
}

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::handle_close (ACE_HANDLE /*fd*/,
                                            ACE_Reactor_Mask /*close_mask*/)
{
  return 0;
}

template <class ACE_LOCK> void
TAO_ECG_Mcast_EH_T<ACE_LOCK>::compute_required_subscriptions (
    const RtecEventChannelAdmin::ConsumerQOS& sub,
    Address_Set& multicast_addresses
    ACE_ENV_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  CORBA::ULong count = sub.dependencies.length ();
  for (CORBA::ULong i = 0; i != count; ++i)
    {
      const RtecEventComm::EventHeader& header =
                           sub.dependencies[i].event.header;
      if (0 <= header.type && header.type < ACE_ES_EVENT_UNDEFINED)
        {
          continue;
        }
      RtecUDPAdmin::UDP_Addr addr;

      // For the time being we are exception neutral, i.e., if an
      // exception is raised at this point we simply propagate it.
      // Notice that we haven't performed any changes to the state of
      // the current class, so this is the easiest approach.  The
      // alternatives are:
      // + Ignore the exception and continue with the operation: risky
      //   because we don't know if the exception indicated a
      //   temporary or permanent condition, and if it is the former
      //   we may loose an important multicast group, with no
      //   opportunity to recover it.
      // + Close the MCast Event Handler completely, too much policy
      //   for this level.
      this->receiver_->get_addr (header, addr ACE_ENV_ARG_PARAMETER);
      ACE_CHECK;

      ACE_INET_Addr inet_addr (addr.port, addr.ipaddr);
      // Ignore errors, if the element is in the set we simply ignore
      // the problem...
      (void) multicast_addresses.insert (inet_addr);
    }
}

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::delete_unwanted_subscriptions (
        Address_Set& multicast_addresses)
{
  ACE_MT (ACE_GUARD_RETURN (ACE_LOCK, ace_mon, this->lock_, 0));

  Subscriptions_Iterator j = this->subscriptions_.begin ();
  while (j != this->subscriptions_.end ())
    {
      ACE_INET_Addr multicast_group = (*j).ext_id_;
      if (multicast_addresses.find (multicast_group))
        {
          // Remove from the list of subscriptions that should be
          // added, because it is already there...
          (void) multicast_addresses.remove (multicast_group);
          ++j;
          continue;
        }

      this->subscriptions_.unbind (multicast_group);
      TAO_Mcast_Socket *socket = (*j).int_id_;
      // Ignore errors, there is no appropriate policy to handle them
      // at this layer.
      // @@ TODO Consider if we should raise exceptions.
      socket->leave (multicast_group, this->net_if_);
      if (this->reactor ()->remove_handler (socket->get_handle (),
                                            ACE_Event_Handler::ALL_EVENTS_MASK 
                                            | ACE_Event_Handler::DONT_CALL) 
          == -1)
        ACE_ERROR ((LM_ERROR, 
                    ACE_TEXT ("failed to remove mcast handler from ")
                    ACE_TEXT ("reactor.\n")));

      ACE_HANDLE handle = socket->get_handle ();
      this->handles_.unbind (handle);
      // We're done with it, so decrement the refcount so it can get 
      // deleted (either now or when it finishes an upcall.
      socket->remove_ref ();

      // Increment and then remove, this is a safe way to remove the
      // element without invalidating the iterator.
      ++j;
    }
    return 0;
}

template <class ACE_LOCK> int
TAO_ECG_Mcast_EH_T<ACE_LOCK>::subscribe_to_existing_socket (
        ACE_INET_Addr& multicast_group)
{
  ACE_MT (ACE_GUARD_RETURN (ACE_LOCK, ace_mon, this->lock_, 0));

  Handle_Iterator h_iter = this->handles_.begin ();
  while (h_iter != this->handles_.end ())
    {
      TAO_Mcast_Socket *socket = (*h_iter).int_id_;
      result = socket->join (multicast_group, 1, this->net_if_);
      if (result != -1)
        {
          // Add the subscription to the subscription list
          (void) this->subscriptions_.bind (multicast_group, socket);
          break;
        }
      ++h_iter;
    }
  return result;
}

template <class ACE_LOCK> void
TAO_ECG_Mcast_EH_T<ACE_LOCK>::subscribe_to_new_socket(
        ACE_INET_Addr& multicast_group)
{
  TAO_Mcast_Socket *socket;
  // Always bind the address, which means that we will only get traffic
  // that was sent to the "single" group we joined and won't get any
  // cross-talk.
  ACE_NEW (socket, TAO_Mcast_Socket(ACE_SOCK_Dgram_Mcast::OPT_BINDADDR_YES));

  socket->join (multicast_group, 1, this->net_if_);

  ACE_MT (ACE_GUARD (ACE_LOCK, ace_mon, this->lock_));

  this->handles_.bind (socket->get_handle (), socket);
  // @@ TODO: we have no way to handle this failure....
  (void) this->subscriptions_.bind (multicast_group, socket);

  // @@ TODO: we have no way to handle this failure....
  if (this->reactor ()->register_handler (socket->get_handle (),
                                          this,
                                          ACE_Event_Handler::READ_MASK) == -1)
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("reg handle failed\n")));
}

template <class ACE_LOCK> void
TAO_ECG_Mcast_EH_T<ACE_LOCK>::add_new_subscriptions (
    Address_Set& multicast_addresses)
{
  typedef ACE_Unbounded_Set_Iterator<ACE_INET_Addr> Address_Iterator;
  for (Address_Iterator k = multicast_addresses.begin ();
       k != multicast_addresses.end ();
       ++k)
    {
      // This is the multicast group we want to add to...
      ACE_INET_Addr multicast_group = *k;

      // Try to find a socket that has space for another multicast
      // group.
      int successful_subscription = -1;

      // It only makes sense to try subscribing to an existing
      // socket if the OS supports it.  Otherwise it will always
      // fail since we bind the address by default and you can't
      // join a multicast group that's different from the one
      // bound to the socket.
#if defined (ACE_LACKS_PERFECT_MULTICAST_FILTERING) \
    && (ACE_LACKS_PERFECT_MULTICAST_FILTERING == 0)
      successful_subscription = 
        this->subscribe_to_existing_socket (multicast_group);
# endif /* ACE_LACKS_PERFECT_MULTICAST_FILTERING == 1 */

      if (successful_subscription == -1)
        {
          // We try all the sockets and all of them appear to be full,
          // we need to open a new one and add it to the Array...
          this->subscribe_to_new_socket(multicast_group);
        }
    }
}

template <class ACE_LOCK> void
TAO_ECG_Mcast_EH_T<ACE_LOCK>::update_consumer (
    const RtecEventChannelAdmin::ConsumerQOS& sub
    ACE_ENV_ARG_DECL)
      ACE_THROW_SPEC ((CORBA::SystemException))
{
  // Make sure we are open for business.
  if (!this->handle_)
    return;

  // @@ TODO This function turned out to be too long, we need to break
  //    it up in pieces, maybe 3 or 4 private member functions....

  // 1) Figure out the list of multicast groups that we need to
  //    subscribe to

  Address_Set multicast_addresses;

  this->compute_required_subscriptions (sub, 
                                        multicast_addresses 
                                        ACE_ENV_ARG_PARAMETER);
  ACE_CHECK;

  // 2) To conserve OS and network resources we first unsubscribe from
  //    the multicast groups no longer wanted.  This is done by
  //    iterating over the current set of multicast groups and
  //    removing those not present in the "multicast_addresses" set.

  // Double check that we are open for business.
  if (!this->handle_)
    return;

  this->delete_unwanted_subscriptions (multicast_addresses);

  // 3) After the loop above the "multicast_addresses" set contains
  //    only the new subscriptions... go ahead and add them to the
  //    sockets, opening sockets if needed.

  this->add_new_subscriptions (multicast_addresses);
}

template <class ACE_LOCK> void
TAO_ECG_Mcast_EH_T<ACE_LOCK>::update_supplier (const RtecEventChannelAdmin::SupplierQOS&
                                     ACE_ENV_ARG_DECL_NOT_USED)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  // Do nothing
}

// ****************************************************************

Observer::Observer (
    TAO_ECG_Mcast_EH_Base* eh)
  :  eh_ (eh)
{
}

void
Observer::update_consumer (
    const RtecEventChannelAdmin::ConsumerQOS& sub
    ACE_ENV_ARG_DECL)
      ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->eh_->update_consumer (sub ACE_ENV_ARG_PARAMETER);
}

void
Observer::update_supplier (
    const RtecEventChannelAdmin::SupplierQOS& pub
    ACE_ENV_ARG_DECL)
      ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->eh_->update_supplier (pub ACE_ENV_ARG_PARAMETER);
}

#endif /* TAO_ECG_MCAST_EH_T_C */
