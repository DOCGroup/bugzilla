--- Asynch_Acceptor.cpp.5.4.7   2005-03-08 14:27:20.000000000 +0200
+++ Asynch_Acceptor.cpp 2005-11-13 15:28:50.803706800 +0200
@@ -363,18 +363,7 @@
 {
   ACE_TRACE ("ACE_Asynch_Acceptor<>::cancel");

-  // All I/O operations that are canceled will complete with the error
-  // ERROR_OPERATION_ABORTED. All completion notifications for the I/O
-  // operations will occur normally.
-#if (defined (ACE_HAS_WINNT4) && (ACE_HAS_WINNT4 != 0)) \
-    && (    defined (_MSC_VER) \
-        || (defined (__BORLANDC__) && (__BORLANDC__ >= 0x530)))
-  return (int) ::CancelIo (this->listen_handle_);
-#else
-  // Supported now
   return this->asynch_accept_.cancel();
-
-#endif /* (defined (ACE_HAS_WINNT4) && (ACE_HAS_WINNT4 != 0)) && ((defined (_MSC_VER)) || (defined (__BORLANDC__) && (_
_BORLANDC__ >= 0x530))) */
 }

 template <class HANDLER> void
