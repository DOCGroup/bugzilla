--- Asynch_Acceptor.h.5.4.7     2005-02-21 11:47:06.000000000 +0200
+++ Asynch_Acceptor.h   2005-11-13 15:38:18.386559000 +0200
@@ -133,10 +133,38 @@
   virtual int accept (size_t bytes_to_read = 0, const void *act = 0);

   /**
-   * Cancels all pending accepts operations issued by this object.
+   * (Attempts to) cancel all pending accepts operations issued by this object.
    *
-   * @note On Windows, only accept operations initiated by the calling thread
-   *       are canceled.
+   * All completion notifications for the I/O operations will occur
+   * normally.
+   *
+   * = Return Values:
+   *
+   * -1 : Operation failed. (can get only in POSIX).
+   *  0 : All the operations were cancelled.
+   *  1 : All the operations were already finished in this
+   *      handle. Unable to cancel them.
+   *  2 : At least one of the requested operations cannot be
+   *      cancelled.
+   *
+   * There is slight difference in the semantics between NT and POSIX
+   * platforms which is given below.
+   *
+   * = Win32 :
+   *
+   *   cancels all pending accepts operations that were issued by the
+   *   calling thread.  The function does not cancel asynchronous
+   *   operations issued by other threads.
+   *   All I/O operations that are canceled will complete with the
+   *   error ERROR_OPERATION_ABORTED.
+   *
+   * = POSIX:
+   *
+   *   Attempts to cancel one or more asynchronous I/O requests
+   *   currently outstanding against the <handle> registered in this
+   *   operation.
+   *   For requested operations that are successfully canceled, the
+   *   associated  error  status is set to ECANCELED.
    */
   virtual int cancel (void);
