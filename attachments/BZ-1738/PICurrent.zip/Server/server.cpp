
#include <fstream>
#include <iostream>
#include <string>

#include "testS.h"

#define IOR_FILE "./ior.txt"

class Test_i : public POA_Test2
{
public:
	void call2(Test1_ptr test1) ACE_THROW_SPEC ((CORBA::SystemException))
	{
		std::cout << "call2" << std::endl;
		test1->call1();
	}
};

int main(int argc, char** argv)
{
	try
	{
		CORBA::ORB_var orb = CORBA::ORB_init(argc,argv);
		{
			CORBA::Object_var poa_obj = orb->resolve_initial_references("RootPOA");
			PortableServer::POA_var root_poa = PortableServer::POA::_narrow(poa_obj);
			PortableServer::POAManager_var poa_manager = root_poa->the_POAManager();

			PortableServer::ServantBase_var test = new Test_i;
			PortableServer::ObjectId_var test_id = PortableServer::string_to_ObjectId("Test");

			root_poa->activate_object_with_id(test_id.in(),test.in());
			CORBA::Object_var test_obj = root_poa->id_to_reference(test_id.in());

			poa_manager->activate();

			std::string ior(orb->object_to_string(test_obj));
			std::cout << ior << std::endl;
			std::ofstream iorFile(IOR_FILE);
			iorFile << ior << std::endl;

			orb->run();
		}
	}
	catch (CORBA::Exception& ex)
	{
		std::cerr << "Caught CORBA exception " << ex << std::endl;
	}
	return 0;
}
