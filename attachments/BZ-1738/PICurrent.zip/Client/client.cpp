
#include <fstream>
#include <iostream>
#include <string>

#include <ace/OS.h>
#include <tao/ORBInitializer_Registry.h>
#include <tao/PortableServer/PortableServer_ORBInitializer.h>

#include "testS.h"

#define IOR_FILE "./ior.txt"

class Test_i : public POA_Test1
{
public:
	virtual void call1(void) ACE_THROW_SPEC ((CORBA::SystemException))
	{
		std::cout << "call1" << std::endl;
	}
};

class Interceptor : public PortableInterceptor::ServerRequestInterceptor
{
public:
	Interceptor(PortableInterceptor::ORBInitInfo_ptr info)
	{
		CORBA::Object_var pic_obj = info->resolve_initial_references("PICurrent");
		m_pic = PortableInterceptor::Current::_narrow(pic_obj.in());

		m_slot = info->allocate_slot_id();
	}

	char* name()
		ACE_THROW_SPEC ((CORBA::SystemException))
	{
		return CORBA::string_dup("foo");
	}

	void destroy()
		ACE_THROW_SPEC ((CORBA::SystemException))
	{
	}

	void receive_request_service_contexts(PortableInterceptor::ServerRequestInfo_ptr ri)
		ACE_THROW_SPEC ((CORBA::SystemException, PortableInterceptor::ForwardRequest))
	{
		CORBA::Any any;
		any <<= CORBA::Any::from_boolean(0);
		ri->set_slot(m_slot,any);
	}

	void receive_request(PortableInterceptor::ServerRequestInfo_ptr ri)
		ACE_THROW_SPEC ((CORBA::SystemException, PortableInterceptor::ForwardRequest))
	{
	}

	void send_reply(PortableInterceptor::ServerRequestInfo_ptr ri)
		ACE_THROW_SPEC ((CORBA::SystemException))
	{
	}

	void send_exception(PortableInterceptor::ServerRequestInfo_ptr ri)
		ACE_THROW_SPEC ((CORBA::SystemException, PortableInterceptor::ForwardRequest))
	{
	}

	void send_other(PortableInterceptor::ServerRequestInfo_ptr ri)
		ACE_THROW_SPEC ((CORBA::SystemException, PortableInterceptor::ForwardRequest))
	{
	}

private:
	PortableInterceptor::Current_var m_pic;
	PortableInterceptor::SlotId m_slot;
};

class Init : public PortableInterceptor::ORBInitializer
{
public:
	Init()
	{
	}

	void pre_init(PortableInterceptor::ORBInitInfo_ptr)
		ACE_THROW_SPEC ((CORBA::SystemException))
	{
	}

	void post_init(PortableInterceptor::ORBInitInfo_ptr info)
		ACE_THROW_SPEC ((CORBA::SystemException))
	{
		PortableInterceptor::ServerRequestInterceptor_var sri = new Interceptor(info);
		info->add_server_request_interceptor(sri.in());
	}

private:
	// The name of this interceptor
	std::string m_name;
};

int main(int argc, char** argv)
{
	try
	{
		PortableInterceptor::ORBInitializer_var init = new Init();
		PortableInterceptor::register_orb_initializer(init.in());

		CORBA::ORB_var orb = CORBA::ORB_init(argc,argv);
		{
			CORBA::Object_var poa_obj = orb->resolve_initial_references("RootPOA");
			PortableServer::POA_var root_poa = PortableServer::POA::_narrow(poa_obj);
			PortableServer::POAManager_var poa_manager = root_poa->the_POAManager();

			PortableServer::ServantBase_var test = new Test_i;
			PortableServer::ObjectId_var test_id = PortableServer::string_to_ObjectId("Test");

			root_poa->activate_object_with_id(test_id.in(),test.in());
			CORBA::Object_var test_obj = root_poa->id_to_reference(test_id.in());
			Test1_var client = Test1::_narrow(test_obj);

			poa_manager->activate();

			std::ifstream iorFile(IOR_FILE);
			std::string ior;
			iorFile >> ior;
			std::cout << ior << std::endl;

			CORBA::Object_var server_obj = orb->string_to_object(ior.c_str());
			Test2_var server = Test2::_narrow(server_obj);

			while (true)
			{
				server->call2(client.in());
				ACE_OS::sleep(1);
			}
		}
	}
	catch (CORBA::Exception& ex)
	{
		std::cerr << "Caught CORBA exception " << ex << std::endl;
	}
	return 0;
}
