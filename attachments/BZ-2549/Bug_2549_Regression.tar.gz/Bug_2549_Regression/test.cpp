// $Id: test.cpp,v 1.1 2006/05/26 07:28:14 sm Exp $

#include "testS.h"

int main (int, char*[])
{
  return 0;
}
