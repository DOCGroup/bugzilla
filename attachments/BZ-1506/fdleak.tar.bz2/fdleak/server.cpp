#include <tao/corba.h>

#include <iostream>
#include <fstream>

#include "DummyS.h"

using namespace std;
using namespace CORBA;
using namespace PortableServer;

class DummyServiceImpl
    : public virtual POA_Dummy::Service
    , public virtual RefCountServantBase
{
public:
    DummyServiceImpl() {}
  
    virtual ~DummyServiceImpl() {}
  
    virtual void ping() throw(::CORBA::SystemException)
    {
        cerr << ".";
    }
};

int run (int argc, char ** argv)
{
    // Setup ORB.
    ORB_var orb = ORB_init(argc, argv);

    // Setup POA
    Object_var poaobj = orb->resolve_initial_references("RootPOA");
    POA_var poa = POA::_narrow(poaobj.in());
    POAManager_var manager = poa->the_POAManager();
    manager->activate();

    // Create the DummyService implementation.
    ObjectId_var objid = poa->activate_object(new DummyServiceImpl);

    // Write the IOR reference to a file.
    Object_var obj = poa->id_to_reference(objid.in());

    String_var iorstr = orb->object_to_string(obj.in());
    ofstream iorfile("DummyService.ior");
    iorfile << iorstr.in() << endl;
    iorfile.close();

    // Run the ORBs event loop.
    cerr << "server (pid=" << getpid() << ") starting" << endl;
    orb->run();
    cerr << "server (pid=" << getpid() << ") finished" << endl;

    return 0;
}

int main(int argc, char ** argv)
{
    try
    {
        return run(argc, argv);
    }
    catch(CORBA::Exception const & ex)
    {
        cerr << "CAUGHT CORBA::Exception: " << ex._name() << endl;
    }
    catch (std::exception const & ex)
    {
        cerr << "CAUGHT std::exception: " << ex.what() << endl;
    }
    catch (...)
    {
        cerr << "CAUGHT unknown exception" << endl;
    }
    return 1;
}
