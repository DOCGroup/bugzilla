#include <tao/corba.h>

#include <string>
#include <iostream>
#include <fstream>

#include "DummyC.h"

using namespace std;
using namespace CORBA;

int
run(int argc, char ** argv)
{
    // Setup ORB.
    ORB_var orb = ORB_init(argc, argv);

    // Read the IOR from the file.
    string iorstr;
    ifstream iorfile("DummyService.ior");
    iorfile >> iorstr;

    // Narrow the object reference a Dummy::Service stub.
    Object_var dsobj = orb->string_to_object(iorstr.c_str());
    Dummy::Service_var ds = Dummy::Service::_narrow(dsobj.in());

    // Ping the Dummy::Service object.
    cerr << "client (pid=" << getpid() << ") starting" << endl;
    while (true)
    {
        try
        {
            ds->ping();
            cerr << '.';
        }
        catch (CORBA::COMM_FAILURE const & ex)
        {
            // If there is a problem, renarrow the object.
            dsobj = orb->string_to_object(iorstr.c_str());
            ds = Dummy::Service::_narrow(dsobj.in());

            cerr << '!';
        }
        ACE_OS::sleep(1);
    }
    cerr << "client (pid=" << getpid() << ") finished" << endl;

    orb->shutdown();
    orb->destroy();
    
    return 0;
}

int main(int argc, char ** argv)
{
    try
    {
        return run(argc, argv);
    }
    catch(CORBA::Exception const & ex)
    {
        cerr << "CAUGHT CORBA::Exception: " << ex._name() << endl;
    }
    catch (std::exception const & ex)
    {
        cerr << "CAUGHT std::exception: " << ex.what() << endl;
    }
    catch (...)
    {
        cerr << "CAUGHT unknown exception" << endl;
    }
    return 1;
}
