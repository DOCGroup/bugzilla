# ----------------------------------------------------------------
# Summary:

Client process leaks file descriptors when SSLIOP connections are
terminated by server.

The server is configured w/ a small connection cache
(-ORBConnectionCacheMax 1).

We connect two clients to the server using SSLIOP.  Each client
attempts to ping the server object periodically.

Since the server's connection pool is small, it terminates the
connections when the other client connection is made.

When clients see COMM_FAILURE, they re-create their stub and retry.

The client processes are leaking file descriptors, one per re-created
stub.


# ----------------------------------------------------------------
# To reproduce:

# Build client and server.
make

# Start server in shell #1:
./runserver

# Start 1st client in shell #2:
./runclient

# Start 2nd client in shell #3:
./runclient

# Observe client fd leak with shell #4
ls -l /proc/`/sbin/pidof -s client`/fd
