#ifndef Server__h_
#define Server__h_
/**
 * @file
 *
 * $Id$
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 *
 */
#include "TestS.h"

class Server : public POA_Test::Server
{
public:
  Server(CORBA::ORB_ptr orb);

  virtual void start_task(Test::Echo_ptr client
                          ACE_ENV_ARG_DECL_WITH_DEFAULTS)
    ACE_THROW_SPEC((CORBA::SystemException));

private:
  CORBA::ORB_var orb_;
};

#endif /* Server__h_ */
