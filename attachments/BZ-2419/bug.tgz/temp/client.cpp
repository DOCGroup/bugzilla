// $Id:$

#include "tao/corba.h"

#include "tao/Messaging/Messaging.h"
#include "ace/Get_Opt.h"

int main (int, char*[])
{
  return 0;
}
