#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "testC.h"

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  if (argc < 2) {
    std::cout << "usage: " << argv[0] << " <msg>" << std::endl;
    return 1;
  }

  /*
   * Read server's object reference.
   */

  Server_var server;
  std::string ior;

  std::ifstream iorfile ("server.ior");
  iorfile >> ior;

  try {
    CORBA::Object_var obj = orb->string_to_object (ior.c_str());
    server = Server::_narrow (obj);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: " << ex << std::endl;
    return 1;
  }

  try {
    server->foo (argv[1]);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << std::endl
	      << "Oops: " << ex
	      << std::endl;
    exit (1);
  }

  orb->shutdown (1);
  orb->destroy ();
  return 0;
}
