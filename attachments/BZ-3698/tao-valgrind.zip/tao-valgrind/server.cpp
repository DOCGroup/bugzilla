#include <iostream>
#include <fstream>
#include <string>
#include "testS.h"

CORBA::ORB_ptr serverOrb;

class Server_impl : virtual public POA_Server {
public:
  Server_impl ();
  void foo (const char *);
};

Server_impl::Server_impl ()
{
}

void
Server_impl::foo (const char * msg)
{
  std::cout << msg << std::endl;
  serverOrb->shutdown ();
}

int
main (int argc, char *argv[])
{
  try {
    serverOrb = CORBA::ORB_init (argc, argv);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: ORB_init: " << ex << std::endl;
    return 0;
  }
  catch (...) {
    std::cout << "Oops: ORB_init failed." << std::endl;
    return 0;
  }

  try {
    CORBA::Object_var obj = serverOrb->resolve_initial_references ("RootPOA");
    PortableServer::POA_var poa = PortableServer::POA::_narrow (obj);
    PortableServer::POAManager_var mgr = poa->the_POAManager ();
    mgr->activate ();

    /*
     * Activate server.
     */

    Server_impl * si = new Server_impl ();
    Server_var s = si->_this ();
    si->_remove_ref ();

    /*
     * Write object reference.
     */

    {
      std::ofstream iorfile ("server.ior");
      CORBA::String_var ior = serverOrb->object_to_string (s);
      iorfile << ior << std::endl;
    }

    /*
     * Run.
     */

    std::cout << "Running ... " << std::endl;
    serverOrb->run ();
    std::cout << "Shutting down ... " << std::endl;

    try {
      serverOrb->shutdown (1);
    }
    catch (const CORBA::BAD_INV_ORDER &) {
      // this is expected in a synchronous server
    }
    catch (const CORBA::Exception & ex) {
      std::cout << "Oops: " << ex << std::endl;
    }

    serverOrb->destroy ();
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: " << ex << std::endl;
  }
  catch (...) {
    std::cout << "Oops." << std::endl;
  }

  CORBA::release (serverOrb);
  return 0;
}
