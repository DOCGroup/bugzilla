#include "main.h"
#include "CtrlCSignalHandler.h"

int ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
// These definitions active the memory leak detection when running the code with MSVisualStudio
#if defined (WIN32) && defined (_DEBUG)
    // _CRTDBG_ALLOC_MEM_DF Enable debug heap allocations and use of memory block type identifiers, such as _CLIENT_BLOCK
    // _CRTDBG_LEAK_CHECK_DF Perform automatic leak checking at program exit and generate an error report if the application failed to free all the memory it allocated
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

    // This can be used to find the exact point where memory leaking allocation is made (execution will break)
    // Allocation must be made after this point! Therefore any allocation made before this point will not break.
    // Also memory leak identifier must be same (number x between curly brackets {x} e.g Dumping objects ->
    // {151} normal... => number is 151) every time the applicaiton is executed
    //_CrtSetBreakAlloc(864);

#endif /* (WIN32) && defined (_DEBUG) */ 

    // Start and register the close signal handler
    CtrlCSignalHandler pCtrlCSignalHandler(SIGINT);
    ACE_Sig_Handlers aceSignalHandler;
    int intSigKey = aceSignalHandler.register_handler (SIGINT, &pCtrlCSignalHandler);

    // Main program execution will stop here as long as Ctrl C (SIGINT) signal is received
    ACE_OS::printf("MAIN Process up and running \n");
    ACE_Reactor::instance ()->run_reactor_event_loop();
    // Remove handler and clear handler memory
    aceSignalHandler.remove_handler(SIGINT, 0 , 0, intSigKey);
    // Reset event loop, so it is ready to receive another signal (if needed)
    ACE_Reactor::instance ()->reset_reactor_event_loop();

    // Depends on IDE settings, if this is needed or not (to see the not released memory areas)
#if defined (WIN32) && defined (_DEBUG)
    //_CrtDumpMemoryLeaks(); 
#endif /* (WIN32) && defined (_DEBUG) */ 
    return 0;
}

