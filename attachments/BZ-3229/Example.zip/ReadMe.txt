// These are the instructions how to create project and make files for Example executable

// Windows

cd C:\tmp\Example
c:
perl C:\o2s2a\ThirdPartySoftware\ACE\Source\ACE+TAO+CIAO-5.6.2\ACE_wrappers\bin\mwc.pl Workspace.mwc -type vc71 -expand_vars


// Linux

ACE_ROOT=/home/o2s2a/ThirdPartySoftware/ACE/Source/ACE+TAO+CIAO-5.6.2/ACE_wrappers; export ACE_ROOT
PATH=$PATH:$ACE_ROOT:$ACE_ROOT/bin/:$ACE_ROOT/lib/

// Release build
cd /tmp/Example/
$ACE_ROOT/bin/mwc.pl Workspace.mwc -type make -expand_vars

// Debug build
cd /tmp/Example/
$ACE_ROOT/bin/mwc.pl Workspace.mwc -type make -expand_vars -value_template configurations=Debug

