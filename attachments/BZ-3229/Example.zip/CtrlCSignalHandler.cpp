#include "CtrlCSignalHandler.h"

CtrlCSignalHandler::CtrlCSignalHandler(int signum) : m_signum(signum)
{
}

CtrlCSignalHandler::~CtrlCSignalHandler()
{
}

int CtrlCSignalHandler::handle_signal (int signum, siginfo_t *, ucontext_t *)
{
    ACE_OS::printf("CtrlCSignalHandler::handle_signal Signal number %d received\n", signum);

    // If correct signal is received, start shutdown
    if(signum == m_signum)
        ACE_Reactor::instance()->end_reactor_event_loop();

    return 0;
}


