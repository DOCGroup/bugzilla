#ifndef CTRLCSIGNALHANDLER_H
#define CTRLCSIGNALHANDLER_H

#include "ace/Event_Handler.h"
#include "ace/Sig_Handler.h"
#include "ace/Reactor.h"
#include "ace/OS.h"

class CtrlCSignalHandler : public ACE_Event_Handler
{
public:
    CtrlCSignalHandler(int signum);
    virtual ~CtrlCSignalHandler();

    virtual int handle_signal (int signum, siginfo_t * = 0, ucontext_t * = 0);

private:
    int m_signum;
};

#endif /* CTRLCSIGNALHANDLER_H */
