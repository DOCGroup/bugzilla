#ifndef MAIN_H
#define MAIN_H

#include "ace/Log_Msg.h"
#include "ace/OS.h"
#include "ace/Get_Opt.h"

#if defined (WIN32) && defined (_DEBUG)
#define CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif /* (WIN32) && defined (_DEBUG) */

#endif /* MAIN_H */
