// $Id: client.cpp,v 1.3 2008/10/24 14:50:29 vz Exp $

#include "ace/Get_Opt.h"
#include "ace/Synch.h"
#include "testC.h"

ACE_RCSID(Bug_3524_Regression,
          client,
          "$Id: client.cpp,v 1.3 2008/10/24 14:50:29 vz Exp $")

const ACE_TCHAR *ior = ACE_TEXT ("file://test.ior");

int
parse_args (int argc, ACE_TCHAR *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, ACE_TEXT ("k:"));
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'k':
        ior = get_opts.opt_arg ();
        break;
      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           ACE_TEXT ("usage:  %s ")
                           ACE_TEXT ("-v ")
                           ACE_TEXT ("\n"),
                           argv [0]),
                          -1);
      }
  return 0;
}

int
ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  int status = 0;

  try
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv);

      if (parse_args (argc, argv) != 0)
        return 1;

      CORBA::Object_var object =
        orb->string_to_object (ior);

      Test::A_var server =
        Test::A::_narrow (object.in ());

      if (CORBA::is_nil (server.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             ACE_TEXT ("Object reference <%s> is nil\n"),
                             ior),
                            1);
        }

      try
        {
          CORBA::String_var arg2, arg3;
          CORBA::String_var res = server->method (::Test::A::RETN,
                                                  "A very long string.",
                                                  arg2,
                                                  arg3);
        }
      catch (const CORBA::BAD_PARAM &)
        {
          // it's ok
        }
      catch (const CORBA::Exception &)
        {
          status = 1;
          ACE_ERROR ((LM_ERROR,
                      "ERROR: Wrong exception is thrown in call "
                      "with long in param.\n"));
        }

      try
        {
          // Now test how server will reply.
          CORBA::String_var arg2 = CORBA::string_dup ("A very long string.");
          CORBA::String_var arg3;
          CORBA::String_var res = server->method (::Test::A::ARG2,
                                                  "ok.",
                                                  arg2,
                                                  arg3);
        }
      catch (const CORBA::BAD_PARAM &)
        {
          // it's ok
        }
      catch (const CORBA::Exception &)
        {
          status = 1;
          ACE_ERROR ((LM_ERROR,
                      "ERROR: Wrong exception is thrown in call "
                      "with long out param.\n"));
        }

      try
        {
          // Now test how server will reply.
          CORBA::String_var arg2;
          CORBA::String_var arg3 = CORBA::string_dup ("ok.");
          CORBA::String_var res = server->method (::Test::A::ARG3,
                                                  "ok.",
                                                  arg2,
                                                  arg3);
        }
      catch (const CORBA::BAD_PARAM &)
        {
          // it's ok
        }
      catch (const CORBA::Exception &)
        {
          status = 1;
          ACE_ERROR ((LM_ERROR,
                      "ERROR: Wrong exception is thrown in call "
                      "with correct params but when server sets "
                      "inout param incorrectly.\n"));
        }

      try
        {
          // Now test how server will reply.
          CORBA::String_var arg2;
          CORBA::String_var arg3 = CORBA::string_dup ("A very long string.");
          CORBA::String_var res = server->method (::Test::A::ARG3,
                                                  "ok.",
                                                  arg2,
                                                  arg3);
        }
      catch (const CORBA::BAD_PARAM &)
        {
          // it's ok
        }
      catch (const CORBA::Exception &)
        {
          status = 1;
          ACE_ERROR ((LM_ERROR,
                      "ERROR: Wrong exception is thrown in call "
                      "with long inout param.\n"));
        }

      try
        {
          // Now test how server will reply.
          CORBA::String_var arg2, arg3;
          CORBA::String_var res = server->method (::Test::A::RETN,
                                                  "ok.",
                                                  arg2,
                                                  arg3);
        }
      catch (const CORBA::BAD_PARAM &)
        {
          // it's ok
        }
      catch (const CORBA::Exception &)
        {
          status = 1;
          ACE_ERROR ((LM_ERROR,
                      "ERROR: Wrong exception is thrown in call "
                      "when server returns long string.\n"));
        }

      server->shutdown ();

      orb->destroy ();
    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception (
                               "Caught exception in client:");
      return 1;
    }

  return status;
}
