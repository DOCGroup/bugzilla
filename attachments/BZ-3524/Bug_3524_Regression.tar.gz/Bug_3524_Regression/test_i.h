// $Id: test_i.h,v 1.1 2003/08/27 22:43:35 vz Exp
// -*- C++ -*-

#ifndef TAO_INTERCEPTOR_TEST_I_H
#define TAO_INTERCEPTOR_TEST_I_H

#include "testS.h"

class A_i : public POA_Test::A
{
public:
  A_i (CORBA::ORB_ptr orb);

  char *method (::Test::A::FailOn where, const char *arg1, ::CORBA::String_out arg2, char *&arg3);

  void shutdown ();

private:

  /// The ORB pseudo-reference (for shutdown).
  CORBA::ORB_var orb_;
};

#endif /* TAO_INTERCEPTOR_TEST_I_H */
