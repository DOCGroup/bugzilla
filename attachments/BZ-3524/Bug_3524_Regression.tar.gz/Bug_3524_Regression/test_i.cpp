// $Id: test_i.cpp,v 1.1 2003/08/27 22:43:35 vz Exp

#include "test_i.h"

ACE_RCSID (Bug_3524_Regression,
           test_i,
           "$Id: test_i.cpp,v 1.3 2008/10/24 14:50:29 vz Exp $")

A_i::A_i (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

char *
A_i::method (::Test::A::FailOn where, const char *, ::CORBA::String_out arg2, char *&arg3)
{
  CORBA::String_var res = CORBA::string_dup ("ok.");
  switch (where)
    {
    case ::Test::A::ARG2:
      CORBA::string_free (arg3);
      arg2 = CORBA::string_dup ("A very long string.");
      arg3 = CORBA::string_dup ("ok.");
      res = CORBA::string_dup ("ok.");
      break;
    case ::Test::A::ARG3:
      CORBA::string_free (arg3);
      arg2 = CORBA::string_dup ("ok.");
      arg3 = CORBA::string_dup ("A very long string.");
      res = CORBA::string_dup ("ok.");
      break;
    case ::Test::A::RETN:
      CORBA::string_free (arg3);
      arg2 = CORBA::string_dup ("ok.");
      arg3 = CORBA::string_dup ("ok.");
      res = CORBA::string_dup ("A very long string.");
      break;
    }
  return res._retn ();
}

void
A_i::shutdown ()
{
  this->orb_->shutdown (0);
}
