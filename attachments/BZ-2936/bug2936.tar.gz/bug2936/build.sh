#!/bin/bash

set -e
#set -v

dir=`dirname ${0}`
cd ${dir}

if [ "${1}" == "version" ] ; then
  ACE_VERSION=${2}
  shift 2
else
  ACE_VERSION=1.5.8
fi

if [ "${1}" == "i686" ] ; then
  SYSPATH=/opt2/linux/i686
  shift 1
elif [ "${1}" == "x86_64" ] ; then
  SYSPATH=/opt2/linux/x86_64
  shift 1
else
  SYSPATH=/opt2/linux/x86_64
fi


ACE_ROOT=${SYSPATH}/ACE/${ACE_VERSION}/ACE_wrappers
TAO_ROOT=${ACE_ROOT}/TAO
CIAO_ROOT=${ACE_ROOT}/TAO/CIAO
DDS_ROOT=/tmp/notthere

export ACE_ROOT
export TAO_ROOT
export CIAO_ROOT
export DDS_ROOT


if [ ! -d ${ACE_ROOT} ] ; then
  echo ${ACE_ROOT} does not exist
  exit 1
fi


pwd=`pwd`
bugname=`basename ${pwd}`

rm -rf core* *.o *.so* .shobj .obj .depend* GNUmakefile* ${bugname} *~


if [ "${1}" == "tar" ] ; then
  cd ..
  tar -cvzf ${bugname}.tar.gz ${bugname}
  exit 0
else
  echo ACE_ROOT=${ACE_ROOT}
  echo TAO_ROOT=${TAO_ROOT}
  echo CIAO_ROOT=${CIAO_ROOT}
  echo DDS_ROOT=${DDS_ROOT}
  
  ${ACE_ROOT}/bin/mwc.pl -type gnuace
  
  make -f GNUmakefile debug=1 clean all
fi

LD_LIBRARY_PATH=.:${ACE_ROOT}/lib
export LD_LIBRARY_PATH

echo LD_LIBRARY_PATH=${LD_LIBRARY_PATH}


if [ "${1}" == "gdb" ] ; then
  gdb ./sig
elif [ "${1}" == "bash" ] ; then
  bash
else
  ulimit -c unlimited
  ./${bugname}
fi
