eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
     & eval 'exec perl -S $0 $argv:q'
     if 0;

# $Id: run_test.pl,v 1.1 2003/04/03 17:06:21 bala Exp $
# -*- perl -*-

use lib '../../../bin';
use PerlACE::Run_Test;

$iorfile = PerlACE::LocalFile ("server.ior");

$SV = new PerlACE::Process ("server", "-o $iorfile");
$CL1 = new PerlACE::Process ("client", "-k file://$iorfile");
$CL2 = new PerlACE::Process ("client", "-k file://$iorfile");
$CL3 = new PerlACE::Process ("client", "-k file://$iorfile");

local $start_time = time();
local $max_running_time = 600; # 10 minutes
my $elapsed = 0;

print STDERR "Running test for $max_running_time seconds...";
while($elapsed < $max_running_time) {

$elapsed = time() - $start_time; # Measure time after each iteration
unlink $iorfile;

my $sv = $SV->Spawn ();

if (PerlACE::waitforfile_timed ($iorfile, 5) == -1) {
    print STDERR "ERROR: cannot find file <$iorfile>\n";
    $SV->Kill(); $SV->TimedWait(1);
    exit 1;
}
# Start all clients in parallel
$client1 = $CL1->Spawn ();
$client2 = $CL2->Spawn ();
$client3 = $CL3->Spawn ();

if($client1 != 0 || $client2 != 0 || $client3 != 0) {
  print STDERR "\nERROR Cannot spawn one client\n";
  $CL1->WaitKill(1) if $client1 == 0;
  $CL2->WaitKill(1) if $client2 == 0;
  $CL3->WaitKill(1) if $client3 == 0;
  $SV->WaitKill(1) if $sv == 0;
}

# The server always aborts, so we ignore its status
$SV->WaitKill(60) unless $sv1 < 0;

$client1 = $CL1->WaitKill (3);
$client2 = $CL2->WaitKill (3);
$client3 = $CL3->WaitKill (3);

if ($client3 != 0 || $client2 != 0 || $client1 != 0) {
  print STDERR "\nERROR Client returned error\n";
  exit $status;
}

} # while(..)
print STDERR "done\n";



exit $status;
