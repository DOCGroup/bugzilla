#include <iostream>
#include <vector>
#include <cstring>
#include <cassert>
#include <tao/corba.h>

void
StringOutTest (CORBA::String_out so)
{
  CORBA::String_var sv;
  sv = "StringOutTest";
  so = sv._retn ();
}

void
StringInoutTest (char *& so)
{
  CORBA::string_free (so);
  so = CORBA::string_dup ("StringInoutTest");
}

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  CORBA::StringSeq ts;
  ts.length (1);
  ts[0] = CORBA::string_dup ("Hello World");

  StringOutTest (ts[0].out());
  assert (std::strcmp (ts[0].in(), "StringOutTest") == 0);

  StringInoutTest (ts[0].inout());
  assert (std::strcmp (ts[0].in(), "StringInoutTest") == 0);

  CORBA::String_var sv = ts[0]._retn ();
  ts[0] = CORBA::string_dup ("Hello Again");

  return 0;
}
