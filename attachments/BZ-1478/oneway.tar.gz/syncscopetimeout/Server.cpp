// one has 5 high-priority threads and queue-size of 20
// the other has 20 threads and a queue-size of 10

// stdlib
#include <fstream>

// corba includes
// #include <tao/RTPortableServer/RTPortableServer.h>

// project includes
#include "TestImpl.h"

void writeIORtoFile(CORBA::ORB_ptr orb,
		    CORBA::Object_ptr objRef)
{
    std::string filename("ior.txt");

    CORBA::String_var ior =
	orb->object_to_string(objRef);

    std::ofstream iorFile(filename.c_str());

    iorFile << ior << flush;
    iorFile.close();
}

int main(int argc, char** argv)
{
    // create the orb
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv, 0);

    // get the root poa
    CORBA::Object_var objRef = orb->resolve_initial_references("RootPOA");
    PortableServer::POA_var rootPOA =
	PortableServer::POA::_narrow(objRef.in());

    // create servant, activate in root poa and publish its ior
    TestImpl* tester = new TestImpl();
    objRef = rootPOA->servant_to_reference(tester);
    writeIORtoFile(orb, objRef);

    // activate poa
    rootPOA->the_POAManager()->activate();

    // start up the ORB
    orb->run();

    // done
    return 0;
}
