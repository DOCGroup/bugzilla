
// project
#include "TestC.h"
#include "tao/Messaging.h"

void usage(const char* progName)
{
    std::cerr << progName
	      << " <-none|-transport|-server|-target> <reps> [timeoutperiod]";
    exit(0);
}

int main(int argc, char* argv[])
{


    const char* progName = argv[0];
    
    if (argc < 3 || argc > 4)
	usage(progName);

    // sort out timeout settings

    int delay = -1;
    if (argc == 4) {
	delay = ACE_OS::atoi(argv[3]);
    }

    // sort out sync scope settings

    const char* policy = argv[1];

    Messaging::SyncScope syncScope;
    if (strcmp("-none", policy) == 0)
	syncScope = Messaging::SYNC_NONE;
    else if (strcmp("-transport", policy) == 0)
	syncScope = Messaging::SYNC_WITH_TRANSPORT;
    else if (strcmp("-server", policy) == 0)
	syncScope = Messaging::SYNC_WITH_SERVER;
    else if (strcmp("-target", policy) == 0)
	syncScope = Messaging::SYNC_WITH_TARGET;
    else
	usage(progName);

    // sort out number of invocations
    int invocations = ACE_OS::atoi(argv[2]);

    try {
	CORBA::ORB_var orb = CORBA::ORB_init(argc, argv, 0);

	// get the object
	CORBA::Object_var obj = orb->string_to_object("file://ior.txt");

	CORBA::PolicyList policies;

	// create the sync policy
	CORBA::Any syncPolicy;
	syncPolicy <<= syncScope;

	// policies if no timeout
	if (delay == -1)
	{
	    policies.length(1);
	    policies[0] =
		orb->create_policy(Messaging::SYNC_SCOPE_POLICY_TYPE,
				   syncPolicy);

	} 

	// policies if timeout
	else
	{
	    TimeBase::TimeT timeout = delay * 10000000;
	    
	    // insert into an any
	    CORBA::Any objectTimeout;
	    objectTimeout <<= timeout;

	    policies.length(2);
	    policies[0] =
		orb->create_policy(Messaging::RELATIVE_RT_TIMEOUT_POLICY_TYPE,
				   objectTimeout);
	    policies[1] =
		orb->create_policy(Messaging::SYNC_SCOPE_POLICY_TYPE,
				   syncPolicy);
	}

	obj = obj->_set_policy_overrides(policies, CORBA::SET_OVERRIDE);
	
	// clean up the policies
	policies[0]->destroy();
	if (delay != -1)
	    policies[1]->destroy();
	
	// narrow the object
	Test_var tester = Test::_narrow(obj);
	
	// invoke method twice
        for(int i = 0; i < invocations; ++i)
	{
	    tester->method();
	}
	
    } catch(const CORBA::TIMEOUT& e) {
	std:: cerr << "Timed out" << std::endl;
	return 1;
    } catch(const CORBA::SystemException & e) {
	std::cerr << "woops" << std::endl;
	std::cerr << e << std::endl;
	return 2;
    }

    return 0;
}
