#include <stdlib.h>

int wib()
{
    if(true)
	return 2;
    else
	exit(1);
}

int main(int argc, char* argv[])
{
    return wib();
}
