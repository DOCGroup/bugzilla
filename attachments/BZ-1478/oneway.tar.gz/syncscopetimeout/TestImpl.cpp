// very boring impl

#include "TestImpl.h"

// Implementation skeleton constructor
TestImpl::TestImpl() : count_(0) {}
  
// Implementation skeleton destructor
TestImpl::~TestImpl(){}

  
void TestImpl::method ()
    throw (CORBA::SystemException)
{
    std::cout << "Message " << ++count_ << " received...zzzz" << std::endl;
    ACE_OS::sleep(5);
    std::cout << "Waking up" << std::endl;
}  
