public class EchoCurrentImpl
    extends org.omg.CORBA.LocalObject
    implements EchoCurrent 
{

public EchoCurrentImpl(int slot_id, org.omg.PortableInterceptor.Current pi_current)
{
	slot_id_ = slot_id;
	pi_current_ = pi_current;
}

public void begin(String ctx)
{
	try {
		// check if context exists
		EchoContext context = getEchoContext();
		if (context != null) {
			System.out.println("begin: context already exists");
			return;
		}

		// create new context
		context = new EchoContext();
		context.ctx = ctx;
		context.elem = new EchoContextElem();
		context.elems = new EchoContextElem[0];

		// set slot
		org.omg.CORBA.Any context_any = org.omg.CORBA.ORB.init().create_any();
		EchoContextHelper.insert(context_any, context);
		context = EchoContextHelper.extract(context_any);
		pi_current_.set_slot(slot_id_, context_any);
	} catch (org.omg.PortableInterceptor.InvalidSlot e) {
		e.printStackTrace();
		return;
	}
}

public void commit()
{
	try {
		// check that context exists
		EchoContext context = getEchoContext();
		if (context == null) {
			System.out.println("commit: context does not exist");
			return;
		}

		// reset context
		org.omg.CORBA.Any null_any = org.omg.CORBA.ORB.init().create_any();
		pi_current_.set_slot(slot_id_, null_any);
	} catch (org.omg.PortableInterceptor.InvalidSlot e) {
		e.printStackTrace();
		return;
	}
}

public String get_context()
{
	EchoContext context = getEchoContext();
	if (context == null)
		return "";
	return context.ctx;
}

public int get_slot_id()
{
	return slot_id_;
}

private EchoContext getEchoContext()
{
	try {
		org.omg.CORBA.Any context_any = pi_current_.get_slot(slot_id_);
		if (context_any == null)
			return null;
		return EchoContextHelper.extract(context_any);
	} catch (org.omg.PortableInterceptor.InvalidSlot e) {
		e.printStackTrace();
		return null;
	} catch (org.omg.CORBA.MARSHAL e) {
		return null;
	}
}

private int slot_id_;
private org.omg.PortableInterceptor.Current pi_current_;

} // class EchoCurrentImpl
