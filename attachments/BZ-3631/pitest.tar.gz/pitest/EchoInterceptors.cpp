#include <tao/ORBInitializer_Registry.h>
#include <tao/PI/PI.h>
#include <tao/PI_Server/PI_Server.h>
#include <tao/LocalObject.h>

#include "EchoCurrentC.h"

namespace {

static unsigned char printable[] = "@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]<>^";

void
dump(const void *data, size_t len)
{
	const unsigned char *p = (const unsigned char *) data;

	size_t j = 0;
	for (size_t i = 0; i < len; i += j) {
		std::cout << std::hex << std::setw(8) << std::setfill('0') << i << ' ';
		for (j = 0; i + j < len && j < 16; ++j) {
			std::cout << std::hex << std::setw(2) << std::setfill('0')
			    << (int) p[i+j] << ' ';
		}
		for (j = 0; i + j < len && j < 16; ++j) {
			unsigned char c = p[i+j];
			if (c >= ' ')
				std::cout << c;
			else
				std::cout << '^' << printable[c];
		}
		std::cout << std::endl;
	}
}

}

class EchoCurrent_impl:
	public virtual EchoCurrent,
	public virtual CORBA::LocalObject
{
public:
	EchoCurrent_impl(
	    PortableInterceptor::SlotId slot_id,
	    PortableInterceptor::Current_ptr pi_current):
		slot_id_(slot_id),
		pi_current_(PortableInterceptor::Current::_duplicate(pi_current))
	{
		// empty
	}

	void
	begin(const char *ctx)
	{
		CORBA::Any_var slot_data = pi_current_->get_slot(slot_id_);
		const EchoContext *context = 0;
		if (slot_data.in() >>= context) {
			std::cerr << "EchoCurrent::begin: context already exists" << std::endl;
			return;
		}

		EchoContext_var new_context(new EchoContext);
		new_context->ctx = ctx;
		slot_data.inout() <<= new_context._retn();	// consuming insertion
		pi_current_->set_slot(slot_id_, slot_data.in());
	}

	void
	commit()
	{
		CORBA::Any_var slot_data = pi_current_->get_slot(slot_id_);
		const EchoContext *context = 0;
		if (!(slot_data.in() >>= context)) {
			std::cerr << "EchoCurrent::commit: context does not exist" << std::endl;
			return;
		}

		// reset context
		CORBA::Any null;
		pi_current_->set_slot(slot_id_, null);
	}

	char *
	get_context()
	{
		const char *ctx;

		CORBA::Any_var slot_data = pi_current_->get_slot(slot_id_);
		const EchoContext *context = 0;
		if (slot_data.in() >>= context) {
			ctx = context->ctx;
		} else {
			ctx = "";
		}

		return CORBA::string_dup(ctx);
	}

	PortableInterceptor::SlotId
	slot_id()
	{
		return slot_id_;
	}

	PortableInterceptor::Current_ptr
	pi_current()
	{
		return pi_current_.in();
	}

private:
	PortableInterceptor::SlotId slot_id_;
	PortableInterceptor::Current_var pi_current_;
};

/// Client request interceptor
class EchoClientRequestInterceptor:
	public virtual PortableInterceptor::ClientRequestInterceptor,
	public virtual CORBA::LocalObject
{
public:
	EchoClientRequestInterceptor(
	    EchoCurrent_impl *echo_current,
	    IOP::Codec_ptr codec):
		echo_current_(echo_current),
		codec_(IOP::Codec::_duplicate(codec))
	{
		// nothing to do
	}

	char *
	name()
	{
		return CORBA::string_dup("EchoClientRequestInterceptor");
	}

	void
	destroy()
	{
		// empty
	}

	void
	send_poll(PortableInterceptor::ClientRequestInfo_ptr)
	{
		// empty
	}

	void
	receive_reply(PortableInterceptor::ClientRequestInfo_ptr)
	{
		// empty
	}

	void
	receive_exception(PortableInterceptor::ClientRequestInfo_ptr)
	{
		// empty
	}

	void
	receive_other(PortableInterceptor::ClientRequestInfo_ptr)
	{
		// empty
	}

	void
	send_request(PortableInterceptor::ClientRequestInfo_ptr info)
	{
		CORBA::String_var operation = info->operation();

		// get slot data
		PortableInterceptor::SlotId slot_id = echo_current_->slot_id();
		CORBA::Any_var slot_data = info->get_slot(slot_id);
		CORBA::TypeCode_var slot_data_type = slot_data->type();
		if (slot_data_type->equal(CORBA::_tc_null)) {
#if 0
			std::cout << "send_request: " << operation.in()
			    << ": no context" << std::endl;
#endif
			return;
		}

		std::cout << "send_request: " << operation.in()
		    << ": got context" << std::endl;

		// generate service context
		CORBA::OctetSeq_var c = codec_->encode(slot_data.in());
		IOP::ServiceContext sc;
		sc.context_id = ECHO_CONTEXT;
		sc.context_data.replace(c->length(), c->length(), c->get_buffer());

		// set service context
		info->add_request_service_context(sc, 1);
	}

private:
	EchoCurrent_impl *echo_current_;
	IOP::Codec_var codec_;
};

/// Server request interceptor
class EchoServerRequestInterceptor:
	public virtual PortableInterceptor::ServerRequestInterceptor,
	public virtual CORBA::LocalObject
{
public:
	EchoServerRequestInterceptor(
	    EchoCurrent_impl *echo_current,
	    IOP::Codec_ptr codec):
		echo_current_(echo_current),
		codec_(IOP::Codec::_duplicate(codec))
	{
		// nothing to do
	}

	char *
	name()
	{
		return CORBA::string_dup("EchoServerRequestInterceptor");
	}

	void
	destroy()
	{
		// empty
	}

	void
	receive_request(PortableInterceptor::ServerRequestInfo_ptr)
	{
		// empty
	}

	void
	receive_request_service_contexts(PortableInterceptor::ServerRequestInfo_ptr info)
	{
		CORBA::String_var operation = info->operation();

		IOP::ServiceContext_var sc;
		try {
			sc = info->get_request_service_context(ECHO_CONTEXT);
		} catch (CORBA::BAD_PARAM &) {
#if 0
			std::cout << "receive_request_service_contexts: " << operation.in()
			    << ": no context received" << std::endl;
#endif
			return;
		}
		std::cout << "receive_request_service_contexts: " << operation.in()
		    << ": got context" << std::endl;

		try {
			// get EchoContext from service context
			CORBA::ULong len = sc->context_data.length();
			dump(sc->context_data.get_buffer(), len);
			CORBA::OctetSeq c(len, len, sc->context_data.get_buffer());
			CORBA::Any_var slot_data(codec_->decode(c));
			std::cout << "receive_request_service_contexts: " << operation.in()
			    << ": context decoded" << std::endl;

#if 1
			// check type
			CORBA::TypeCode_var slot_data_type = slot_data->type();
			if (!slot_data_type->equal(_tc_EchoContext)) {
				std::cout << "receive_request_service_contexts: " << operation.in()
				    << ": wrong context type" << std::endl;
				return;
			}
#endif

			// set slot
			PortableInterceptor::SlotId slot_id = echo_current_->slot_id();
			info->set_slot(slot_id, slot_data.in());
		} catch (CORBA::Exception &e) {
			std::cout << e._info() << std::endl;
			throw;
		}
	}

	void
	send_reply(PortableInterceptor::ServerRequestInfo_ptr)
	{
		// empty
	}

	void
	send_exception(PortableInterceptor::ServerRequestInfo_ptr)
	{
		// empty
	}

	void
	send_other(PortableInterceptor::ServerRequestInfo_ptr)
	{
		// empty
	}

private:
	EchoCurrent_impl *echo_current_;
	IOP::Codec_var codec_;
};

/// ORB initializer
class EchoORBInitializer:
	public virtual PortableInterceptor::ORBInitializer,
	public virtual CORBA::LocalObject
{
public:
	void
	pre_init(PortableInterceptor::ORBInitInfo_ptr info)
	{
		// empty
	}

	void
	post_init(PortableInterceptor::ORBInitInfo_ptr info)
	{
		// allocate slots
		PortableInterceptor::SlotId slot_id = info->allocate_slot_id();

		// get PICurrent
		CORBA::Object_var obj = info->resolve_initial_references("PICurrent");
		PortableInterceptor::Current_var pi_current =
		    PortableInterceptor::Current::_narrow(obj.in());
		if (CORBA::is_nil(pi_current.in()))
	                throw CORBA::INTERNAL();

		// create and register EchoCurrent
		EchoCurrent_impl *echo_current(
		    new EchoCurrent_impl(slot_id, pi_current.in()));
		info->register_initial_reference("EchoCurrent", echo_current);

		// get CodecFactory
	        obj = info->resolve_initial_references("CodecFactory");
	        IOP::CodecFactory_var codec_factory = IOP::CodecFactory::_narrow(obj.in());
	        if (CORBA::is_nil(codec_factory.in()))
	                throw CORBA::INTERNAL();

		// create Codec
		IOP::Encoding encoding;
		encoding.format = IOP::ENCODING_CDR_ENCAPS;
		encoding.major_version = 1;
		encoding.minor_version = 2;
		IOP::Codec_var codec = codec_factory->create_codec(encoding);

		// install client request interceptor
		PortableInterceptor::ClientRequestInterceptor_var client_ri(
		    new EchoClientRequestInterceptor(echo_current, codec.in()));
		info->add_client_request_interceptor(client_ri.in());

		// install server request interceptor
		PortableInterceptor::ServerRequestInterceptor_var server_ri(
		    new EchoServerRequestInterceptor(echo_current, codec.in()));
		info->add_server_request_interceptor(server_ri.in());
	}
};

int
registerEchoInitializer()
{
	PortableInterceptor::ORBInitializer_var initializer(new EchoORBInitializer);
	PortableInterceptor::register_orb_initializer(initializer.in());
}

int _registerEchoInitializer = registerEchoInitializer();
