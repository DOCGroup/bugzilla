#include <iostream>
#include <fstream>

#include <ace/Get_Opt.h>
#include <tao/ORB.h>

#include "EchoC.h"
#include "EchoCurrentC.h"

void
usage(const char *progname)
{
	std::cerr << "Usage: " << progname << " -f <iorfile>" << std::endl;
	exit(1);
}

int
main(int argc, char *argv[])
{
	try {
		// init ORB
		CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

		// parse options
		std::string iorfile;

		ACE_Get_Opt get_opts(argc, argv, "f:");
		int c = 0;
		while ((c = get_opts()) != -1) {
			switch (c) {
			case 'f':
				iorfile = get_opts.opt_arg();
				break;
			default:
				usage(argv[0]);
				// NOTREACHED
			}
		}
		if (iorfile.empty())
			usage(argv[0]);
		argc -= get_opts.opt_ind();
		argv += get_opts.opt_ind();

		// read IOR
		ifstream f(iorfile.c_str());
		if (!f) {
			std::cerr << "open: " << strerror(errno) << std::endl;
			exit(1);
		}
		std::string ior;
		f >> ior;
		f.close();
		std::cout << ior << std::endl;

		// resolve
		CORBA::Object_var obj = orb->string_to_object(ior.c_str());
		Echo_var echo = Echo::_narrow(obj.in());

		// get EchoCurrent
		obj = orb->resolve_initial_references("EchoCurrent");
		EchoCurrent_var echo_current = EchoCurrent::_narrow(obj.in());

		// call w/ context
		echo_current->begin("client");
		CORBA::String_var s = echo->echo_string("Hello");
		std::cout << "echo: " << s.in() << std::endl;
		echo_current->commit();

		// call w/o context
		s = echo->echo_string("world");
		std::cout << "echo: " << s.in() << std::endl;
	} catch (CORBA::SystemException &e) {
		std::cerr << "CORBA::SystemException: " << e._info() << std::endl;
		exit(1);
	}

	// we're done
	exit(0);
}
