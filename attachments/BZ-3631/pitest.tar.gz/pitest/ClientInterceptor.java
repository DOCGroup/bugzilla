public class ClientInterceptor
    extends org.omg.CORBA.LocalObject
    implements org.omg.PortableInterceptor.ClientRequestInterceptor
{

public ClientInterceptor(EchoCurrentImpl echo_current, org.omg.IOP.Codec codec)
{
	echo_current_ = echo_current;
	codec_ = codec;
}

public void send_request(org.omg.PortableInterceptor.ClientRequestInfo ri)
	throws org.omg.PortableInterceptor.ForwardRequest
{
	try {
		// get slot
		org.omg.CORBA.Any context_any = ri.get_slot(echo_current_.get_slot_id());
		if (context_any.type().kind().value() == org.omg.CORBA.TCKind._tk_null) {
			System.out.println("send_request(" + ri.operation() + "): no context");
			return;
		}
		System.out.println("send_request(" + ri.operation() + "): got context");

		// set service context
		org.omg.IOP.ServiceContext sc = new org.omg.IOP.ServiceContext();
		sc.context_id = ECHO_CONTEXT.value;
		sc.context_data = codec_.encode(context_any);
		ri.add_request_service_context(sc, true);
	} catch (org.omg.IOP.CodecPackage.InvalidTypeForEncoding e) {
		e.printStackTrace();
	} catch (org.omg.PortableInterceptor.InvalidSlot e) {
		e.printStackTrace();
	}
}

public void send_poll(org.omg.PortableInterceptor.ClientRequestInfo ri)
{
	System.out.println("send_poll: " + ri.operation());
}

public void receive_reply(org.omg.PortableInterceptor.ClientRequestInfo ri)
{
	System.out.println("receive_reply: " + ri.operation());
}

public void receive_exception(org.omg.PortableInterceptor.ClientRequestInfo ri)
	throws org.omg.PortableInterceptor.ForwardRequest
{
	System.out.println("receive_exception: " + ri.operation() + ": " + ri.received_exception_id());
}

public void receive_other(org.omg.PortableInterceptor.ClientRequestInfo ri)
	throws org.omg.PortableInterceptor.ForwardRequest
{
	System.out.println("receive_other: " + ri.operation());
}

public String name()
{
	return "ClientInterceptor";
}

public void destroy()
{
}

private EchoCurrentImpl echo_current_;
private org.omg.IOP.Codec codec_;

} // class ClientInterceptor
