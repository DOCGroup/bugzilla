public final class EchoClient
{

public static void main(String[] args)
{
	if (args.length == 0) {
		System.err.println("Usage: EchoClient <iorfile>");
		System.exit(1);
	}

        try {
		// init ORB
		java.util.Properties props = new java.util.Properties();
		props.put("org.omg.CORBA.ORBClass", "org.openorb.orb.core.ORB");
		props.put("org.omg.CORBA.ORBSingletonClass", "org.openorb.orb.core.ORBSingleton");
		props.put("org.omg.PortableInterceptor.ORBInitializerClass.Initializer", "");
		org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, props);

		// read IOR
		java.io.FileInputStream file = new java.io.FileInputStream(args[0]);
		java.io.BufferedReader in = new java.io.BufferedReader(
		    new java.io.InputStreamReader(file));
		String ior = in.readLine();
		file.close();

		// get reference
		org.omg.CORBA.Object obj = orb.string_to_object(ior);
		Echo echo = EchoHelper.narrow(obj);

		// get EchoCurrent
		obj = orb.resolve_initial_references("EchoCurrent");
		EchoCurrent echo_current = EchoCurrentHelper.narrow(obj);

		// perform call
		echo_current.begin("client");
		String s = echo.echo_string("Hello, world");
		System.out.println("echo: " + s);
		echo_current.commit();
        } catch  (java.lang.Exception e) {
		e.printStackTrace();
		System.exit(1);
        }
} // main

} // class EchoClient
