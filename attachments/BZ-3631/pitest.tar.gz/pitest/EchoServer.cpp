#include <iostream>
#include <fstream>
#include <sstream>

#include <ace/Get_Opt.h>

#include "EchoS.h"
#include "EchoCurrentC.h"

CORBA::String_var ior;

class Echo_impl: public POA_Echo {
public:
	Echo_impl(CORBA::ORB_ptr orb)
	{
		CORBA::Object_var obj = orb->resolve_initial_references("EchoCurrent");
		echo_current_ = EchoCurrent::_narrow(obj.in());
	}

	char *
	echo_string(const char *s)
	{
		std::cout << "echo(" << getctx() << "): " << s << std::endl;
		return CORBA::string_dup(s);
	}

	EchoContext *
	get_context()
	{
		EchoContext_var echo_context = new EchoContext;
		echo_context->ctx = "echo context";
		return echo_context._retn();
	}

private:
	std::string
	getctx()
	{
		std::ostringstream s;

		// print context (if any)
		CORBA::String_var ctx = echo_current_->get_context();
		if (strcmp(ctx.in(), "") != 0)
			s << "ctx: " << ctx.in();
		return s.str();
	}

	EchoCurrent_var echo_current_;
};

void
usage(const char *progname)
{
	std::cerr << "Usage: " << progname << " -f <iorfile>" << std::endl;
	exit(1);
}

int
main(int argc, char *argv[])
{
	try {
		// init ORB
		CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

		// parse options
		std::string iorfile;

		ACE_Get_Opt get_opts(argc, argv, "f:");
		int c = 0;
		while ((c = get_opts()) != -1) {
			switch (c) {
			case 'f':
				iorfile = get_opts.opt_arg();
				break;
			default:
				usage(argv[0]);
				// NOTREACHED
			}
		}
		if (iorfile.empty())
			usage(argv[0]);

		// init POA
		CORBA::Object_var obj = orb->resolve_initial_references("RootPOA");
		PortableServer::POA_var poa = PortableServer::POA::_narrow(obj.in());
		PortableServer::POAManager_var poa_mgr = poa->the_POAManager();
		poa_mgr->activate();

		// create servant
		Echo_impl echo_servant(orb.in());
		PortableServer::ObjectId_var id = poa->activate_object(&echo_servant);
		CORBA::Object_var ref = poa->id_to_reference(id.in());
		CORBA::String_var ior = orb->object_to_string(ref.in());
		std::cout << ior.in() << std::endl;

		// write IOR
		ofstream f(iorfile.c_str());
		f << ior;
		f.close();

		// ORB main loop
		orb->run();
	} catch (CORBA::SystemException &e) {
		std::cerr << "CORBA::SystemException: " << e._info() << std::endl;
		exit(1);
	}

	// we're done
	exit(0);
}
