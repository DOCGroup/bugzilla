public class Initializer
    extends org.omg.CORBA.LocalObject
    implements org.omg.PortableInterceptor.ORBInitializer
{

public void pre_init(org.omg.PortableInterceptor.ORBInitInfo info)
{
	// nothing to do
}

public void post_init(org.omg.PortableInterceptor.ORBInitInfo info)
{
	try {
		// create and register EchoCurrent
		int slot_id = info.allocate_slot_id();
		org.omg.PortableInterceptor.Current pi_current =
		    org.omg.PortableInterceptor.CurrentHelper.narrow(
			info.resolve_initial_references("PICurrent"));
		EchoCurrentImpl echo_current = new EchoCurrentImpl(slot_id, pi_current);
		info.register_initial_reference("EchoCurrent", echo_current);

		// create codec
		org.omg.IOP.Encoding encoding = new org.omg.IOP.Encoding();
		encoding.format = org.omg.IOP.ENCODING_CDR_ENCAPS.value;
		encoding.major_version = 1;
		encoding.minor_version = 2;
		org.omg.IOP.Codec codec = info.codec_factory().create_codec(encoding);

		// create and install client interceptor
		ClientInterceptor clientInterceptor = new ClientInterceptor(echo_current, codec);
		info.add_client_request_interceptor(clientInterceptor);
	} catch (org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName e) {
		e.printStackTrace();
	} catch (org.omg.PortableInterceptor.ORBInitInfoPackage.InvalidName e) {
		e.printStackTrace();
	} catch (org.omg.IOP.CodecFactoryPackage.UnknownEncoding e) {
		e.printStackTrace();
	}
}

} // class Initializer
