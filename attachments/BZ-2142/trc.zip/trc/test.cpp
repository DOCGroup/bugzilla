#include <iostream>
#include <assert.h>
#include "HelloS.h"

class Hello_impl :
  virtual public POA_Hello,
  virtual public PortableServer::RefCountServantBase
{
public:
  Hello_impl ()
  {
    std::cout << "Hello_impl::Hello_impl()" << std::endl;
  }

  ~Hello_impl ()
  {
    std::cout << "Hello_impl::~Hello_impl()" << std::endl;
  }

  void
  moo ()
  {
  }
};

CORBA::ULong
getRefCount (PortableServer::ServantBase * sb)
{
  PortableServer::RefCountServantBase * rcsb =
    dynamic_cast<PortableServer::RefCountServantBase *> (sb);
  return rcsb->_refcount_value ();
}

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);
  CORBA::Object_var poaobj = orb->resolve_initial_references ("RootPOA");
  PortableServer::POA_var poa = PortableServer::POA::_narrow (poaobj);

  Hello_impl * h = new Hello_impl;

  std::cout << "Before activation: "
	    << getRefCount (h)
	    << std::endl;

  PortableServer::ObjectId_var oid = poa->activate_object (h);

  std::cout << "After activation:  "
	    << getRefCount (h)
	    << std::endl;

  {
    /*
     * C++ Language Mapping (formal/03-06-03), section 1.37.3 (Servant
     * Memory Management Considerations), first bullet on page 1-136:
     *
     *   POA::id_to_servant returns a Servant. The POA invokes _add_ref
     *   once on the Servant before returning it; the caller of
     *   id_to_servant is responsible for invoking _remove_ref on the
     *   returned servant when it is finished with it.
     */

    CORBA::ULong refCountBeforeIdToServant = getRefCount (h);

    std::cout << "Before id_to_servant: "
	      << refCountBeforeIdToServant
	      << std::endl;

    PortableServer::ServantBase_var srv = poa->id_to_servant (oid.in());

    CORBA::ULong refCountAfterIdToServant = getRefCount (srv.in());

    std::cout << "After id_to_servant:  "
	      << refCountAfterIdToServant
	      << std::endl;

    /*
     * According to the above quote, this assertion shall be true.
     */

    assert (refCountAfterIdToServant == refCountBeforeIdToServant + 1);

    /*
     * At the end of this scope, "srv" is destructed, which decrements
     * the servant's reference count.
     */
  }

  std::cout << "Before deactivate_object: "
	    << getRefCount (h)
	    << std::endl;

  poa->deactivate_object (oid.in());

  /*
   * Because id_to_servant did not increment the reference count, but
   * the reference count was decremented by the "srv" destructor, the
   * reference count, using TAO 1.4.5, is now 0, and the servant has
   * been destructed. So the following will crash, despite being
   * correct.
   */

  std::cout << "After deactivate_object:  "
	    << getRefCount (h)
	    << std::endl;

  h->_remove_ref ();

  return 0;
}
