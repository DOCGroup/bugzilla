#include "ace\Pipe.h"
#include "ace\reactor.h"
#include "ace\event_handler.h"
#include "Reactortask.h"

#define _OBJECT_WIIL_LEAK // put in comment to stop object leak

#ifdef NDEBUG
#ifdef ACE_DEBUG
#undef  ACE_DEBUG

static const char message[] = "abcdefghijklmnopqrstuvwxyz";
static const int message_size = 26;

class Trace
{
public:
   Trace(const char* Str): m_Str(Str)
   {
      printf("Enter %s\n", m_Str);
   }
   ~Trace()
   {
      printf("Exit %s\n", m_Str);
   };
private:
   const char* m_Str;
};

class Log
{
public:
   Log(){};
   ~Log(){};

   void Print(int i, const char* Fmt, ...)
   {
      va_list marker;
      va_start( marker, Fmt );
      vprintf(Fmt, marker);
   };

};

Log gLog;

#define ACE_DEBUG(X) {gLog.Print X;}
#endif
#endif

//
// >>> TestEventHandler
//
// DESCRIPTION:
//
//
class TestEventHandler : public ACE_Event_Handler
{

public:

   // Constructor / destructor
   TestEventHandler(ACE_Reactor& R);
   virtual ~TestEventHandler();

   // classes, structures, unions

   // enumeration

   // function, method
   /// Called when input events occur (e.g., connection or data).
   virtual int handle_input (ACE_HANDLE fd = ACE_INVALID_HANDLE);

   /// Called when output events are possible (e.g., when flow control
   /// abates or non-blocking connection completes).
   virtual int handle_output (ACE_HANDLE fd = ACE_INVALID_HANDLE);

   /// Called when a <handle_*()> method returns -1 or when the
   /// <remove_handler> method is called on an <ACE_Reactor>.  The
   /// <close_mask> indicates which event has triggered the
   /// <handle_close> method callback on a particular <handle>.
   virtual int handle_close (ACE_HANDLE handle,
                            ACE_Reactor_Mask close_mask);


   virtual Reference_Count add_reference (void);

   virtual Reference_Count remove_reference (void);

   Reference_Count GetRefCnt() { return reference_count_.value ();}

  ACE_Pipe pipe_;       // Socket event simulator;
  bool Received_;
  ACE_Reactor_Mask masks_;
protected:
   // class, structure, union

   // enumeration

   // method

   // member

private:
   // Copy constructor
   TestEventHandler(const TestEventHandler& Src);

   // Assign operator
   TestEventHandler& operator=(const TestEventHandler& Src);

   // class, structure, union

   // enumeration

   // function, method

   // member

};

TestEventHandler::TestEventHandler(ACE_Reactor& R):
ACE_Event_Handler(&R),
Received_(false),
pipe_(),
masks_(0)
{
  Trace FctTrace("TestEventHandler::TestEventHandler");
  reference_counting_policy().value(Reference_Counting_Policy::ENABLED);

  ACE_DEBUG ((LM_DEBUG,
              "Reference count in TestEventHandler::TestEventHandler() is %d\n",
              this->reference_count_.value ()));

}

TestEventHandler::~TestEventHandler()
{
  Trace FctTrace("TestEventHandler::~TestEventHandler");
  ACE_DEBUG ((LM_DEBUG,
              "Reference count in TestEventHandler::~TestEventHandler() is %d\n",
              this->reference_count_.value ()));
}

int TestEventHandler::handle_input (ACE_HANDLE)
{
  Trace FctTrace("TestEventHandler::handle_input");
  ACE_DEBUG ((LM_DEBUG,
              "Reference count in TestEventHandler::handle_input() is %d\n",
              this->reference_count_.value ()));

  char buf[message_size + 1];

  ssize_t result =
    ACE::recv_n (this->pipe_.read_handle (),
                 buf,
                 sizeof buf - 1);

  ACE_ASSERT (result == message_size);

  buf[message_size] = '\0';

  ACE_DEBUG ((LM_DEBUG,
              "Message received: %s\n",
              buf));

  Received_ = true;
  return 0;
}

int TestEventHandler::handle_output (ACE_HANDLE)
{
  Trace FctTrace("TestEventHandler::handle_output");
  ACE_DEBUG ((LM_DEBUG,
              "Reference count in TestEventHandler::handle_output() is %d\n",
              this->reference_count_.value ()));

  ssize_t result =
    ACE::send_n (this->pipe_.write_handle (),
                 message,
                 message_size);

  ACE_ASSERT (result == message_size);

#ifndef _OBJECT_WIIL_LEAK
  ACE_CLR_BITS(masks_, WRITE_MASK);

  // No longer interested in output.
  return -1;
#else
  // By returning 0, will leak the object when the pipe is closed.
  return 0;
#endif
}


int TestEventHandler::handle_close (ACE_HANDLE handle, ACE_Reactor_Mask masks)
{
  Trace FctTrace("TestEventHandler::handle_close");
  ACE_DEBUG ((LM_DEBUG,
              "TestEventHandler::handle_close() called with handle = %d and masks = %d. "
              "Reference count is %d\n",
              handle,
              masks,
              this->reference_count_.value ()));

   if (ACE_BIT_ENABLED(masks, READ_MASK) && ACE_BIT_ENABLED(masks_, READ_MASK))
   {
      ACE_CLR_BITS(masks_, READ_MASK);
      reactor()->remove_handler(pipe_.read_handle(), READ_MASK | DONT_CALL);
      ACE_DEBUG ((LM_DEBUG,
                 "Reference count after remove_handler() read is %d\n",
                 this->reference_count_.value ()));
   }

   if (ACE_BIT_ENABLED(masks, WRITE_MASK) && ACE_BIT_ENABLED(masks_, WRITE_MASK))
   {
      ACE_CLR_BITS(masks_, WRITE_MASK);
      reactor()->remove_handler(pipe_.write_handle(), WRITE_MASK | DONT_CALL);
      ACE_DEBUG ((LM_DEBUG,
                 "Reference count after remove_handler() write is %d\n",
                 this->reference_count_.value ()));
   }

   if (masks_ == 0)
   {
      // Destroy this object by itself, same as delete this;
      remove_reference();
   }

   return 0;
}


ACE_Event_Handler::Reference_Count TestEventHandler::add_reference (void)
{
  Trace FctTrace("TestEventHandler::add_reference");
  ACE_Event_Handler::Reference_Count reference_count =
    this->ACE_Event_Handler::add_reference ();

  ACE_DEBUG ((LM_DEBUG,
              "Reference count after add_reference() is %d\n",
              this->reference_count_.value ()));

  return reference_count;
}

ACE_Event_Handler::Reference_Count TestEventHandler::remove_reference (void)
{
  Trace FctTrace("TestEventHandler::remove_reference");
  ACE_Event_Handler::Reference_Count reference_count =
    this->ACE_Event_Handler::remove_reference ();

  ACE_DEBUG ((LM_DEBUG,
              "Reference count after remove_reference() is %d\n",
              reference_count));

  return reference_count;
}


int main(int argc, char **argv)
{
   CReactorTask* ReactorTask = new CReactorTask();

   ReactorTask->Activate();


   // With 50 times will crash see WFMO_Reactor line #775 when _OBJECT_WIIL_LEAK is defined
   // will hang 50% of the time when _OBJECT_WIIL_LEAK is not defined.
   // Got a "HEAP: Free Heap block 869898 modified at 8698bc after it was freed"
   // when creating a second handler or an access violation, the reactor is referencing to an invalid object.

   for (int i=0; i < 2 ; i++ )
   {
      Trace FctTrace("new TestEventHandler");
      TestEventHandler* TestHandler = new TestEventHandler(ReactorTask->GetReactor());

      if (TestHandler)
      {
         if (TestHandler->pipe_.open () == 0)
         {
            ACE_SET_BITS(TestHandler->masks_, ACE_Event_Handler::READ_MASK | ACE_Event_Handler::WRITE_MASK);
            TestHandler->reactor()->register_handler(TestHandler->pipe_.read_handle(), TestHandler, ACE_Event_Handler::READ_MASK);
            ACE_DEBUG ((LM_DEBUG,
                       "Reference count after register_handler() read is %d\n",
                       TestHandler->GetRefCnt));
            TestHandler->reactor()->register_handler(TestHandler->pipe_.write_handle(), TestHandler , ACE_Event_Handler::WRITE_MASK);
            ACE_DEBUG ((LM_DEBUG,
                       "Reference count after register_handler() write is %d\n",
                       TestHandler->GetRefCnt()));

            while (!TestHandler->Received_)
            {
               ::Sleep(1);
            }

            ::Sleep(100);


            ACE_DEBUG ((LM_DEBUG,
                       "Reference count before pipe_.close() is %d\n",
                       TestHandler->GetRefCnt()));

            // Simulate socket close by remote peer.
            TestHandler->pipe_.close ();
            // TestHandler, from here, is ivalid since is will be deleted in handle_close

            TestHandler = NULL;

            ::Sleep(500);

         }
         else
         {
            // Delete this;
            TestHandler->remove_reference();
         }

      }

   }

   ReactorTask->Shutdown();
   delete ReactorTask;

   // TestHandler shall be deleted in handle_close

   return 0;
}