//*****************************************************************************
//
// Copyright 2001-2003 by Positron Public Safety Systems Inc.
// All rights reserved.
//
// No part of this document may be reproduced, stored in
// a retrieval system, or transmitted, in any form or by any means,
// electronic, mechanical, photocopying, recording, or otherwise,
// without the prior written permission of Positron Public Safety Systems Inc.
//
//*****************************************************************************
//    TITLE: ProactorTask
//    DESCRIPTION:
//             Defintion of the Reaction task class. This class is used to
//             pool the event loop of a ACE_Reactor.
//             
//             
//    AUTHOR      :  Alain Dupont
//    DATE CREATED:  20/4/2004
//
//*****************************************************************************
#ifndef _REACTORTASK_H_
#define _REACTORTASK_H_


// >>> Include files
#include "ace/Reactor.h"
#include "ace/task.h" 
#include "ace\synch.h"

// >>> Definitions, 


// >> Enumerations

// >>> Classes, Structures
// >>> CReactorTask
//
/// @brief Class instiate a reactor and its associate pooling task.
///
///
/// @author      : Alain Dupont
/// @date        : 4/20/2004
///
class CReactorTask : public virtual ACE_Task_Base
{

public:

   // Constructor / destructor
   CReactorTask(ACE_Reactor* Reactor = NULL);
   virtual ~CReactorTask();

   // classes, structures, unions 

   // enumeration

   // function, method

   /// @brief Activate task 
   virtual bool Activate();

   /// @brief Shutdown task 
   virtual void Shutdown();

   ACE_Reactor& GetReactor() { return *reactor();}

protected:

   // class, structure, union

   // enumeration

   // method

   virtual int svc(void);

   // member
   // Reactor
   bool                       m_ToDelete;

private:
   // Copy constructor
   CReactorTask(const CReactorTask& Src);

   // Assign operator
   CReactorTask& operator=(const CReactorTask& Src);

   // class, structure, union

   // enumeration

   // function, method


   // member

   // Debug information
   ACE_HANDLE                 m_WinHandle;

};

// >>> Public methods

#endif
// End of ReactorTask.h file
