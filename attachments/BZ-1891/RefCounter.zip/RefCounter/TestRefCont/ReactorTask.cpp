//*****************************************************************************
//
// Copyright 2001-2003 by Positron Public Safety Systems Inc.
// All rights reserved.
//
// No part of this document may be reproduced, stored in
// a retrieval system, or transmitted, in any form or by any means,
// electronic, mechanical, photocopying, recording, or otherwise,
// without the prior written permission of Positron Public Safety Systems Inc.
//
//*****************************************************************************
//    TITLE: ProactorTask
//    DESCRIPTION:
//             Implementation file of the reactor task class. This class is used to
//             pool the event loop of a ACE_Reactor.
//             
//    AUTHOR      :  Alain Dupont
//    DATE CREATED:  6/5/2003
//
//*****************************************************************************

// >>> Include files
#include "ReactorTask.h"

// >>> Variable
// >>>    Global

// >>> External
// >>>    variable
// >>>    function

// >>> Definition, Enumeration

// >>> Local class, structure

// >>> Variable
// >>>    Local

// >>> Prototypes

// >>> Implementation
// >>> CReactorTask::CReactorTask
//
//    DESCRIPTION:
//          Constructor
//
CReactorTask::CReactorTask(ACE_Reactor* Reactor):
ACE_Task_Base(),
m_ToDelete(false),
m_WinHandle(0)
{
   if (Reactor == NULL)
   {
      // Create local reactor
      Reactor = new ACE_Reactor();
   }

   // Initialize Task with the reactor.
   reactor(Reactor);
}

// >>> CReactorTask::~CReactorTask
//
//    DESCRIPTION:
//          Destructor
//          
//
CReactorTask::~CReactorTask()
{
   if (reactor())
   {
      reactor()->close();
      reactor(0);
   }
}

// >>> CReactorTask::Activate
//
//    DESCRIPTION:
//          Activate the ZBox task manager.
//    RETURN:
//          bool, true successful, otherwise false.
//
bool CReactorTask::Activate()
{

   // Is task started ?
   return (activate() == 0);
}
// >>> CReactorTask::Shutdown
//
//    DESCRIPTION:
//          Shutdown reactor and itd thread.
//
void CReactorTask::Shutdown()
{ 
   reactor()->end_reactor_event_loop();

   wait();

   reactor()->close();

   reactor(0);
}

// >>> CReactorTask::svc
//
//    DESCRIPTION:
//          Run by a daemon thread to pool Reactor's events loop.
//    RETURN
//          int, exit code
// 
int CReactorTask::svc(void)
{
   int Error = 0;
      
   // Save window's handle for debug purpused
   m_WinHandle = (ACE_HANDLE)::GetCurrentThreadId();

   ACE_thread_t TreadId = ACE_Thread::self();

   reactor()->owner(TreadId);

   if (reactor())
   {
      Error = reactor()->run_reactor_event_loop();
   }

   return Error;
}


// End of ReactorTask.cpp file
