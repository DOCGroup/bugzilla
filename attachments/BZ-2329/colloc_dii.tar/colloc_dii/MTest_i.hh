#ifndef MTest_i_hh
#define MTest_i_hh

#include <ace/Task.h>
#include <MTestS.hh>
#include <iostream>
#include <fstream>

extern CORBA::ORB_ptr g_orb;
extern PortableServer::POA_ptr g_poa;

class MyProxy_i: public virtual POA_MyProxy,
	       public virtual PortableServer::RefCountServantBase
{
public:
  MyProxy_i();
  
  virtual ~MyProxy_i();
  
  virtual void action(const char *string)
      throw(CORBA::SystemException);
  
  virtual PortableServer::POA_ptr _default_POA()
    { return PortableServer::POA::_duplicate(g_poa); }
  
private:
  CORBA::Object_var _peer;
};

class MyAction_i: public virtual POA_MyAction,
	       public virtual PortableServer::RefCountServantBase
{
public:
  MyAction_i();
  
  virtual ~MyAction_i();
  
  virtual char *test()
      throw(CORBA::SystemException);
  
  virtual PortableServer::POA_ptr _default_POA()
    { return PortableServer::POA::_duplicate(g_poa); }
  
private:
};

#endif 
