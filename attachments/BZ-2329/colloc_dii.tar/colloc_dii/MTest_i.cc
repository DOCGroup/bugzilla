#include <MTest_i.hh>
#include <iostream>
#include <fstream>
#include <assert.h>
#include <string>
#include <stdlib.h>
#include <tao/DynamicInterface/Request.h>

using namespace std;

CORBA::Object_var HackobjVar;

//==============================================================

MyProxy_i::MyProxy_i() 
{
  cerr << "MyProxy_i::MyProxy_i" << endl;
  
  PortableServer::ObjectId_var oidb =
	PortableServer::string_to_ObjectId("1");
  
  cerr << "MyProxy_i::MyProxy_i 1" << endl;

  // activate object
  g_poa->activate_object_with_id(oidb.in(), this);
  
  cerr << "MyProxy_i::MyProxy_i 2" << endl;

  // obtain pointer to object
  CORBA::Object_var objVar = g_poa->id_to_reference(oidb.in());
  
  cerr << "MyProxy_i::MyProxy_i 3" << endl;
  
  // stringify IOR and write to file
  CORBA::String_var ior = g_orb->object_to_string(objVar.in());
  string nm("test");
  nm += ".ior";
  std::ofstream iorfile(nm.c_str());
  iorfile<<ior.in()<<std::ends;
  iorfile.close();
}

MyProxy_i::~MyProxy_i()
{
  std::cout << "destructor of MyProxy_i::~MyProxy_i" <<std::endl;
}

void MyProxy_i::action(const char *act)
  throw(CORBA::SystemException)
{
  cerr << "proxy action called!!" << endl;

  MyAction_var subtest;
  subtest =  MyAction::_narrow(HackobjVar);
  CORBA::String_var expect = subtest->test();

  cerr << "EXPECTED " << expect << endl;

  CORBA::Request_var req = subtest->_request(act);

  req->set_return_type(CORBA::_tc_string);
  
  req->invoke();
  
  const char *xstr;
  req->return_value () >>= xstr;
  assert(xstr != NULL);  // <<=========== ASSERTS HERE!!!
  
  cerr << "EXTRACTED " << xstr << " X " << endl;
  
}

//==============================================================

MyAction_i::MyAction_i() 
{
  cerr << "MyAction_i::MyAction_i" << endl;
  
  PortableServer::ObjectId_var oidb =
	PortableServer::string_to_ObjectId("2");
  
  cerr << "MyAction_i::MyAction_i 1" << endl;

  // activate object
  g_poa->activate_object_with_id(oidb.in(), this);
  
  cerr << "MyAction_i::MyAction_i 2" << endl;

  // obtain pointer to object
  HackobjVar = g_poa->id_to_reference(oidb.in());
}

MyAction_i::~MyAction_i()
{
  std::cout << "destructor of MyAction_i::~MyAction_i" <<std::endl;
}

char *MyAction_i::test()
  throw(CORBA::SystemException)
{
  cerr << "action test called!!" << endl;

  return CORBA::string_dup("Hello");
}

