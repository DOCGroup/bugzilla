#include <tao/corba.h>
#include <MTest_i.hh>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char *argv[])
{

  // Command line parameters:
  // 1. mode (0=create test object, 1=just start event loop)
  // 2. server name/ persistent POA name
  cerr << "**** CLIENT STARTING UP" << endl;

  CORBA::ORB_var orb = CORBA::ORB_init(argc, argv, "TAO"); 

  std::string nm = "test.ior";
  std::ifstream iorfile(nm.c_str());
  char ior[500];
  iorfile>>ior;
  std::cout<<"ior ="<<ior<<std::endl;

  try {
	cerr << "client invoking server A" << endl;
	
	CORBA::Object_var obj = orb->string_to_object(ior);
	MyProxy_var b = MyProxy::_narrow(obj.in());
	
	cerr << "Before test() client" << endl;
	b->action("test");
	cerr << "After test() client" << endl;
  }
  catch(CORBA::SystemException &exc) {
	std::cerr<<"CORBA SYSTEM EXCEPTION: "<<exc<<std::endl; 
  }
  catch(CORBA::Exception &exc) {
	std::cerr<<"CORBA EXCEPTION: "<<exc<<std::endl; 
  }
  
  orb->destroy();

  return 0;
}
