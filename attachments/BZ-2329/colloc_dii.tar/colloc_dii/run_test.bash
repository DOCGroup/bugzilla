#!/bin/bash
#
# This script automatically starts up the ImplRepo_Service and ImR_Activator
# on entry and stops them on exit. 
# 
# 
# 
# 
# 
#

rm -f ImplRepo_pid ImR_Act_pid

echo -e "Start ImplRepo_Service"
ImplRepo_Service -ORBEndpoint iiop://claremont:3000 \
-o ./ImplRepo_Service.ior \
2>&1 > /dev/null &

sleep 3
echo -e "Start ImR_Activator"
ImR_Activator \
-ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService \
-t 90 -o ./ImplRepo_Activator.ior \
2>&1 > /dev/null &

sleep 3

ps | grep ImplRepo | sed 's/^ //g' | sed 's/  */ /g' | cut -f 1 -d' ' > ImplRepo_pid
ps | grep ImR_Act | sed 's/^ //g' | sed 's/  */ /g' | cut -f 1 -d' ' > ImR_Act_pid

tao_imr -ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService add A -c `pwd`"/server -- -ORBUseIMR 1 \
-ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService \
-ORBCollocation global -ORBCollocationStrategy thru_poa"

echo -e "\nEstablish server A\n"
`pwd`/server -- -ORBUseIMR 1 \
-ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService \
-ORBCollocation global -ORBCollocationStrategy thru_poa &
sleep 2

sleep 3
tao_imr -ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService shutdown A
sleep 3


# start client which should bring up server
echo -e "\nStep 2: bring up client and expect server to follow\n"
./client

sleep 3

# kill servers
echo -e "\nStep 3: kill servers\n"
tao_imr -ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService shutdown A

# remove servers from IMR
echo -e "\nStep 4: remove servers from IMR\n"
tao_imr -ORBInitRef ImplRepoService=corbaloc:iiop:1.2@claremont:3000/ImplRepoService remove A

kill -9 `cat ImR_Act_pid` `cat ImplRepo_pid` > /dev/null 2>&1

# rm -f ImplRepo_pid ImR_Act_pid

