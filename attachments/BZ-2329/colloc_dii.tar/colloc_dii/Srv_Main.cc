#include <tao/corba.h>
#include <MTest_i.hh>
#include <iostream>
#include <unistd.h>

using namespace std;

CORBA::ORB_ptr g_orb;
PortableServer::POA_ptr g_poa;

static CORBA::Object_var _peer;

int main(int argc, char *argv[])
{

  cerr << "**** SERVER STARTING UP" << endl;

  CORBA::ORB_var orb = CORBA::ORB_init(argc, argv, "TAO");
  
  g_orb = orb.in();
  
  CORBA::Object_var poa_object = orb->resolve_initial_references("RootPOA");
  
  if(CORBA::is_nil(poa_object.in())) {
    std::cout<<"Unable to initialize the RootPOA object"<<std::endl;
    return 0;
  }
  PortableServer::POA_var rootPOA = PortableServer::POA::_narrow(poa_object.in());
  PortableServer::POAManager_var rootPOAMgr = rootPOA->the_POAManager();
  
  CORBA::PolicyList policies(2);
  policies.length(2);
  
  policies[0] = rootPOA->create_lifespan_policy(PortableServer::PERSISTENT);
  policies[1] = rootPOA->create_id_assignment_policy(PortableServer::USER_ID);

  sleep(1);

  cerr<<"Create POA..."<<std::endl;
  PortableServer::POA_var thePOA = rootPOA->create_POA("test",
						       rootPOAMgr.in(),
						       policies);
  cerr<<"POA created"<<std::endl;
  g_poa = thePOA.in();
  
  for (CORBA::ULong i=0; i<policies.length(); ++i) {
    CORBA::Policy_ptr policy = policies[i];
    policy->destroy();
  }

  new MyProxy_i();
  new MyAction_i();

  try {
      cerr<< "Activate POA Manager..."<<std::endl;
      rootPOAMgr->activate();
      
      ACE_Time_Value timeout = 10000;
      cerr << "wait for requests" << endl;
      orb->run(timeout);
  }
  catch(CORBA::SystemException &exc)  {
    std::cout<<"A system exception caught: "<<exc<<std::endl;
  }
  
  orb->destroy();

  return 0;
}
