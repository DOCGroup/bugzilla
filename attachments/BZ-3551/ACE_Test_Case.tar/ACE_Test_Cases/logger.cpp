#include "logger.h"

namespace test_space
{
    void logger::init_logger(   const char *host,
                                const char *prog_name,
                                severity_t minimum_log_severity )
    {
        if( strlen(prog_name) >= sizeof(program_) )
        {
            throw std::logic_error(std::string("Buffer Overflow Program Name: ")
                                    + __PRETTY_FUNCTION__);
        }
        strcpy(program_, prog_name);

        if( strlen(host) >= sizeof(hostname_) )
        {
            throw std::logic_error(std::string("Buffer Overflow Hostname: ")
                                    + __PRETTY_FUNCTION__);
        }
        strcpy(hostname_, host);

        min_log_severity_ = minimum_log_severity;
        int open_result = open();
        if(open_result != 0)
        {
            throw std::runtime_error(std::string("Cannot spawn a new Thread: ")
                                        + __PRETTY_FUNCTION__);
        }
    };

    void logger::log_message(   severity_t severity_level,
                                unsigned int line_number,
                                const char *file,
                                const char *function_name,
                                const char *message_string )
    {
        time_t today_in_sec = time(NULL);

        logger_message *msg = new logger_message();
        msg->severity_   = severity_level;
        msg->datestamp_  = today_in_sec / (60 * 60 * 24);
        msg->timestamp_  = seconds_since_midnight();
        msg->line_       = line_number;

        if( sizeof(msg->source_) < strlen(function_name) )
        {
            throw std::logic_error(std::string("Buffer overflow: ")
                                    + std::string(function_name)
                                    + " : "
                                    + __PRETTY_FUNCTION__);
        }
        strcpy(msg->source_ , function_name);

        if( sizeof(msg->message_) < strlen(message_string) )
        {
            throw std::logic_error(std::string("Buffer overflow: ")
                                    + std::string(message_string)
                                    + " : "
                                    + __PRETTY_FUNCTION__);
        }
        strcpy(msg->message_ , message_string);

        if( sizeof(msg->filename_) < strlen(file) )
        {
            throw std::logic_error(std::string("Buffer overflow: ")
                                    + std::string(file)
                                    + " : "
                                    + __PRETTY_FUNCTION__);
        }
        strcpy(msg->filename_, file);

        strcpy(msg->program_, program_);
        strcpy(msg->hostname_, hostname_);

        ACE_Message_Block *mb = new ACE_Message_Block((char *)msg);
        ACE_Time_Value nowait( ACE_OS::gettimeofday() );
        if( -1 == put(mb, &nowait) )
        {
            throw std::runtime_error(std::string("Cannot put message onto the queue: ")
                                + __PRETTY_FUNCTION__);
            abort();
        }

        ACE_Notification_Buffer buffer(this, ACE_Event_Handler::READ_MASK);
        ssize_t n = ACE::send(  notification_pipe_.write_handle(),
                                (char *)&buffer,
                                sizeof(buffer));
        if( -1 == n )
        {
            throw std::runtime_error(
                    std::string("Cannot write notification for log_message: ")
                                + __PRETTY_FUNCTION__);
            abort();
        }
    };

    int logger::svc()
    {
        select_reactor_->register_handler(  notification_pipe_.read_handle(),
                                            this,
                                            ACE_Event_Handler::READ_MASK);
        reactor_->owner(ACE_OS::thr_self());
        reactor_->restart(1);
        reactor_->run_reactor_event_loop();
        return 0;
    };

    int logger::handle_input(ACE_HANDLE handle)
    {
        int result = 0;
        ACE_Notification_Buffer buffer;
        result = read_notify_pipe(handle, buffer);
        if(result < 0)
        {
            return result;
        }
        ACE_Message_Block *mb = NULL;
        ACE_Time_Value nowait( ACE_OS::gettimeofday() );
        while( getq(mb, &nowait) != -1 )
        {
            logger_message *msg = ((logger_message *)mb->rd_ptr());
            /// Do Stuff Here with the message
            delete msg;
            mb->release();
        }
        return 0;
    };

    int logger::open(void *)
    {
        if( -1 == this->notification_pipe_.open() )
        {
            return -1;
        }
#if defined (F_SETFD)
        ACE_OS::fcntl (this->notification_pipe_.read_handle (), F_SETFD, 1);
        ACE_OS::fcntl (this->notification_pipe_.write_handle (), F_SETFD, 1);
#endif /* F_SETFD */
        if( -1 == ACE::set_flags(this->notification_pipe_.read_handle(), ACE_NONBLOCK) )
        {
            return -1;
        }
        return this->activate(THR_NEW_LWP);
    };

    int logger::read_notify_pipe(ACE_HANDLE handle,
                                 ACE_Notification_Buffer& buffer)
    {
        ssize_t n = ACE::recv(handle, (char *) &buffer, sizeof(buffer));

        if(n>0)
        {
            if(n != sizeof(buffer))
            {
                ssize_t remainder = sizeof(buffer)-n;
                if(ACE::recv(handle, ((char *)&buffer)+n, remainder) != remainder)
                {
                    return -1;
                }
            }
        }
        return 1;
    };
};
