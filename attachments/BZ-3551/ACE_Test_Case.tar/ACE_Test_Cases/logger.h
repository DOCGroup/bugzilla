#ifndef _LOGGER_H_
#define _LOGGER_H_

#include "base_logger.h"
#include <ace/Null_Mutex.h>
#include <ace/Select_Reactor.h>
#include <ace/Reactor.h>

namespace test_space
{
    /* @{ */
    /**
     * @class logger
     *
     * @brief Implementation of the logger
     */
    class logger : public base_logger
    {
    private:
        /// string holding program name
        char program_[512];
        /// String holding host name
        char hostname_[256];
        /// Minimum logging severity.
        severity_t min_log_severity_;

        /// ACE_Select_Reactor.  Implementation of the reactor to be used
        ACE_Select_Reactor *select_reactor_;
        /// ACE_Reactor pointer to use for event dispatching
        ACE_Reactor *reactor_;

        /// ACE_Pipe to use for notification
        ACE_Pipe notification_pipe_;

        /// Process from notify_pipe_
        int read_notify_pipe(ACE_HANDLE handle, ACE_Notification_Buffer& buffer);

         int seconds_since_midnight()
         {
            time_t t = time(NULL);
            tm tmp_tm;
            tm tm_time = *localtime_r( &t, &tmp_tm );
            return ((tm_time.tm_hour*3600) + (tm_time.tm_min*60) + tm_time.tm_sec);
         };

    public:
        /// Destructor
        ~logger()
        {
            reactor_->close();
            //delete reactor_;
        };

        /// Constructor
        logger()
            : base_logger()
            , min_log_severity_(sev_DEBUG)
            , select_reactor_(NULL)
            , reactor_(NULL)
        {
            select_reactor_ = new ACE_Select_Reactor();
            reactor_ = new ACE_Reactor(select_reactor_, true);
        };

        /// DB Logger initialization function.
        /// Function initializes the DB Pool and the prepared queries for it.
        /// Function also sets the minimum logging severity
        void init_logger(   const char *host,
                            const char *prog_name,
                            severity_t minimum_log_severity = sev_DEBUG );

        /// Implementation of the function from the base_logger class
        virtual void log_message(   severity_t severity_level,
                                    unsigned int line_number,
                                    const char *file,
                                    const char *function_name,
                                    const char *message_string
                                );

        /// Implemenation of the open hook
        virtual int open(void * = 0);
        /// Implementation of the put method
        virtual int put( ACE_Message_Block *mb, ACE_Time_Value *timeout = 0 )
        {
            return putq(mb, timeout);
        };
        /// Service Handler
        virtual int svc();

        /// Handle Input
        int handle_input(ACE_HANDLE handle);

        /// Function to set flag for exit
        void end_logging()
        {
            while(!(msg_queue()->is_empty()));
            reactor_->end_reactor_event_loop();
        };

    };

    /* @} */
};

#endif


