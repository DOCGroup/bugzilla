#include <assert.h>
#include <string>
#include <iostream>
#include <fstream>
#include <ostream>
#include <sys/utsname.h>

#include "log.h"
#include "logger.h"


using namespace test_space;

bool exiting;

extern "C" void sig_handler (int)
{
    exiting = true;
    ACE_Reactor::instance()->end_reactor_event_loop();
};

void generate_log_message(logger *logger)
{
    while(!exiting)
    {
        logger->log_message(sev_DEBUG,
                            __LINE__,
                            __FILE__,
                            __PRETTY_FUNCTION__,
                            "TEST Logger");
        sleep(2);
    }
}

int main(int argc, char ** argv )
{
    exiting = false;
    char program_name[256];
    utsname uname_info;
    if( -1 == uname(&uname_info) )
    {
        throw std::runtime_error(std::string("Cannot Get hostname: ") + __PRETTY_FUNCTION__);
    }
    strcpy(program_name, argv[0]);

    logger logger1;
    logger logger2;

    logger1.init_logger(uname_info.nodename,
                        program_name,
                        sev_DEBUG );
    logger2.init_logger(uname_info.nodename,
                        program_name,
                        sev_DEBUG );

    ACE_Thread::spawn((ACE_THR_FUNC)generate_log_message, (void *)&logger1);
    ACE_Thread::spawn((ACE_THR_FUNC)generate_log_message, (void *)&logger2);
    ACE_Reactor::instance()->run_reactor_event_loop();
    logger1.end_logging();
    logger2.end_logging();
    return 0;
};
