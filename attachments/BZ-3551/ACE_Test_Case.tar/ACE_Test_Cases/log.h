#ifndef _LOG_H_
#define _LOG_H_

#include <expat.h>
#include <string>
#include <inttypes.h>
#include <stdint.h>
#include <stdexcept>

#include <sys/time.h>

#include <time.h>

namespace test_space
{
    typedef enum severity_t
    {
        sev_DEBUG = 0,
        sev_NORMAL = 1,
        sev_WARNING = 2,
        sev_ERROR = 3,
        sev_SEVERE_ERROR = 4,
        sev_CRITICAL = 5,
        sev_FATAL = 6
    };

    struct logger_message
    {
        char source_[512];
        char hostname_[256];
        uint32_t datestamp_;
        char message_[4096];
        char program_[512];
        char filename_[64];
        uint32_t timestamp_;
        severity_t severity_;
        uint32_t line_;

        virtual ~logger_message()
        {
        };
        logger_message()
            : datestamp_(0)
            , timestamp_(0)
            , severity_(sev_DEBUG)
            , line_(0)
        {
            filename_[0]='\0';
            hostname_[0]='\0';
            message_[0]='\0';
            program_[0]='\0';
            source_[0]='\0';
        };
    };

};

#endif

