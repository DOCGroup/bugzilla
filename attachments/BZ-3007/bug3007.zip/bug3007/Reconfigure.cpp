// $Id: TSS_Test.cpp 77805 2007-03-26 15:42:51Z wotte $

// ============================================================================
//
// = LIBRARY
//    tests
//
// = FILENAME
//    TSS_Test.cpp
//
// = DESCRIPTION
//     This program tests thread specific storage of data. The ACE_TSS
//     wrapper transparently ensures that the objects of this class
//     will be placed in thread-specific storage. All calls on
//     ACE_TSS::operator->() are delegated to the appropriate method
//     in the Errno class.
//
// = AUTHOR
//    Prashant Jain <pjain@cs.wustl.edu> and Doug Schmidt <schmidt@cs.wustl.edu>
//
// ============================================================================

#include "test_config.h"

#include "ace/Service_Config.h"

ACE_RCSID(tests, TSS_Test, "$Id: Reconfigure.cpp 77805 2007-03-26 15:42:51Z wotte $")


int
run_main (int argc, ACE_TCHAR *argv[])
{
  ACE_START_TEST (ACE_TEXT ("Reconfigure"));
  
  ACE_Service_Config::open(argc, argv, ACE_DEFAULT_LOGGER_KEY);

    ACE_DEBUG(( LM_TRACE,  ACE_TEXT("LogTest: Trace\n") ));
    ACE_DEBUG(( LM_DEBUG,  ACE_TEXT("LogTest: Debug\n") ));
    ACE_DEBUG(( LM_INFO,   ACE_TEXT("LogTest: Info\n") ));
    ACE_DEBUG(( LM_WARNING,ACE_TEXT("LogTest: Warning\n") ));
    ACE_DEBUG(( LM_NOTICE, ACE_TEXT("LogTest: Notice\n") ));
    ACE_DEBUG(( LM_ERROR,  ACE_TEXT("LogTest: Error\n") ));

	ACE_Service_Config::reconfigure ();

	ACE_DEBUG(( LM_TRACE,  ACE_TEXT("LogTest: Trace\n") ));
    ACE_DEBUG(( LM_DEBUG,  ACE_TEXT("LogTest: Debug\n") ));
    ACE_DEBUG(( LM_INFO,   ACE_TEXT("LogTest: Info\n") ));
    ACE_DEBUG(( LM_WARNING,ACE_TEXT("LogTest: Warning\n") ));
    ACE_DEBUG(( LM_NOTICE, ACE_TEXT("LogTest: Notice\n") ));
    ACE_DEBUG(( LM_ERROR,  ACE_TEXT("LogTest: Error\n") ));

	return 0;
  ACE_END_TEST;
}
