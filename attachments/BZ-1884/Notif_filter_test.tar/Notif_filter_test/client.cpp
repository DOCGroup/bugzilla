// client.cpp,v 1.5 2002/01/29 20:21:07 okellogg Exp

#include "orbsvcs/orbsvcs/CosNotifyChannelAdminC.h"
#include "orbsvcs/orbsvcs/CosNotifyChannelAdminS.h"

#include <iostream>


const char *ior = "file://ecf.ior";

CosNotifyChannelAdmin::EventChannel_var 
get_event_channel(CORBA::ORB_ptr orb)

{
    CosNotifyChannelAdmin::EventChannel_var ec;
    CosNotifyChannelAdmin::ChannelID id;
    CosNotification::QoSProperties init_qos(0);
    CosNotification::AdminProperties init_admin(0);


    
	std::cout << "Get CosNotifyChannelAdmin::EventChannelFactory"  << std::endl;
	std::cout << "IorEventChannelFactory=" << ior << std::endl;
	CORBA::Object_ptr obj = orb->string_to_object(ior);

    if (CORBA::is_nil(obj))
	{
		std::cerr << "Bad ecf.ior " << std::endl; 
	    exit(1);
	}

    
    CosNotifyChannelAdmin::EventChannelFactory_var factory =
	CosNotifyChannelAdmin::EventChannelFactory::_narrow(obj);
	if (CORBA::is_nil(factory.in()))
	{
	    std::cerr << "Could not _narrow object to type CosNotifyChannelAdmin::EventChannelFactory" << std::endl;
	    exit(1);
	}
	
	//Get the first ec
	CosNotifyChannelAdmin::ChannelIDSeq_var channelIdSeq;
	try
	{
	 channelIdSeq = factory->get_all_channels();
    }
    catch (CORBA::SystemException& se )
    {
	    std::cerr << "System exception occurred during get_all_channels: " 
		 << se << std::endl;
	    exit(1);
    }
	
	if( channelIdSeq->length() == 0 )
	{

	    try 
	    {
		ec = factory->create_channel( init_qos, init_admin, id);
	    }
	    catch (CORBA::SystemException& se )
	    {
		    std::cerr << "System exception occurred during find_channel: " 
			 << se << std::endl;
		    exit(1);
	    }
	}
	else {
		try
		{
		ec = factory->get_event_channel(channelIdSeq[0]);
		}
		catch (CosNotifyChannelAdmin::ChannelNotFound& notfoundexc )
	    {
		    std::cerr << "ChannelNotFound: " 
			 << channelIdSeq[0] << std::endl;
		    exit(1);
	    }

    	catch (CORBA::SystemException& se )
	    {
		    std::cerr << "System exception occurred during get_event_channel: " 
			 << se << std::endl;
		    exit(1);
	    }

	}
	
	

    return ec._retn();
}




namespace CosNotifyCommImpl{
	class StructuredPushSupplier: public virtual POA_CosNotifyComm:: StructuredPushSupplier 
	{
	public:
	   	void disconnect_structured_push_supplier()
	   		throw (CORBA::SystemException)
	   	{};
		void subscription_change( const CosNotification::EventTypeSeq& added, 
	   		const CosNotification::EventTypeSeq& removed )
	   		throw(CosNotifyComm::InvalidEventType, CORBA::SystemException)
	   	{};
	   
	};
}


int
main (int argc, char *argv[])
{



    try
    {

	    PortableServer::POAManager_var poa_manager;
	
		CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
	
		CORBA::Object_var poa_obj = orb->resolve_initial_references("RootPOA");
		PortableServer::POA_var root_poa = PortableServer::POA::_narrow(poa_obj.in());
	
		poa_manager = root_poa->the_POAManager();
	
		poa_manager->activate();
	
		/*Get event_channel*/
		std::cout << "Create event_channel now"  << std::endl;
		CosNotifyChannelAdmin::EventChannel_var ec = get_event_channel(orb.in());
	
	
	
		//Instanciating the Supplier
	    CosNotifyComm::StructuredPushSupplier_var sps = 
	                          CosNotifyComm::StructuredPushSupplier::_nil();
	
		
	
	
		CosNotifyCommImpl::StructuredPushSupplier *pImpl_sps = new CosNotifyCommImpl::StructuredPushSupplier;
		sps = pImpl_sps->_this();
	
		//Obtain a Supplier Admin
		CosNotifyChannelAdmin::SupplierAdmin_var sa = ec->default_supplier_admin();
		if( sa.in() == CosNotifyChannelAdmin::SupplierAdmin::_nil() ){
			std::cerr << "sa is nil!" << std::endl;
			return 1;
		}
	
		//Obtain a Proxy Consumer
		CosNotifyChannelAdmin::ProxyID proxy_id;
		CosNotifyChannelAdmin::ClientType ctype = CosNotifyChannelAdmin::STRUCTURED_EVENT;
	
		CosNotifyChannelAdmin::ProxyConsumer_var proxyCon_obj;
		try
		{
			proxyCon_obj = sa->obtain_notification_push_consumer(ctype, proxy_id);
		}
		catch(CosNotifyChannelAdmin::AdminLimitExceeded err)
		{
			std::cerr << "CosNotifyChannelAdmin::AdminLimitExceeded Exception!" << std::endl;
			// handle the exception
		}
		
		CosNotifyChannelAdmin::StructuredProxyPushConsumer_ptr ppc =
			CosNotifyChannelAdmin::StructuredProxyPushConsumer::_narrow(proxyCon_obj.in());
	
		//Connecting a Supplier to a Proxy Consumer
		try
		{
			ppc->connect_structured_push_supplier(sps.in());
		}
		catch (CosEventChannelAdmin::AlreadyConnected ac)
		{
			std::cerr << "CosEventChannelAdmin::AlreadyConnected" << std::endl;
			// Handle the exception
		}
		catch (CORBA::SystemException& se)
		{
			std::cerr << "System exception occurred during connect: " <<
				se << std::endl;
			exit(1);
		}
	
	
		//Demo::demo_send_heart_beat(ppc);
		//Send a Demo Notification

		CosNotification::StructuredEvent event;
	
		event.header.fixed_header.event_type.domain_name =
		    CORBA::string_dup("Test_domain");
		event.header.fixed_header.event_type.type_name =
		    CORBA::string_dup("Test_type_name");
	
		event.header.variable_header.length(0);
		event.remainder_of_body <<= "";
		
		std::cout << "Sending a demo event...," << std::endl;
		std::cout << "event.header.fixed_header.event_type.domain_name = " 
			 	  << event.header.fixed_header.event_type.domain_name 
			 	  << std::endl;
		std::cout << "event.header.fixed_header.event_type.type_name = " 
				  << event.header.fixed_header.event_type.type_name
				  << std::endl;

				  
		try{
			ppc->push_structured_event(event);
		}  	
	    catch (CORBA::SystemException& se)
	    {
		std::cerr << "System exception occurred during push: "
		     << se << std::endl;
		exit(1);
	    }
	    catch (CORBA::Exception&)
	    {
		std::cerr << "Unknown exception occurred during push" << std::endl;
		exit(1);
	    }
		
		try{
			ppc->disconnect_structured_push_consumer();
		}
		catch(CORBA::Exception&)
		{
			std::cerr << "Disconnect fail!" << std::endl;
		}
	
		orb->shutdown();
	}
	catch(...)
	{
		std::cerr << "Some exceptions was caught!" << std::endl;

	}

	


    return 0;
}

