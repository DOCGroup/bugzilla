// client.cpp,v 1.5 2002/01/29 20:21:07 okellogg Exp

#include "orbsvcs/orbsvcs/CosNotifyChannelAdminC.h"
#include "orbsvcs/orbsvcs/CosNotifyChannelAdminS.h"

#include <iostream>


const char *ior = "file://ecf.ior";

CosNotifyChannelAdmin::EventChannel_var 
get_event_channel(CORBA::ORB_ptr orb)

{
    CosNotifyChannelAdmin::EventChannel_var ec;
    CosNotifyChannelAdmin::ChannelID id;
    CosNotification::QoSProperties init_qos(0);
    CosNotification::AdminProperties init_admin(0);


    
	std::cout << "Get CosNotifyChannelAdmin::EventChannelFactory"  << std::endl;
	std::cout << "IorEventChannelFactory=" << ior << std::endl;
	CORBA::Object_ptr obj = orb->string_to_object(ior);

    if (CORBA::is_nil(obj))
	{
		std::cerr << "Bad ec_fact.ior " << std::endl; 
	    exit(1);
	}

    
    CosNotifyChannelAdmin::EventChannelFactory_var factory =
	CosNotifyChannelAdmin::EventChannelFactory::_narrow(obj);
	if (CORBA::is_nil(factory.in()))
	{
	    std::cerr << "Could not _narrow object to type CosNotifyChannelAdmin::EventChannelFactory" << std::endl;
	    exit(1);
	}
	
	//Get the first ec
	CosNotifyChannelAdmin::ChannelIDSeq_var channelIdSeq;
	try
	{
	 channelIdSeq = factory->get_all_channels();
    }
    catch (CORBA::SystemException& se )
    {
	    std::cerr << "System exception occurred during get_all_channels: " 
		 << se << std::endl;
	    exit(1);
    }
	
	if( channelIdSeq->length() == 0 )
	{

	    try 
	    {
		ec = factory->create_channel( init_qos, init_admin, id);
	    }
	    catch (CORBA::SystemException& se )
	    {
		    std::cerr << "System exception occurred during find_channel: " 
			 << se << std::endl;
		    exit(1);
	    }
	}
	else {
		try
		{
		ec = factory->get_event_channel(channelIdSeq[0]);
		}
		catch (CosNotifyChannelAdmin::ChannelNotFound& notfoundexc )
	    {
		    std::cerr << "ChannelNotFound: " 
			 << channelIdSeq[0] << std::endl;
		    exit(1);
	    }

    	catch (CORBA::SystemException& se )
	    {
		    std::cerr << "System exception occurred during get_event_channel: " 
			 << se << std::endl;
		    exit(1);
	    }

	}
	
	

    return ec._retn();
}




namespace CosNotifyCommImpl{
	class StructuredPushConsumer: public virtual POA_CosNotifyComm:: StructuredPushConsumer 
	{
	public:
		void push_structured_event(
	 	 const CosNotification::StructuredEvent &event)
	 		throw(CosEventComm::Disconnected)
	 	{
			std::cout << "Received an event...," << std::endl;
			std::cout << "event.header.fixed_header.event_type.domain_name = " 
				 	  << event.header.fixed_header.event_type.domain_name 
				 	  << std::endl;
			std::cout << "event.header.fixed_header.event_type.type_name = " 
					  << event.header.fixed_header.event_type.type_name
					  << std::endl;

	 	};
		
		void disconnect_structured_push_consumer()
			throw (CORBA::SystemException)
		{};	 	
		
      	void offer_change (
	 	 const CosNotification::EventTypeSeq &added,
	 	 const CosNotification::EventTypeSeq &removed )
	 		throw ( CosNotifyComm::InvalidEventType )
	 	{};
	   
	};
}


int
main (int argc, char *argv[])
{



    try
    {

	    PortableServer::POAManager_var poa_manager;
	
		CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
	
		CORBA::Object_var poa_obj = orb->resolve_initial_references("RootPOA");
		PortableServer::POA_var root_poa = PortableServer::POA::_narrow(poa_obj.in());
	
		poa_manager = root_poa->the_POAManager();
	
		poa_manager->activate();
	
		/*Get event_channel*/
		std::cout << "Get event_channel now"  << std::endl;
		CosNotifyChannelAdmin::EventChannel_var ec = get_event_channel(orb.in());
	
	
	
		//Instanciating the Consumer
	    CosNotifyComm::StructuredPushConsumer_var spc = 
	                          CosNotifyComm::StructuredPushConsumer::_nil();
	
		
	
	
		CosNotifyCommImpl::StructuredPushConsumer *pImpl_spc = new CosNotifyCommImpl::StructuredPushConsumer;
		spc = pImpl_spc->_this();
	
		//Obtain a Consumer Admin
		CosNotifyChannelAdmin::ConsumerAdmin_var ca = ec->default_consumer_admin();
		if( ca.in() == CosNotifyChannelAdmin::ConsumerAdmin::_nil() ){
			std::cerr << "ca is nil!" << std::endl;
			return 1;
		}
		
		
		
	
		//Obtain a Proxy Consumer
		CosNotifyChannelAdmin::ProxyID proxy_id;
		CosNotifyChannelAdmin::ClientType ctype = CosNotifyChannelAdmin::STRUCTURED_EVENT;
	
		CosNotifyChannelAdmin::ProxySupplier_var proxySupplier_obj;
		try
		{
			proxySupplier_obj = ca->obtain_notification_push_supplier(ctype, proxy_id);
		}
		catch(CosNotifyChannelAdmin::AdminLimitExceeded err)
		{
			std::cerr << "CosNotifyChannelAdmin::AdminLimitExceeded Exception!" << std::endl;
			// handle the exception
		}
		
		CosNotifyChannelAdmin::StructuredProxyPushSupplier_ptr pps =
			CosNotifyChannelAdmin::StructuredProxyPushSupplier::_narrow(proxySupplier_obj.in());
			
			
		//Attaching a filter to pps
		    CosNotifyFilter::FilterFactory_var dff = 
			ec->default_filter_factory();
		
		    assert(!CORBA::is_nil(dff.in()));
		
		    CosNotifyFilter::Filter_var filter = dff->create_filter("EXTENDED_TCL");
		
		    CosNotification::EventTypeSeq event_types(1);
		    event_types.length(1);
		
		    //event_types[0].domain_name = CORBA::string_dup("Orbix Demos");
		    event_types[0].domain_name = CORBA::string_dup("AAA");
		    event_types[0].type_name = 
			CORBA::string_dup("Structured Notification Push Demo Event");
		
		    CosNotifyFilter::ConstraintExpSeq constraints(1);
		    constraints.length(1);
		
		    constraints[0].event_types = event_types;
		    constraints[0].constraint_expr = CORBA::string_dup(
			"");
		    
			filter->add_constraints(constraints);					
			
			pps->add_filter(filter.in());
			
			std::cout << "Attached a filter to ProxyPushSupplier" << std::endl;
			std::cout << "The filter's domain_name=" <<  event_types[0].domain_name << std::endl;
			std::cout << "The filter's type_name=" <<  event_types[0].type_name << std::endl;
			
	
		//Connecting a Supplier to a Proxy Consumer
		try
		{
			pps->connect_structured_push_consumer(spc.in());
		}
		catch (CosEventChannelAdmin::AlreadyConnected ac)
		{
			std::cerr << "CosEventChannelAdmin::AlreadyConnected" << std::endl;
			// Handle the exception
		}
		catch (CORBA::SystemException& se)
		{
			std::cerr << "System exception occurred during connect: " <<
				se << std::endl;
			exit(1);
		}
	
	
		
	
		orb->run();
	
	}
	catch(...)
	{
		std::cerr << "Some exceptions was caught!" << std::endl;

	}


    return 0;
}

