/********************************************************************************
*                                                                               *
*                         Scribble  Application coding sample                   *
*                                                                               *
********************************************************************************/

#include "test_i.h"


#include "tao/fox_resource.h"

// Here we begin
int main(int argc,char *argv[]){

  // Make application
  FXApp application("Scribble","FoxTest");

  // Start app
  application.init(argc,argv);

  // Scribble window
  ScribbleWindow *w=new ScribbleWindow(&application);

  // Create the application's windows
  application.create();
  
//  ACE_Service_Config::process_directive(ACE_TEXT("static Resource_Factory \"TAO_FoxResource_Factory\""));

  TAO_FoxResource_Factory::set_context (&application);

  try {
    // First initialize the ORB, that will remove some arguments...
    CORBA::ORB_var orb =
      CORBA::ORB_init (argc, argv,
                       "" /* the ORB name, it can be anything! */);
    CORBA::Object_var poa_object =
      orb->resolve_initial_references ("RootPOA");
    PortableServer::POA_var poa =
      PortableServer::POA::_narrow (poa_object.in ());
    PortableServer::POAManager_var poa_manager =
      poa->the_POAManager ();

    Test_i test(w);

    {
      ofstream of("server.ior");
      CORBA::Object_var obj=test._this();
      CORBA::String_var ior=orb->object_to_string(obj.in());
      of<<ior.in();
    };
    
    cout<<"Server ready..."<<endl;
    w->show();

    poa_manager->activate ();

    application.run();
    //orb->run ();

    // Destroy the POA, waiting until the destruction terminates
    poa->destroy (1, 1);
    orb->destroy ();
  }
  catch (CORBA::Exception &) {
    cerr << "CORBA exception raised!" << endl;
  }
  
}




