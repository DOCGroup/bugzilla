
#include "testC.h"
#include "testS.h"

#include "fox/fx.h"

// Main Window
class ScribbleWindow : public FXMainWindow {

  // Macro for class hierarchy declarations
  FXDECLARE(ScribbleWindow)

private:

  FXHorizontalFrame *contents;                // Content frame
  FXVerticalFrame   *canvasFrame;             // Canvas frame
  FXVerticalFrame   *buttonFrame;             // Button frame
  FXCanvas          *canvas;                  // Canvas to draw into
  int                mdflag;                  // Mouse button down?
  int                dirty;                   // Canvas has been painted?
  FXColor            drawColor;               // Color for the line
  
  FXuint px, py;
protected:
  ScribbleWindow(){}

public:

public:

  // Messages for our class
  enum{
    ID_CANVAS=FXMainWindow::ID_LAST,
    ID_CLEAR,
    ID_LAST
    };

public:

  // ScribbleWindow's constructor
  ScribbleWindow(FXApp* a);

  // Initialize
  virtual void create();
  
  void drawto(FXuint x, FXuint y);
  void drawbegin(FXuint x, FXuint y);
  void drawend(FXuint x, FXuint y);

  void clearCmd();

  long onPaint(FXObject*,FXSelector,void*);
  
};





class Test_i : public POA_Test {
  ScribbleWindow *w_;
public:
  Test_i(ScribbleWindow* w): w_(w) {};

  virtual void drawbegin (
      CORBA::Long x,
      CORBA::Long y
      ACE_ENV_ARG_DECL_WITH_DEFAULTS
    )
    ACE_THROW_SPEC ((
      CORBA::SystemException
    )) 
    { printf("drawbegin()\n"); w_->drawbegin(x,y); };

  virtual void drawend (
      CORBA::Long x,
      CORBA::Long y
      ACE_ENV_ARG_DECL_WITH_DEFAULTS
    )
    ACE_THROW_SPEC ((
      CORBA::SystemException
    ))
    { w_->drawend(x,y); };
  
  virtual void drawto (
      CORBA::Long x,
      CORBA::Long y
      ACE_ENV_ARG_DECL_WITH_DEFAULTS
    )
    ACE_THROW_SPEC ((
      CORBA::SystemException
    ))
    { w_->drawto(x,y); };

  virtual void clear (
    )
    ACE_THROW_SPEC ((
      CORBA::SystemException
    ))
    { w_->clearCmd(); };    
};