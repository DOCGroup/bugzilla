eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# $Id: run_test.pl,v 1.1 2003/07/22 21:18:41 irfan Exp $
# -*- perl -*-

use lib '../../../bin';
use PerlACE::Run_Test;

$T = new PerlACE::Process ("Collocation_Corbaloc", "-ORBListenEndpoints iiop://localhost:10101");

$test = $T->SpawnWaitKill (60);

if ($test != 0) {
    print STDERR "ERROR: test returned $test\n";
    exit 1;
}

exit 0;
