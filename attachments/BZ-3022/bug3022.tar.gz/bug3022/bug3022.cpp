
#include "tao/corba.h"
#include "tao/Exception.h"
#include "tao/AnyTypeCode/Any.h"

int main(int, char **)
{
  try
  {
    // ...
  }
  catch (CORBA::Exception& exc)
  {
    CORBA::Any any;
    any <<= exc;
  }
  
  return 0;
}
