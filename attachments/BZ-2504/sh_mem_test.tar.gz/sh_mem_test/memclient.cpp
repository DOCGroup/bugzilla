// CPP-memclient.cpp,v 4.9 2004/10/27 21:06:58 shuston Exp

// This tests the features of the <ACE_MEM_Connector> and
// <ACE_MEM_Stream> classes.  In addition, it can be used to test the
// oneway and twoway latency and throughput at the socket-level.  This
// is useful as a baseline to compare against ORB-level performance
// for the same types of data.

#include "ace/OS_NS_string.h"
#include "ace/MEM_Connector.h"
#include "ace/INET_Addr.h"
#include "ace/Thread_Manager.h"
#include "ace/Singleton.h"
#include "ace/Get_Opt.h"
#include "ace/Profile_Timer.h"


ACE_RCSID(SOCK_SAP, CPP_inclient, "CPP-memclient.cpp,v 4.9 2004/10/27 21:06:58 shuston Exp")

static int
run_client (void)
{
  ACE_Profile_Timer::ACE_Elapsed_Time et;
  ACE_Profile_Timer timer;
  ACE_MEM_Connector connector;
  ACE_MEM_Stream stream;
  ACE_MEM_Addr server_addr (ACE_DEFAULT_SERVER_PORT);
  int i, msg;

  if (connector.connect (stream, server_addr.get_remote_addr ()) == -1)
    ACE_ERROR_RETURN ((LM_ERROR, ACE_TEXT ("%p\n"),
                       ACE_TEXT ("connect")), -1);

  msg = 0;
  timer.start();
  for (i=0; i<100000; i++)
  {
      msg = i;
      stream.send( &msg, sizeof(msg) );
  }
  timer.stop();
  timer.elapsed_time(et);
  printf( "%d messages transmitted in %e\n", i, et.real_time );
                       
  return 0;
}

int ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  ACE_UNUSED_ARG(argc);
  // Initialize the logger.
  ACE_LOG_MSG->open (argv[0]);

  // Run the client
  run_client ();

  return 0;
}

#if defined (ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION)
#elif defined (ACE_HAS_TEMPLATE_INSTANTIATION_PRAGMA)
#endif /* ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION */
