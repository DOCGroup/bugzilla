eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
     & eval 'exec perl -S $0 $argv:q'
     if 0;

# run_test.pl,v 1.1 2001/09/13 18:24:53 bala Exp
# -*- perl -*-

use lib '../../../bin';
use PerlACE::Run_Test;

$iorfile = "server.ior";
# PerlACE::LocalFile ("server.ior");
# unlink $iorfile;
$status = 0;




# "-ORBSvcConfDirective \"static Resource_Factory \'-ORBConnectionCacheMax 10\'\"";


$SV = new PerlACE::Process ("server", "-o $iorfile -ORBSvcConfDirective \"static Resource_Factory \'-ORBConnectionCacheMax 10\'\"  -ORBDebugLevel 1");
@CL = new PerlACE::Process ("client", " -k file://$iorfile");
$CL1 = new PerlACE::Process ("client", " -k file://$iorfile -x");

for ($i = 0; $i != 30; $i++) {
   $CL[$i] = new PerlACE::Process ("client", " -k file://$iorfile");
}

$SV->Spawn ();

if (PerlACE::waitforfile_timed ($iorfile, 5) == -1) {
    print STDERR "ERROR: cannot find file <$iorfile>\n";
    $SV->Kill (); $SV->TimedWait (1);
    exit 1;
} 

for ($i = 0; $i != 20; $i++) {
#    $client = $CL->SpawnWaitKill (300);
   
    
 
   $CL[$i]->Spawn ();

  
}

# wait for the last processed spawned to finish
$blah = $CL[$i]->WaitKill (30);

$client1 = $CL1->SpawnWaitKill (300);

if ($client1 != 0) {
    print STDERR "ERROR: client1 returned $client\n";
    $status = 1;
}

#$server = $SV->WaitKill (10);

if ($server != 0) {
    print STDERR "ERROR: server returned $server\n";
    $status = 1;
}

unlink $iorfile;

exit $status;
