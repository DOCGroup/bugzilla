//
// $Id: Hello.cpp,v 1.1.1.1 2008/03/11 15:41:18 vz Exp $
//
#include "Hello.h"

ACE_RCSID(Hello, Hello, "$Id: Hello.cpp,v 1.1.1.1 2008/03/11 15:41:18 vz Exp $")

Hello::Hello (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

char *
Hello::get_string (void)
{
  return CORBA::string_dup ("Hello there!");
}

void
Hello::shutdown (void)
{
  this->orb_->shutdown (0);
}
