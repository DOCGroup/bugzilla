/**
 * @file
 *
 * $Id$
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */

#include "TestS.h"
#include "tao/Utils/ORB_Destroyer.h"
#include "tao/Utils/RIR_Narrow.h"
#include "tao/Utils/Servant_Var.h"
#include "tao/Utils/PolicyList_Destroyer.h"
#include "tao/PortableServer/PortableServer.h"

#include <iostream>
#include <sstream>
#include <stdexcept>

ACE_RCSID(Bug_1985_Regression, client, "$Id$")

PortableServer::POA_ptr create_default_servant_poa(
    PortableServer::POA_ptr parent, PortableServer::Servant dservant);

void make_request(
    PortableServer::POA_ptr reply_poa, C::B_ptr server,
    int request_id);

class A_Reply_Handler
  : public virtual POA_A::AMI_BHandler
  , public virtual PortableServer::RefCountServantBase
{
public:
  A_Reply_Handler();

  int reply_count() const;

  virtual void shutdown()
    throw(CORBA::SystemException);
  virtual void shutdown_excep(A::AMI_BExceptionHolder*)
    throw(CORBA::SystemException);
  virtual void echo(char const * s)
    throw(CORBA::SystemException);
  virtual void echo_excep(A::AMI_BExceptionHolder *)
    throw(CORBA::SystemException);

  virtual PortableServer::POA_ptr _default_POA()
    throw(CORBA::SystemException);

protected:
  std::string current_request_id();
  void log_exception(
      char const * function_name,
      CORBA::Exception const & ex);

protected:
  int reply_count_;
  PortableServer::Current_var current_;

  unsigned long padding[1024];
};

class Reply_Handler
  : public virtual A_Reply_Handler
  , public virtual POA_C::AMI_BHandler
  , public virtual PortableServer::RefCountServantBase
{
public:
  Reply_Handler();

  virtual void double_echo(char const * s)
    throw(CORBA::SystemException);
  virtual void double_echo_excep(C::AMI_BExceptionHolder *)
    throw(CORBA::SystemException);

private:
  unsigned long padding[1024];
};

int
main(int argc, char * argv[])
{
  try
  {
    CORBA::ORB_var orb(CORBA::ORB_init(argc, argv));
    TAO::Utils::ORB_Destroyer destroy_orb(orb.in());

    PortableServer::POA_var root_poa =
      TAO::Utils::RIR_Narrow<PortableServer::POA>::narrow(
          orb.in(), "RootPOA");

    C::B_var server =
      TAO::Utils::RIR_Narrow<C::B>::narrow(
          orb.in(), "server");

    PortableServer::POAManager_var poa_manager =
      root_poa->the_POAManager();

    TAO::Utils::Servant_Var<Reply_Handler> rh_impl(new Reply_Handler);

    PortableServer::POA_var child =
      create_default_servant_poa(root_poa.in(), rh_impl.in());

    poa_manager->activate();

    int request_count = 1000;
    for (int i = 0; i != request_count; ++i)
    {
      make_request(child.in(), server.in(), i);
    }

    int countdown = 20;
    while(--countdown > 0
        && rh_impl->reply_count() < request_count)
    {
      ACE_Time_Value v(1);
      orb->run(v);
    }

    server->shutdown();

    if (rh_impl->reply_count() < request_count)
    {
      std::cerr << "Still missing replys" << std::endl;
      return 1;
    }
  }
  catch(CORBA::Exception const & ex)
  {
    std::cerr << "CORBA exception caught: " << ex << std::endl;
    return 1;
  }
  catch(std::exception const & ex)
  {
    std::cerr << "standard exception caught: " << ex.what() << std::endl;
    return 1;
  }
  catch(...)
  {
    std::cerr << "unknown exception caught: " << std::endl;
    return 1;
  }
  return 0;
}

PortableServer::POA_ptr create_default_servant_poa(
    PortableServer::POA_ptr parent, PortableServer::Servant dservant)
{
  TAO::Utils::PolicyList_Destroyer plist(6); plist.length(6);

  plist[0] = parent->create_request_processing_policy(
      PortableServer::USE_DEFAULT_SERVANT);
  plist[1] = parent->create_servant_retention_policy(
      PortableServer::NON_RETAIN);
  plist[2] = parent->create_implicit_activation_policy(
      PortableServer::NO_IMPLICIT_ACTIVATION);
  plist[3] = parent->create_id_assignment_policy(
      PortableServer::USER_ID);
  plist[4] = parent->create_id_uniqueness_policy(
      PortableServer::MULTIPLE_ID);
  plist[5] = parent->create_lifespan_policy(
      PortableServer::TRANSIENT);

  PortableServer::POAManager_var mgr =
    parent->the_POAManager();

  PortableServer::POA_var poa =
    parent->create_POA("C::B::AMI_ReplyHandler", mgr.in(), plist);

  // No exception can be raised after this point, the policies
  // guarantee that the set_servant() operation will work.
  poa->set_servant(dservant);

  return poa._retn();
}

void make_request(
    PortableServer::POA_ptr reply_poa, C::B_ptr server,
    int request_id)
{
  std::ostringstream os;
  os << "Request # " << request_id << std::ends;

  std::string s = os.str();

  PortableServer::ObjectId_var id =
    PortableServer::string_to_ObjectId(s.c_str());

  CORBA::Object_var obj =
    reply_poa->create_reference_with_id(
        id.in(), C::_tc_AMI_BHandler->id());

  C::AMI_BHandler_var handler =
    C::AMI_BHandler::_narrow(obj.in());

  if (request_id % 2 == 0)
  {
    server->sendc_echo(handler.in(), s.c_str());
  }
  else
  {
    server->sendc_double_echo(handler.in(), s.c_str());
  }
}

A_Reply_Handler::
A_Reply_Handler()
  : POA_A::AMI_BHandler()
  , PortableServer::RefCountServantBase()
  , reply_count_(0)
  , current_(0)
{
  int argc = 0;
  CORBA::ORB_var orb = CORBA::ORB_init(argc, 0);

  current_ =
    TAO::Utils::RIR_Narrow<PortableServer::Current>::narrow(
        orb.in(), "POACurrent");
}

int A_Reply_Handler::
reply_count() const
{
  return reply_count_;
}

void A_Reply_Handler::
shutdown()
  throw(CORBA::SystemException)
{
}

void A_Reply_Handler::
shutdown_excep(A::AMI_BExceptionHolder *)
  throw(CORBA::SystemException)
{
}

void A_Reply_Handler::
echo(char const * s)
  throw(CORBA::SystemException)
{
  ++reply_count_;
  std::string id = current_request_id();

  std::string const & expected = id;

  if (expected != s)
  {
    std::cerr << "Mismatch in echo '"
              << expected << "' != '"
              << s << "'" << std::endl;
  }
}

void A_Reply_Handler::
echo_excep(A::AMI_BExceptionHolder * h)
  throw(CORBA::SystemException)
{
  ++reply_count_;
  try
  {
    h->raise_echo();
  }
  catch(CORBA::Exception const & ex)
  {
    log_exception("echo", ex);
  }
}

PortableServer::POA_ptr A_Reply_Handler::
_default_POA()
  throw(CORBA::SystemException)
{
  throw CORBA::NO_IMPLEMENT();
}

std::string A_Reply_Handler::
current_request_id()
{
  PortableServer::ObjectId_var id = current_->get_object_id();
  CORBA::String_var msg =
    PortableServer::ObjectId_to_string(id.in());

  return std::string(msg.in());
}

void A_Reply_Handler::
log_exception(
    char const * function_name,
    CORBA::Exception const & ex)
{
  std::string id;
  try
  {
    id = current_request_id();
  }
  catch(CORBA::Exception const & ex)
  {
    std::cerr << "CORBA exception (" << ex << ") trying to get current id"
              << std::endl;
  }
  catch(...)
  {
    std::cerr << "unknown exception trying to get current id" << std::endl;
  }

  std::cerr << "CORBA exception (" << ex << ") in "
            << function_name << " for " << id << std::endl;
}

Reply_Handler::
Reply_Handler()
  : PortableServer::RefCountServantBase()
  , A_Reply_Handler()
  , POA_C::AMI_BHandler()
{
}

void Reply_Handler::
double_echo(char const * s)
  throw(CORBA::SystemException)
{
  ++reply_count_;
  std::string id = current_request_id();

  std::string expected = id;
  expected += ' ';
  expected += id;

  if (expected != s)
  {
    std::cerr << "Mismatch in double echo '"
              << expected << "' != '"
              << s << "'" << std::endl;
  }
}

void Reply_Handler::
double_echo_excep(C::AMI_BExceptionHolder * h)
  throw(CORBA::SystemException)
{
  ++reply_count_;
  try
  {
    h->raise_double_echo();
  }
  catch(CORBA::Exception const & ex)
  {
    log_exception("double_echo", ex);
  }
}

