/**
 * @file
 *
 * $Id$
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */

#include "TestS.h"
#include "tao/Utils/ORB_Destroyer.h"
#include "tao/Utils/RIR_Narrow.h"
#include "tao/Utils/Servant_Var.h"
#include "ace/Get_Opt.h"

#include <iostream>
#include <fstream>
#include <stdexcept>

ACE_RCSID (Bug_1985_Regression, server, "$Id$")

const char * ior_output_file="test.ior";

void parse_args (int argc, char * argv[]);

class B
  : public virtual POA_C::B
  , public virtual PortableServer::RefCountServantBase
{
public:
  B();

  bool continue_running() const;

  virtual void shutdown()
    throw(CORBA::SystemException);
  virtual char * echo(char const * s)
    throw(CORBA::SystemException);
  virtual char * double_echo(char const * s)
    throw(CORBA::SystemException);

private:
  bool continue_flag_;
};

int
main (int argc, char *argv[])
{
  try
  {
    CORBA::ORB_var orb(CORBA::ORB_init(argc, argv));
    TAO::Utils::ORB_Destroyer destroy_orb(orb.in());

    parse_args(argc, argv);

    PortableServer::POA_var root_poa =
      TAO::Utils::RIR_Narrow<PortableServer::POA>::narrow(
          orb.in(), "RootPOA");

    PortableServer::POAManager_var poa_manager =
      root_poa->the_POAManager();

    TAO::Utils::Servant_Var<B> b_impl(new B);

    C::B_var b = b_impl->_this();

    CORBA::String_var ior = orb->object_to_string(b.in());
    std::ofstream os(ior_output_file);
    os << ior.in() << std::endl;

    poa_manager->activate();

    while(b_impl->continue_running())
    {
      ACE_Time_Value v(1);
      orb->run(v);
    }
  }
  catch(CORBA::Exception const & ex)
  {
    std::cerr << "CORBA exception caught: " << ex << std::endl;
    return 1;
  }
  catch(std::exception const & ex)
  {
    std::cerr << "standard exception caught: " << ex.what() << std::endl;
    return 1;
  }
  catch(...)
  {
    std::cerr << "unknown exception caught: " << std::endl;
    return 1;
  }
  return 0;
}

void
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "o:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'o':
        ior_output_file = get_opts.opt_arg ();
        break;

      case '?':
      default:
        throw std::runtime_error(
            "Invalid option: Usage server [-o iorfilename]");
      }
}

B::B()
  : POA_C::B()
  , PortableServer::RefCountServantBase()
  , continue_flag_(true)
{
}

bool B::
continue_running() const
{
  return continue_flag_;
}

void B::
shutdown()
  throw(CORBA::SystemException)
{
  continue_flag_ = false;
}

char * B::
echo(char const * s)
    throw(CORBA::SystemException)
{
  return CORBA::string_dup(s);
}

char * B::
double_echo(char const * s)
    throw(CORBA::SystemException)
{
  std::string x(s);
  x += ' ';
  x += s;
  return CORBA::string_dup(x.c_str());
}
