
#include "ace/SSL/SSL_Context.h"

#include <iostream>
#include <string>

int
ACE_TMAIN (int, ACE_TCHAR**)
{
  std::string ca_file("ssl/ca.pem"),
    ca_dir("ssl");

  ACE_SSL_Context ssl_contex;

  int ret = ssl_contex.load_trusted_ca (ca_file.c_str(), ca_dir.c_str());
  std::cout << "ACE_SSL_Context::load_trusted_ca "
            << ((ret==-1)?"failed":"succeeded") << std::endl;

  return 0;
}
