/**
 * @file        testTAO_IDL.cpp
 *
 * @author      Georg Lohrer
 *
 * substitute   -
 *
 * @brief       Only to check whether the sequence realization from TAO_IDL 
 *              produced code will succeed.
 *
 */
#include <ace/OS.h>
#include <ace/ACE.h>
#include <ace/Get_Opt.h>
#include <ace/ARGV.h>
#include <ace/Log_Msg.h>
#include "testTAO_IDLC.h"

//////////////////////////////////////////////////////////////////////////////
static char progName[128];
static ACE_INT32 numCycles = 0;
static const ACE_INT32 DEFAULT_CYCLES = 1000000;
static char versionStr[] = "0.1";

////////////////////////////////////////////////////////////////////////
void print_usage_and_die (void)
{
    ACE_OS::printf(
                "Usage: %s\n"
                " [-h]  print help\n"
                " [-v]  print version\n\n",
                progName);
    ACE_OS::exit(1);
}

////////////////////////////////////////////////////////////////////////
bool parse_args (int argc, char** argv)
{
    ACE_Get_Opt get_opts (argc, argv, "vh");
    int c = 0;

    while ((c = get_opts ()) != -1)
        switch (c) {
            case 'v':
                ACE_OS::printf("%s version %s\n", argv[0], versionStr);
                numCycles = ACE_OS::atoi(get_opts.optarg);
                if (numCycles <= 0)
                    numCycles = DEFAULT_CYCLES;
                break;
            case 'h':
                print_usage_and_die();
            default:
                ACE_DEBUG ((LM_ERROR, "ERROR: Wrong parameter '%c'!\n", c, 0));
                print_usage_and_die();
        }

    // Indicates successful parsing of command line.
    return true;
}

////////////////////////////////////////////////////////////////////////
int main ( ACE_INT32 argc, ACE_TCHAR **argv)
{
    ACE::init ();

    // Set default values
    ACE_OS::strcpy(progName,argv[0]); // Save for further usage

    ACE_OS::printf("%s: Start of application!\n\n", progName);

    numCycles = DEFAULT_CYCLES;
    if (! parse_args(argc, argv))
        print_usage_and_die();

    /*
     * PROBLEM 1
     */
    Test::UShortSeq tmpSeq;
    tmpSeq.length(10000);

    ////////////////////////////////////////////////
    // UNIONS - switch (boolean)
    ////////////////////////////////////////////////
    Test::SeqPresenceOpt seqOpt;

    seqOpt.bills(tmpSeq);
    seqOpt._default();

    tmpSeq.length(1); // smaller
    seqOpt.bills(tmpSeq);

    /*
     * PROBLEM 2
     */
    ////////////////////////////////////////////////
    // UNIONS - specific (DOLLAR|EURO)
    ////////////////////////////////////////////////
    Test::ModeUnion mode_1;
    mode_1.billsInEuro( tmpSeq);
    mode_1._default();

    ////////////////
    // option: set mode_1 to another mode
    ////////////////
    mode_1.billsInDollar( tmpSeq);

    ////////////////
    // option: assing mode_1 to mode_2
    ////////////////
    Test::ModeUnion mode_2;
    mode_2._d(Test::UNSPECIFIED);
    mode_1 = mode_2;

    /*
     * PROBLEM 3
     */
#define GREETING "\
This test will check wether reducing the size of a sequence will\n\
call default-initialization of the 'free'ed elements or if they\n\
are still intact and perhaps dangling.\n"

    ACE_OS::puts("TAO-sequence test");
    ACE_OS::puts("=================");
    ACE_OS::puts(GREETING);

    ACE_OS::puts("Set length of tmpSeq to 10\n");
    tmpSeq.length(10);

    ACE_OS::printf("Length of tmpSeq: %d\n", tmpSeq.length());
    tmpSeq[9] = 0xfeed;

    ACE_OS::printf("Write data '0xfeed' into last entry\n");
    ACE_OS::printf("tmpSeq[9]:0x%x\n", tmpSeq[9]);

    ACE_OS::printf("Set length of tmpSeq to 0\n");
    tmpSeq.length(0);

    ACE_OS::printf("Set length of tmpSeq to 10\n");
    tmpSeq.length(10);

    ACE_OS::printf("tmpSeq[9]:0x%x\n\n", tmpSeq[9]);

    if (tmpSeq[9] == 0xfeed) {
        ACE_OS::puts("Test FAILED! Elements are still intact after resizing of sequence.");
    } else {
        ACE_OS::puts("Test PASSED! Elements have been initialized after resizing of sequence.");
    }

    ACE_OS::printf("\n%s: End of application!\n", progName);
    return 0;
}
