#include <iostream>
#include "TestDataC.h"

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  SeqTest::NodeSeq ns;
  ns.length (1);
  ns[0].ls.length (1);
  ns[0].ls[0] = 42;

  ns.length (0); // Shrink sequence
  ns.length (1); // Re-grow sequence; should re-initialize meber sequence
                 // "as if" default constructed. I.e., the "ls" member
                 // should have a length of zero.

  if (ns[0].ls.length() == 0) {
    std::cout << "passed." << std::endl;
  }
  else {
    std::cout << "failed." << std::endl;
  }

  return 0;
}
