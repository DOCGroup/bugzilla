// -*- C++ -*-

//=============================================================================
/**
 *  @file Incoming_Message_Stack.h
 *
 *  $Id: Incoming_Message_Stack.h,v 1.21 2005/11/24 11:05:45 ossama Exp $
 *
 *  @author Frank Rehberger <frehberg@prismtech.com>
 */
//=============================================================================

#ifndef TAO_INCOMING_MESSAGE_STACK_H
#define TAO_INCOMING_MESSAGE_STACK_H

#include /**/ "ace/pre.h"

#include "tao/Incoming_Message_Queue.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

ACE_BEGIN_VERSIONED_NAMESPACE_DECL
class ACE_Allocator;
ACE_END_VERSIONED_NAMESPACE_DECL

TAO_BEGIN_VERSIONED_NAMESPACE_DECL

/** 
 Internal class, providing stack functionality for TAO_Queued_Data objects. 
 Stack operations don't require memory allocation.
*/
class Incoming_Message_Stack
{
  private:
    /// Default Copy-Constructor -  not for public usage.
    Incoming_Message_Stack (const Incoming_Message_Stack&);

  public:
    /// default constructor, intiliazes empty stack.
    Incoming_Message_Stack();

    /// destructor, releases all elements on stack
    ~Incoming_Message_Stack() ;

    /// pushing a new element onto stack
    /// @return 0 for Ok, -1 for error
    int push(TAO_Queued_Data *data);

    /// removing top element of stack,
    /// @return 0 for Ok and @a data is defined, -1 for error
    int pop (TAO_Queued_Data* &data);

    /// peeking top element of stack
    /// @return 0 for Ok, -1 for error
    int top (TAO_Queued_Data* &data);

    ///  @return 1 if empty otherwise 0
    bool is_empty ();

  private:
    /// top element of stack
    TAO_Queued_Data *top_;
};


TAO_END_VERSIONED_NAMESPACE_DECL

#if defined (__ACE_INLINE__)
# include "Incoming_Message_Stack.inl"
#endif /* __ACE_INLINE__ */

#include /**/ "ace/post.h"
#endif /*TAO_INCOMING_MESSAGE_STACK_H*/
