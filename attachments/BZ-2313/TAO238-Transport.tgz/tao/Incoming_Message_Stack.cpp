
# include "Incoming_Message_Stack.h"

#if !defined (__ACE_INLINE__)
# include "Incoming_Message_Stack.inl"
#endif /* __ACE_INLINE__ */

ACE_RCSID (tao,
           Incoming_Message_Stack,
           "$Id: Incoming_Message_Stack.cpp,v 1.18 2005/11/02 07:13:03 ossama Exp $")

TAO_BEGIN_VERSIONED_NAMESPACE_DECL

TAO_END_VERSIONED_NAMESPACE_DECL