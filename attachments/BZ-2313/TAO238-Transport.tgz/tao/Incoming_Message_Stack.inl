// -*- C++ -*-
//
//$Id: Incoming_Message_Queue.inl,v 1.13 2005/11/02 07:13:03 ossama Exp $

TAO_BEGIN_VERSIONED_NAMESPACE_DECL

/************************************************************************/
// Methods  for TAO_Incoming_Message_Stack
/************************************************************************/
ACE_INLINE
TAO_Incoming_Message_Stack::TAO_Incoming_Message_Stack() 
: top_(0)
{
}

ACE_INLINE
TAO_Incoming_Message_Stack::~TAO_Incoming_Message_Stack() 
{
   // Delete all the nodes left behind
   TAO_Queued_Data *del;

   while (this->pop (del) != -1)
     {
        TAO_Queued_Data::release (del);
     }
}

    /* @return 0 for Ok, -1 for error */
ACE_INLINE int
TAO_Incoming_Message_Stack::push(TAO_Queued_Data *data)
{
  data->next_ = this->top_;
  this->top_ = data;

  return 0;
}

    
    /* @return 0 for Ok, -1 for error */
ACE_INLINE int
TAO_Incoming_Message_Stack::pop (TAO_Queued_Data* &data) 
{
  if (this->top_ == 0) 
    return -1;

  data = this->top_;
  this->top_ = data->next_;

  return 0;
}
    
ACE_INLINE int
TAO_Incoming_Message_Stack::top (TAO_Queued_Data* &data) 
{
  if (this->top_ == 0) 
    return -1;

  data = this->top_;

  return 0;
}

ACE_INLINE int
TAO_Incoming_Message_Stack::is_empty () 
{
  return this->top_ == 0;
}

TAO_END_VERSIONED_NAMESPACE_DECL
