#include <iostream>
#include <tao/corba.h>

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);
  CORBA::StringSeq foo;

  foo.length (1);
  foo[0] = "Hello World";

  const CORBA::StringSeq & bar = foo;

  std::cout << bar[0].in() << std::endl;
  return 0;
}
