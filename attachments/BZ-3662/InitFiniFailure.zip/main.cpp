
#include <windows.h>
#include <eh.h>
#include <iostream>

#include "services.h"

// Don't forget to set /EHa option.

#define ARRAY_LENGTH(array) (sizeof(array)/sizeof((array)[0]))

class seh_exception : std::exception
{
public:
    seh_exception(unsigned code)
    {
        form_reason(code);
    }

    virtual const char* what() const
    {
        return _reason;
    }

    static void prepare_translation()
    {
        _set_se_translator(
            &seh_exception::se_translator);
    }

private:
    enum { reasonMaxLength = 50 };
    char _reason[reasonMaxLength + 1];

    void form_reason(unsigned code)
    {
        sprintf_s(
            _reason, 
            ARRAY_LENGTH(_reason), 
            "Structured exception, code=0x%X.",
            code);
    }

    static void se_translator(
        unsigned code, EXCEPTION_POINTERS*)
    {
        throw seh_exception(code);
    }
};

void debug_output_iteration(unsigned iteration)
{
    char output_message[100];

    sprintf_s(
        output_message, 
        ARRAY_LENGTH(output_message),
        "Starting %d iteration...\n",
        iteration);

    OutputDebugStringA(output_message);
}

int main(int argc, char* argv[])
{
    const unsigned iterations_count = 2000;
    unsigned curr_iteration = 0;

    try
    {
        seh_exception::prepare_translation();

        while (curr_iteration++ < iterations_count)
        {
            debug_output_iteration(curr_iteration);

            services::initialize();
            services::finalize();
        }

        std::cout 
            << "Initialization/finalization is fine." 
            << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout 
            << "Error on "
            << curr_iteration
            << "-th iteration: " 
            << ex.what() 
            << std::endl;
    }
}
