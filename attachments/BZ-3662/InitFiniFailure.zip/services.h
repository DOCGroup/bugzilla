#pragma once

class services
{
public:
    static void initialize();
    static void finalize();

private:
    services();
};
