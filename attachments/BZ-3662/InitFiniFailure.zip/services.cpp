
#include <ace/ACE.h>
#include "services.h"

void services::initialize()
{
    ACE::init();
}

void services::finalize()
{
    ACE::fini();
}
