// $Id: server.cpp,v 1.2 2009/11/11 16:05:15 sma Exp $

#include "ace/Get_Opt.h"
#include "ace/ARGV.h"
#include "tao/ORB.h"
#include "tao/ORB_Core.h"
#include "tao/Resource_Factory.h"

ACE_TCHAR const *orb1_args =
  ACE_TEXT ("AAA -ORBGestalt LOCAL -ORBSvcConf MY_TEST_ORB_1.conf");
ACE_TCHAR const *orb2_args =
  ACE_TEXT ("BBB");

int
parse_args (int argc, ACE_TCHAR *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, ACE_TEXT ("a:b:"));
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'a':
        orb1_args = get_opts.opt_arg ();
        break;
      case 'b':
        orb2_args = get_opts.opt_arg ();
        break;
      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           ACE_TEXT ("usage:  %s")
                           ACE_TEXT (" -a <orb1_args>")
                           ACE_TEXT (" -b <orb2_args>")
                           ACE_TEXT ("\n"),
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}

int
ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  try
    {
      if (parse_args (argc, argv) != 0)
        {
          return 1;
        }

      ACE_ARGV orb1_argv (orb1_args);
      int orb1_argc = orb1_argv.argc ();

      ACE_ARGV orb2_argv (orb2_args);
      int orb2_argc = orb2_argv.argc ();

      ACE_DEBUG ((LM_DEBUG,
                  "Initialize ORB instances...\n"));

      CORBA::ORB_var orb1 =
        CORBA::ORB_init (orb1_argc, orb1_argv.argv (), "AAA");

      CORBA::ORB_var orb2 =
        CORBA::ORB_init (orb2_argc, orb2_argv.argv (), "BBB");

      ACE_DEBUG ((LM_DEBUG,
                  "After ORB_init...\n"));

      TAO_Resource_Factory *trf = orb2->orb_core ()->resource_factory ();

      if (trf == 0)
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             ACE_TEXT ("ERROR: Can not resolve ")
                             ACE_TEXT ("Resource Factory.\n")),
                            -1);
        }

      if (trf->cache_maximum () != TAO_CONNECTION_CACHE_MAXIMUM)
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             ACE_TEXT ("ERROR: '-ORBConnectionCacheMax' is ")
                             ACE_TEXT ("applied globally while it's expected ")
                             ACE_TEXT ("to apply to the first ORB only.\n")),
                            -1);
        }

      orb1->destroy ();
      orb2->destroy ();

      ACE_DEBUG ((LM_DEBUG,
                  ACE_TEXT ("'-ORBConnectionCacheMax' is applied to the first ")
                  ACE_TEXT ("ORB only as expected.\n")));
    }
  catch (CORBA::Exception const &ex)
    {
      ex._tao_print_exception ("Caught Exception in main:\n");
      return 1;
    }

  return 0;
}
