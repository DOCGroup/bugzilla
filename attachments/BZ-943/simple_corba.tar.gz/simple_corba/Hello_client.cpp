//------------------------------------------------------------------------------
// Copyright (c) Acxiom Corporation, 2000
//------------------------------------------------------------------------------
//
// Filename:     simple_MT_client.cpp
// Author:       Your Name (userid)
// Date Created: Month Day, Year
//
// Description:  This is a simple client for the MT service.
//
//------------------------------------------------------------------------------
// Maintenance History
//------------------------------------------------------------------------------
//
// YYYY/MM/DD (userid) - Initial Implementation
//
//------------------------------------------------------------------------------
// Miscellaneous Notes
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Bugs, Future Enhancements, Comments, etc...
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------

#define  MAX_VALUE  256

#include <iostream>
#include <fstream>

#include <pthread.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

#include "HelloC.h"

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------
void  threadMain(void*);

//----------------------------------------------------------
// Global varaibles
//----------------------------------------------------------
long   NumTransactions = 0;
long   NumThreads = 0;
char   szMessage[] = "The client program says hello!";

static const int ThreadFailed = EXIT_FAILURE;
static const int ThreadSuccess = EXIT_SUCCESS;

//----------------------------------------------------------
// Global Properties pointer
//----------------------------------------------------------
CORBA::ORB_var      g_orb;
//CORBA::Object_var   g_object;
//Hello_var           g_server;
char                g_ior[1024];

//----------------------------------------------------------------------------
// void main(int argc, char **argv)
//----------------------------------------------------------------------------
//
// DESCRIPTION
//
//  This is the main function.
//
// PARAMETERS
//
//  Normal main() parameters
//
// RETURN VALUE
//
//  None
//
// ERROR HANDLING
//
//  None
//
//----------------------------------------------------------------------------
int main(int argc, char **argv)
{
   pthread_t         *thread_id;
   unsigned int       status = 0;
   void              *status_ptr = &status;
   time_t             starttime;
   time_t             stoptime;
   float              totaltime=0.0;
   int                totalrecords = 0;
   int                i = 0;

   //----------------------------------------------------------
   // Ensure command line args
   //----------------------------------------------------------
   if(argc < 3)
   {
      cerr << endl << "Usage:  " << argv[0] << " <num_threads> <num_times_loop> <iorfile>" << endl << endl;
      exit(EXIT_SUCCESS);
   }

   NumThreads = atoi(argv[1]);
   NumTransactions = atoi(argv[2]);
   
   cout << "NumThreads: " << NumThreads << endl;
   cout << "NumTransactions: " << NumTransactions << endl;
   cout << "IOR file: " << argv[3] << endl;
   
   try
   {
     // initialize the orb
     g_orb = CORBA::ORB_init(argc, argv);
   }
   catch(...)
   {
     cerr << "ERROR: An error occurred while initializing the ORB!" << endl;
     exit(EXIT_FAILURE);
   }

   //----------------------------------------------------------
   // Get the object reference
   //----------------------------------------------------------
   try
   {
    
     ifstream iorFile(argv[3]);
  
     if(iorFile.good())
     {
       iorFile >> g_ior;
     }
     else
     {
       cerr << "could not open " << argv[3] << endl;
       return EXIT_FAILURE;
     }
  
     iorFile.close();
   }
   catch(...)
   {
     cerr << "ERROR: An error occurred while opening the ior file!" << endl;
     exit(EXIT_FAILURE);
   }

#if 0   
   try
   {
     // I thought threads could share the server object reference, but I get
     // get errors if they all use g_server!  :-(
     CORBA::Object_var g_object = g_orb->string_to_object (g_ior);

     if ( CORBA::is_nil( g_object ) )
     {
       cerr << "ERROR: Object reference from IOR is nil." << endl;
       exit(EXIT_FAILURE);
     }
     else
     {
       g_server = Hello::_narrow(g_object);
     }
     
     if ( CORBA::is_nil (g_server) )
     {
       cerr << "ERROR: Unable to narrow to server object reference." << endl;
       exit(EXIT_FAILURE);
     }
   }
   catch(...)
   {
     cerr << "ERROR: An error occurred while getting the object reference!" << endl;
     exit(EXIT_FAILURE);
   }
#endif
     
   //----------------------------------------------------------
   // Get starting time
   //----------------------------------------------------------
   time(&starttime);

   //----------------------------------------------------------
   // Allocate space for Threads
   //----------------------------------------------------------
   thread_id = new pthread_t[NumThreads];
   if(thread_id == NULL)
   {
     cerr << "ERROR Allocating memory for thread_id";
     exit(EXIT_FAILURE);
   }   

   //----------------------------------------------------------
   // Create Threads
   //----------------------------------------------------------
   for(i=0; i<NumThreads; i++)
   {
      if(pthread_create(&thread_id[i], NULL, (void *(*)(void *))threadMain, NULL))
      {
         printf("Error creating threads\n");
         exit(EXIT_FAILURE);
      }
   }

   //----------------------------------------------------------
   // Wait for threads to finish
   //----------------------------------------------------------
   for(i=0; i<NumThreads; i++)
   {
      if(pthread_join(thread_id[i], &status_ptr))
      {
         printf("Error joining worker thread %d.\n", i);
         exit(EXIT_FAILURE);
      }

   }

   //----------------------------------------------------------
   // Get end time and calculate total records processed
   //----------------------------------------------------------
   time(&stoptime);
   
   totaltime = stoptime - starttime;
   totalrecords = NumThreads * NumTransactions;

   //----------------------------------------------------------
   // Output timing stuff
   //----------------------------------------------------------
   printf("\nTotal time in seconds......%f\n", totaltime);
   printf("Calls per second.........%.0f\n\n", (float)totalrecords/totaltime);
   printf("Calls per hour...........%.0f\n\n", ((float)totalrecords/totaltime)*3600);

   //----------------------------------------------------------
   // Cleanup and exit
   //----------------------------------------------------------
   delete [] thread_id; 

   exit(EXIT_SUCCESS);
}

//----------------------------------------------------------------------------
// void threadMain(void *ThreadParm)
//----------------------------------------------------------------------------
//
// DESCRIPTION
//
//  This functions is what each thread executes.  It actually calls the Service.
//
// PARAMETERS
//
//  void *ThreadParm  This is the parameter sent to this thread.  It contais 
//         a pointer to a MT object.
//
// RETURN VALUE
//
//  None
//
// ERROR HANDLING
//
//  This function will print out errors if it catches exceptions.
//    It may cause the process to exit.  (Not important for a test client.)
//
//----------------------------------------------------------------------------
void threadMain(void *ThreadParam)
{

   int                  i;

   Hello_var            server;
   CORBA::Object_var    object;

   try
   {
     // I thought threads could share the server object reference, but I get
     // get errors if they all use one global server object. :-(
     
     CORBA::Object_var object = g_orb->string_to_object (g_ior);

     if ( CORBA::is_nil( object ) )
     {
       cerr << "ERROR: Object reference from IOR is nil."
            << "( thread - " << pthread_self() << " )" << endl;
       pthread_exit((void*) &ThreadFailed);
     }
     else
     {
       server = Hello::_narrow(object);
     }
     if ( CORBA::is_nil (server) )
     {
       cerr << "ERROR: Unable to narrow to server object reference." 
            << "( thread - " << pthread_self() << " )" << endl;
       pthread_exit((void*) &ThreadFailed);

     }
   }
   catch(...)
   {
     cerr << "ERROR: An error occurred while getting the object reference!" << endl;
     pthread_exit((void*) &ThreadFailed);
   }
   
   //----------------------------------------------------------
   // Call the service as many times as specified
   //----------------------------------------------------------
   for(i=0;i<NumTransactions;i++)
   {
      CORBA::String_var    szOutMessage;
      try
      {
         server->helloWorld(szMessage,szOutMessage);

      }
      catch (CORBA::SystemException &sysEx)
      {
         cerr << "ERROR: Unexpected system exception occurred while trying to call helloWorld()."
              << "( thread - " << pthread_self() << " )" << endl;
         cerr << &sysEx;
         pthread_exit((void*) &ThreadFailed);
      }
      catch (...)
      {
         cerr << "ERROR: Unexpected exception occurred while trying to call helloWorld()."
              << "( thread - " << pthread_self() << " )" << endl;
         pthread_exit((void*) &ThreadFailed);
      }

      //----------------------------------------------------------
      // Print the results of one response
      //----------------------------------------------------------
      cerr << "Message from server: " << szOutMessage  
           << "( thread - " << pthread_self() << " )" << endl;
   }


}

