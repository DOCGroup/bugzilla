//------------------------------------------------------------------------------
// Copyright (c) Acxiom Corporation, 2000
//------------------------------------------------------------------------------
//
// Filename:     Hello_impl.h
// Author:       mtalle
// Date Created: 12 June 2001
//
// Description:  This is the header file for the implementation of the 
//               Hello.
//
//------------------------------------------------------------------------------
// Maintenance History
//------------------------------------------------------------------------------
//
// 12 June 2001 (mtalle) - Initial Implementation.
//
//------------------------------------------------------------------------------
// Miscellaneous Notes
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Bugs, Future Enhancements, Comments, etc...
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------

#ifndef HELLO_H
#define HELLO_H


#include "HelloS.h"


//----------------------------------------------
// CLASS CHello
//----------------------------------------------
class CHello : public POA_Hello,
                           public PortableServer::RefCountServantBase
{
  public:

    CHello();
    
    virtual void helloWorld (
                               const char *         szInMessage,
                               CORBA::String_out    szOutMessage
                              )  ACE_THROW_SPEC (( CORBA::SystemException));

  protected:

    // This is protected so these are always heap-allocated
    virtual ~CHello();

  private:

    // Copy constructor and assignment operator are not needed
    CHello( const CHello & );
    void operator=( const CHello & );
    
};

#endif  // ifndef HELLO_H
