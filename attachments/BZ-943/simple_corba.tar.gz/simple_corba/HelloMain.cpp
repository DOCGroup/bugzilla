//------------------------------------------------------------------------------
// Copyright (c) Acxiom Corporation, 2000
//------------------------------------------------------------------------------
//
// Filename:     HelloMain.cpp
// Author:       mtalle
// Date Created: 12 June 2001
//
// Description:  This file contains the main() function which is executed on the
//               server.
//
//------------------------------------------------------------------------------
// Maintenance History
//------------------------------------------------------------------------------
//
// 12 June 2001 (mtalle) - Initial Implementation
//
//------------------------------------------------------------------------------
// Miscellaneous Notes
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Bugs, Future Enhancements, Comments, etc...
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <ace/Thread_Manager.h>

#include "tao/corba.h"
#include "tao/PortableServer/PortableServer.h"
#ifndef DEFAULT_THROW
#define DEFAULT_THROW   ACE_THROW_SPEC (( CORBA::SystemException))
#endif
#ifndef THROW
#define THROW   ACE_THROW_SPEC (( CORBA::SystemException ))
#endif 


#include "Hello_impl.h"

#define MAX_VALUE 256
#define CONF_FILE_NAME "svc.conf"

//------------------------------------------------------------------------------
// Globals 
//------------------------------------------------------------------------------
PortableServer::POA_var g_hello_poa   = PortableServer::POA::_nil();
CORBA::ORB_var g_orb                    = CORBA::ORB::_nil();

//------------------------------------------------------------------------------
// Function prototypes
//------------------------------------------------------------------------------
void display_usage(int argc, char * argv[]);
void display_version();
void splash_screen();
void *run_orb( void *arg );
int writeConfigFile();
int writeIORFile(const char *pszFileName, const char *pszIor);
int  writeToPIDFile();     

//------------------------------------------------------------------------------
// int main(int argc, char * argv[])
//------------------------------------------------------------------------------
//
// DESCRIPTION
//
//  This initializes everything and starts the MT service.
//
// PARAMETERS
//
//  Normal main() parameters.
//
// RETURN VALUE
//
//  EXIT_FAILURE -- failure
//  EXIT_SUCCESS -- success
//
// ERROR HANDLING
//
//  None.
//
//------------------------------------------------------------------------------
int main (int argc, char * argv[])
{
  CORBA::Object_var                 obj;
  CORBA::Object_ptr                 pHelloRef;
  PortableServer::POA_var           root_poa;
  PortableServer::POAManager_var    root_poa_mgr;
  PortableServer::POAManager_var    hello_poa_mgr;
  PortableServer::POAManager_var    nil_mgr = PortableServer::POAManager::_nil();
  CORBA::PolicyList                 policy_list;
  PortableServer::ThreadPolicy_var  thread_policy;
  PortableServer::ObjectId_var      HelloId;
  PortableServer::ObjectId_var      ServiceControllerId;
  CHello                           *pHelloServant = NULL;
  time_t                            startTime;
  time_t                            endTime;  
  int                               nCnt;
  long                              nNumThreads = 0;
  long                              nThreadStackSize = 0;
  CORBA::String_var                 hello_ior;
  
  // Display the splash screen
  splash_screen();
  
  // Ensure correct usage
  if (argc < 2)
  {
    display_usage(argc, argv);
    return (EXIT_FAILURE);
  }

  if( writeConfigFile() != 0 )
    return(EXIT_FAILURE);
    
  nNumThreads = atoi(argv[1]);
  nThreadStackSize = 5;
  
  cout << "Number of threads: " << nNumThreads << endl;
  

  try
  {
    // initialize the orb
    g_orb = CORBA::ORB_init(argc, argv);
  }
  catch(...)
  {
    cerr << "ERROR: An error occurred while initializing the ORB!" << endl;
    return (EXIT_FAILURE);
  }
 
  try
  {
    // get a reference to the Root POA
    obj = g_orb->resolve_initial_references("RootPOA");
  }
  catch( CORBA::ORB::InvalidName )
  {
    cerr << "ERROR: An error occurred while try trying to get a "
         << "reference to the Root POA!" << endl;
    return (EXIT_FAILURE);
  }

  root_poa = PortableServer::POA::_narrow(obj);

  if( CORBA::is_nil( root_poa ) )
  {
    cerr << "ERROR: The reference to the Root POA is nil!" << endl;
    return (EXIT_FAILURE);
  }
  
  // get a reference to the Root POA's manager
  root_poa_mgr = root_poa->the_POAManager();
  
  // activate the Root POA's manager to allow for connections
  root_poa_mgr->activate();
  
  policy_list.length(1);
  
  
  // set the thread policy to orb controlled for the service 
  thread_policy = root_poa->create_thread_policy( PortableServer::ORB_CTRL_MODEL );
  policy_list[0] = PortableServer::ThreadPolicy::_duplicate( thread_policy );

  try
  {
    g_hello_poa = root_poa->create_POA( "HelloPOA", nil_mgr, policy_list );
  }
  catch( PortableServer::POA::AdapterAlreadyExists )
  {
    cerr << "ERROR:  Caught AdapterAlreadyExists while trying to"
         << " create the Factory POA"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }
  catch( PortableServer::POA::InvalidPolicy )
  {
    // this is a design error
    cerr << "ERROR:  Caught InvalidPolicy while trying to"
         << " create the Factory POA"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }

  // get the POA manager for the Factory POA
  hello_poa_mgr = g_hello_poa->the_POAManager();
  
  // activate the Factory's POA manager
  hello_poa_mgr->activate();
  
  policy_list[0]->destroy();
  

  try
  {
    //---------------------------------------------------------------------------
    // Create a Hello servant 
    //---------------------------------------------------------------------------
    pHelloServant = new CHello();

    if(pHelloServant == NULL)
    {
      cerr << "Error creating Hello Object.  Exiting..." << endl;
      return (EXIT_FAILURE);
    }
  }
  catch( ... )
  {
    cerr << "Unknown Error creating Hello Object."
         << endl << "Exiting..." << endl;
    return (EXIT_FAILURE);
  }

 
  try
  {
    // activate the Hello Object
    HelloId = g_hello_poa->activate_object( pHelloServant );
  }
  catch( PortableServer::POA::ServantAlreadyActive )
  {
    cerr << "ERROR:  Caught ServantAlreadyActive while trying to"
         << " activate the Factory Object"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }
  catch( PortableServer::POA::WrongPolicy )
  {
    cerr << "ERROR:  Caught WrongPolicy while trying to"
         << " activate the Factory Object"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }
  
  try
  {
    // convert the id to an object reference
    pHelloRef = g_hello_poa->id_to_reference( HelloId );
  }
  catch( PortableServer::POA::ObjectNotActive )
  {
    cerr << "ERROR:  Caught ObjectNotActive while trying to"
         << " get a reference to the Factory Object"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }
  catch( PortableServer::POA::WrongPolicy )
  {
    cerr << "ERROR:  Caught WrongPolicy while trying to"
         << " get a reference to the Factory Object"
         << " ( file: " << __FILE__ << ", line: " << __LINE__ << " )" << endl;
    return (EXIT_FAILURE);
  }
 
  // converting the object reference into a string 
  hello_ior = g_orb->object_to_string( pHelloRef );
 
  // write the stringified object reference to a file
  if( writeIORFile( "hello.ior", (const char *) hello_ior ) != 0 )
    return(EXIT_FAILURE);


  // array of thread ids
  ACE_thread_t *pThreadIds  = new ACE_thread_t[ nNumThreads ];
  
  if( pThreadIds == NULL )
  {
    cerr << "Error allocating memory for thread ids..." << endl;
    return (EXIT_FAILURE);
  }
  
  // array of stack sizes for the threads
  size_t *pThreadStackSize = new size_t[ nNumThreads ];

  if( pThreadStackSize == NULL )
  {
    cerr << "Error allocating memory for thread stack size..." << endl;
    return (EXIT_FAILURE);
  }
  
  // each thread will have the same stack size
  for( nCnt = 0; nCnt < nNumThreads; nCnt++ )
  {
    pThreadStackSize[nCnt] = nThreadStackSize * 1024 * 1024;
  }
  
  // start the threads
  int nRetVal = ACE_Thread_Manager::instance()->spawn_n( 
                            pThreadIds,                  // array of thread ids
                            nNumThreads,                 // number of threads to spawn
                            &run_orb,                    // pointer a function
                            (void *) g_orb.in(),         // argument to the function
                            THR_JOINABLE | THR_NEW_LWP,  // new threads, that are joinable
                            ACE_DEFAULT_THREAD_PRIORITY, // default priority
                            -1,                          // default group id
                            0,                           // default pointer to thread stack
                            pThreadStackSize,            // array of thread stack sizes
                            0                            // default pointer to ACE_Task
                            );
                            
  if( nRetVal < 0 )
  {
    cerr << "Error spawning threads for the thread pool.  Exiting..." << endl;
    return (EXIT_FAILURE);  
  }
  
  //-------------------------------------------------------------- 
  // create PID file used to stop the service
  // exit if this fails
  //--------------------------------------------------------------
  if (writeToPIDFile() != 0)
   return(EXIT_FAILURE);
  
  //------------------------------------------------------------------
  // Log start time
  //------------------------------------------------------------------
  startTime = time(NULL);
  cout << "=============================================================" << endl;
  cout << argv[0] << endl;
  cout << "Start time: " << ctime(&startTime) << endl;
  display_version();


  //---------------------------------------------------------------------------
  // Wait for the threads to complete
  //---------------------------------------------------------------------------
  for( nCnt = 0; nCnt < nNumThreads; nCnt++ )
  {
    ACE_Thread_Manager::instance()->join( pThreadIds[nCnt], NULL );
  }
  
  //---------------------------------------------------------------------------
  // Free memory needed for TAO's Thread Pool 
  //---------------------------------------------------------------------------
  delete [] pThreadIds;
  delete [] pThreadStackSize;


  //---------------------------------------------------------------------------
  // Release the CORBA objects.
  //---------------------------------------------------------------------------
  CORBA::release(pHelloRef);
  
  //---------------------------------------------------------------------------
  // Decrement the reference count of the servant class
  // - This should make the reference count zero, therefore it will be deleted
  //---------------------------------------------------------------------------
  pHelloServant->_remove_ref();
  
  cout << "Shutdown complete." << endl;
  
  //----------------------------------------------------------------------
  // Log end time
  //----------------------------------------------------------------------
  endTime = time(NULL);
  cout << "=============================================================" << endl;
  cout << "End time: " << ctime(&endTime) << endl << endl;
  
  return (EXIT_SUCCESS);
}

//------------------------------------------------------------------------------
// display_usage
//
// This routine simply displays the usage instructions for this application to
// the screen.
//------------------------------------------------------------------------------
void display_usage(int argc, char * argv[])
{
  cout << "Usage: " << argv[0] << " num_threads" << endl;
  cout << endl;
  cout << "num_threads    number of threads for the service" << endl;
  cout << endl;
  cout << "This application is a simple test." << endl;
  cout << "on this server." << endl;  
  cout << endl;
}

//------------------------------------------------------------------------------
// display_version
//
// This routine simply displays the version of this application to
// the screen.
//------------------------------------------------------------------------------
void display_version()
{
  cout << "\tHello Service - version DEVELOPMENT" << endl
       << "\t\tBuilt " << __DATE__ << " " << __TIME__ << endl << endl;
}

//------------------------------------------------------------------------------
// splash_screen
//
// Displays the splash screen
//------------------------------------------------------------------------------
void splash_screen()
{
  time_t current_time;
  
  // Grab the current time
  time(&current_time);
  
  // Display the splash screen info
  cout << endl;
  cout << "-------------------------------------------------------" << endl;
  cout << "                  Hello Server" << endl << endl;
  cout << "Start Time: " << ctime(&current_time);
  cout << "-------------------------------------------------------" << endl;
  cout << endl;
}

//----------------------------------------------------------------------------
//  Function Name       : writeToPIDFile()
//  Purpose             : write process id to a file for use when killing the 
//                         service
//  Inputs              : 
//  Returns             : 
//  External Functions  : 
//  Comments            : 
//-----------------------------------------------------------------------------
//  Notes:
//-----------------------------------------------------------------------------
int writeToPIDFile()
{
  // copy the services pid to the pid file
  ofstream pidFile("service.pid");
  
  if (!pidFile)
  {
    cerr << "Hello - Could not create PID file for service." << endl;
    return(EXIT_FAILURE);    
  }
  
  pidFile << getpid() << endl;
  pidFile.close();
  
  return(EXIT_SUCCESS);
}    

//----------------------------------------------------------------------------
//  Function Name       : writeConfigFile()
//  Purpose             : write needed config information to a file in the
//                      : directory that the service is being started in 
//  Inputs              : 
//  Returns             : 
//  External Functions  : 
//  Comments            :
//-----------------------------------------------------------------------------
//  Notes:
//-----------------------------------------------------------------------------
int writeConfigFile()
{
  ofstream confFile( CONF_FILE_NAME );
  
  if( !confFile.good() )
  {
    cerr << "Hello - Could not create \"" << CONF_FILE_NAME 
         << "\" file for the service." << endl;
    return(EXIT_FAILURE);    
  }
 
  // this tells the TAO Orb to use a Thread Pool Reactor
  confFile << "static Resource_Factory \"-ORBReactorType tp\""<< endl;
  confFile.close();
  return(EXIT_SUCCESS);
}

//----------------------------------------------------------------------------
//  Function Name       : writeIORFile()
//  Purpose             : write the stringified IOR to a file
//  Inputs              : 
//  Returns             : 
//  External Functions  : 
//  Comments            :
//-----------------------------------------------------------------------------
//  Notes:
//-----------------------------------------------------------------------------
int writeIORFile(const char *pszFileName, const char *pszIor)
{
  // open a file stream for the ior
  ofstream iorFile( pszFileName );
  
  if( !iorFile.good() )
  {
    cerr << "Hello - Could not create \"" << pszFileName 
         << "\" file for the service." << endl;
    return(EXIT_FAILURE);    
  }
 
  // write the ior to the file stream
  iorFile << pszIor << endl;
  iorFile.close();
  
  return(EXIT_SUCCESS);
}

//----------------------------------------------------------------------------
//  Function Name       : run_orb()
//  Purpose             : function the threads are spawned to run in
//  Inputs              : 
//  Returns             : 
//  External Functions  : 
//  Comments            : 
//-----------------------------------------------------------------------------
//  Notes:
//-----------------------------------------------------------------------------
void *run_orb( void *arg )
{
  CORBA::ORB_ptr orb = ( CORBA::ORB_ptr ) arg ;
  
  try
  {
    // ORB event loop
    orb->run();
  }
  catch( CORBA::SystemException &sysEx ) 
  {     
    cerr << "ERROR:  Unexpected system exception in orb->run()" << endl;
    cerr << &sysEx;
    return NULL;
  }
  catch(...)
  {
    cerr << "ERROR:  An error occurred during orb->run()" << endl;
    return NULL;
  }

  return NULL;
}
