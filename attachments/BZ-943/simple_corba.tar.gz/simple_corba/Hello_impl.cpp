#include <iostream.h>
#include "Hello_impl.h"

#define MAX_VALUE 256

//------------------------------------------------------------------------------
// void CHello::CHello()
//------------------------------------------------------------------------------
//
// DESCRIPTION
//  
//  Constructor
//
// PARAMETERS
//  
//  None.
//
// RETURN VALUE
//
//  None.
//
// ERROR HANDLING
//
//  None.
//
//------------------------------------------------------------------------------
CHello::CHello()
{
    
}

//------------------------------------------------------------------------------
// void CHello::~CHello()
//------------------------------------------------------------------------------
//
// DESCRIPTION
//  
//  Destructor
//
// PARAMETERS
//  
//  None.
//
// RETURN VALUE
//
//  None.
//
// ERROR HANDLING
//
//  None.
//
//------------------------------------------------------------------------------
CHello::~CHello()
{
    
}

//------------------------------------------------------------------------------
// void CHello::helloWorld(const char *szInMessage, CORBA::String_out szOutMessage)
//------------------------------------------------------------------------------
//
// DESCRIPTION
//
//  Implementation of the getServiceInfo method.  This is the method that a client
//  will call to get information about the service.
//
// PARAMETERS
//
//  const char *szInMessage
//
//   The incoming message
//
//  CORBA::String_out szOutMessage
//
//   The outgoing message
//
// RETURN VALUE
//
//  None.
//
// ERROR HANDLING
//
//  None.
//
//------------------------------------------------------------------------------
void CHello::helloWorld ( 
    const char *        szInMessage, 
    CORBA::String_out   szOutMessage )  
    ACE_THROW_SPEC (( CORBA::SystemException))
{
#ifdef _DEBUG
  cout << "inside CHelloWorld::helloWorld()" << endl;
#endif

   char return_value[MAX_VALUE];

   cout << "Incoming message: " << szInMessage << "(thread - " 
        << pthread_self() << ")" << endl;
    
   strcpy(return_value, "You had me at hello.");
   szOutMessage = CORBA::string_alloc(strlen(return_value) + 1);
   strcpy(szOutMessage, return_value);

#ifdef _DEBUG
  cout << "leaving CHello::helloWorld()" << endl;
#endif
}
