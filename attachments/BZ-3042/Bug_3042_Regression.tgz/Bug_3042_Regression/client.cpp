// -*- C++ -*-

#include "testC.h"
#include "ace/Log_Msg.h"

ACE_RCSID (BoundedSeq,
           client,
           "$Id: client.cpp 78703 2007-06-30 18:43:31Z tryteks $")

int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  try
    {

       //creation
       Foo::Node node;


    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("Bug_3042_Test test:");
      return -1;
    }
    catch (...)
    {
	return -1;
    }
  return 0;
}
