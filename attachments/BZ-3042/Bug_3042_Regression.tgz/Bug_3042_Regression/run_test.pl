eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
# $Id: run_test.pl 78030 2007-04-16 11:29:29Z johnnyw $

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::Run_Test;

print STDERR "\n\n==== Running Bug_3042_Test test\n";

if (PerlACE::is_vxworks_test()) {
    $T = new PerlACE::ProcessVX ("client");
}
else {
    $T = new PerlACE::Process ("client");
}

$test = $T->SpawnWaitKill ($PerlACE::wait_interval_for_process_creation);

if ($test != 0) {
    print STDERR "ERROR: Bug 3042 test returned $test\n";
    exit 1;
}

exit 0;
