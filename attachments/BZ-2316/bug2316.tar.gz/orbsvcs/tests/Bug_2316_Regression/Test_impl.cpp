// $Id: Test_impl.cpp,v 1.1 2005/11/24 14:07:45 sm Exp $

#include "Test_impl.h"

void Server_impl::shutdown ()
    throw (CORBA::SystemException)
{
  this->orb_->shutdown (0);
}

Server_impl::Server_impl (CORBA::ORB_ptr orb)
    : orb_ (CORBA::ORB::_duplicate (orb))
{
}

void Server_impl::method (CORBA::Object_ptr)
    throw (CORBA::SystemException)
{
}
