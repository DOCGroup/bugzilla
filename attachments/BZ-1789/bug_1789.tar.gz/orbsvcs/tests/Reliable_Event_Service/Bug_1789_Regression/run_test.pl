eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -w -S $0 $argv:q'
    if 0;

# $Id$
# -*- perl -*-

use lib '../../../../../bin';
use PerlACE::Run_Test;
use strict;

my $output_file = '';
my $status = 0;

sub run_test;
sub redirect_output;
sub restore_output;
sub analyze_results;

redirect_output();
$status = 1 if run_test() != 0;
restore_output();
$status = 1 if analyze_results() != 0;

exit $status;

sub run_test {
  my $ps = new PerlACE::Process ("Bug_1789_Regression");
  if ($ps->Spawn () == -1) {
    print STDERR "ERROR startup failed\n";
    return -1;
  }
  my $result = 0;

  $result = -1 if $ps->WaitKill(300) != 0;

  print STDERR "ERROR detected during shutdown\n" if $result != 0;

  return $result;
}

sub redirect_output {
    my $rundate = POSIX::strftime("%Y_%m_%d_%H_%M", localtime);
    $output_file = PerlACE::LocalFile ("run_test_$rundate");

    open (OLDOUT, ">&STDOUT");
    open (STDOUT, ">$output_file") or die "can't redirect stdout: $!";
    open (OLDERR, ">&STDERR");
    open (STDERR, ">&STDOUT") or die "can't redirect stderror: $!";
}

sub restore_output {
    # Restore output facilities.
    close (STDERR);
    close (STDOUT);
    open (STDOUT, ">&OLDOUT");
    open (STDERR, ">&OLDERR");
}

sub analyze_results {
  open (TEST_OUTPUT, "<$output_file")
    || die "ERROR Cannot open $output_file\n";

  while (<TEST_OUTPUT>) {
    next if(m/REC_NOTICE/);
    next if(m/REC_INFO/);

    $status = -1;
    print STDERR "ERROR, unexpected output: ", $_;
  }
  close (TEST_OUTPUT);

  if($status == 0) {
    print "SUCCESS\n";
    return 0;
  }

  print STDERR "ERROR: check $output_file for full output\n";
  return -1;
}
