#include "orbsvcs/ReliableEvent/REC_Basic_Sequence_Verifier.h"
#include "orbsvcs/Event_Service_Constants.h"
#include "tao/Utils/ORB_Destroyer.h"
#include "tao/ORB.h"
#include "ace/Vector_T.h"

#include <iostream>

class Test_Sequence_Verifier
  : public TAO_REC_Basic_Sequence_Verifier
{
public:
  Test_Sequence_Verifier (CORBA::ORB_ptr orb);

  bool test_heartbeat_at_start (ACE_ENV_SINGLE_ARG_DECL);

  // The next function is the actual regression test for 1789, the
  // other functions test other potentially broken conditions and
  // ensure that the class works as expected in the normal scenarios.
  bool test_accept_first_event (ACE_ENV_SINGLE_ARG_DECL);

  bool test_missed_first_event (ACE_ENV_SINGLE_ARG_DECL);
  bool test_normal_case (ACE_ENV_SINGLE_ARG_DECL);
  bool test_high_heartbeat (ACE_ENV_SINGLE_ARG_DECL);
  bool test_resends_on_gap (ACE_ENV_SINGLE_ARG_DECL);
  bool test_heartbeat_at_end (ACE_ENV_SINGLE_ARG_DECL);

protected:
  virtual void persist_new_entry (MAP::ENTRY * entry);
  virtual void persist_old_entry (MAP::ENTRY * entry);
  virtual void ask_for_resend (ReliableEventComm::EventSourceID source,
                               ReliableEventComm::SequenceNumber last_received
                               ACE_ENV_ARG_DECL);

private:
  void clear_all (void);

private:
  struct Entry
  {
    Entry (void);
    Entry (MAP::ENTRY const & entry);

    CORBA::Long source_id_;
    RtecEventComm::SequenceNumber next_event_sequence_number_;
    unsigned long index_in_persistent_storage_;
    long resend_request_timer_id_;
  };
  ACE_Vector<Entry> new_entries_;
  ACE_Vector<Entry> old_entries_;

  struct Resend
  {
    Resend (void);
    Resend (ReliableEventComm::EventSourceID source,
            ReliableEventComm::SequenceNumber last_received);

    ReliableEventComm::EventSourceID source_;
    ReliableEventComm::SequenceNumber last_received_;
  };
  ACE_Vector<Resend> resends_;

  CORBA::ORB_var orb_;
};

int
main(int argc, char * argv[])
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb (CORBA::ORB_init(argc,
                                          argv,
                                          ""
                                          ACE_ENV_ARG_PARAMETER));
      ACE_TRY_CHECK;

      TAO::Utils::ORB_Destroyer orb_destroyer (orb.in());

      Test_Sequence_Verifier tester (orb.in ());

      bool success = true;

      success &= tester.test_heartbeat_at_start (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_accept_first_event (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_missed_first_event (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_normal_case (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_high_heartbeat (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_resends_on_gap (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      success &= tester.test_heartbeat_at_end (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (!success)
      {
        return 1;
      }
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION, "Exception raised in test: ");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

Test_Sequence_Verifier::
Test_Sequence_Verifier (CORBA::ORB_ptr orb)
  : TAO_REC_Basic_Sequence_Verifier (// very long resend request rate,
                                     // so it does not affect the test
                                     ACE_Time_Value(100, 0),
                                     orb,
                                     // null REC_ProxyPushSupplier,
                                     // not used in the test
                                     0)
  , new_entries_ ()
  , old_entries_ ()
  , resends_ ()
  , orb_ (CORBA::ORB::_duplicate(orb))
{
}

#define assert_equals(X, Y, FLAG) \
  if ((X) != (Y)) { \
    std::cerr << "ERROR assert_equals failed " \
              << #X << " != " << #Y \
              << ",expected=" << X \
              << ",was=" << Y \
              << ",context=" << __FILE__ << ":" << __LINE__ \
              << std::endl; \
    FLAG = false; \
  }


bool Test_Sequence_Verifier::
test_heartbeat_at_start (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_HEARTBEAT;
  event.header.source = 1234;
  event.header.event_sequence = 1;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(1, new_entries_[0].next_event_sequence_number_, success);
  }

  event.header.type = ACE_ES_EVENT_UNDEFINED;

  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, old_entries_.size(), success);
  if (old_entries_.size() >= 1)
  {
    assert_equals(event.header.source, old_entries_[0].source_id_, success);
    assert_equals(2, old_entries_[0].next_event_sequence_number_, success);
  }

  assert_equals(0, resends_.size(), success);

  return success;
}

bool Test_Sequence_Verifier::
test_accept_first_event (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_UNDEFINED; // first usable type
  event.header.source = 2345;
  event.header.event_sequence = 1;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(2, new_entries_[0].next_event_sequence_number_, success);
  }

  assert_equals(0, old_entries_.size(), success);
  assert_equals(0, resends_.size(), success);

  return success;
}

bool Test_Sequence_Verifier::
test_missed_first_event (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_UNDEFINED; // first usable type
  event.header.source = 3456;
  event.header.event_sequence = 4;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(1, new_entries_[0].next_event_sequence_number_, success);
  }

  // Run the event loop, as the resend request is scheduled in a
  // (very short) timer ...
  ACE_Time_Value tv(0, 100000);
  orb_->run(tv ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);

  assert_equals(1, resends_.size(), success);
  if (resends_.size() >= 1)
  {
    assert_equals(event.header.source, resends_[0].source_, success);
    assert_equals(0, resends_[0].last_received_, success);
  }

  event.header.event_sequence = 1;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  event.header.event_sequence = 2;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  event.header.event_sequence = 3;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  event.header.event_sequence = 4;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  assert_equals(4, old_entries_.size(), success);
  for (size_t i = 0; i != old_entries_.size(); ++i)
  {
    assert_equals(event.header.source, old_entries_[i].source_id_, success);
    assert_equals(i + 2, old_entries_[i].next_event_sequence_number_, success);
  }

  assert_equals(1, resends_.size(), success);

  return success;
}

bool Test_Sequence_Verifier::
test_normal_case (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_UNDEFINED; // first usable type
  event.header.source = 4567;
  event.header.event_sequence = 1;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(2, new_entries_[0].next_event_sequence_number_, success);
  }

  event.header.event_sequence = 2;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, old_entries_.size(), success);
  if (old_entries_.size() >= 1)
  {
    assert_equals(event.header.source, old_entries_[0].source_id_, success);
    assert_equals(3, old_entries_[0].next_event_sequence_number_, success);
  }

  assert_equals(0, resends_.size(), success);

  return success;
}

bool Test_Sequence_Verifier::
test_high_heartbeat (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_HEARTBEAT;
  event.header.source = 5678;
  event.header.event_sequence = 4;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(1, new_entries_[0].next_event_sequence_number_, success);
  }

  // Run the event loop, as the resend request is scheduled in a
  // (very short) timer ...
  ACE_Time_Value tv(0, 100000);
  orb_->run(tv ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);

  assert_equals(1, resends_.size(), success);
  if (resends_.size() >= 1)
  {
    assert_equals(event.header.source, resends_[0].source_, success);
    assert_equals(0, resends_[0].last_received_, success);
  }

  event.header.type = ACE_ES_EVENT_UNDEFINED;
  event.header.event_sequence = 1;

  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  assert_equals(1, old_entries_.size(), success);
  if (old_entries_.size() >= 1)
  {
    assert_equals(event.header.source, old_entries_[0].source_id_, success);
    assert_equals(2, old_entries_[0].next_event_sequence_number_, success);
    assert_equals(-1, old_entries_[0].resend_request_timer_id_, success);
  }

  assert_equals(1, resends_.size(), success);

  return success;
}

bool Test_Sequence_Verifier::
test_resends_on_gap (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_UNDEFINED; // first usable type
  event.header.source = 6789;
  event.header.event_sequence = 1;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(2, new_entries_[0].next_event_sequence_number_, success);
  }

  event.header.event_sequence = 2;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, old_entries_.size(), success);
  if (old_entries_.size() >= 1)
  {
    assert_equals(event.header.source, old_entries_[0].source_id_, success);
    assert_equals(3, old_entries_[0].next_event_sequence_number_, success);
  }

  assert_equals(0, resends_.size(), success);

  event.header.event_sequence = 4;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);
  assert_equals(1, new_entries_.size(), success);
  assert_equals(1, old_entries_.size(), success);

  // Run the event loop, as the resend request is scheduled in a
  // (very short) timer ...
  ACE_Time_Value tv(0, 100000);
  orb_->run(tv ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);

  assert_equals(1, resends_.size(), success);
  if (resends_.size() >= 1)
  {
    assert_equals(event.header.source, resends_[0].source_, success);
    assert_equals(2, resends_[0].last_received_, success);
  }

  event.header.event_sequence = 3;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  assert_equals(2, old_entries_.size(), success);
  if (old_entries_.size() >= 2)
  {
    assert_equals(event.header.source, old_entries_[1].source_id_, success);
    assert_equals(4, old_entries_[1].next_event_sequence_number_, success);
    assert_equals(-1, old_entries_[1].resend_request_timer_id_, success);
  }


  event.header.type = ACE_ES_EVENT_HEARTBEAT;
  event.header.event_sequence = 5;
  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  assert_equals(2, old_entries_.size(), success);

  // Run the event loop, as the resend request is scheduled in a
  // (very short) timer ...
  tv.set(0, 100000);
  orb_->run(tv ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);

  assert_equals(2, resends_.size(), success);
  if (resends_.size() >= 2)
  {
    assert_equals(event.header.source, resends_[1].source_, success);
    assert_equals(3, resends_[1].last_received_, success);
  }

  return success;
}

bool Test_Sequence_Verifier::
test_heartbeat_at_end (ACE_ENV_SINGLE_ARG_DECL)
{
  clear_all ();

  RtecEventComm::Event event;

  event.header.type = ACE_ES_EVENT_UNDEFINED;
  event.header.source = 67890;
  event.header.event_sequence = 1;

  bool success = true;

  int accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(1, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  if (new_entries_.size() >= 1)
  {
    assert_equals(event.header.source, new_entries_[0].source_id_, success);
    assert_equals(2, new_entries_[0].next_event_sequence_number_, success);
  }

  event.header.type = ACE_ES_EVENT_HEARTBEAT;
  event.header.event_sequence = 2;

  accepted = this->verify (event ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);
  assert_equals(0, accepted, success);

  assert_equals(1, new_entries_.size(), success);
  assert_equals(0, old_entries_.size(), success);

  // Run the event loop, as the resend request is scheduled in a
  // (very short) timer ...
  ACE_Time_Value tv(0, 100000);
  orb_->run(tv ACE_ENV_ARG_PARAMETER);
  ACE_CHECK_RETURN(false);

  assert_equals(0, resends_.size(), success);

  return success;
}



void Test_Sequence_Verifier::
persist_new_entry (MAP::ENTRY * entry)
{
  new_entries_.push_back (Entry(*entry));
}

void Test_Sequence_Verifier::
persist_old_entry (MAP::ENTRY * entry)
{
  old_entries_.push_back (Entry(*entry));
}

void Test_Sequence_Verifier::
ask_for_resend (ReliableEventComm::EventSourceID source,
                ReliableEventComm::SequenceNumber last_received
                ACE_ENV_ARG_DECL)
{
  resends_.push_back (Resend(source, last_received));
}

void Test_Sequence_Verifier::
clear_all (void)
{
  new_entries_.clear ();
  old_entries_.clear ();
  resends_.clear ();
}

Test_Sequence_Verifier::Entry::
Entry (void)
  : source_id_ ()
  , next_event_sequence_number_ ()
  , index_in_persistent_storage_ ()
  , resend_request_timer_id_ ()
{
}

Test_Sequence_Verifier::Entry::
Entry (MAP::ENTRY const & entry)
  : source_id_ (entry.ext_id_)
  , next_event_sequence_number_ (entry.int_id_.next_)
  , index_in_persistent_storage_ (entry.int_id_.index_)
  , resend_request_timer_id_ (entry.int_id_.timer_id_)
{
}

Test_Sequence_Verifier::Resend::
Resend (void)
  : source_ ()
  , last_received_ ()
{
}

Test_Sequence_Verifier::Resend::
Resend (ReliableEventComm::EventSourceID source,
        ReliableEventComm::SequenceNumber last_received)
  : source_ (source)
  , last_received_ (last_received)
{
}


