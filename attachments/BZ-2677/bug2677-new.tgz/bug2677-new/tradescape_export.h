
// -*- C++ -*-
// $Id$
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl tradescape
// ------------------------------
#ifndef TRADESCAPE_EXPORT_H
#define TRADESCAPE_EXPORT_H

#include "ace/config-all.h"

#if !defined (TRADESCAPE_HAS_DLL)
#  define TRADESCAPE_HAS_DLL 1
#endif /* ! TRADESCAPE_HAS_DLL */

#if defined (TRADESCAPE_HAS_DLL) && (TRADESCAPE_HAS_DLL == 1)
#  if defined (TRADESCAPE_BUILD_DLL)
#    define tradescape_Export ACE_Proper_Export_Flag
#    define TRADESCAPE_SINGLETON_DECLARATION(T) ACE_EXPORT_SINGLETON_DECLARATION (T)
#    define TRADESCAPE_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_EXPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  else /* TRADESCAPE_BUILD_DLL */
#    define tradescape_Export ACE_Proper_Import_Flag
#    define TRADESCAPE_SINGLETON_DECLARATION(T) ACE_IMPORT_SINGLETON_DECLARATION (T)
#    define TRADESCAPE_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_IMPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  endif /* TRADESCAPE_BUILD_DLL */
#else /* TRADESCAPE_HAS_DLL == 1 */
#  define tradescape_Export
#  define TRADESCAPE_SINGLETON_DECLARATION(T)
#  define TRADESCAPE_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#endif /* TRADESCAPE_HAS_DLL == 1 */

// Set TRADESCAPE_NTRACE = 0 to turn on library specific tracing even if
// tracing is turned off for ACE.
#if !defined (TRADESCAPE_NTRACE)
#  if (ACE_NTRACE == 1)
#    define TRADESCAPE_NTRACE 1
#  else /* (ACE_NTRACE == 1) */
#    define TRADESCAPE_NTRACE 0
#  endif /* (ACE_NTRACE == 1) */
#endif /* !TRADESCAPE_NTRACE */

#if (TRADESCAPE_NTRACE == 1)
#  define TRADESCAPE_TRACE(X)
#else /* (TRADESCAPE_NTRACE == 1) */
#  if !defined (ACE_HAS_TRACE)
#    define ACE_HAS_TRACE
#  endif /* ACE_HAS_TRACE */
#  define TRADESCAPE_TRACE(X) ACE_TRACE_IMPL(X)
#  include "ace/Trace.h"
#endif /* (TRADESCAPE_NTRACE == 1) */

#endif /* TRADESCAPE_EXPORT_H */

// End of auto generated file.
