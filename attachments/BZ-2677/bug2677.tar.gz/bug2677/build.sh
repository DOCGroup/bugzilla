#!/bin/bash

#set -e
set -v


SYSPATH=/opt2/linux/i686
#SYSPATH=/opt2/linux/x86_64

#GXX=/opt2/linux/ix86/x86_64-pc-linux-gnu/bin/g++
GXX=g++


ACE_ROOT=$SYSPATH/ACE/1.5.1/ACE_wrappers

LOG4CPLUS_INCLUDE=$SYSPATH/include
LOG4CPLUS_LIB=$SYSPATH/lib

dir=`dirname $0`
cd ${dir}

if [ "${1}" == "tar" ] ; then
	rm -f core *.o *.so sig *~
	cd ..
	tar -cvzf sig.tar.gz sig
	exit 0
fi

$GXX --version

FLAG=-m32
#FLAG=-m64

$GXX -g -O0 $FLAG -fPIC -I$ACE_ROOT -I$ACE_ROOT/TAO -I$LOG4CPLUS_INCLUDE -DTRADESCAPE_BUILD_DLL -O0 -c -o DllOrb.o DllOrb.cpp

$GXX -g -O0 $FLAG -fPIC -I$ACE_ROOT -I$ACE_ROOT/TAO -I$LOG4CPLUS_INCLUDE -O0 -c -o sig.o sig.cpp

$GXX -g -O0 $FLAG -L$ACE_ROOT/lib -L$LOG4CPLUS_LIB -shared -lTAO_PortableServer -lTAO -lACE -o libtradescape.so DllOrb.o

$GXX -g -O0 $FLAG -L$ACE_ROOT/lib -L$LOG4CPLUS_LIB -lACE -llog4cplus -o sig sig.o


LD_LIBRARY_PATH=.:$ACE_ROOT/lib:$LOG4CPLUS_LIB
export LD_LIBRARY_PATH

rm -f core*

if [ "${1}" == "gdb" ] ; then
	gdb ./sig
elif [ "${1}" == "bash" ] ; then
	bash
else
	ulimit -c unlimited
	./sig
fi
