/*
 * Copyright (c) 2005 Tradescape Inc.  All rights reserved.
 * 
 * @author lothar
 */


#include "ace/Arg_Shifter.h"
#include "ace/SString.h"
#include "ace/OS_NS_unistd.h"

#include "tao/corba.h"
#include "tao/TAO_Singleton_Manager.h"
#include "tao/Version.h"


#include "DllOrb.h"



DllOrb::DllOrb ( )
:
  m_failPrePostInit(0),
  mp_barrier(0),
  mv_orb(),
  mv_rootPOA()
{
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) DllOrb\n"));
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) using TAO_VERSION=%s\n", TAO_VERSION));
} /* end of DllOrb::DllOrb ( ) */


DllOrb::~DllOrb ( )
{
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) ~DllOrb\n"));
  delete mp_barrier;
} /* end of DllOrb::~DllOrb ( ) */


int DllOrb::init (int argc, char *argv[])
{
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) init\n"));
  
  int result = 0;
  int threadCnt = 1;
    
  try
  {
//    ENFORCE(argc >= 1)("need at least one argument");
//    for(int i = 0; i < argc; ++i)
//    {
//      ACE_DEBUG(LM_DEBUG, "argv[" << i << "]=" <<  argv[i]);
//    }
    std::string orbName = argv[0];
    
    ACE_Arg_Shifter as(argc, argv);
    const ACE_TCHAR *currentArg = 0;
    while(as.is_anything_left())
    {
      if((currentArg = as.get_the_parameter("-NumThreads")))
      {
        int num = ACE_OS::atoi(currentArg);
        if(num >= 1)
          threadCnt = num;
        as.consume_arg();
      }
      else
        as.ignore_arg();
    }
    
    // 0 == fail (default)
    // 1 == ignore
    // 2 == do not warn
    // 3 == do not execute
    unsigned int const c_failPrePostInit = 1;
    
/*
    // read configuration information
    SystemConfiguration config;
    LOG4CPLUS_DEBUG(LM_DEBUG, "checking general 'FailPrePostInit'");
    config.getIntegerValue(
      std::string("tradescape/harvest/DllOrb"),
      std::string("FailPrePostInit"),
      c_failPrePostInit,
      m_failPrePostInit
    );
    if(m_failPrePostInit != c_failPrePostInit)
      LOG4CPLUS_INFO(LM_DEBUG, "general FailPrePostInit=" << m_failPrePostInit);
    
    LOG4CPLUS_DEBUG(LM_DEBUG, "checking 'FailPrePostInit' for ORB '" << orbName << "'");
    config.getIntegerValue(
      std::string("tradescape/harvest/DllOrb/") + orbName,
      std::string("FailPrePostInit"),
      m_failPrePostInit,
      m_failPrePostInit
    );
    if(m_failPrePostInit != c_failPrePostInit)
      LOG4CPLUS_INFO(LM_DEBUG, "'" << orbName << "' FailPrePostInit=" << m_failPrePostInit);
*/

    if (m_failPrePostInit < 3)
    {
      ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Pre-ORB initialization ...\n"));
      // -----------------------------------------------------------------
      // Pre-ORB initialization steps necessary for proper DLL ORB
      // support.
      // -----------------------------------------------------------------
      // Make sure TAO's singleton manager is initialized, and set to not
      // register itself with the ACE_Object_Manager since it is under the
      // control of the Service Configurator.  If we register with the
      // ACE_Object_Manager, then the ACE_Object_Manager will still hold
      // (dangling) references to instances of objects created by this
      // module and destroyed by this object when it is dynamically
      // unloaded.
      int register_with_object_manager = 0;
      TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
      result = p_tsm->init(register_with_object_manager);
      
      if (result == -1)
      {
        if (m_failPrePostInit == 0)
        {
          ACE_ERROR((LM_DEBUG, "TEST (%P|%t) Pre-ORB initialization failed.\n"));
          return -1;
  			} /* end of if */
        else if (m_failPrePostInit < 2)
        {
          ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Pre-ORB initialization failed (ignored due to FailPrePostInit setting).\n"));
        } /* end of else if */
        else
        {
          ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Pre-ORB initialization failed (ignored due to FailPrePostInit setting).\n"));
        } /* end of else */
      } /* end of if */
      else
      {
        ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Pre-ORB initialization done\n"));
      } /* end of else */
    } /* end of if */
          
    // Initialize the ORB
    mv_orb = CORBA::ORB_init(
      argc,
      argv,
      0
    );
    if (CORBA::is_nil(mv_orb.in()))
    {
      ACE_ERROR((LM_DEBUG, "TEST (%P|%t) nil ORB\n"));
      return -1;
    }
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) got ORB\n"));
    
    CORBA::Object_var v_poa = mv_orb->resolve_initial_references("RootPOA");
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) got root POA\n"));
    
    mv_rootPOA = PortableServer::POA::_narrow(v_poa.in ());
    if (CORBA::is_nil(mv_rootPOA.in()))
    {
      ACE_ERROR((LM_DEBUG, "TEST (%P|%t) nil RootPOA\n"));
      return -1;
    }
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) narrowed root POA\n"));
    
    mv_poaManager = mv_rootPOA->the_POAManager();
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) got POA manager\n"));
    if (CORBA::is_nil(mv_poaManager.in()))
    {
      ACE_ERROR((LM_DEBUG, "TEST (%P|%t) nil POAManager\n"));
      return -1;
    }
    
    mv_poaManager->activate();
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) activated POA manager\n"));
  }
/*
  DM_catchExceptionsCORBA(LM_DEBUG, return -1)
  DM_catchExceptionsTradescape(LM_DEBUG, true, return -1)
  DM_catchExceptions(LM_DEBUG, return -1)
*/
  catch(...)
  {
    ACE_ERROR((LM_DEBUG, "TEST (%P|%t) exception\n"));
    return -1;
  }

  mp_barrier = new ACE_Thread_Barrier(threadCnt + 1);
//  ENFORCE(mp_barrier != 0)("could not allocate barrier");
  
  this->activate(
    THR_NEW_LWP|THR_JOINABLE|THR_INHERIT_SCHED,
    threadCnt
  );
  mp_barrier->wait();
  
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) ORB runs with %d threads\n", threadCnt));

  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) ORB initialization done\n"));

  return 0;
} /* end of DllOrb::init ( ) */
   

int DllOrb::fini (void)
{
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) fini\n"));
  int result;
  
  try
  {
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_poaManager->deactivate(1, 1) ...\n"));
    mv_poaManager->deactivate(1, 1);
    mv_poaManager = PortableServer::POAManager::_nil();
    ACE_DEBUG ((LM_DEBUG, "TEST (%P|%t) mv_poaManager->deactivate(1, 1) done\n"));
    
    // attempt to protect against sporadic BAD_INV_ORDER exceptions
    ACE_OS::sleep(ACE_Time_Value(0, 500));
    
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->shutdown(1) ...\n"));
    mv_orb->shutdown(1);
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->shutdown(1) done\n"));
  }
//  DM_catchExceptionsCORBA(LM_DEBUG, return -1)
  catch(...)
  {
    ACE_ERROR((LM_DEBUG, "TEST (%P|%t) exception\n"));
    return -1;
  }
  
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) wait() ..."));
  // wait for our threads to finish
  wait();
  ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) wait() done\n"));
  
  delete mp_barrier;
  mp_barrier = 0;
  
  try
  {
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->destroy() ...\n"));
    mv_orb->destroy();
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->destroy() done\n"));
    mv_orb = CORBA::ORB::_nil();
  }
  catch(CORBA::Exception const & rc_ex)
  {
    ACE_ERROR((LM_DEBUG, "TEST (%P|%t) could not destroy ORB:\n")); //, rc_ex));
    return -1;
  }
  
  if (m_failPrePostInit < 3)
  {
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Post-ORB finalization ...\n"));
    // -----------------------------------------------------------------
    // Post-ORB finalization steps necessary for proper DLL ORB
    // support.
    // -----------------------------------------------------------------
    // Explicitly clean up singletons created by TAO before
    // unloading this module.
    TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
    result = p_tsm->fini();
    if (result == -1)
    {
      if (m_failPrePostInit == 0)
      {
        ACE_ERROR((LM_DEBUG, "TEST (%P|%t) Post-ORB finalization failed.\n"));
        return -1;
      } /* end of if */
      else if (m_failPrePostInit < 2)
      {
        ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Post-ORB finalization failed (ignored due to FailPrePostInit setting).\n"));
      } /* end of else if */
      else
      {
        ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) Post-ORB finalization failed (ignored due to FailPrePostInit setting).\n"));
      }
    } /* end of if */
    else
    {
      ACE_DEBUG ((LM_DEBUG, "TEST (%P|%t) Post-ORB finalization done\n"));
    } /* end of else */
  } /* end of if */
    
  ACE_DEBUG ((LM_DEBUG, "TEST (%P|%t) ORB finalization done\n"));
  
  return 0;
} /* end of DllOrb::fini ( ) */

int DllOrb::svc (void)
{

  mp_barrier->wait();
  
  int result = -1;
  
  try
  {
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->run ...\n"));
    try
    {
      mv_orb->run();
    }
    catch(CORBA::BAD_INV_ORDER const & rc_ex)
    {
      const CORBA::ULong VMCID = rc_ex.minor() & 0xFFFFF000U;
      const CORBA::ULong minorCode = rc_ex.minor() & 0xFFFU;
      if (VMCID == CORBA::OMGVMCID && minorCode == 4)
      {
        ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) ignored 'CORBA::BAD_INV_ORDER: ORB has shutdown.'\n"));
      }
      else
      {
        throw;
      }
    }
    ACE_DEBUG((LM_DEBUG, "TEST (%P|%t) mv_orb->run done\n"));
  }
/*
  DM_catchExceptionsCORBA(LM_DEBUG, return result)
  DM_catchExceptionsTradescape(LM_DEBUG, true, return result)
  DM_catchExceptions(LM_DEBUG, return result)
*/
  catch(...)
  {
    ACE_ERROR((LM_DEBUG, "TEST (%P|%t) svc - exception\n"));
    return result;
  }
  
  result = 0;
  return result;
} /* end of DllOrb::svc ( ) */


ACE_FACTORY_DEFINE (tradescape, DllOrb)
