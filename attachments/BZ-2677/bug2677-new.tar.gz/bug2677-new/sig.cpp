#include "ace/OS.h"
#include "ace/Service_Config.h"


char const * const scpc_orbId = "testORB";

char const * const scpc_loadOrb = ACE_DYNAMIC_SERVICE_DIRECTIVE(
  "testDllOrb",
  "tradescape",
  "_make_DllOrb",
  "testDllOrb -ORBDebugLevel 30 -ORBId testORB -ORBInitRef NameService=file:///tmp/test-ns.ior -ORBDottedDecimalAddresses 1"
);

char const * const scpc_unloadOrb = ACE_REMOVE_SERVICE_DIRECTIVE("testDllOrb");


char const * const scpc_namingServiceIorFileName = "/tmp/test-ns.ior";

char const * const scpc_loadNamingService = ACE_DYNAMIC_SERVICE_DIRECTIVE(
  "testNamingService",
  "TAO_CosNaming_Serv",
  "_make_TAO_Naming_Loader",
  "testNameService -m 0 -o /tmp/test-ns.ior -ORBId testORB"
);

char const * const scpc_unloadNamingService = ACE_REMOVE_SERVICE_DIRECTIVE("testNamingService");



int main(int argc, char ** argv)
{
	int result;

	// do not use the default svc.conf file
	ACE_Service_Config::open (
	argv[0],
	ACE_DEFAULT_LOGGER_KEY,
	1,
	1,
	0
	);

	result = ACE_Service_Config::process_directive(scpc_loadOrb);
	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "loading ORB (1) done"));

	ACE_OS::sleep(1);

	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "unloading ORB (1) ..."));
	result = ACE_Service_Config::process_directive(scpc_unloadOrb);
	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "unloading ORB (1) done"));

	ACE_OS::sleep(1);

	result = ACE_Service_Config::process_directive(scpc_loadOrb);
	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "loading ORB (2) done"));
		
	ACE_OS::sleep(1);

	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "unloading ORB (2) ..."));
	result = ACE_Service_Config::process_directive(scpc_unloadOrb);
	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "unloading ORB (2) done"));

	ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "test done, exiting"));

	return 0;
}
