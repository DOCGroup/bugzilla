#!/bin/bash

set -e
#set -v

dir=`dirname ${0}`
cd ${dir}

if [ "${1}" == "version" ] ; then
  ACE_VERSION=${2}
  shift 2
else
  ACE_VERSION=1.5.7
fi

if [ "${1}" == "i686" ] ; then
  SYSPATH=/opt2/linux/i686
  FLAG=" -m32"
  shift 1
elif [ "${1}" == "x86_64" ] ; then
  SYSPATH=/opt2/linux/x86_64
  FLAG=" -m64"
  shift 1
else
  SYSPATH=/opt2/linux/x86_64
  FLAG=" -m64"
fi

if [ "${1}" == "gxx" ] ; then
  GXX=${2}
  shift 2
else
  GXX=/opt2/linux/ix86/x86_64-pc-linux-gnu/bin/g++
fi


ACE_ROOT=${SYSPATH}/ACE/${ACE_VERSION}/ACE_wrappers
TAO_ROOT=${ACE_ROOT}/TAO
CIAO_ROOT=${ACE_ROOT}/TAO/CIAO
DDS_ROOT=/tmp/notthere

export ACE_ROOT
export TAO_ROOT
export CIAO_ROOT
export DDS_ROOT

LOG4CPLUS_INCLUDE=${SYSPATH}/include
LOG4CPLUS_LIB=${SYSPATH}/lib

if [ ! -d ${ACE_ROOT} ] ; then
  echo ${ACE_ROOT} does not exist
  exit 1
fi

rm -rf core* *.o *.so* .shobj .obj .depend* sig *~

if [ "${1}" == "tar" ] ; then
  pwd=`pwd`
  tarname=`basename ${pwd}`
  cd ..
  tar -cvzf ${tarname}.tar.gz ${tarname}
  exit 0
elif [ "${1}" == "mpc" ] ; then
  shift
  echo ACE_ROOT=${ACE_ROOT}
  echo TAO_ROOT=${TAO_ROOT}
  echo CIAO_ROOT=${CIAO_ROOT}
  echo DDS_ROOT=${DDS_ROOT}
  
  ${ACE_ROOT}/bin/mwc.pl -type gnuace
  make -f GNUmakefile clean all
else
  echo ACE_ROOT=${ACE_ROOT}
  echo TAO_ROOT=${TAO_ROOT}
  echo CIAO_ROOT=${CIAO_ROOT}
  echo DDS_ROOT=${DDS_ROOT}
  
  ${GXX} --version
  
  ${GXX} -g -O0 ${FLAG} -fPIC -I${ACE_ROOT} -I${TAO_ROOT} -I${LOG4CPLUS_INCLUDE} -DTRADESCAPE_BUILD_DLL -O0 -c -o DllOrb.o DllOrb.cpp
  
  ${GXX} -g -O0 ${FLAG} -fPIC -I${ACE_ROOT} -I${TAO_ROOT} -I${LOG4CPLUS_INCLUDE} -O0 -c -o sig.o sig.cpp
  
  ${GXX} -g -O0 ${FLAG} -L${ACE_ROOT}/lib -L${LOG4CPLUS_LIB} -shared -lTAO_PortableServer -lTAO -lACE -o libtradescape.so DllOrb.o
  
  ${GXX} -g -O0 ${FLAG} -L${ACE_ROOT}/lib -L${LOG4CPLUS_LIB} -lACE -o sig sig.o
fi

LD_LIBRARY_PATH=.:${ACE_ROOT}/lib:${LOG4CPLUS_LIB}
export LD_LIBRARY_PATH

echo LD_LIBRARY_PATH=${LD_LIBRARY_PATH}


if [ "${1}" == "gdb" ] ; then
  gdb ./sig
elif [ "${1}" == "bash" ] ; then
  bash
else
  ulimit -c unlimited
  ./sig
fi
