/*
 * Copyright (c) 2007 Tradescape Inc.  All rights reserved.
 * 
 * @author lothar
 */


#include "ace/Arg_Shifter.h"
#include "ace/SString.h"
#include "ace/OS_NS_unistd.h"
#include "tao/corba.h"
#include "tao/TAO_Singleton_Manager.h"
#include "tao/Version.h"


#include "DllOrb.h"


DllOrb::DllOrb ( )
:
  m_failPrePostInit(3),
  mp_barrier(0),
  mv_orb(),
  mv_rootPOA()
{
  ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), TAO_VERSION));
} /* end of DllOrb::DllOrb ( ) */


DllOrb::~DllOrb ( )
{
  delete mp_barrier;
} /* end of DllOrb::~DllOrb ( ) */


int DllOrb::init (int argc, char *argv[])
{
  int result = 0;
  int threadCnt = 1;
    
  try
  {
    std::string orbName = argv[0];
    
    ACE_Arg_Shifter as(argc, argv);
    const ACE_TCHAR *currentArg = 0;
    while(as.is_anything_left())
    {
      if((currentArg = as.get_the_parameter("-NumThreads")))
      {
        int num = ACE_OS::atoi(currentArg);
        if(num >= 1)
          threadCnt = num;
        as.consume_arg();
      }
      else
        as.ignore_arg();
    }
    
    // 0 == fail (default)
    // 1 == ignore
    // 2 == do not warn
    // 3 == do not execute
    unsigned int const c_failPrePostInit = 1;

    if (m_failPrePostInit < 3)
    {
      ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Pre-ORB initialization ..."));
      // -----------------------------------------------------------------
      // Pre-ORB initialization steps necessary for proper DLL ORB
      // support.
      // -----------------------------------------------------------------
      // Make sure TAO's singleton manager is initialized, and set to not
      // register itself with the ACE_Object_Manager since it is under the
      // control of the Service Configurator.  If we register with the
      // ACE_Object_Manager, then the ACE_Object_Manager will still hold
      // (dangling) references to instances of objects created by this
      // module and destroyed by this object when it is dynamically
      // unloaded.
      int register_with_object_manager = 0;
      TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
      result = p_tsm->init(register_with_object_manager);
      
      if (result == -1)
      {
        if (m_failPrePostInit == 0)
        {
          ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "Pre-ORB initialization failed."));
          return -1;
  			} /* end of if */
        else if (m_failPrePostInit < 2)
        {
          ACE_DEBUG((LM_WARNING, ACE_TEXT("%s\n"), "Pre-ORB initialization failed (ignored due to FailPrePostInit setting)."));
        } /* end of else if */
        else
        {
          ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Pre-ORB initialization failed (ignored due to FailPrePostInit setting)."));
        } /* end of else */
      } /* end of if */
      else
      {
        ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Pre-ORB initialization done"));
      } /* end of else */
    } /* end of if */
          
    // Initialize the ORB
    mv_orb = CORBA::ORB_init(
      argc,
      argv,
      0
    );
    if (CORBA::is_nil(mv_orb.in()))
    {
      ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "nil ORB"));
      return -1;
    }
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "got ORB"));
    
    CORBA::Object_var v_poa = mv_orb->resolve_initial_references("RootPOA");
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "got root POA"));
    
    mv_rootPOA = PortableServer::POA::_narrow(v_poa.in ());
    if (CORBA::is_nil(mv_rootPOA.in()))
    {
      ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "nil RootPOA"));
      return -1;
    }
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "narrowed root POA"));
    
    mv_poaManager = mv_rootPOA->the_POAManager();
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "got POA manager"));
    if (CORBA::is_nil(mv_poaManager.in()))
    {
      ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "nil POAManager"));
      return -1;
    }
    
    mv_poaManager->activate();
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "activated POA manager"));
  }
  catch(...)
  {
    ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "exception"));
    return -1;
  }

  mp_barrier = new ACE_Thread_Barrier(threadCnt + 1);
  
  this->activate(
    THR_NEW_LWP|THR_JOINABLE|THR_INHERIT_SCHED,
    threadCnt
  );
  mp_barrier->wait();
  
  ACE_DEBUG((LM_INFO, ACE_TEXT("%s %d %s\n"), "ORB runs with", threadCnt, "threads"));

  ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "ORB initialization done"));

  return 0;
} /* end of DllOrb::init ( ) */
   

int DllOrb::fini (void)
{
  int result;
  
  try
  {
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_poaManager->deactivate(1, 1) ..."));
    mv_poaManager->deactivate(1, 1);
    mv_poaManager = PortableServer::POAManager::_nil();
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_poaManager->deactivate(1, 1) done"));
    
    // attempt to protect against sporadic BAD_INV_ORDER exceptions
    ACE_OS::sleep(ACE_Time_Value(0, 500));
    
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->shutdown(1) ..."));
    mv_orb->shutdown(1);
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->shutdown(1) done"));
  }
  catch(...)
  {
    ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "exception"));
    return -1;
  }
  
  ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "wait() ..."));
  // wait for our threads to finish
  wait();
  ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "wait() done"));
  
  delete mp_barrier;
  mp_barrier = 0;
  
  try
  {
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->destroy() ..."));
    mv_orb->destroy();
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->destroy() done"));
    mv_orb = CORBA::ORB::_nil();
  }
  catch(CORBA::Exception const & rc_ex)
  {
    ACE_DEBUG((LM_ERROR, ACE_TEXT("%s%s\n"), "could not destroy ORB: ", rc_ex._info().c_str()));
    return -1;
  }
  
  if (m_failPrePostInit < 3)
  {
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Post-ORB finalization ..."));
    // -----------------------------------------------------------------
    // Post-ORB finalization steps necessary for proper DLL ORB
    // support.
    // -----------------------------------------------------------------
    // Explicitly clean up singletons created by TAO before
    // unloading this module.
    TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
    result = p_tsm->fini();
    if (result == -1)
    {
      if (m_failPrePostInit == 0)
      {
        ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "Post-ORB finalization failed."));
        return -1;
      } /* end of if */
      else if (m_failPrePostInit < 2)
      {
        ACE_DEBUG((LM_WARNING, ACE_TEXT("%s\n"), "Post-ORB finalization failed (ignored due to FailPrePostInit setting)."));
      } /* end of else if */
      else
      {
        ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Post-ORB finalization failed (ignored due to FailPrePostInit setting)."));
      }
    } /* end of if */
    else
    {
      ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "Post-ORB finalization done"));
    } /* end of else */
  } /* end of if */
    
  ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "ORB finalization done"));
  
  return 0;
} /* end of DllOrb::fini ( ) */


int DllOrb::svc (void)
{
  mp_barrier->wait();
  
  int result = -1;
  
  try
  {
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->run ..."));
    try
    {
      mv_orb->run();
    }
    catch(CORBA::BAD_INV_ORDER const & rc_ex)
    {
      const CORBA::ULong VMCID = rc_ex.minor() & 0xFFFFF000U;
      const CORBA::ULong minorCode = rc_ex.minor() & 0xFFFU;
      if (VMCID == CORBA::OMGVMCID && minorCode == 4)
      {
        ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "ignored 'CORBA::BAD_INV_ORDER: ORB has shutdown.'"));
      }
      else
      {
        throw;
      }
    }
    ACE_DEBUG((LM_INFO, ACE_TEXT("%s\n"), "mv_orb->run done"));
  }
  catch(...)
  {
    ACE_DEBUG((LM_ERROR, ACE_TEXT("%s\n"), "exception"));
    return result;
  }
  
  result = 0;
  return result;
} /* end of DllOrb::svc ( ) */


ACE_FACTORY_DEFINE (tradescape, DllOrb)
