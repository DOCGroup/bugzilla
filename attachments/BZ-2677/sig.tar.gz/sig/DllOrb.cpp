/*
 * Copyright (c) 2005 Tradescape Inc.  All rights reserved.
 * 
 * @author lothar
 */


#include "ace/Arg_Shifter.h"
#include "ace/SString.h"
#include "tao/corba.h"
#include "tao/TAO_Singleton_Manager.h"
#include "tao/Version.h"

#include "log4cplus/logger.h"

#include "DllOrb.h"


log4cplus::Logger DllOrb::ms_logger(
  log4cplus::Logger::getInstance("tradescape.utility.DllOrb")
);


DllOrb::DllOrb ( )
:
  m_failPrePostInit(0),
  mp_barrier(0),
  mv_orb(),
  mv_rootPOA()
{
  LOG4CPLUS_TRACE_METHOD(ms_logger, "DllOrb");
  LOG4CPLUS_DEBUG(ms_logger, "using TAO_VERSION=" << TAO_VERSION);
} /* end of DllOrb::DllOrb ( ) */


DllOrb::~DllOrb ( )
{
  LOG4CPLUS_TRACE_METHOD(ms_logger, "~DllOrb");
  delete mp_barrier;
} /* end of DllOrb::~DllOrb ( ) */


int DllOrb::init (int argc, char *argv[])
{
  LOG4CPLUS_TRACE_METHOD(ms_logger, "init");
  log4cplus::NDCContextCreator context("init");
  
  int result = 0;
  int threadCnt = 1;
    
  try
  {
//    ENFORCE(argc >= 1)("need at least one argument");
//    for(int i = 0; i < argc; ++i)
//    {
//      LOG4CPLUS_TRACE(ms_logger, "argv[" << i << "]=" <<  argv[i]);
//    }
    std::string orbName = argv[0];
    
    ACE_Arg_Shifter as(argc, argv);
    const ACE_TCHAR *currentArg = 0;
    while(as.is_anything_left())
    {
      if((currentArg = as.get_the_parameter("-NumThreads")))
      {
        int num = ACE_OS::atoi(currentArg);
        if(num >= 1)
          threadCnt = num;
        as.consume_arg();
      }
      else
        as.ignore_arg();
    }
    
    // 0 == fail (default)
    // 1 == ignore
    // 2 == do not warn
    // 3 == do not execute
    unsigned int const c_failPrePostInit = 1;
    
/*
    // read configuration information
    SystemConfiguration config;
    LOG4CPLUS_DEBUG(ms_logger, "checking general 'FailPrePostInit'");
    config.getIntegerValue(
      std::string("tradescape/harvest/DllOrb"),
      std::string("FailPrePostInit"),
      c_failPrePostInit,
      m_failPrePostInit
    );
    if(m_failPrePostInit != c_failPrePostInit)
      LOG4CPLUS_INFO(ms_logger, "general FailPrePostInit=" << m_failPrePostInit);
    
    LOG4CPLUS_DEBUG(ms_logger, "checking 'FailPrePostInit' for ORB '" << orbName << "'");
    config.getIntegerValue(
      std::string("tradescape/harvest/DllOrb/") + orbName,
      std::string("FailPrePostInit"),
      m_failPrePostInit,
      m_failPrePostInit
    );
    if(m_failPrePostInit != c_failPrePostInit)
      LOG4CPLUS_INFO(ms_logger, "'" << orbName << "' FailPrePostInit=" << m_failPrePostInit);
*/

    if (m_failPrePostInit < 3)
    {
      LOG4CPLUS_TRACE(ms_logger, "Pre-ORB initialization ...");
      // -----------------------------------------------------------------
      // Pre-ORB initialization steps necessary for proper DLL ORB
      // support.
      // -----------------------------------------------------------------
      // Make sure TAO's singleton manager is initialized, and set to not
      // register itself with the ACE_Object_Manager since it is under the
      // control of the Service Configurator.  If we register with the
      // ACE_Object_Manager, then the ACE_Object_Manager will still hold
      // (dangling) references to instances of objects created by this
      // module and destroyed by this object when it is dynamically
      // unloaded.
      int register_with_object_manager = 0;
      TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
      result = p_tsm->init(register_with_object_manager);
      
      if (result == -1)
      {
        if (m_failPrePostInit == 0)
        {
          LOG4CPLUS_ERROR(ms_logger, "Pre-ORB initialization failed.");
          return -1;
  			} /* end of if */
        else if (m_failPrePostInit < 2)
        {
          LOG4CPLUS_WARN(ms_logger, "Pre-ORB initialization failed (ignored due to FailPrePostInit setting).");
        } /* end of else if */
        else
        {
          LOG4CPLUS_TRACE(ms_logger, "Pre-ORB initialization failed (ignored due to FailPrePostInit setting).");
        } /* end of else */
      } /* end of if */
      else
      {
        LOG4CPLUS_INFO(ms_logger, "Pre-ORB initialization done");
      } /* end of else */
    } /* end of if */
          
    // Initialize the ORB
    mv_orb = CORBA::ORB_init(
      argc,
      argv,
      0
    );
    if (CORBA::is_nil(mv_orb.in()))
    {
      LOG4CPLUS_ERROR(ms_logger, "nil ORB");
      return -1;
    }
    LOG4CPLUS_TRACE(ms_logger, "got ORB");
    
    CORBA::Object_var v_poa = mv_orb->resolve_initial_references("RootPOA");
    LOG4CPLUS_TRACE(ms_logger, "got root POA");
    
    mv_rootPOA = PortableServer::POA::_narrow(v_poa.in ());
    if (CORBA::is_nil(mv_rootPOA.in()))
    {
      LOG4CPLUS_ERROR(ms_logger, "nil RootPOA");
      return -1;
    }
    LOG4CPLUS_TRACE(ms_logger, "narrowed root POA");
    
    mv_poaManager = mv_rootPOA->the_POAManager();
    LOG4CPLUS_TRACE(ms_logger, "got POA manager");
    if (CORBA::is_nil(mv_poaManager.in()))
    {
      LOG4CPLUS_ERROR(ms_logger, "nil POAManager");
      return -1;
    }
    
    mv_poaManager->activate();
    LOG4CPLUS_TRACE(ms_logger, "activated POA manager");
  }
/*
  DM_catchExceptionsCORBA(ms_logger, return -1)
  DM_catchExceptionsTradescape(ms_logger, true, return -1)
  DM_catchExceptions(ms_logger, return -1)
*/
  catch(...)
  {
    LOG4CPLUS_ERROR(ms_logger, "exception");
    return -1;
  }

  mp_barrier = new ACE_Thread_Barrier(threadCnt + 1);
//  ENFORCE(mp_barrier != 0)("could not allocate barrier");
  
  this->activate(
    THR_NEW_LWP|THR_JOINABLE|THR_INHERIT_SCHED,
    threadCnt
  );
  mp_barrier->wait();
  
  LOG4CPLUS_INFO(ms_logger, "ORB runs with " << threadCnt << " threads");

  LOG4CPLUS_INFO(ms_logger, "ORB initialization done");

  return 0;
} /* end of DllOrb::init ( ) */
   

int DllOrb::fini (void)
{
  LOG4CPLUS_TRACE_METHOD(ms_logger, "fini");
  log4cplus::NDCContextCreator context("fini");
//  LOG4CPLUS_DEBUG(ms_logger, "(" << this << ")");
  
  int result;
  
  try
  {
    LOG4CPLUS_TRACE(ms_logger, "mv_poaManager->deactivate(1, 1) ...");
    mv_poaManager->deactivate(1, 1);
    mv_poaManager = PortableServer::POAManager::_nil();
    LOG4CPLUS_DEBUG(ms_logger, "mv_poaManager->deactivate(1, 1) done");
    
    // attempt to protect against sporadic BAD_INV_ORDER exceptions
    ACE_OS::sleep(ACE_Time_Value(0, 500));
    
    LOG4CPLUS_TRACE(ms_logger, "mv_orb->shutdown(1) ...");
    mv_orb->shutdown(1);
    LOG4CPLUS_DEBUG(ms_logger, "mv_orb->shutdown(1) done");
  }
//  DM_catchExceptionsCORBA(ms_logger, return -1)
  catch(...)
  {
    LOG4CPLUS_ERROR(ms_logger, "exception");
    return -1;
  }
  
  LOG4CPLUS_TRACE(ms_logger, "wait() ...");
  // wait for our threads to finish
  wait();
  LOG4CPLUS_DEBUG(ms_logger, "wait() done");
  
  delete mp_barrier;
  mp_barrier = 0;
  
  try
  {
    LOG4CPLUS_TRACE(ms_logger, "mv_orb->destroy() ...");
    mv_orb->destroy();
    LOG4CPLUS_DEBUG(ms_logger, "mv_orb->destroy() done");
    mv_orb = CORBA::ORB::_nil();
  }
  catch(CORBA::Exception const & rc_ex)
  {
    LOG4CPLUS_ERROR(ms_logger, "could not destroy ORB: " << rc_ex);
    return -1;
  }
  
  if (m_failPrePostInit < 3)
  {
    LOG4CPLUS_TRACE(ms_logger, "Post-ORB finalization ...");
    // -----------------------------------------------------------------
    // Post-ORB finalization steps necessary for proper DLL ORB
    // support.
    // -----------------------------------------------------------------
    // Explicitly clean up singletons created by TAO before
    // unloading this module.
    TAO_Singleton_Manager * p_tsm = TAO_Singleton_Manager::instance();
    result = p_tsm->fini();
    if (result == -1)
    {
      if (m_failPrePostInit == 0)
      {
        LOG4CPLUS_ERROR(ms_logger, "Post-ORB finalization failed.");
        return -1;
      } /* end of if */
      else if (m_failPrePostInit < 2)
      {
        LOG4CPLUS_WARN(ms_logger, "Post-ORB finalization failed (ignored due to FailPrePostInit setting).");
      } /* end of else if */
      else
      {
        LOG4CPLUS_TRACE(ms_logger, "Post-ORB finalization failed (ignored due to FailPrePostInit setting).");
      }
    } /* end of if */
    else
    {
      LOG4CPLUS_INFO(ms_logger, "Post-ORB finalization done");
    } /* end of else */
  } /* end of if */
    
  LOG4CPLUS_INFO(ms_logger, "ORB finalization done");
  
  return 0;
} /* end of DllOrb::fini ( ) */


int DllOrb::svc (void)
{
  LOG4CPLUS_TRACE_METHOD(ms_logger, "svc");
  log4cplus::NDCContextCreator context("DllOrb::svc");

  mp_barrier->wait();
  
  int result = -1;
  
  try
  {
    LOG4CPLUS_TRACE(ms_logger, "mv_orb->run ...");
    try
    {
      mv_orb->run();
    }
    catch(CORBA::BAD_INV_ORDER const & rc_ex)
    {
      const CORBA::ULong VMCID = rc_ex.minor() & 0xFFFFF000U;
      const CORBA::ULong minorCode = rc_ex.minor() & 0xFFFU;
      if (VMCID == CORBA::OMGVMCID && minorCode == 4)
      {
        LOG4CPLUS_DEBUG(ms_logger, "ignored 'CORBA::BAD_INV_ORDER: ORB has shutdown.'");
      }
      else
      {
        throw;
      }
    }
    LOG4CPLUS_DEBUG(ms_logger, "mv_orb->run done");
  }
/*
  DM_catchExceptionsCORBA(ms_logger, return result)
  DM_catchExceptionsTradescape(ms_logger, true, return result)
  DM_catchExceptions(ms_logger, return result)
*/
  catch(...)
  {
    LOG4CPLUS_ERROR(ms_logger, "exception");
    return result;
  }
  
  result = 0;
  return result;
} /* end of DllOrb::svc ( ) */


ACE_FACTORY_DEFINE (tradescape, DllOrb)
