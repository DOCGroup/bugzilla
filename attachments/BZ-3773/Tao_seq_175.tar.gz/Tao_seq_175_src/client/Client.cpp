
#include <Client.h>

#include <sstream>
#include <iostream>

/**
 * Constructor.
 */
Client::Client (mod1::Server_ptr p_server)
    throw()
{
  m_server_ref = mod1::Server::_duplicate (p_server);
}


/**
 * Destructor.
 */
Client::~Client()
    throw()
{
    // NOOP
}


void Client::run_thread()
      throw()
{
  // call the server
  try
  {
    std::cout << "client thread is running" << std::endl;
    
    unsigned long long num_push=0;
    
    mod1::data_seq_var data_block = new mod1::data_seq();
    data_block->length(data_block->maximum());
    
    CORBA::Octet * p_buffer = data_block->get_buffer();

	  p_buffer[0] = (char) 1;
	  p_buffer[2] = (char) 2;
	  p_buffer[4] = (char) 3;
	  p_buffer[6] = (char) 4;
    
    for (;;)
		{
		  m_server_ref->push(data_block.in());
			
			num_push++;
			if (num_push % 10 == 0)
			{
				std::cout << "[client] push " << num_push << " times\n";
			}
			
			timespec ts;
      ts.tv_sec  = 0;
      ts.tv_nsec = 200000000;

      ::nanosleep(&ts, 0);
		}
	}

  catch(const CORBA::Exception& ex) 
  {
    std::cerr << ex << std::endl;
  }
  catch (...) 
  {
    std::cerr << "unknown exception in Client thread" << std::endl;
  }
}



