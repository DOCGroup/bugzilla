
#ifndef _Client_h
#define _Client_h

#include <intfC.h>


class Client
{
  public:
  
    Client (mod1::Server_ptr p_server)
      throw();

    virtual ~Client()
      throw();
    
    void run_thread()
      throw();
  
  private:
    mod1::Server_var m_server_ref;

}; 

#endif
