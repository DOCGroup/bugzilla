
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include <cerrno>
#include <cstdio>
// To get PTHREAD_STACK_MIN
#include <limits.h>

#include <tao/corba.h>
#include <tao/PortableServer/PortableServer.h>
#include <tao/Messaging/Messaging.h>

#include <intfC.h>

#include <Client.h>

namespace
{
  std::string server_corbaloc = "corbaloc::localhost:5000/server_";
  
  int SUCCESS = 0;
  int FAILURE = -1;
  
  /**
   * Define values for Contention Scope
   */
  enum ThrScope
  {
    THR_PROCESS_SCOPE,
    THR_SYSTEM_SCOPE
  };

  /**
   * Define values for Scheduling Policy
   */
  enum ThrSchedulPolicy
  {
    THR_SCHEDULE_OTHER,
    THR_SCHEDULE_FIFO,
    THR_SCHEDULE_RR
  };
  
  const unsigned long DEFAULT_STACK_SIZE = 2048*1024;

        
} // anonymous namespace

//
// Static functions called by the POSIX function, in a new thread
//
extern "C"
void* thread_posix_thread_entry_point (void* pThreadData)
  throw()
{
  Client* p_client = static_cast<Client*>(pThreadData);

  // Sets the status of the thread
  p_client->run_thread();

  // At this time we return nothing,
  return NULL;
}
  
  

/**
 * init client thead:
 *
 */
int init_thread (pthread_attr_t& pthread_attr)
{
  int status = FAILURE;
  
  int status_attr;
  
  std::cout << "create thread attribute" << std::endl;

  // initialise the thread attribute with the default values
  status_attr = ::pthread_attr_init(&pthread_attr);

  switch (status_attr)
  {
    case 0:
      status = SUCCESS;
      break;

    // No more memory to allocate the structure
    case ENOMEM:
      std::cerr << "init_thread : pthread_attr_init OutOfMemory" << std::endl;
      break;

    // As we have set no parameters ??
    case EINVAL:
      std::cerr << "init_thread : pthread_attr_init BadParameter, Invalid parameters in pthread_attr" << std::endl;
      break;

    default:
      std::cerr << "init_thread : pthread_attr_init status error " << status_attr << std::endl;
      std::cerr << "init_thread : pthread_attr_init InternalError, Invalid parameters in pthread_attr" << std::endl;
      break;
  }

  if (status == FAILURE)
  {
    return status;
  }

  status = FAILURE;
  
  status_attr = ::pthread_attr_setinheritsched(&pthread_attr, PTHREAD_EXPLICIT_SCHED);

  switch (status_attr)
  {
    case 0:
      status = SUCCESS;
      break;

    case EINVAL:
      std::cerr << "init_thread : BadParameter, inheritsched is invalid" << std::endl;
      break;

    default:
      std::cerr << "init_thread : pthread_attr_setinheritsched status error " << status_attr << std::endl;
      std::cerr << "init_thread : InternalError, Invalid parameters in pthread_attr_setinheritsched" << std::endl;
      break;
  }
  
  return status;
}


//
// Set the size of the stack
//
int set_stackSize(pthread_attr_t& pthread_attr, size_t stackSize)
{
  std::cout << "set thread stack size" << std::endl;
  
  int status = FAILURE;
  
  // set default stack size if undefined
  if (stackSize == 0)
  {
    stackSize = DEFAULT_STACK_SIZE;
  }

  // We allocate the specified size.
  // Warning: this function may return EINVAL, if m_pthread_attr or m_stackSize
  //    are invalid. If the error is for m_pthread_attr, we are corrupted,
  //    but if it is for m_stackSize, maybe the size is too big.
  //    We have no way to separate both error in status
  //    So we check stackSize value before.
  if (stackSize < PTHREAD_STACK_MIN)
  {
    std::stringstream buffer;
    buffer << "below PTHREAD_STACK_MIN (" << stackSize << " < " << PTHREAD_STACK_MIN << ")" << std::ends;
    std::cerr << "set_stackSize : BadParameter, stackSize " << buffer.str() << std::endl;
    return status;
  }
  else
  {
    int status_set_stack = ::pthread_attr_setstacksize (&pthread_attr, stackSize);

    // Possible status are 0, EINVAL
    switch (status_set_stack)
    {
      // No problem the initialisation is done
      case 0:
        status = SUCCESS;
        break;

      // one of the m_pthread_attr argument is invalid,
      case EINVAL:
      {
        std::stringstream buffer;
        buffer << stackSize << std::ends;
        std::cerr << "set_stackSize : BadParameter, stacksize is invalid " << buffer.str() << std::endl;;
      }
      break;

      // Unspecified error code returned
      default:
      {
        std::cerr << "set_stackSize : pthread_attr_setstacksize status error : "
                  << status_set_stack << std::endl;
        std::cerr << "set_stackSize : InternalError, Invalid parameters in pthread_attr_setstacksize" << std::endl;
      }
      break;
    };
  }
  
  return status;
}
  
  
//
// set the contention scope and scheduling policy
//
int set_scopeSchedPolicy (pthread_attr_t& pthread_attr,
                          ThrScope scope, ThrSchedulPolicy policy)
{
  int status = FAILURE;
  
  int pthread_scope = 0;
  bool scope_ok = true;

  switch (scope)
  {
    case THR_PROCESS_SCOPE:
      // Linux implementation does not allow process-scope threads
      // ENOTSUP error is returned
      pthread_scope = PTHREAD_SCOPE_PROCESS;
      break;

    case THR_SYSTEM_SCOPE:
      pthread_scope = PTHREAD_SCOPE_SYSTEM;
      break;

    default:
      scope_ok = false;
      break;
  }

  // error has been detected
  if (scope_ok == false)
  {
    std::stringstream buffer;
    buffer << scope << std::ends;
    std::cerr << "set_scopeSchedPolicy : BadParameter, scope is invalid " << buffer.str() << std::endl;
    return status;
  }

  // no error
  int status_set_scope = ::pthread_attr_setscope (&pthread_attr, pthread_scope);

  // Possible status are 0, EINVAL, ENOTSUP
  // But if EINVAL is returned maybe
  //  ==> m_pthread_attr is invalid, so we are corrupted
  //  ==> pthread_scope is set with a bad value
  // We have no way to know the error, so we hope we are
  //    not corrupted and return a BadParameter
  switch (status_set_scope)
  {
    case 0:
      status = SUCCESS;
      break;

    case EINVAL:
    {
      scope_ok = false;
      std::stringstream buffer;
      buffer << pthread_scope << std::ends;
      std::cerr << "set_scopeSchedPolicy : BadParameter, scope is invalid " << buffer.str() << std::endl;
    }
    break;
        
    case ENOTSUP:
    {
      scope_ok = false;
      std::cerr << "set_scopeSchedPolicy : PermissionDenied" << std::endl;
    }
    break;

    default:
    {
      scope_ok = false;
      std::cerr << "set_scopeSchedPolicy : pthread_attr_setscope status error " << status_set_scope << std::endl;
      std::cerr << "set_scopeSchedPolicy : InternalError, Invalid parameters in pthread_attr_setscope" << std::endl;
    }
    break;
  }

  // if no error store the requested scope else return
  if (!scope_ok)
  {
    return status;
  }

  status = FAILURE;
  int pthread_schedPolicy = 0;
  bool policy_ok = true;

  switch (policy)
  {
    case THR_SCHEDULE_OTHER:
      pthread_schedPolicy = SCHED_OTHER;
      break;

    case THR_SCHEDULE_FIFO:
      // Linux implementation does not allow SCHED_FIFO policy if not superuser
      // ENOTSUP error is returned
      pthread_schedPolicy = SCHED_FIFO;
      break;

    case THR_SCHEDULE_RR:
      // Linux implementation does not allow SCHED_RR policy if not superuser
      // ENOTSUP error is returned
      pthread_schedPolicy = SCHED_RR;
      break;

    default:
      policy_ok = false;
      break;
  }

  // error has been detected
  if (policy_ok == false)
  {
    std::stringstream buffer;
    buffer << policy << std::ends;
    std::cerr << "set_scopeSchedPolicy : BadParameter, schedule policy is invalid " << buffer.str() << std::endl;
    return status;
  }

  // no error
  int status_set_policy =
            ::pthread_attr_setschedpolicy (&pthread_attr, pthread_schedPolicy);

  // Possible status are 0, EINVAL, ENOTSUP
  // But if EINVAL is returned maybe
  //  ==> m_pthread_attr is invalid, so we are corrupted
  //  ==> pthread_schedPolicy is set with a bad value
  // We have no way to know the error, so we hope we are
  //    not corrupted and return a BadParameter
  switch (status_set_policy)
  {
    case 0:
      status = SUCCESS;
      break;

    case EINVAL:
    {
      policy_ok = false;
      std::stringstream buffer;
      buffer << pthread_schedPolicy << std::ends;
      std::cerr << "set_scopeSchedPolicy : BadParameter, scheduling policy is invalid " << buffer.str() << std::endl;
    }
    break;
        
    case ENOTSUP:
    {
      policy_ok = false;
      std::cerr << "set_scopeSchedPolicy : PermissionDenied" << std::endl;
    }
    break;

    default:
    {
      policy_ok = false;
      std::cerr << "set_scopeSchedPolicy : pthread_attr_setschedpolicy status error " << status_set_policy << std::endl;
      std::cerr << "set_scopeSchedPolicy : InternalError, Invalid parameters in pthread_attr_setschedpolicy" << std::endl;
    }
    break;
  }
  
  return status;
}

//
// set the initial priority of the thread
//
int set_initial_priority(pthread_attr_t& pthread_attr, int priority)
{
  int status = FAILURE;
  
  struct sched_param schedParam;

  // We get the scheduling parameters of the thread
  int status_get_sched = ::pthread_attr_getschedparam (&pthread_attr, &schedParam);

  // Possible status are 0, EINVAL
  // but the structure must be correct, we have change nothing
  switch (status_get_sched)
  {
    case 0:
      status = SUCCESS;
      break;

    case EINVAL:
    default:
    {
      std::cerr << "set_initial_priority : pthread_attr_getschedparam status error " << status_get_sched << std::endl;
      std::cerr << "set_initial_priority : InternalError, Invalid parameters in pthread_attr_getschedparam" << std::endl;
    }
    break;
  }
  
  if (status == FAILURE)
  {
    return status;
  }

  status = FAILURE;

  // Set priority
  schedParam.sched_priority = priority;

  // then set the scheduling parameters of the thread
  int status_set_sched = ::pthread_attr_setschedparam (&pthread_attr, &schedParam);

  // Possible status are 0, EINVAL
  // But if EINVAL is returned maybe
  //  ==> m_pthread_attr is invalid, so we are corrupted
  //  ==> schedParam is set with a bad value
  // We have no way to know the error, so we hope we are
  //    not corrupted and return a BadParameter
  switch (status_set_sched)
  {
    case 0:
      status = SUCCESS;
      break;

    case EINVAL:
    {
      std::stringstream buffer;
      buffer << priority << std::ends;
      std::cerr << "set_initial_priority : BadParameter, priority is invalid " << buffer.str() << std::endl;
    }
    break;

    default:
    {
      std::cerr << "set_initial_priority : pthread_attr_setschedparam status error " << status_set_sched << std::endl;
      std::cerr << "set_initial_priority : InternalError, Invalid parameters in pthread_attr_setschedparam" << std::endl;
    }
    break;
  }
  
  return status;
}

/**
 * run client:
 *
 */
int start_thread (pthread_attr_t& pthread_attr, Client* p_client)
{
  int status = FAILURE;
  
  std::cout << "start client thread" << std::endl;

  // Posix id of the thread
  pthread_t pthreadId;
  
  // Possible status are 0, ENOMEM, EINVAL, EPERM
  int status_thread = ::pthread_create (&pthreadId,
                                        &pthread_attr,
                                        &thread_posix_thread_entry_point,
                                        p_client);

  // check os return status
  if (status_thread != 0)
  {
    std::cout << "start_thread : pthread_create status error "
              << status_thread << std::endl;
  }

  switch (status_thread)
  {
    // No problem the initialisation is done
    case 0:
      status = SUCCESS;
      break;

    // Not enough memory to satisfy the initialisation
    case ENOMEM:
    {
      std::cerr << "start_thread : pthread_create OutOfMemory" << std::endl;
    }
    break;

    // The user is not allowed to use the specified thread
    // policy
    case EPERM:
    {
      std::cerr << "start_thread : pthread_create ThreadScheduling Invalid" << std::endl;
    }
    break;

    // one of the m_pthread_attr argument is invalid,
    case EINVAL:
    {
      std::cerr << "start_thread : pthread_create BadParameter, Invalid parameters in pthread_attr" << std::endl;
    }
    break;

    // Unspecified error code returned
    default:
    {
      std::cerr << "start_thread :  pthread_create status error " << status_thread << std::endl;
      std::cerr << "start_thread : InternalError in pthread_create" << std::endl;
    }
    break;
  };
  
  return status;
}

void print_sync_scope_policy(CORBA::PolicyManager_ptr policy_manager)
{
  // get the Sync Scope policy
  CORBA::PolicyTypeSeq sync_scope_type_seq(1);
  sync_scope_type_seq.length (1);
  sync_scope_type_seq[0] = Messaging::SYNC_SCOPE_POLICY_TYPE;
    
  CORBA::PolicyList_var policy_list =
        policy_manager->get_policy_overrides (sync_scope_type_seq);
        
        
  if (policy_list->length() == 0)
  {
    std::cerr << "---> SyncScope policy not exposed" << std::endl;
  }
  else
  {
    CORBA::ULong index = 0;
    Messaging::SyncScopePolicy_var sync_scope_policy = Messaging::SyncScopePolicy::_narrow (policy_list[index].in());

    if (CORBA::is_nil (sync_scope_policy.in()))
    {
      std::cerr << "---> SyncScope policy cannot be narrowed" << std::endl;
    }
    else
    {
      Messaging::SyncScope sync_scope_type = sync_scope_policy->synchronization ();
      
      if (sync_scope_type == Messaging::SYNC_NONE)
      {
        std::cout << "---> SyncScope policy is SYNC_NONE" << std::endl;
      }
      else if (sync_scope_type == Messaging::SYNC_WITH_TRANSPORT)
      {
        std::cout << "---> SyncScope policy is SYNC_WITH_TRANSPORT" << std::endl;
      }
      else if (sync_scope_type == Messaging::SYNC_WITH_SERVER)
      {
        std::cout << "---> SyncScope policy is SYNC_WITH_SERVER" << std::endl;
      }
      else if (sync_scope_type == Messaging::SYNC_WITH_TARGET)
      {
        std::cout << "---> SyncScope policy is SYNC_WITH_TARGET" << std::endl;
      }
    }
  }
}


/**
 * Main.
 */
int main(int argc, char* argv[])
{
  int status = SUCCESS;
  
  CORBA::ORB_var orb = CORBA::ORB::_nil();
  PortableServer::POA_var root_POA = PortableServer::POA::_nil();
    
  mod1::Server_var server_ref = mod1::Server::_nil();

  try 
  {
    // initialise the orb 
    orb = CORBA::ORB_init(argc,argv);

    if (CORBA::is_nil(orb.in()))
    {
      std::cerr << "client : orb can not be initialized" << std::endl;
      exit (EXIT_FAILURE);
	  }
		     
    //  Get the root poa.
    CORBA::Object_var poaObj = orb->resolve_initial_references("RootPOA");
   
    if(CORBA::is_nil(poaObj.in())) 
    {
      std::cerr << "client : can not resolve Root POA" << std::endl;
      exit (EXIT_FAILURE);
    }
   
    root_POA = PortableServer::POA::_narrow(poaObj); 
    if(CORBA::is_nil(root_POA.in())) 
    {
      std::cerr << "client : Root POA is not a POA" << std::endl;
      exit (EXIT_FAILURE);
    }
  
    //
    //  Get the poa manager.
    //
    PortableServer::POAManager_var POA_mngr = root_POA->the_POAManager();
    POA_mngr->activate();

    if(CORBA::is_nil(POA_mngr.in()))
    {
      std::cerr << "client : Root POA is not a POA" << std::endl;
      exit (EXIT_FAILURE);
    }
  

    // get the server reference from corbaloc
    CORBA::Object_var server_obj = 
           orb->string_to_object(server_corbaloc.c_str());
    
    if (CORBA::is_nil(server_obj.in()))
    {
      std::cerr << "client : Invalid server corbaloc" << std::endl;
      exit (EXIT_FAILURE);
    }
    
    mod1::Server_var server_ref;
    
    try 
    {
      server_ref = mod1::Server::_narrow(server_obj.in());        
    } 
    catch (const CORBA::SystemException & ex) 
    {
      std::cerr << "client : Exception while contacting server : "
                << ex << "\n"
                << server_corbaloc << " is probably invalid"
                << std::endl;
      exit (EXIT_FAILURE);
    }
    
    
    //------------------------------
    // Section to add SYNC_WITH_TARGET on the collector object
    // the oneway operations (put_formated_message) will behave
    // like two ways operations

    // Messaging::SyncScope SYNC_NONE = 0;
    // Messaging::SyncScope SYNC_WITH_TRANSPORT = 1;
    // Messaging::SyncScope SYNC_WITH_SERVER = 2;
    // Messaging::SyncScope SYNC_WITH_TARGET = 3;
    
    // note : no memory leak with SYNC_NONE
    // note : memory leak with SYNC_WITH_TRANSPORT
    
    static Messaging::SyncScope sync_scope = Messaging::SYNC_WITH_TRANSPORT;

    CORBA::Object_var obj = orb->resolve_initial_references("ORBPolicyManager");

    CORBA::PolicyManager_var policy_manager = CORBA::PolicyManager::_narrow(obj.in());
    
    
    
    
    // print the default Sync Scope policy
    print_sync_scope_policy(policy_manager.in());
    


    // Set up the sync scope any.
    CORBA::Any sync_scope_any;
    sync_scope_any <<= sync_scope;

    // Set the length of the policy list.
    CORBA::PolicyList sync_scope_policy_list (1);
    sync_scope_policy_list.length (1);
      
    // Set up the sync scope policy.
    sync_scope_policy_list[0] = orb->create_policy (Messaging::SYNC_SCOPE_POLICY_TYPE,
                                                    sync_scope_any);

    // Set the sync scope policy at the object level.
    // obj = server_ref->_set_policy_overrides (sync_scope_policy_list, CORBA::ADD_OVERRIDE);
            
    // Get the new object reference with the updated policy.
    //server_ref = mod1::Server::_narrow (obj.in());
    
    // Set the sync scope policy at the orb level.
    policy_manager->set_policy_overrides(sync_scope_policy_list, CORBA::ADD_OVERRIDE);

    sync_scope_policy_list[0]->destroy();
    
    
    // End of Section to add SYNC_WITH_TARGET
    
    // print the default Sync Scope policy
    print_sync_scope_policy(policy_manager.in());

    
    //------------------------------
    
    // create the client
    Client * p_client = new Client(server_ref.in());
    
    // create the client thread and start it
    pthread_attr_t pthread_attr;
    
    status = init_thread (pthread_attr);
    
    if (status == SUCCESS) 
    {
      status = set_stackSize(pthread_attr, 0);
    }
    
    if (status == SUCCESS) 
    {
      status = set_scopeSchedPolicy (pthread_attr, THR_SYSTEM_SCOPE, THR_SCHEDULE_FIFO);
    }
    
    if (status == SUCCESS) 
    {
      status = set_initial_priority(pthread_attr, 5);
    }

    if (status == SUCCESS) 
    {
      status = start_thread (pthread_attr, p_client);
    }
    
    if (status == SUCCESS) 
    {
      std::cout << "client running ......" << std::endl;
      
      // just run the ORB.
      orb->run();
    }
    
    // client is stopped
    delete p_client;
	}

  catch(const CORBA::Exception& ex) 
  {
    std::cerr << ex << std::endl;
    status = FAILURE;
  }
  catch (...) 
  {
    std::cerr << "unknown exception in main" << std::endl;
    status = FAILURE;
  }

  // end of corba processing

  if(!CORBA::is_nil(orb.in())) 
  {
    try 
    {
      // Interrupt orb polling, but does not clean anything
      orb->shutdown(false);
      orb->destroy();
    }
    catch(const CORBA::Exception& ex) 
    {
      std::cerr << ex << std::endl;
      status = FAILURE;
    }
  }

  return status;
}
