
- set the TAO environment

    ACE_ROOT         example export ACE_ROOT=/tools/exec/TAO151_2-gcc344-inline-071215/src
    TAO_ROOT         example export TAO_ROOT=$ACE_ROOT/TAO

    and

    export PATH=$TAO_ROOT/TAO_IDL:$PATH
    export LD_LIBRARY_PATH=$ACE_ROOT/lib:$LD_LIBRARY_PATH

- To compile start "make_test"
- To run start server with "start_server.sh" and client with "start_client.sh"


