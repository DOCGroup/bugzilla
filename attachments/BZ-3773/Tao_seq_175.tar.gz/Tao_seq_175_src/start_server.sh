
./server_gcc_rhel4_tao.exe -ORBEndpoint iiop://localhost:5000
