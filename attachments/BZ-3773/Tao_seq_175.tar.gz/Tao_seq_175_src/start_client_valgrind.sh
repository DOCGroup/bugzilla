
valgrind --tool=memcheck --leak-check=full --log-file=client_valgrind_log -v -v ./client_gcc_rhel4_tao.exe -ORBDebugLevel 10
