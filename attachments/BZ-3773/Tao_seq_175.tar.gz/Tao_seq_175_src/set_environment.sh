#!/bin/sh

# TAO 
export ACE_ROOT=/tools/exec/ACE_TAO_1.7.5/ACE_wrappers
export TAO_ROOT=$ACE_ROOT/TAO

export PATH=$TAO_ROOT/TAO_IDL:$PATH
export PATH=$TAO_ROOT/orbsvcs/IFR_Service:$PATH
export PATH=$TAO_ROOT/orbsvcs/Naming_Service:$PATH
export LD_LIBRARY_PATH=$ACE_ROOT/lib:$LD_LIBRARY_PATH

