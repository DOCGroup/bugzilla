
./client_gcc_rhel4_tao.exe -ORBDebugLevel 10
