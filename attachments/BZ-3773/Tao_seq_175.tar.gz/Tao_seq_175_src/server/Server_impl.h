
#ifndef _Server_impl_h
#define _Server_impl_h

#include <intfS.h>


class Server_impl : public virtual POA_mod1::Server,
                    public PortableServer::RefCountServantBase
{
  public:
  
    Server_impl ()
      throw();

    virtual ~Server_impl()
      throw();
    
    //
    // methods defined on the interface
    //
    
    void push (const ::mod1::data_seq & data_seq_elt_in) 
        throw (CORBA::SystemException);
        
   private:
    unsigned long long num_push;

}; 

#endif
