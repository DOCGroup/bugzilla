
#include <Server_impl.h>

#include <sstream>
#include <iostream>
#include <vector>

/**
 * Constructor.
 */
Server_impl::Server_impl ()
    throw()
{
    num_push = 0;
}


/**
 * Destructor.
 */
Server_impl::~Server_impl()
    throw()
{
    // NOOP
}



void Server_impl::push (const ::mod1::data_seq & data_seq_elt_in)
    throw(CORBA::SystemException)
{
  num_push++;
  if (num_push % 10 == 0)
  {
		std::cout << "[server] push called" << num_push << " " << data_seq_elt_in[0] << " times\n";
  }
}

