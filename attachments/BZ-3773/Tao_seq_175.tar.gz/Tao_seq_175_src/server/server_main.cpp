
#include <iostream>
#include <fstream>
#include <stdlib.h>

#include <tao/corba.h>
#include <tao/PortableServer/PortableServer.h>
#include <tao/IORTable/IORTable.h>

#include <Server_impl.h>

namespace
{
  int SUCCESS = 0;
  int FAILURE = -1;
  
  enum PolicyTypes {
    THREAD              = 0,
    LIFESPAN            = 1,
    IDUNIQUENESS        = 2,
    IDASSIGNMENT        = 3,
    IMPLICIT_ACTIVATION = 4,
    SERVANT_RETENTION   = 5,
    REQUEST_PROCESSING  = 6,
  };

  // * Thread Policy: ORB_CTRL_MODEL
  // * Lifespan Policy: TRANSIENT
  // * Object Id Uniqueness Policy: UNIQUE_ID
  // * Id Assignment Policy: SYSTEM_ID
  // * Servant Retention Policy: RETAIN
  // * Request Processing Policy: USE_ACTIVE_OBJECT_MAP_ONLY
  // * Implicit Activation Policy: IMPLICIT_ACTIVATION

  /** 
   * Policies Field Format
   * |------|--------------------------|
   * |Bit 0 | ThreadPolicy             |
   * |------|--------------------------|
   * |Bit 1 | LifespanPolicy           |
   * |------|--------------------------|
   * |Bit 2 | IdUniquenessPolicy       |
   * |------|--------------------------|
   * |Bit 3 | IdAssignmentPolicy       |
   * |------|--------------------------|
   * |Bit 4 | ImplicitActivationPolicy |
   * |------|--------------------------|
   * |Bit 5 | ServantRetentionPolicy   |
   * |------|--------------------------|
   * |Bit 6 |                          |
   * |------| RequestProcessingPolicy  |
   * |Bit 7 |                          |
   * |------|--------------------------|
   */

  typedef unsigned char PolicyValueId ;
  
  static const PolicyValueId THREAD_ORB_CTRL_MODEL      = 0x0 << THREAD; 
  static const PolicyValueId THREAD_SINGLE_THREAD_MODEL = 0x1 << THREAD;
 
  static const PolicyValueId LIFESPAN_TRANSIENT         = 0x0 << LIFESPAN; 
  static const PolicyValueId LIFESPAN_PERSISTENT        = 0x1 << LIFESPAN;

  static const PolicyValueId IDUNIQUENESS_UNIQUE_ID     = 0x0 << IDUNIQUENESS;
  static const PolicyValueId IDUNIQUENESS_MULTIPLE_ID   = 0x1 << IDUNIQUENESS;

  static const PolicyValueId IDASSIGNMENT_SYSTEM_ID     = 0x0 << IDASSIGNMENT;
  static const PolicyValueId IDASSIGNMENT_USER_ID       = 0x1 << IDASSIGNMENT;

  static const PolicyValueId IMPLICIT_ACTIVATION_IMPLICIT_ACTIVATION       = 0x0 << IMPLICIT_ACTIVATION;
  static const PolicyValueId IMPLICIT_ACTIVATION_NO_IMPLICIT_ACTIVATION    = 0x1 << IMPLICIT_ACTIVATION;

  static const PolicyValueId SERVANT_RETENTION_RETAIN                      = 0x0 << SERVANT_RETENTION;
  static const PolicyValueId SERVANT_RETENTION_NON_RETAIN                  = 0x1 << SERVANT_RETENTION;

  static const PolicyValueId REQUEST_PROCESSING_USE_ACTIVE_OBJECT_MAP_ONLY = 0x0 << REQUEST_PROCESSING;
  static const PolicyValueId REQUEST_PROCESSING_USE_DEFAULT_SERVANT        = 0x1 << REQUEST_PROCESSING;
  static const PolicyValueId REQUEST_PROCESSING_USE_SERVANT_MANAGER        = 0x2 << REQUEST_PROCESSING;
  

} // anonymous namespace


// create poa with policies
PortableServer::POA_ptr create_POA (PortableServer::POA_ptr root_POA,
                                    PortableServer::POAManager_ptr POA_mngr,
                                    const char * poaName,
                                    const unsigned char policiesField)
{
  //
  // Policies Creation
  //
  CORBA::PolicyList policies;
  
  // Default : every body should support the following ...
  policies.length(7);
  unsigned char map[7] = { 
         THREAD,
			   LIFESPAN,
			   IDUNIQUENESS,
			   IDASSIGNMENT,
			   IMPLICIT_ACTIVATION,
			   SERVANT_RETENTION,
			   REQUEST_PROCESSING}; 
  
  // Following lines are not "reader Friendly" ...
  // Each line of the policy list is filled with the correct value.
  int count=0;

  /*LIFESPAN*/
  policies[count++] = root_POA->create_lifespan_policy((policiesField&(0x1<<LIFESPAN))?PortableServer::PERSISTENT:PortableServer::TRANSIENT);

  /*IDUNIQUENESS*/
  policies[count++] = root_POA->create_id_uniqueness_policy((policiesField&(0x1<<IDUNIQUENESS))?PortableServer::MULTIPLE_ID:PortableServer::UNIQUE_ID);

  /*IDASSIGNMENT*/
  policies[count++] = root_POA->create_id_assignment_policy((policiesField&(0x1<<IDASSIGNMENT))?PortableServer::USER_ID:PortableServer::SYSTEM_ID);

  /*SERVANT_RETENTION*/
  policies[count++] = root_POA->create_servant_retention_policy((policiesField&(0x1<<SERVANT_RETENTION))?PortableServer::NON_RETAIN:PortableServer::RETAIN);

  /*REQUEST_PROCESSING*/
  if(policiesField & (0x1<<REQUEST_PROCESSING))
    policies[count++] = root_POA->create_request_processing_policy(PortableServer::USE_DEFAULT_SERVANT);
  else if(policiesField & (0x1<<(REQUEST_PROCESSING+1)))
    policies[count++] = root_POA->create_request_processing_policy(PortableServer::USE_SERVANT_MANAGER);
  else
    policies[count++] = root_POA->create_request_processing_policy(PortableServer::USE_ACTIVE_OBJECT_MAP_ONLY);
  
  //
  // POA Creation
  //
  PortableServer::POA_var aPoa;
  try 
  {
    aPoa = root_POA->create_POA (poaName, POA_mngr, policies);
  }
  
  // POA creation May failed for a lot of reason, but anyway we just print
  // a warning message and we return nil.
  catch (PortableServer::POA::AdapterAlreadyExists ex)
  {
    std::cerr << "server : error poa ["<<poaName<<"] already exists" << std::endl;
    aPoa=PortableServer::POA::_nil();
  }

  catch (PortableServer::POA::InvalidPolicy ex)
  {
    std::cerr << "server : can not create POA : unconsistent policy : [";
    
    if(ex.index<count)
    {
      switch(map[ex.index])
      {
        case THREAD :
	        std::cerr << "Thread Policy/"
	             << ((policiesField&(0x1<<THREAD))?"SINGLE_THREAD_MODEL":"THREAD_ORB_CTRL_MODEL");
	        break;
        case LIFESPAN :
	        std::cerr << "Lifespan Policy/"
	             << ((policiesField&(0x1<<LIFESPAN))?"PERSISTENT":"TRANSIENT");
	        break;
        case IDUNIQUENESS :
	        std::cerr << "Id Uniqueness Policy/"
	             << ((policiesField&(0x1<<IDUNIQUENESS))?"MULTIPLE_ID":"UNIQUE_ID");
	        break;
        case IDASSIGNMENT :
	        std::cerr << "Id Assignment Policy/"
	             << ((policiesField&(0x1<<IDASSIGNMENT))?"USER_ID":"SYSTEM_ID");
	        break;
        case IMPLICIT_ACTIVATION :
	        std::cerr << "Implicit Activation Policy/"
	             << ((policiesField&(0x1<<IMPLICIT_ACTIVATION))?"NO_IMPLICIT_ACTIVATION":"IMPLICIT_ACTIVATION");
	        break;
        case SERVANT_RETENTION :
	        std::cerr << "Servant Retention Policy/"
	             << ((policiesField&(0x1<<SERVANT_RETENTION))?"NON_RETAIN":"RETAIN");
	        break;
        case REQUEST_PROCESSING :
	        std::cerr << "Request Processing Policy/";
	        if (policiesField&(0x1<<REQUEST_PROCESSING))
	          std::cerr << "USE_DEFAULT_SERVANT";
	        else if(policiesField&(0x1<<(REQUEST_PROCESSING+1)))
	          std::cerr << "USE_SERVANT_MANAGER";
	        else
	          std::cerr << "USE_ACTIVE_OBJECT_MAP_ONLY";
	          break;
      }
    }
    
    else
    {
      std::cerr << "INVALID INDEX";
    }
    
    std::cerr << "]" << std::endl;
    aPoa=PortableServer::POA::_nil();
  }


  return aPoa._retn();
}

//
// Attach a servant to a corbaloc reachable object
//
void bind_object_to_corbaloc(CORBA::ORB_ptr orb,
                             const std::string& corbaloc_name,
                             CORBA::Object_ptr object)
   throw(CORBA::SystemException)
{
  CORBA::Object_var iorTableObj = orb->resolve_initial_references("IORTable");

  IORTable::Table_var iorTable = IORTable::Table::_narrow(iorTableObj.in());

  // Are we not using a specific version of Tao ?
  if(CORBA::is_nil(iorTable.in())) 
  {
    std::cerr << "server : can not get IORTable" << std::endl;
    exit (EXIT_FAILURE);
  }

  // register the object

  try
  {
    CORBA::String_var ior_string = orb->object_to_string(object);

    iorTable->bind(corbaloc_name.c_str(), ior_string.in());
  }
  catch (const IORTable::AlreadyBound &)
  {
    throw CORBA::BAD_PARAM(0, CORBA::COMPLETED_NO );
  }
  catch (const CORBA::SystemException &)
  {
    throw;
  }
}


/**
 * server initialization:
 *
 */
int init_server (CORBA::ORB_ptr orb,
                 PortableServer::POA_ptr appli_POA,
                 int argc, char* argv[],
                 mod1::Server_ptr& p_server)
{
  int status = FAILURE;

  mod1::Server_var server_ref = mod1::Server::_nil();

  try 
  {
    // create the Servant to handle registration request (ref count is incremented)
    Server_impl* p_server_servant = new Server_impl ();

    // create an object var to take pointer ownership
    // (ref count will be decremented when var will be destroyed at the method end)
    PortableServer::ServantBase_var servant_var = p_server_servant;

    // create an object id
    PortableServer::ObjectId_var oid =
                  PortableServer::string_to_ObjectId("Server");
      

    // activate servant on POA (ref count is incremented)
    appli_POA->activate_object_with_id(oid.in(), p_server_servant);
    CORBA::Object_var object = appli_POA->id_to_reference(oid.in());
    server_ref = mod1::Server::_narrow(object.in());

    // export the object reference to a file.
    CORBA::String_var ref_string = orb->object_to_string(server_ref.in());
    std::ofstream os("server.ior");
    os << ref_string.in();
    os.close();

    p_server = server_ref._retn();
        
    status = SUCCESS;
  }
  catch (const CORBA::SystemException& ex) 
  {
    std::cerr << "CORBA::SystemException" << ex << std::endl;
  }
  catch(const CORBA::Exception& ex) 
  {
    std::cerr << "CORBA::Exception:" << ex << std::endl;
  }

  return status;
}


/**
 * Main.
 * start with -ORBEndpoint iiop://<host>:<portNumber>"
 */
int main(int argc, char* argv[])
{
  int status = SUCCESS;
  
  const unsigned char policies = 0;

  CORBA::ORB_var orb = CORBA::ORB::_nil();
  PortableServer::POA_var root_POA = PortableServer::POA::_nil();
    
  mod1::Server_var server_ref = mod1::Server::_nil();

  try 
  {
    // initialise the orb 
    orb = CORBA::ORB_init(argc,argv);

    if (CORBA::is_nil(orb.in()))
    {
      std::cerr << "server : orb can not be initialized" << std::endl;
      exit (EXIT_FAILURE);
	  }
		     
    //  Get the root poa.
    CORBA::Object_var poaObj = orb->resolve_initial_references("RootPOA");
   
    if(CORBA::is_nil(poaObj.in())) 
    {
      std::cerr << "server : can not resolve Root POA" << std::endl;
      exit (EXIT_FAILURE);
    }
   
    root_POA = PortableServer::POA::_narrow(poaObj); 
    if(CORBA::is_nil(root_POA.in())) 
    {
      std::cerr << "server : Root POA is not a POA" << std::endl;
      exit (EXIT_FAILURE);
    }
  
    //
    //  Get the poa manager.
    //
    PortableServer::POAManager_var POA_mngr = root_POA->the_POAManager();
    POA_mngr->activate();

    if(CORBA::is_nil(POA_mngr.in()))
    {
      std::cerr << "server : Root POA is not a POA" << std::endl;
      exit (EXIT_FAILURE);
    }
  
    //
    //  Create our POA with our policies.
    //
    PortableServer::POA_var user_POA = PortableServer::POA::_nil();
  
    if (policies != 0)
    {
      // This is not the default policy set, so we use internal method
      // to create the POA with correct policies.
    
      user_POA = create_POA(user_POA.in(), POA_mngr.in(), "USER_POA", policies);
    
      if(CORBA::is_nil(user_POA.in()))
      {
        // We still trying with the root poa. But user must be warned !
        std::cerr << "server : POA Creation Failed : use Root POA as POA !" << std::endl;
        user_POA = root_POA;
      }
    }
    else 
    { 
      user_POA = root_POA;
    }

        
    // init the server.
    status = init_server (orb.in(), user_POA.in(), argc, argv, server_ref.out());
    
    // publishes the server corbaloc
    bind_object_to_corbaloc (orb.in(), "server_", server_ref.in());
    
    std::cout << "bind server to server_" << std::endl;

    if (status == SUCCESS) 
    {
      std::cout << "server running ......" << std::endl;
      
      // just run the ORB.
      orb->run();
    }
  }
  catch(const CORBA::Exception& ex) 
  {
    std::cerr << ex << std::endl;
    status = FAILURE;
  }
  catch (...) 
  {
    std::cerr << "unknown exception in main" << std::endl;
    status = FAILURE;
  }

  // end of corba processing

  if(!CORBA::is_nil(orb.in())) 
  {
    try 
    {
      // Interrupt orb polling, but does not clean anything
      orb->shutdown(false);
      orb->destroy();
    }
    catch(const CORBA::Exception& ex) 
    {
      std::cerr << ex << std::endl;
      status = FAILURE;
    }
  }

  return status;
}
