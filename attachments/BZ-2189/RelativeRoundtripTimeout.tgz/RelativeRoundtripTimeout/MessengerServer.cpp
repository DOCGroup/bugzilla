#include "Messenger_i.h"
#include <ace/streams.h>

int
main(int argc, char * argv[])
{
  try {
    // Initialize orb
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
    // Get reference to Root POA.
    CORBA::Object_var obj = orb->resolve_initial_references("RootPOA");
    PortableServer::POA_var poa = PortableServer::POA::_narrow(obj.in());

    // Activate POA manager
    PortableServer::POAManager_var mgr = poa->the_POAManager();
    mgr->activate();

    // Create an object
    Messenger_i messenger_servant;

    // Write its stringified reference to a file
    PortableServer::ObjectId_var oid = poa->activate_object(&messenger_servant);
    obj = poa->id_to_reference(oid.in());
    Messenger_var messenger = Messenger::_narrow(obj.in());
    CORBA::String_var str = orb->object_to_string(messenger.in());
    ofstream fout("MessengerServer.ior");
    fout << str.in() << endl;
    fout.close();
    cout << "IOR written to file MessengerServer.ior" << endl;

    // Accept requests
    orb->run();
    orb->destroy();
  }
  catch (CORBA::Exception& ex) {
    cerr << "CORBA::Exception " << ex << endl;
    return 1;
  }

  return 0;
}
