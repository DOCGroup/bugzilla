eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

use Env (ACE_ROOT);
use lib "$ACE_ROOT/bin";
use PerlACE::Run_Test;

$ior="MessengerServer.ior";
unlink $ior;

# start MessengerServer
$S = new PerlACE::Process("MessengerServer");
$S->Spawn();
if (PerlACE::waitforfile_timed ($ior, 5) == -1) {
    print STDERR "ERROR: cannot find file $ior\n";
    $S->Kill(); 
    exit 1;
}


# start MessengerClient
$C = new PerlACE::Process("MessengerClient", "20");

if ($C->SpawnWaitKill(10) == -1) {
     $S->Kill();
     exit (1);
}

# clean-up 
$S->Kill();
unlink $ior;

exit 0;



