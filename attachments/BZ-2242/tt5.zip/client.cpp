#include <iostream>
#include <fstream>
#include <winsock2.h>
#include <windows.h>
#include <tao/corba.h>
#include <tao/DynamicInterface/Request.h>
#include "testC.h"

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  /*
   * Read server's object reference.
   */

  std::ifstream in ("server.ior");

  if (!in.good()) {
    std::cout << "Oops: server.ior not found." << std::endl;
    return 1;
  }

  CORBA::String_var ior;
  in >> ior;

  Server_var server;

  try {
    CORBA::Object_var obj = orb->string_to_object (ior.in());
    server = Server::_narrow (obj);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: " << ex << std::endl;
    return 1;
  }

  /*
   * Call server.
   */

  CORBA::Request_var req;

  try {
    req = server->_request ("shutdown");
    req->set_return_type (CORBA::_tc_void);
    req->send_deferred ();
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops sending request: " << ex << std::endl;
    exit (1);
  }

  Sleep (5000);

  try {
    req->get_response ();
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops receiving response: " << ex << std::endl;
  }

  orb->destroy ();
  return 0;
}
