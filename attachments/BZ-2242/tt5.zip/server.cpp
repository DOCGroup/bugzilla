#include <iostream>
#include <fstream>
#include <string>
#include "testS.h"

class Server_impl : virtual public POA_Server {
public:
  Server_impl (CORBA::ORB_ptr, Monitor_ptr);
  void shutdown ();

private:
  CORBA::ORB_var orb;
  Monitor_var monitor;
};

Server_impl::Server_impl (CORBA::ORB_ptr o, Monitor_ptr m)
  : orb (CORBA::ORB::_duplicate (o)),
    monitor (Monitor::_duplicate (m))
{
  std::string msg = "The server is started.";

  try {
    monitor->started (msg.c_str());
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Started oops: " << ex << std::endl;
  }
}

void
Server_impl::shutdown ()
{
  std::string msg = "The server is stopped.";

  try {
    monitor->stopped (msg.c_str());
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Stopped oops: " << ex << std::endl;
  }

  try {
    orb->shutdown (0);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Shutdown oops: " << ex << std::endl;
  }
}

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);
  CORBA::Object_var obj = orb->resolve_initial_references ("RootPOA");
  PortableServer::POA_var poa = PortableServer::POA::_narrow (obj);
  PortableServer::POAManager_var mgr = poa->the_POAManager ();
  mgr->activate ();

  /*
   * Read monitor's object reference.
   */

  std::ifstream in ("monitor.ior");

  if (!in.good()) {
    std::cout << "Oops: monitor.ior not found." << std::endl;
    return 1;
  }

  CORBA::String_var ior;
  in >> ior;

  Monitor_var monitor = Monitor::_nil ();

  try {
    obj = orb->string_to_object (ior.in());
    monitor = Monitor::_narrow (obj);
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: " << ex << std::endl;
    return 1;
  }

  /*
   * Activate server.
   */

  Server_impl * si = new Server_impl (orb, monitor);
  Server_var s = si->_this ();

  /*
   * Write object reference.
   */

  {
    std::ofstream out ("server.ior");
    CORBA::String_var ior = orb->object_to_string (s);
    out << ior << std::endl;
  }

  /*
   * Run.
   */

  std::cout << "Running ... " << std::endl;
  orb->run ();
  std::cout << "Shutting down ... " << std::endl;

  try {
    orb->shutdown (1);
  }
  catch (const CORBA::BAD_INV_ORDER &) {
    // this is expected in a synchronous server
  }
  catch (const CORBA::Exception & ex) {
    std::cout << "Oops: " << ex << std::endl;
  }

  orb->destroy ();
  return 0;
}
