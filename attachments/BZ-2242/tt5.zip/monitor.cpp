#include <iostream>
#include <fstream>
#include "testS.h"

class Monitor_impl : virtual public POA_Monitor {
public:
  void started (const char *);
  void stopped (const char *);
};

void
Monitor_impl::started (const char * message)
{
  std::cout << message << std::endl;
}

void
Monitor_impl::stopped (const char * message)
{
  std::cout << message << std::endl;
}

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);
  CORBA::Object_var obj = orb->resolve_initial_references ("RootPOA");
  PortableServer::POA_var poa = PortableServer::POA::_narrow (obj);
  PortableServer::POAManager_var mgr = poa->the_POAManager ();
  mgr->activate ();

  /*
   * Activate server.
   */

  Monitor_impl * si = new Monitor_impl;
  Monitor_var s = si->_this ();

  /*
   * Write object reference.
   */

  {
    std::ofstream out ("monitor.ior");
    CORBA::String_var ior = orb->object_to_string (s);
    out << ior << std::endl;
  }

  /*
   * Run.
   */

  std::cout << "Running ... " << std::endl;
  orb->run ();

  return 0;
}
