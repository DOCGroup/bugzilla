// server.cpp,v 1.4 2001/03/04 21:59:13 coryan Exp

#include "test_i.h"
#include "ace/Get_Opt.h"
#include "ace/Task.h"
#include "orbsvcs/CosNamingC.h"
#include "orbsvcs/Naming/Naming_Utils.h"
#include "tao/IORTable/IORTable.h"

ACE_RCSID(MT_Server, server, "server.cpp,v 1.4 2001/03/04 21:59:13 coryan Exp")

PortableServer::POA_ptr 
CreatePersistentPOA(const char *pPOAName, PortableServer::POA_ptr pParent);

const char *ior_output_file = 0;
int nthreads = 20;

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "o:n:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'o':
	ior_output_file = get_opts.optarg;
	break;

      case 'n':
	nthreads = ACE_OS::atoi (get_opts.optarg);
	break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
			   "-o <iorfile>"
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}

class Worker : public ACE_Task_Base
{
  // = TITLE
  //   Run a server thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run server threads
  //
public:
  Worker (CORBA::ORB_ptr orb);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

class Worker2 : public ACE_Task_Base
{
  // = TITLE
  //   Run a server thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run server threads
  //
public:
  Worker2 (CORBA::ORB_ptr orb);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

int
main (int argc, char *argv[])
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "", ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA", ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (poa_object.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Unable to initialize the POA.\n"),
                          1);

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in (), ACE_TRY_ENV);
      ACE_TRY_CHECK;

      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      Simple_Server_i server_impl (orb.in ());

      Simple_Server_var server =
        server_impl._this (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::String_var ior =
	orb->object_to_string (server.in (), ACE_TRY_ENV);
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "Activated as <%s>\n", ior.in ()));

      // If the ior_output_file exists, output the ior to it
      if (ior_output_file != 0)
	{
	  FILE *output_file= ACE_OS::fopen (ior_output_file, "w");
	  if (output_file == 0)
	    ACE_ERROR_RETURN ((LM_ERROR,
			       "Cannot open output file for writing IOR: %s",
			       ior_output_file),
			      1);
	  ACE_OS::fprintf (output_file, "%s", ior.in ());
	  ACE_OS::fclose (output_file);
	}

   PortableServer::POA_var persist_poa=CreatePersistentPOA("Persistent",root_poa.in());

   poa_manager->activate (ACE_TRY_ENV);
   ACE_TRY_CHECK;
   
    // get a reference to the IORTable
    CORBA::Object_var table_object = orb->resolve_initial_references ("IORTable");
    
    ACE_TRY_CHECK;
    // narrow the object to an IOR table
    IORTable::Table_var  iorTable = IORTable::Table::_narrow (table_object.in ());
    if (CORBA::is_nil (iorTable))
    {
      ACE_ERROR ((LM_ERROR, "Nil IORTable (%N:%l)\n"));
      return -1;
    }

// ------- If this does not dead lock try moving this section to **HERE** below
    ACE_DEBUG ((LM_DEBUG,"Initializing Naming Service\n"));
    // Activate the name service
    TAO_Naming_Server naming_server;
    if(naming_server.init (orb.in (),
                            persist_poa,
                            ACE_DEFAULT_MAP_SIZE,
                            0 /* timeout */,
                            0 /* resolve_for_existing_naming_service */,
                            0 /* persistence_location */,
                            TAO_NAMING_BASE_ADDR /*base_addr*/,
                            0 /* enable_multicast */))
    {
      ACE_DEBUG((LM_ERROR, "Failed to initialize Naming Service!"));
      return -1;
    }
 // -----------------------------------------------------------------

    ACE_DEBUG ((LM_DEBUG,"Activating ORB\n"));

    Worker worker (orb.in ());
    if (worker.activate (THR_NEW_LWP | THR_JOINABLE,
                           nthreads) != 0)
    ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);

// --- Move above section here if deadlock does not occur up there
// **HERE**
// ----------------------------------------------------------------

    Worker2 worker2(orb.in());
    if (worker2.activate (THR_NEW_LWP | THR_JOINABLE,
                           1) != 0)
         ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);

    worker.thr_mgr ()->wait ();
    worker2.thr_mgr()->wait ();

    ACE_DEBUG ((LM_DEBUG, "event loop finished\n"));
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

// ****************************************************************

Worker::Worker (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
Worker::svc (void)
{
  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      this->orb_->run (ACE_TRY_ENV);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
    }
  ACE_ENDTRY;
  return 0;
}

// ****************************************************************

Worker2::Worker2 (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
Worker2::svc (void)
{
  char hostName[256];
  if(ACE_OS::hostname (hostName,256) != 0)
  {
      ACE_ERROR_RETURN ((LM_ERROR,
                        "Cannot Get hostname\n"),
                          -1);
  }

  char buffer[512];
  sprintf(buffer, "corbaloc:iiop:%s:6464/NameService",hostName/*,ACE_DEFAULT_SERVER_PORT*/);
  for(int i=0; i<1000; ++i)
  {
    ACE_DECLARE_NEW_CORBA_ENV;
    ACE_TRY
      {   
        CORBA::Object_var obj = orb_->string_to_object(buffer);
        if(!CORBA::is_nil(obj))
        {
           ACE_DEBUG((LM_DEBUG,"Accessing Naming Server %d of 1000\n",i));
           CosNaming::NamingContext_var root(CosNaming::NamingContext::_narrow(obj.in()));
        }
        ACE_TRY_CHECK;
      }
    ACE_CATCHANY
      {
         ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      }
    ACE_ENDTRY;
  }
  return 0;
}


PortableServer::POA_ptr 
CreatePersistentPOA(const char *pPOAName, PortableServer::POA_ptr pParent)
{
  try
  {
	  CORBA::PolicyList Policies(3);
	  Policies.length(3);  

    // Lifespan Policy
	  Policies[0] =
		  pParent->create_lifespan_policy (PortableServer::PERSISTENT);

    // ID Assignment Policy
	  Policies[1] =
		  pParent->create_id_assignment_policy (PortableServer::USER_ID);
	  
	  // Id Uniqueness Policy
	  Policies[2] =
		  pParent->create_id_uniqueness_policy (PortableServer::UNIQUE_ID);


  	PortableServer::POAManager_var POAManager = pParent->the_POAManager();
	  	  
	  PortableServer::POA_var NewPOA = pParent->create_POA( pPOAName,
		  							                                      POAManager.in(),
										                                      Policies);
	  for (CORBA::ULong i = 0; i < Policies.length (); ++i)
    {
      CORBA::Policy_ptr pPolicy = Policies[i];
      pPolicy->destroy();
	  }

	  return NewPOA._retn();
	}
  catch(CORBA::SystemException&)
  {
	  ACE_DEBUG((LM_ERROR, "System Exception Raised crating persistent POA"));
  }

	return PortableServer::POA::_nil();
}
