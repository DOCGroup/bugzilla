// $Id:$

#include "ChildI.h"

int main (int, char*[])
{
  AMI_ChildHandler_i myChildHandler;
  return 0;
}
