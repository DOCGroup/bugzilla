// -*- C++ -*-
// $Id$

#ifndef CIAO_SIMPLESUPPORTS_EXEC_M2WCXF_H_
#define CIAO_SIMPLESUPPORTS_EXEC_M2WCXF_H_


#include "SimpleSupportsEC.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#include "SimpleSupports_exec_export.h"
#include "tao/LocalObject.h"

/// Namespace for implementation of Simple::SimpleSupports component
namespace CIAO_Simple_SimpleSupports_Impl
{

  /// Component Executor Implementation Class: SimpleSupports_exec_i
  class SIMPLESUPPORTS_EXEC_Export SimpleSupports_exec_i
    : public virtual SimpleSupports_Exec,
      public virtual ::CORBA::LocalObject
  {
  public:
    /// Constructor
    SimpleSupports_exec_i (void);
    /// Destructor
    virtual ~SimpleSupports_exec_i (void);

    /** @name Supported operations and attributes. */
    //@{

    virtual void hello (const char * hello);

    //@}

    /** @name Component attributes and port operations. */
    //@{
    //@}

    /** @name Session component operations */
    //@{

    /// Setter for container context for this component
    /// @param[in] ctx - Container context
    virtual void set_session_context (::Components::SessionContext_ptr ctx);

    /// Component state change method to configuration_complete state
    virtual void configuration_complete (void);

    /// Component state change method to activated state
    virtual void ccm_activate (void);

    /// Component state change method to passivated state
    virtual void ccm_passivate (void);

    /// Component state change method to removed state
    virtual void ccm_remove (void);
    //@}

    /** @name User defined public operations. */
    //@{

    //@}

  private:
    /// Context for component instance. Used for all middleware communication
    ::Simple::CCM_SimpleSupports_Context_var ciao_context_;

    /** @name Component attributes. */
    //@{
    //@}

    /** @name Component facets. */
    //@{
    //@}

    /** @name User defined members. */
    //@{

    //@}

    /** @name User defined private operations. */
    //@{
    bool triggered_;
    //@}
  };

  /// Factory method and library entry point used by the middleware
  /// @return new component instance
  extern "C"  ::Components::EnterpriseComponent_ptr
  SIMPLESUPPORTS_EXEC_Export create_Simple_SimpleSupports_Impl (void);
}

namespace CIAO_Simple_SimpleSupports_Impl
{
  /**
   * Home Executor Implementation Class: SimpleSupportsHome_exec_i
   */
  class SIMPLESUPPORTS_EXEC_Export SimpleSupportsHome_exec_i
    : public virtual SimpleSupportsHome_Exec,
      public virtual ::CORBA::LocalObject
  {
  public:
    /// Constructor
    SimpleSupportsHome_exec_i (void);

    /// Destructor
    virtual ~SimpleSupportsHome_exec_i (void);

    /// Factory method
    virtual ::Components::EnterpriseComponent_ptr create (void);
  };

  /// Factory method for Simple::SimpleSupportsHome
  extern "C"  ::Components::HomeExecutorBase_ptr
  SIMPLESUPPORTS_EXEC_Export create_Simple_SimpleSupportsHome_Impl (void);
}

#endif /* ifndef */
