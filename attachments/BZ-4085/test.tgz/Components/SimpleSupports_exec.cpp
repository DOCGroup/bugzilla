// -*- C++ -*-
// $Id$

#include "SimpleSupports_exec.h"

namespace CIAO_Simple_SimpleSupports_Impl
{

  /**
   * Component Executor Implementation Class: SimpleSupports_exec_i
   */

  SimpleSupports_exec_i::SimpleSupports_exec_i (void) : triggered_(false)
  {
    ACE_TRACE ("SimpleSupports_exec_i::SimpleSupports_exec_i ()");
  }

  SimpleSupports_exec_i::~SimpleSupports_exec_i (void)
  {
    ACE_TRACE ("SimpleSupports_exec_i::~SimpleSupports_exec_i ()");
  }

  // Supported operations and attributes.

  void
  SimpleSupports_exec_i::hello (
    const char * hello)
  {
    ACE_TRACE ("SimpleSupports_exec_i::hello ()");
    this->triggered_ = true;
    // Your code here.
    ACE_DEBUG ((LM_EMERGENCY, "SimpleSupports_exec_i::hello - "
               "Got the following information from trig port: %C\n",
               hello));
  }

  // Component attributes and port operations.

  // Operations from Components::SessionComponent.

  void
  SimpleSupports_exec_i::set_session_context (
    ::Components::SessionContext_ptr ctx)
  {
    ACE_TRACE ("SimpleSupports_exec_i::set_session_context ()");
    this->ciao_context_ =
      ::Simple::CCM_SimpleSupports_Context::_narrow (ctx);

    if ( ::CORBA::is_nil (this->ciao_context_.in ()))
      {
        throw ::CORBA::INTERNAL ();
      }
  }

  void
  SimpleSupports_exec_i::configuration_complete (void)
  {
    ACE_TRACE ("SimpleSupports_exec_i::configuration_complete ()");
    /* Your code here. */
  }

  void
  SimpleSupports_exec_i::ccm_activate (void)
  {
    ACE_TRACE ("SimpleSupports_exec_i::ccm_activate ()");
    /* Your code here. */
  }

  void
  SimpleSupports_exec_i::ccm_passivate (void)
  {
    ACE_TRACE ("SimpleSupports_exec_i::ccm_passivate ()");
    /* Your code here. */
  }

  void
  SimpleSupports_exec_i::ccm_remove (void)
  {
    ACE_TRACE ("SimpleSupports_exec_i::ccm_remove ()");
    /* Your code here. */
    if (!triggered_)
      ACE_ERROR ((LM_EMERGENCY, "Error:  My facet wasn't triggered!!\n"));
  }

  extern "C"  ::Components::EnterpriseComponent_ptr
  SIMPLESUPPORTS_EXEC_Export create_Simple_SimpleSupports_Impl (void)
  {
    ACE_TRACE ("create_Simple_SimpleSupports_Impl ()");
    ::Components::EnterpriseComponent_ptr retval =
      ::Components::EnterpriseComponent::_nil ();

    ACE_NEW_NORETURN (
      retval,
      SimpleSupports_exec_i);

    return retval;
  }
}

namespace CIAO_Simple_SimpleSupports_Impl
{
  /**
   * Home Executor Implementation Class: SimpleSupportsHome_exec_i
   */

  SimpleSupportsHome_exec_i::SimpleSupportsHome_exec_i (void)
  {
    ACE_TRACE ("SimpleSupportsHome_exec_i::SimpleSupportsHome_exec_i ()");
  }

  SimpleSupportsHome_exec_i::~SimpleSupportsHome_exec_i (void)
  {
    ACE_TRACE ("SimpleSupportsHome_exec_i::~SimpleSupportsHome_exec_i ()");
  }

  // Implicit operations.

  ::Components::EnterpriseComponent_ptr
  SimpleSupportsHome_exec_i::create (void)
  {
    ACE_TRACE ("SimpleSupportsHome_exec_i::create ()");
    ::Components::EnterpriseComponent_ptr retval =
      ::Components::EnterpriseComponent::_nil ();
    
    ACE_NEW_THROW_EX (
      retval,
      SimpleSupports_exec_i,
      ::CORBA::NO_MEMORY ());
    
    return retval;
  }

  extern "C"  ::Components::HomeExecutorBase_ptr
  SIMPLESUPPORTS_EXEC_Export create_Simple_SimpleSupportsHome_Impl (void)
  {
    ACE_TRACE ("create_Simple_SimpleSupportsHome_Impl ()");
    ::Components::HomeExecutorBase_ptr retval =
      ::Components::HomeExecutorBase::_nil ();
    
    ACE_NEW_NORETURN (
      retval,
      SimpleSupportsHome_exec_i);
    
    return retval;
  }
}
