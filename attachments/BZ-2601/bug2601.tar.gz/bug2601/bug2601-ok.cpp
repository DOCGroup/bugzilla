#include "ace/OS.h"
#include "ace/Log_Msg.h"

int main(int argc, char ** argv)
{
  ACE_DEBUG((
    LM_DEBUG,
    ACE_TEXT ("(%P|%t) main - entered\n")
  ));

  char const * pc_fileName = "/tmp/bug2601.img";

  if(argc >= 2)
    pc_fileName = argv[1];
  
  ACE_OS::unlink(pc_fileName);
  
  ACE_DEBUG((
    LM_DEBUG,
    ACE_TEXT ("(%P|%t) main - sizeof(off_t)=%d, sizeof(size_t)=%d\n"),
    sizeof(off_t), sizeof(size_t)
  ));

  for(int i = 20; i < 40; ++i)
  {
    size_t size = 2L << i;
    errno = 0;
    ACE_HANDLE fd = ACE_OS::open(pc_fileName, O_RDWR|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR);
    if(fd == ACE_INVALID_HANDLE)
    {
      ACE_DEBUG((
        LM_DEBUG,
        ACE_TEXT ("(%P|%t) main - oops, cannot open file(%s): %s\n"),
        pc_fileName, ACE_OS::strerror(errno)
      ));
      abort();
    }
    errno = 0;
    int result = ACE_OS::ftruncate(fd, size);
    if(result != 0)
    {
      ACE_DEBUG((
        LM_DEBUG,
        ACE_TEXT ("(%P|%t) main - oops, cannot truncate file(%s, %g): %s\n"),
        pc_fileName, (double)size, ACE_OS::strerror(errno)
      ));
      abort();
    }
    errno = 0;
    void * p_memory = ACE_OS::mmap(0, size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    if(p_memory == 0)
    {
      ACE_DEBUG((
        LM_DEBUG,
        ACE_TEXT ("(%P|%t) main - oops, cannot map memory(%g): %s\n"),
        (double)size, ACE_OS::strerror(errno)
      ));
      abort();
    }
    else
    {
      ACE_DEBUG((
        LM_DEBUG,
        ACE_TEXT ("(%P|%t) main - map memory (%g == 2^%d) OK)\n"),
        (double)size, i
      ));
      
      char * p_x = (char *)p_memory;
      p_x += size - 1;
      *p_x = 1;
      ACE_OS::munmap(p_memory, size);
      ACE_OS::close(fd);
    }
  }
  
  ACE_OS::unlink(pc_fileName);
  
  ACE_DEBUG((
    LM_DEBUG,
    ACE_TEXT ("(%P|%t) main - finished\n")
  ));
  return 0;
}
