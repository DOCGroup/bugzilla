--- Asynch_Acceptor.h.5.4.7     2005-02-21 11:47:06.000000000 +0200
+++ Asynch_Acceptor.h   2005-11-13 13:52:41.758224600 +0200
@@ -123,7 +123,7 @@
    * closed and the all outstanding asynchronous operations have
    * either completed or have been canceled on the old listen handle.
    */
-  virtual void set_handle (ACE_HANDLE handle);
+  virtual int set_handle (ACE_HANDLE handle);

   /// This initiates a new asynchronous accept operation.
   /**

