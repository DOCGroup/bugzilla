--- Asynch_Acceptor.cpp.5.4.7   2005-03-08 14:27:20.000000000 +0200
+++ Asynch_Acceptor.cpp 2005-11-13 14:45:08.182187100 +0200
@@ -172,7 +172,7 @@
   return 0;
 }

-template <class HANDLER> void
+template <class HANDLER> int
 ACE_Asynch_Acceptor<HANDLER>::set_handle (ACE_HANDLE listen_handle)
 {
   ACE_TRACE ("ACE_Asynch_Acceptor<>::set_handle");
@@ -185,9 +185,12 @@
                                  this->listen_handle_,
                                  0,
                                  this->proactor ()) == -1)
-    ACE_ERROR ((LM_ERROR,
-                ACE_LIB_TEXT ("%p\n"),
-                ACE_LIB_TEXT ("ACE_Asynch_Accept::open")));
+    ACE_ERROR_RETURN ((LM_ERROR,
+                       ACE_LIB_TEXT ("%p\n"),
+                       ACE_LIB_TEXT ("ACE_Asynch_Accept::open")),
+                      -1);
+
+  return 0;
 }

 template <class HANDLER> ACE_HANDLE
