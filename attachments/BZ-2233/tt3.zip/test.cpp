/*
 * This code should not compile. An error should be reported in line 41.
 */

#include <iostream>
#include <orbsvcs/CosNamingC.h>

int
main (int argc, char *argv[])
{
  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  std::cout << "Testing ... " << std::flush;

  {
    CORBA::Object_var foo;

    {
      CosNaming::NamingContext_var nc;

      try {
	CORBA::Object_var obj = orb->resolve_initial_references ("NameService");
	nc = CosNaming::NamingContext::_narrow (obj);
      }
      catch (...) {
	nc = CosNaming::NamingContext::_nil ();
      }

      if (CORBA::is_nil (nc)) {
	std::cout << "Oops. Need naming service." << std::endl;
	return 1;
      }

      std::cout << "1 " << std::flush;

      /*
       * Implicit widening. Should raise a compile-time error.
       * (C++ Language mapping, section 1.3.2.)
       */

      foo = nc;
      std::cout << "2 " << std::flush;
    }

    std::cout << "3 " << std::flush;
  }

  std::cout << "done." << std::endl;
  orb->destroy ();

  return 0;
}
