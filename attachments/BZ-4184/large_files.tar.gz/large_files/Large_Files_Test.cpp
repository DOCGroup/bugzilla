
//=============================================================================
/**
 *  @file    Log_Msg_Test.cpp
 *
 *  $Id: Log_Msg_Test.cpp 93638 2011-03-24 13:16:05Z johnnyw $
 *
 *   This program tests the <ACE_Log_Msg> class in various ways and
 *   also illustrates many of the features of the <ACE_Log_Msg> For
 *   instance, this program tests the <ACE_Log_Msg> abstraction wrt
 *   writing to stderr and to a file.  It also tests writing to user
 *   defined callback objects.
 *
 *
 *  @author Douglas C. Schmidt <schmidt@cs.wustl.edu>
 */
//=============================================================================


#include "test_config.h"

// FUZZ: disable check_for_streams_include
#include "ace/streams.h"

#include "ace/FILE_Connector.h"
#include "ace/Auto_Ptr.h"
#include "ace/Log_Msg_Callback.h"
#include "ace/Log_Record.h"
#include "ace/OS_NS_fcntl.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_unistd.h"
#include "ace/OS_Memory.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/OS_NS_time.h"
#include "ace/Time_Value.h"
#include "ace/Thread.h"


static void
 test_large_files_features (void)
{

#if 1
  ACE_OFF_T fsize = 0, loff=0;  
  ssize_t rsize;  
  ACE_INT32 magicnumRead;
	
  printf("large files: size: %d, %d, ace off: %d...\n", sizeof(size_t), sizeof(ACE_INT32), sizeof(ACE_OFF_T));

    const char *filename= "File.txt";

    ACE_HANDLE hFile = ACE_OS::open(filename, O_RDWR); 
    if (hFile == ACE_INVALID_HANDLE) 
    {
  	printf("open failed.\n");
    }
    else
    { 
	printf("file open OK\n");

	if (hFile == ACE_INVALID_HANDLE)
	{
		printf("lseek first failed\n");
	}

	fsize = ACE_OS::lseek(hFile, 0, SEEK_END);

	printf("file size: %d, comp: %d...\n", fsize,  ((ACE_INT32)sizeof(size_t)) + ((ACE_INT32)sizeof(ACE_INT32)));
  	// if (/*(ACE_UINT32)*/fsize == 14 )	
	{
		loff = ACE_OS::lseek(hFile, (ACE_OFF_T)(-1*(sizeof(ACE_INT32))), SEEK_END);
	
		printf("file size: %d, comp: %d...\n", loff,  ((ACE_INT32)sizeof(size_t)) + ((ACE_INT32)sizeof(ACE_INT32)));
		//if(/*(ACE_UINT32)*/loff == 10)
		{
			printf("lseek second OK\n");

			magicnumRead = 0;

			rsize = ACE_OS::read(hFile, &magicnumRead, sizeof(ACE_INT32));

			printf("read returned: %d, magic: %x...\n", rsize, magicnumRead);	

		}	
	}
	ACE_OS::close(hFile);
    }

#else // Straight Solaris:

    const char *filename= "File.txt";
    ACE_INT32 magicnumRead=0;
offset_t lret = 0;

printf("lret size: %d...\n", sizeof(offset_t));

int file_d = open64(filename, O_RDWR /*| O_LARGEFILE*/);

if (file_d > -1)
{
                size_t result = read(file_d, &magicnumRead, sizeof(ACE_INT32));
                        printf("read ret: %d, magic: %d...\n", result, magicnumRead);
        if (/*l*/lseek(file_d, 0, SEEK_END) < (offset_t)0)
                        printf("lseek Failed");
        else
        {
                lret = (offset_t)/*l*/lseek(file_d, (offset_t)(-1L*(sizeof(ACE_INT32))), SEEK_END);


                printf("ret: %d...\n", lret);

                magicnumRead = 0;

                result = read(file_d, &magicnumRead, sizeof(ACE_INT32));

                if(result== -1 || result!= sizeof(ACE_INT32))
                        printf("read Failed: %d, magic: %d...\n", result, magicnumRead);
                else
                        printf("read OK: %d, magic: %d...\n", result, magicnumRead);
                if (close(file_d) == -1)
                        printf("llseek failed...\n");

        }
}

#endif
}

// Main function.

int
run_main (int argc, ACE_TCHAR *argv[])
{
  printf("Hello: %d...\n", _FILE_OFFSET_BITS);
  ACE_START_TEST (ACE_TEXT ("Log_Msg_Test"));

  int status = 0;

  ACE_DEBUG ((LM_DEBUG,
              ACE_TEXT ("**** running Large File test\n")));

 test_large_files_features();

  ACE_END_TEST;
  return status;
}

