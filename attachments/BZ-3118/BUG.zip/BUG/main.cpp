#include "C.h"
#include "ace/OS.h"
#include <iostream>

int main(int, char*[])
{
  std::cout << s << std::endl;

  return 0;
}