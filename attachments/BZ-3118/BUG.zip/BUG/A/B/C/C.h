#ifndef C_H_
#define C_H_

#include <string>

const std::string s = "hello world";

#endif /* C_H_ */