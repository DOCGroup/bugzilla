eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# $Id: run_test.pl,v 1.1.2.1 2006/03/03 20:10:39 mitza Exp $
# -*- perl -*-

# This is a Perl script that runs some tests.

use lib '../../../bin';
use PerlACE::Run_Test;
use Cwd;
use strict;

## Save the starting directory
my $startdir = getcwd();

# Amount of delay (in seconds) between starting a server and a client
# to allow proper server initialization.
my $sleeptime = 10;

my $quiet = 0;

# check for -q flag
if ($ARGV[0] eq '-q') {
    $quiet = 1;
}

# Variables for command-line arguments to client and server
# executables.
my $iorfile = PerlACE::LocalFile ("ns.ior");

my $status = 0;

my $args = "-o $iorfile";
my $prog = "$startdir/../../orbsvcs/Naming_Service/Naming_Service";
my $NS = new PerlACE::Process ($prog, $args);

unlink $iorfile;

$NS->Spawn ();

if (PerlACE::waitforfile_timed ($iorfile, $sleeptime) == -1) {
  print STDERR "ERROR: cannot find IOR file <$iorfile>\n";
  $NS->Kill ();
  exit 1;
}

my $args = "-ORBInitRef NameService=file://$iorfile";
my $prog = "$startdir/CollocationLockup";

my $CL = new PerlACE::Process ($prog, $args);

# In testing on various platforms, the builds with the bug failed before 
# 20 seconds and when the bug was fixed it returned before 20 seconds.
my $client = $CL->SpawnWaitKill (20);

if ($client != 0) {
  print STDERR "ERROR: client returned $client\n";
  $status = 1;
}

$NS->Kill ();

unlink $iorfile;

exit $status;
