// $Id: CollocationLockup.cpp,v 1.1.2.1 2006/03/03 20:10:39 mitza Exp $

/**
 * CollocationLockup.cpp
 * This is regression test against bug #2130.
 * It tests a deadlock between a thread making a collocated invocation 
 * (which holds a lock on the ORB core and attempts to lock the POA) and a
 * thread activating a servant (which locks the POA and attempts to lock the
 * ORB core).
 *
 * This test was developed from a test submitted by Rick Marlborough for bug
 * #2297 and refined by Paul Calabrese.
 */

#include "ABS.h"

#include <orbsvcs/CosNamingC.h>

#include <ace/Thread_Manager.h>
#include <ace/SString.h>

namespace
{
  const size_t N_THREADS = 20;
  const size_t N_ITERATIONS = 100;
  const char* nameString = "myBobject";

  CORBA::ORB_var g_pOrb;
  PortableServer::POA_var g_pPoa;
  CosNaming::NamingContextExt_var g_pNameService;
}

class A_i : public virtual POA_A
{
};

class B_i : public virtual POA_B
{
public:
  virtual A_ptr
  makeA () throw (CORBA::SystemException)
  {
    A_i* servant = new A_i;
    g_pPoa->activate_object (servant);
    CORBA::Object_var obj = g_pPoa->servant_to_reference (servant);
    return A::_narrow (obj.in());
  }
};

// Thread for ORB->run()
ACE_THR_FUNC_RETURN OrbRunThread (void*);

// Thread to run the test
ACE_THR_FUNC_RETURN TestThread (void*);

int
ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  try
    {
      ACE_Thread_Manager threads;

      // Normal corba init
      g_pOrb = CORBA::ORB_init (argc, argv);
      CORBA::Object_var pPoaObj =
        g_pOrb->resolve_initial_references ("RootPOA");
      g_pPoa = PortableServer::POA::_narrow (pPoaObj.in ());
      PortableServer::POAManager_var pMgr = g_pPoa->the_POAManager ();
      pMgr->activate ();

      CORBA::Object_var pNSObj =
        g_pOrb->resolve_initial_references ("NameService");
      g_pNameService = CosNaming::NamingContextExt::_narrow (pNSObj.in ());
      if (CORBA::is_nil (g_pNameService.in ()))
        {
          ACE_DEBUG ((LM_ERROR, 
		      "ERROR: Could not locate COS Naming Service\n"));
	  return 1;
        }

      ACE_Thread::spawn (OrbRunThread, 0, THR_NEW_LWP | THR_DETACHED);

      // Setup
      B_i* servant = new B_i;
      g_pPoa->activate_object (servant);
      CORBA::Object_var b = g_pPoa->servant_to_reference (servant);
      CosNaming::Name_var name = g_pNameService->to_name (nameString);
      g_pNameService->rebind (name.in (), b.in ());

      //Start threads
      threads.spawn_n (N_THREADS, TestThread);
      ACE_DEBUG ((LM_INFO, "All threads spawned.\n"));

    } //destructor of ACE_Thread_Manager = implicit join
  catch (const CORBA::Exception& ex)
    {
      ACE_DEBUG ((LM_ERROR, "Corba Exception: %s\n", ex._info ().c_str ()));
      return 1;
    }

  g_pOrb->shutdown ();
  return 0;
}

ACE_THR_FUNC_RETURN
OrbRunThread (void*)
{
  try
    {
      g_pOrb->run ();
    }
  catch (const CORBA::Exception& ex)
    {
      ACE_DEBUG ((LM_ERROR, 
		  "In OrbRunThread: Corba Exception: %s\n", 
		  ex._info ().c_str ()));
    }
  return 0;
}

ACE_THR_FUNC_RETURN
TestThread (void*)
{
  for (size_t i(0); i < N_ITERATIONS; ++i)
    {
      CosNaming::Name_var name = g_pNameService->to_name (nameString);
      CORBA::Object_var obj = g_pNameService->resolve (name.in ());
      B_var b = B::_narrow (obj.in ());
      b->makeA ();
      ACE_DEBUG ((LM_INFO, "collocated call returned\n"));
    }
  return 0;
}
