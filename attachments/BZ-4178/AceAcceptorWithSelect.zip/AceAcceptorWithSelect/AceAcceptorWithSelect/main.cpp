//Specifies that WE will instantiate the manager where we want to.
#define ACE_DOESNT_INSTANTIATE_NONSTATIC_OBJECT_MANAGER

#include <ace/OS.h>
#include <ace/Select_Reactor.h>
#include <ace/Acceptor.h>

#include "tcpAcceptorHandler.h"

typedef ACE_Acceptor<tcpAcceptorHandler,ACE_SOCK_ACCEPTOR> tcpAcceptor;


int main (int argc, char** argv)
{
	ACE::init();

	ACE_Select_Reactor * pReactor = new ACE_Select_Reactor();
	ACE_Reactor::instance( new ACE_Reactor(pReactor, 1));

	ACE_INET_Addr addr("mlnewville:1138");
	tcpAcceptor * oAcceptor = new tcpAcceptor(addr, ACE_Reactor::instance());

	tcpAcceptorHandler acceptor;	
	ACE_Reactor::instance()->run_event_loop();

	ACE::fini();
	return 0;
}