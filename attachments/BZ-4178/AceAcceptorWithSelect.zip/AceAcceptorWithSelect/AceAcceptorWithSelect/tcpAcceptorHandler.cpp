#include <ace/Acceptor.h>
#include "tcpAcceptorHandler.h"
#include <iostream>
#include <fstream>

#if defined(linux)
#include <sys/utsname.h>
#endif



/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::tcpAcceptorHandler
**
** Author      : pagibeault
** Date        : 6/4/02
**
** Return      : 
** Purpose     : ACE uses this default constructor
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
tcpAcceptorHandler::tcpAcceptorHandler():
  _name(""), 
  _RemoteAddress(""), 
  _LocalAddress(""), 
  _RemoteAddressIP(""), 
  _LocalAddressIP(""), 
  _traceinstance("SystemTrace"),   
  _timerid(0), 
  _timeout(0)
{
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::~tcpAcceptorHandler
**
** Author      : pagibeault
** Date        : 3/29/00
**
** Return      : 
** Purpose     : Service Object Destructor
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
tcpAcceptorHandler::~tcpAcceptorHandler()
{
  // Close the timer for this connection if one was scheduled
  if (0 != _timerid)
  {
    reactor()->cancel_timer(_timerid);
    _timerid = 0;
  }
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::open
**
** Author      : pagibeault
** Date        : 3/29/00
**
** Return      : int 
** Argument    : void*
** Purpose     : This method is called back automagicly by the reactor when 
**				 a TCP/IP connection has been established
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::open(void* p)
{
  try
  {
    // Call the parent's Open functionality
    // This will register this handler with the reactor
	size_t reactorDescriptorCount = reactor()->size();

	if (SUPER::open(p) == -1)
    {
      return -1;
    }

    // Use the Port Number to obtain the connection name
    ACE_INET_Addr LocalAddr;
    peer().get_local_addr(LocalAddr);
    long lport = LocalAddr.get_port_number();  
  
    // Register my OATCPLib with the new the connection name
    OAString sConnectionName(GetName() + "/" + GetRemoteAddress());
	std::cout << "Accepted remote connection:" << sConnectionName << std::endl;
    if (0 < _timeout)
    {
      _timerid = reactor()->schedule_timer(this, &_timerid, ACE_Time_Value(_timeout));
    }
  }
  catch(const std::exception& e )
  {
	  std::cerr << "Caught std::exception" << e.what() << std::endl;
  }
  
  return 0;
}

/*(*+*)*/
/*****************************************************************************
** Function    : 
**
** Author      : pagibeault
** Date        : 9/27/01
**
** Return      : int tcpAcceptorHandler::handle_close 
** Argument    : ACE_HANDLE handle
** Argument    : ACE_Reactor_Mask close_mask
** Purpose     : Called by the reactor when the method handle_input returns -1
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::handle_close (ACE_HANDLE handle, ACE_Reactor_Mask close_mask)
{
  try
  {
    // Don't do anything if this is just a write close event
    if (ACE_Event_Handler::WRITE_MASK == close_mask)
    {
      return 0;
    }

    // Close the timer for this connection if one was scheduled
    if (0 != _timerid)
    {
      reactor()->cancel_timer(_timerid);
      _timerid = 0;
    }


  }
  catch(const std::exception& e )
  {
	  std::cerr << "Caught std::exception" << e.what() << std::endl;
  }

  return SUPER::handle_close(handle, close_mask);
}



/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::handle_input
**
** Author      : pagibeault
** Date        : 3/29/00
**
** Return      : int 
** Argument    : ACE_HANDLE
** Purpose     : This method is called back automagicly by the reactor when 
**				       new data arives on TCP/IP socket
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::handle_input(ACE_HANDLE handle) 
{
  int iReturn = -1;

  try
  {
	  std::cout << "ACE_HANDLE on handle_input:[" << handle << "]" << std::endl;

    // Renew the timer when activity comes in
    if (0 != _timerid)
    {
      // Cancel the old timer
      reactor()->cancel_timer(_timerid);
      // Schedule a new one
      std::cout << "Scheduling timer: _timeout = " << _timeout << std::endl;
      _timerid = reactor()->schedule_timer(this, &_timerid, ACE_Time_Value(_timeout));
      std::cout << "New _timerid = " << _timerid << std::endl;
    }

    // Refetch the remote and local addresses
    _RemoteAddress = "";
    _LocalAddress = "";
    _RemoteAddressIP = "";
    _LocalAddressIP = "";
        
    OAString data;
    if (peer().get_handle() != ACE_INVALID_HANDLE)
    {
      // Read the data in the socket
      data = ReadFromSocket();

      if (data.empty())
      {
		  std::cerr << _RemoteAddressIP << " Returned no Data.  Closing socket." << std::endl;  // The close is actually done returning -1 from this method.
      }
      else
      {
		std::cout << "Data:[" << data << "]" << std::endl;
		send(data);
        iReturn = 0;
      }
    }
	else
	{
        std::cerr << _RemoteAddressIP << " Invalid Handle.  Closing socket." << std::endl;  
	}    
  }
  catch(const std::exception& e )
  {
	  std::cerr << "Caught std::exception" << e.what() << std::endl;
  }
  return iReturn;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::handle_timeout
**
** Author      : pagibeault
** Date        : 11/27/2007
**
** Return      : int 
** Argument    :  const ACE_Time_Value& tv
** Argument    : const void* arg
** Purpose     : Called by Reactor when a related timeout occurs.
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::handle_timeout( const ACE_Time_Value& tv, const void* arg )
{
	OAString sMsg = "Connection Timeout: " + GetRemoteAddress();
	std::cout << sMsg << std::endl;    

	OAString sConnectionPair = GetName() + "/" + GetRemoteAddress();

	std::cerr << "Timeout" << std::endl;
	close_socket();
	return 0;
}



/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::GetName const
**
** Author      : pagibeault
** Date        : 6/3/02
**
** Return      : const OAString& 
** Purpose     : 
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
const OAString tcpAcceptorHandler::GetName() const
{
  return _name;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::GetLocalAddress
**
** Author      : pagibeault
** Date        : 6/19/02
**
** Return      : const OAString& 
** Argument    : int iUseName
** Purpose     : 
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
const OAString tcpAcceptorHandler::GetLocalAddress()
{
  OAString sReturn;
  
  if ("" == _LocalAddressIP)
  {
    char pcAddr[MAXADDRESS];
    ACE_INET_Addr newaddr;
    peer().get_local_addr(newaddr);
    newaddr.addr_to_string(pcAddr,MAXADDRESS,1);
    _LocalAddressIP = pcAddr;
  }
  sReturn = _LocalAddressIP;
  
  return sReturn;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::GetRemoteAddress
**
** Author      : pagibeault
** Date        : 6/19/02
**
** Return      : const OAString& 
** Argument    : int iUseName
** Purpose     : 
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
const OAString tcpAcceptorHandler::GetRemoteAddress()
{
  OAString sReturn;
  
  if ("" == _RemoteAddressIP)
  {
    char pcAddr[MAXADDRESS];
    ACE_INET_Addr newaddr;
    peer().get_remote_addr(newaddr);
    newaddr.addr_to_string(pcAddr,MAXADDRESS,1);
    _RemoteAddressIP = pcAddr;
  }
  sReturn = _RemoteAddressIP;
  
  return sReturn;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::send
**
** Author      : pagibeault
** Date        : 6/3/02
**
** Return      : int 
** Argument    : const OAString& inData
** Purpose     : 
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::send(const OAString& inData)
{
  OAString sConnectionPair = GetName() + "/" + GetRemoteAddress();

  // Renew the timer when messages are sent
  if (0 != _timerid)
  {
    // Cancel the old timer
    reactor()->cancel_timer(_timerid);
    // Schedule a new one
    std::cout << "Scheduling timer: _timeout = " << _timeout << std::endl;
    _timerid = reactor()->schedule_timer(this, &_timerid, ACE_Time_Value(_timeout));
    std::cout << "New _timerid = " << _timerid << std::endl;
  }
  
  // Send the text
  size_t iBytesSent = peer().send_n(inData.c_str(), inData.length(), 0);
  std::cout << "Sent " << iBytesSent << " Bytes of " << inData.length() << " Byte Message to " << sConnectionPair << std::endl;
  
  // Make sure entire message was sent
  if (0 > iBytesSent || (signed int)(inData.length()) != iBytesSent)
  {
    std::cerr << "Failed to send complete message: " << iBytesSent << " of " << inData.length() << " Bytes Sent to " << sConnectionPair << std::endl;
  }

  return iBytesSent;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::close_socket
**
** Author      : pagibeault
** Date        : 6/3/02
**
** Return      : int 
** Purpose     : 
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
int tcpAcceptorHandler::close_socket()
{
    
  // Set a reactor notify on this object, which will call handle_input when
  // all pending reactor notifications have been processed.  In handle_input
  // we try to read from this connection.  The read will return no data so 
  // the connection will be closed.
  ACE_Time_Value atv(1,0);
  if( -1 == ACE_Reactor::instance()->notify(this,ACE_Event_Handler::WRITE_MASK,&atv))
  {
    std::cerr << " ACE_Reactor::notify failed.  This connection may remain open." << std::endl;
  }
  
  return 0;
}


/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::FormatAddress
**
** Author      : pagibeault
** Date        : 6/20/02
**
** Return      : OAString 
** Argument    : const OAString& inAddress
** Purpose     : Format the address
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
OAString tcpAcceptorHandler::FormatAddress(const OAString& inAddress) const
{
  OAString  sFormattedAddress = inAddress;
  
  // Copy the address into a variable we can play with
  // we want to uppercase the address so it will match
  // all case permutations of localhost
  OAString sTempAddress = inAddress;
  
  OAString::size_type pos = sTempAddress.find("LOCALHOST");
  if (OAString::npos != pos)
  {
    // Get the name of the host we are running on
    char cHostname[1024] = {'\0'};
    if (-1 == ACE_OS::hostname(cHostname,MAXHOSTNAME))
    {
      std::cerr << "Unable to retrieve HostName" << std::endl;
    }
    
    // Replace 'Localhost' with the hostname
    sFormattedAddress = inAddress.substr(0,pos);    // use any prefix specified
    sFormattedAddress += cHostname;                 // use this hostname
    sFormattedAddress += inAddress.substr(pos + 9); // Use any suffix specified (9 = length of string 'Localhost')
    std::cout << "Using hostname [" << cHostname << "]" << std::endl;
  }
  
  return sFormattedAddress;
}

/*(*+*)*/
/*****************************************************************************
** Function    : tcpAcceptorHandler::ReadFromSocket
**
** Author      : pagibeault
** Date        : 3/29/00
**
** Return      : OAString 
** Purpose     : This method will return the data on the socket in a OAString
**				 without knowing the size of the data before hand
**
** History     : 
**
** Date           Programmer         History
** -------------- ------------------ -----------------------------------------
**
*****************************************************************************/
/*(*-*)*/
const OAString tcpAcceptorHandler::ReadFromSocket() const
{ 
  iovec inBuff;
  inBuff.iov_base = 0;
  OAString returnVal("");
  size_t recvd = 0;
  size_t recvd_total = 0;
  bool bContinue = true;
  
  ACE_Time_Value *timeVal = new ACE_Time_Value(0);
  
  
  while (bContinue)
  {
    // Re-Initialize inBuff
    if ( inBuff.iov_base )
    {
      delete [] inBuff.iov_base;
      inBuff.iov_base = 0;
      inBuff.iov_len = 0;
    }
    
    // peer() returns a pointer to the underlying SOCK_Stream
    recvd = peer().recvv(&inBuff, timeVal);
    if (-1 == recvd || 0 == recvd)
    {
      std::cout << "Nothing to read" << std::endl;
      bContinue = false;
    }
    else
    {
      if (recvd != (int)inBuff.iov_len)
      {
        std::cerr << "Contradiction! peer.recvv returned: " << recvd << " and inBuff.iov_len is: " << inBuff.iov_len << std::endl;
        recvd_total += inBuff.iov_len;
      }
      else
      {
        recvd_total += recvd;
      }
      
      returnVal.append(OAString((char*)inBuff.iov_base, inBuff.iov_len));
      std::cout << "Received " << recvd_total << " Bytes of data from " << _RemoteAddressIP << std::endl;
    }
  }
  
  delete timeVal;
  return returnVal;
}


