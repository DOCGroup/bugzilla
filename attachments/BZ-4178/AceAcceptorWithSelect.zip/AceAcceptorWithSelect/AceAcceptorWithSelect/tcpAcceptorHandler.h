#if !defined(tcpAcceptorHANDLER_H)
#define tcpAcceptorHANDLER_H

#include <ace/Svc_Handler.h>
#include <ace/Synch.h>
#include <ace/SOCK_Acceptor.h>

//Type definitions
typedef std::string OAString;
typedef ACE_Svc_Handler<ACE_SOCK_STREAM,ACE_NULL_SYNCH> SUPER;

const int MAXADDRESS  = 255;
const int MAXHOSTNAME = 255;


class tcpAcceptorHandler : public SUPER
{
public:
	// Service Object Constructor/Destructor
	tcpAcceptorHandler();  
	virtual ~tcpAcceptorHandler();

	// This method is called back automagicly by the reactor when 
	// a TCP/IP connection has been established
	virtual int open(void* p = 0);

	// This method is called back automagicly by the reactor when 
	// new data arives on TCP/IP socket
	virtual int handle_input(ACE_HANDLE fd = ACE_INVALID_HANDLE);

	// Called by the reactor when the method handle_input returns -1
	virtual int handle_close(ACE_HANDLE handle, ACE_Reactor_Mask close_mask);

	// Called by Reactor when a related timeout occurs.
	virtual int handle_timeout( const ACE_Time_Value& tv, const void* arg );

	void SetName(const OAString& inName) {_name = inName;}

	// Interface inherited from ItcpHandler
	const OAString GetName() const;
	const OAString GetLocalAddress();
	const OAString GetRemoteAddress();
	int send(const OAString& inData);
	int close_socket();

protected:  
	// Format the address
	OAString FormatAddress(const OAString& inAddress) const;

	// This method will return the data on the socket in a string
	// without knowing the size of the data before hand
	const OAString ReadFromSocket() const;
	

	OAString _name;
	OAString _RemoteAddress;
	OAString _LocalAddress;
	OAString _RemoteAddressIP;
	OAString _LocalAddressIP;

	OAString _traceinstance;
	long      _timerid;
	int       _timeout;
};

#endif // !defined(tcpAcceptorHANDLER_H)
