#include <iostream> 
#include <ace/Reactor.h>

using namespace std;

class Mike : public ACE_Event_Handler
{
  public:
  virtual int  
  handle_timeout (const ACE_Time_Value &current_time, const void *act=0) 
  {
    cout << "Timeout" << endl;
    return 0;
  }
};

int main()
{
  cout << "hello world" << endl;

  Mike* m = new Mike;

  ACE_Reactor* reactor = ACE_Reactor::instance();
  reactor->schedule_timer(m, 
                          0, 
                          ACE_Time_Value(2,0), 
                          ACE_Time_Value(2,0));

  reactor->run_reactor_event_loop();

  return 0;
}

