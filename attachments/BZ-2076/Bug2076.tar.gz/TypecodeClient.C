// client.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp

#include "typecodeC.h"
#include "ace/Get_Opt.h"
#include "tao/TimeBaseC.h"
#include <iostream.h>
#include "tao/Messaging/Messaging_RT_PolicyC.h"

ACE_RCSID(Typecode, client, "client.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp")

const char *ior = "file://typecodeServer.ior";
int min_timeout = 0;
int max_timeout = 20;

using namespace TYPECODE;


bool findIor(CORBA::String_var & ior, const char* file)
{
    if (!file || !(*file))
	return 0;

    FILE *pFile = fopen(file, "rb");

    if (!pFile){
	cout << endl << "Could not open ior file!";
	return 0;
    }

    unsigned long ulLen = 10000;
    char* pszBuff = new char[ulLen];
    pszBuff[0] = '\0';
    ulLen = fread((void*)(pszBuff), 1, ulLen, pFile);
    cout << endl << "ior length: " << ulLen;
    pszBuff[ulLen] = '\0';

    ior = ((const char*)strstr(strtok(pszBuff, " \t\n\r"), "IOR:"));

    cout  << endl << "Using IOR: " << ior << endl;

    fclose(pFile);
    //delete [] pszBuff;

    return ulLen > 100UL;
}


int main (int argc, char* argv[])
{
  ACE_TRY_NEW_ENV
    {

      const char* iorFile = "/tmp/typecodeServer.ior";
      CORBA::String_var iorTypecodeServer;

      if ( !findIor(iorTypecodeServer, iorFile) )
      {
         cout << endl << "Could not read IOR file "
              <<  "typecodeServer.ior" << endl << flush;
         return 1;
      }

      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "");
      ACE_TRY_CHECK;

//        if (parse_args (argc, argv) != 0)
//          return 1;

      //JRo:
      CORBA::Object_var object =
        orb->string_to_object (iorTypecodeServer);
      ACE_TRY_CHECK;

      Typecode_Server_var server =
        Typecode_Server::_narrow (object.in ());
      ACE_TRY_CHECK;

      if (CORBA::is_nil (server.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Object reference <%s> is nil\n",
                             ior),
                            1);
        }

//        CORBA::TypeCode_ptr tmpTypeCode;
//        tmpTypeCode = orb->create_alias_tc("IDL:NWI3/SDH_TP/LoopType:1.0", //RepositoryID
//  					  "LoopType", // LoopType
//  					  CORBA::_tc_short);


      CORBA::Any any;
      CORBA::Any& rAny = any;

      LoopType  value = 42;

      any <<= value;
      any.type(_tc_LoopType);


      AttributeVal attrVal;
      attrVal.shortVal =  value;
      attrVal.laserModeVal = value;
      attrVal.anyVal  = any;

      server->sendRequest(attrVal, value, value);

      ACE_TRY_CHECK;


    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION, "Catched exception:");
      return 1;
    }
  ACE_ENDTRY;
  return 0;
}
