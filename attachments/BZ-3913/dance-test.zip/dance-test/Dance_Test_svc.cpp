#include "Dance_Test_svc.h"
#include <iostream>


int
Dance_Test_svc::init (int argc, ACE_TCHAR *argv[])
{
  std::cerr<<"Inside init..............."<<std::endl; 
  this->orb_ = ::CORBA::ORB_init (argc, argv, "DANCE");
  return 0;
}

int Dance_Test_svc::fini (void)
{
  std::cerr<<"Inside fini..............."<<std::endl; 
  return 0;
}

//
// info
//
int Dance_Test_svc::info (ACE_TCHAR **str, size_t len) const
{
  std::cerr<<"Inside info..............."<<std::endl; 
  return 0;
}
