#include "ace/Service_Config.h"
#include "ace/Reactor.h"
#include "ace/Service_Object.h"
#include "Dance_Test_svc_export.h"
#include "tao/corba.h"


//class ACE_Svc_Export Dance_Test_svc : public ACE_Service_Object
class Dance_Test_svc_Export Dance_Test_svc : public ACE_Service_Object
{
  
public:
  //Dance_Test_svc (void);
  // Default constructor.

  virtual int init (int argc, ACE_TCHAR *argv[]);
  // Initialization hook.

  
  virtual int fini (void);

  /**
   * Provides information about the service bing configured
   */
  virtual int info (ACE_TCHAR **str, size_t len) const;

private:
	::CORBA::ORB_var orb_;

};

ACE_FACTORY_DEFINE (Dance_Test_svc, Dance_Test_svc)

