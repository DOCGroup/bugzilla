#include "..\OneWayClient_s.hh"

class OneWayClient: public POA_TestClient::OneWayTestClient
{
public:
	OneWayClient();
	virtual void CallTest(const char* Text);
};

