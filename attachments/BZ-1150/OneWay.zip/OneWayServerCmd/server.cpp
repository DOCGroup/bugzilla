#include "server.h"

extern CORBA::ORB_var m_Orb;

void OneWayServer::register_Client(TestClient::OneWayTestClient_ptr Client)
{
	try
	{
		m_Client = TestClient::OneWayTestClient::_duplicate(Client);
		printf("Client connected.\n");
	}
	catch(CORBA::Exception&)
	{
		printf("CORBA::Exception during connect.\n");
	}
}

void OneWayServer::SendToClient()
{
  static int Counter=0;
  try
  {
	if ( ! CORBA::is_nil(m_Client))
	{
	   char msg[250];
	   TestClient::a_seq_var my_seq;
	   CORBA::Long a_long;

	   sprintf(msg,"Send Message %u",Counter++);
	   m_Client->CallTest(msg);
	   printf("Send Message %u\r",Counter);
	}
//	if (Counter%500 == 0)
//		m_Client = NULL;
  }
  catch(CORBA::Exception& e)
  {
	printf("CORBA Excpetion on sending: %s\n",e._id());
	m_Client = NULL;
  }
  catch(...)
  {
	printf("catch all\n");
	m_Client = NULL;
  }
}

OneWayServer::OneWayServer(): POA_TestServer::OneWayTestServer()
{
}
