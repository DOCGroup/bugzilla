#include "..\OneWayServer_s.hh"
#include "..\OneWayClient_c.hh"

class OneWayServer: public POA_TestServer::OneWayTestServer
{
public:
	OneWayServer();
	virtual void register_Client(TestClient::OneWayTestClient_ptr _Client);
	void SendToClient();
protected:
	TestClient::OneWayTestClient_var	m_Client;
};


