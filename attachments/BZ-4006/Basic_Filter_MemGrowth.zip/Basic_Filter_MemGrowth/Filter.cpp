//$Id: Filter.cpp 91672 2010-09-08 18:44:58Z johnnyw $

#include "ace/Arg_Shifter.h"
#include "ace/Get_Opt.h"
#include "tao/debug.h"
#include "Filter.h"



Filter::Filter (void)
{
}

Filter::~Filter (void)
{
}

int
Filter::init (int argc, ACE_TCHAR* argv [])
{
  // Initialized the base class.
  Notify_Test_Client::init (argc,
                            argv);

  // Create all participents.
  this->create_EC ();

  CosNotifyChannelAdmin::AdminID adminid;

  this->supplier_admin_ =
    this->ec_->new_for_suppliers (this->ifgop_,
                                  adminid);

  ACE_ASSERT (!CORBA::is_nil (supplier_admin_.in ()));

  this->consumer_admin_ =
    this->ec_->new_for_consumers (this->ifgop_,
                                  adminid);

  ACE_ASSERT (!CORBA::is_nil (consumer_admin_.in ()));

  return 0;
}

void
Filter::run_test (void)
{
    if (TAO_debug_level)
        ACE_DEBUG ((LM_DEBUG, " Obtaining FilterAdmin interface from ConsumerAdmin\n"));

    CosNotifyFilter::FilterAdmin_var ca_filter_admin =
        CosNotifyFilter::FilterAdmin::_narrow (consumer_admin_.in ());

    for (unsigned int i = 0; i < 2500; i++) {
        this->run_filter_test (consumer_admin_.in ());  
    }

    this->ec_->destroy ();
}

void
Filter::run_filter_test (CosNotifyFilter::FilterAdmin_ptr filter_admin)
{
    if (TAO_debug_level)
        ACE_DEBUG ((LM_DEBUG, "Adding a filter\n"));

    CosNotifyFilter::FilterID id_1 = this->add_filter (filter_admin);

    this->verify_filter_count (filter_admin, 1);

    if (TAO_debug_level)
        ACE_DEBUG ((LM_DEBUG, "Calling remove_filter\n"));

    // remove the filter.
    filter_admin->remove_filter (id_1);

    this->verify_filter_count (filter_admin, 0);
}

void
Filter::verify_filter_count (CosNotifyFilter::FilterAdmin_ptr filter_admin, CORBA::ULong expected_count)
{
  expected_count = expected_count; // if we don;t do this, we get a warning on linux about arg not used.
  CosNotifyFilter::FilterIDSeq_var filter_seq = filter_admin->get_all_filters ();
  ACE_ASSERT (filter_seq->length () == expected_count);
}

CosNotifyFilter::FilterID
Filter::add_filter (CosNotifyFilter::FilterAdmin_ptr filter_admin)
{
  CosNotifyFilter::FilterFactory_var ffact = ec_->default_filter_factory ();

  CosNotifyFilter::Filter_var filter =
    ffact->create_filter ("ETCL");

  ACE_ASSERT (!CORBA::is_nil (filter.in ()));

  const char* test_filter_string = "A > B";

  CosNotifyFilter::ConstraintExpSeq constraint_list (1);
  constraint_list.length (1);

  constraint_list[0].event_types.length (0);
  constraint_list[0].constraint_expr = CORBA::string_dup (test_filter_string);

  filter->add_constraints (constraint_list);

  CosNotifyFilter::FilterID id = filter_admin->add_filter (filter.in ());

  // Print the ID
  if (TAO_debug_level)
    ACE_DEBUG ((LM_DEBUG, "Added Filter %d\n", id));

  return id;
}

void
Filter::create_EC (void)
{
  CosNotifyChannelAdmin::ChannelID id;

  this->ec_ = notify_factory_->create_channel (this->initial_qos_,
                                               this->initial_admin_,
                                               id);

  ACE_ASSERT (!CORBA::is_nil (ec_.in ()));
}

//***************************************************************************

int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  Filter events;

  if (events.parse_args (argc, argv) == -1)
    {
      return 1;
    }

  try
    {
      events.init (argc,
                   argv);

      events.run_test ();
    }
  catch (const CORBA::Exception& se)
    {
      se._tao_print_exception ("Error: ");
      return 1;
    }

  return 0;
}
