// -*- C++ -*-
// ORB_init.cpp,v 1.12 2004/09/05 16:36:20 ossama Exp
// Adapted by Jules Colding <colding@omesc.com>

#include "tao/ORB.h"
#include "tao/Object.h"
#include "tao/SystemException.h"

#include "ace/Log_Msg.h"

#include <string.h>
#include <stdlib.h>

ACE_RCSID (ORB_object_to_string,
           ORB_object_to_string,
           "ORB_object_to_string.cpp,v 1.0 2005/10/28 09:42:00  Jules Colding <colding@omesc.com>")

// Valid test IOR.
// Do not attempt to narrow the object represented by this IOR, nor
// should you modify the IOR unless you replace it with another
// valid one!
static const char IOR[] =
"IOR:010000001600000049444c3a43756269745f466163746f72793a312e30000000010000000000000090000000010102cd14000000616e647572696c2e6563652e7563692e6564750057fecdcd2d00000014010f004e5550000000130000000001000000006368696c645f706f61000000000001000000666163746f7279cdcdcd03000000000000000800000001cdcdcd004f4154010000001400000001cdcdcd01000100000000000901010000000000004f41540400000001cd0000";

static const char ORBIT2_IOR[] = 
"IOR:010000002600000049444c3a6f6d632e6272757475732f4252555455532f427275747573436865636b3a312e30000000040000000054424f580000000101020005000000554e495800000000100000006f6d632d322e6f6d6573632e636f6d00290000002f746d702f6f726269742d65766f2f6c696e632d313534642d302d343561373635656463306432640000000000000000000000004000000001010200100000006f6d632d322e6f6d6573632e636f6d003c8000001c00000000000000c080313dc3caa1c3462024c0964c4d0501000000e1b8086800000000caaedfba5400000001010200290000002f746d702f6f726269742d65766f2f6c696e632d313534642d302d34356137363565646330643264000000001c00000000000000c080313dc3caa1c3462024c0964c4d0501000000e1b8086801000000480000000100000002000000050000001c00000000000000c080313dc3caa1c3462024c0964c4d0501000000e1b8086801000000140000000100000001000105000000000901010000000000";


/*
 * This method will return an ORB which is initialized 
 * to potentially trigger the bug.
 *
 * argc and argv are command line arguments with other
 * options that must be given to the ORB in ORB_init().
 *
 * argc                  : ORB command line argument count
 *
 * argv                  : ORB command line arguments
 *
 * orb_name              : Name of return ORB or empty string
 *
 * Return value          : Initialized ORB or CORBA::ORB::_nil()
 *
 */
CORBA::ORB_ptr 
create_orb (int argc,
	    char **argv,
	    const char *orb_name)
{
	// sanity checks
	if (!argc)
		return CORBA::ORB::_nil();
	if (!*argv)
		return CORBA::ORB::_nil();
	if (!orb_name)
		return CORBA::ORB::_nil();
	
	CORBA::ORB_var orb = CORBA::ORB::_nil();
	int init_argc = argc + 2;
	char **init_argv = (char**)malloc (sizeof(char*) * (init_argc));
	if (!init_argv)
		return CORBA::ORB::_nil();
	memset ((void*)init_argv, 0, init_argc);

	// copy the original arguments
	memcpy ((void*)init_argv, (void*)argv, sizeof(char*) * (argc));

	init_argv[argc] = "-ORBObjRefStyle";
	init_argv[argc+1] = "URL";

	// initialize the ORB
        orb = CORBA::ORB_init (init_argc, init_argv, orb_name);

	free(init_argv);

	return orb._retn();
}

int
main (int argc, char *argv[])
{
	CORBA::ORB_var orb;

	ACE_DECLARE_NEW_CORBA_ENV;
	ACE_TRY
		{
			const char orbid[] = "mighty_orb";
			CORBA::String_var object_ref_str = "";

			orb = create_orb (argc, argv, orbid);

			// --------------------------------------------------------
			// Create an object (but don't narrow() it) so we can test
			// that we can stringify it later
			// --------------------------------------------------------

			CORBA::Object_var object = orb->string_to_object (IOR ACE_ENV_ARG_PARAMETER);
			ACE_TRY_CHECK;
			object_ref_str = orb->object_to_string (object.in() ACE_ENV_ARG_PARAMETER);
			ACE_TRY_CHECK;
			if (NULL == object_ref_str.in()) {
				ACE_DEBUG ((LM_ERROR,
					    "\n"
					    "ORB_object_to_string test failed with TAO test IOR.\n"));
				return 1;
			} else {
				ACE_DEBUG ((LM_INFO,
					    "\n"
					    "ORB_object_to_string test passed with TAO test IOR."));
			}

			object = orb->string_to_object (ORBIT2_IOR ACE_ENV_ARG_PARAMETER);
			ACE_TRY_CHECK;
			object_ref_str = orb->object_to_string (object.in() ACE_ENV_ARG_PARAMETER);
			ACE_TRY_CHECK;
			if (NULL == object_ref_str.in()) {
				ACE_DEBUG ((LM_ERROR,
					    "\n"
					    "ORB_object_to_string test failed with ORBit2 test IOR.\n"));
				return 1;
			} else {
				ACE_DEBUG ((LM_INFO,
					    "\n"
					    "ORB_object_to_string test passed with ORBit2 test IOR."));
			}

		}
	ACE_CATCHANY
		{
			ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
					     "Caught unexpected exception:");
			ACE_DEBUG ((LM_ERROR,
				    "\n"
				    "ORB_object_to_string test failed.\n"));
			return 1;
		}
	ACE_ENDTRY;

	ACE_DEBUG ((LM_INFO,
		    "\n"
		    "ORB_object_to_string test completed successfully.\n"));

	return 0;
}
