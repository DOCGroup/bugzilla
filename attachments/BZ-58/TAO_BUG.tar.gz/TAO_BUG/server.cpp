#include <iostream>

#include "TestServer_i.h"

int
main (int argc, char *argv[])
{
  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      CORBA::ORB_var orb = CORBA::ORB_init (argc,
                                            argv,
                                            "server orb",
                                            ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::Object_var obj =
        orb->resolve_initial_references ("RootPOA",
                                         ACE_TRY_ENV);
      ACE_TRY_CHECK;

      PortableServer::POA_var poa =
        PortableServer::POA::_narrow (obj.in(),
                                      ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (poa.in ()))
        {
          std::cerr << "poa is nil" << endl;
          return -1;
        }

      PortableServer::POAManager_var mgr =
        poa->the_POAManager (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      mgr->activate (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      TestServer_i tsrv_i;

      TestServer_var tsrv_v = tsrv_i._this (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::String_var str = orb->object_to_string (tsrv_v.in (),
                                                     ACE_TRY_ENV);
      ACE_TRY_CHECK;

      std::cout << str.in () << endl;

      orb->run (ACE_TRY_ENV);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Caught exception: ");

      return -1;
    }
  ACE_CATCHALL
    {
      std::cerr << "unexpected exception caught" << endl;
      return -1;
    }
  ACE_ENDTRY;

  return 0;
}
