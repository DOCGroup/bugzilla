#include <iostream>
#include <string>
#include "TestServer_i.h"

TestServer_i::TestServer_i (void)
{
}

TestServer_i::~TestServer_i (void)
{
}

void
TestServer_i::SayKnockKnock (const char * s1,
                             const char * s2,
                             int,
                             const char * s3,
                             CORBA::Environment &)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  const std::string str1 = s1;
  const std::string str2 = s2;
  const std::string str3 = s3;

  std::cerr << "KnockKnock" << endl;
}
