// -*- C++ -*-

#include "TestServerS.h"

class TestServer_i : public virtual POA_TestServer
{
public:
  TestServer_i (void);
  ~TestServer_i (void);

  virtual void SayKnockKnock (const char * s1,
                              const char * s2,
                              int l,
                              const char * s3,
                              CORBA::Environment &ACE_TRY_ENV =
                                TAO_default_environment ())
    ACE_THROW_SPEC ((CORBA::SystemException));
};
