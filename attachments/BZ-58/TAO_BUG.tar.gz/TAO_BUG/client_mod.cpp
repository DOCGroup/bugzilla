#include <iostream>
#include "TestServer_modC.h"

int
main (int argc, char *argv[])
{
  if (argc != 2) {
    std::cerr << "usage: " << argv[0] << " <server IOR>" << endl;
    return -1;
  }

  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
      CORBA::ORB_var orb = CORBA::ORB_init (argc,
                                            argv,
                                            "client_mod orb",
                                            ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::Object_var obj =
        orb->string_to_object (argv[1],
                               ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (obj.in ()))
        {
          std::cerr << "Nil reference" << endl;
          return -1;
        }

      TestServer_var tsrv_v = TestServer::_narrow (obj.in (),
                                                   ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (tsrv_v.in ()))
        {
          std::cerr << "Nil TestServer reference" << endl;
          return -1;
        }

      tsrv_v->SayKnockKnock ("param0",
                             12,
                             "param3",
                             ACE_TRY_ENV);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Caught exception: ");
      return -1;
    }
  ACE_CATCHALL
    {
      std::cerr << "unexpected exception caught" << endl;
      return -1;
    }
  ACE_ENDTRY;

  return 0;
}
