#include "QMgrS.h"
#include "QMgrC.h"

#include "resolve.h"

#include "orbsvcs/orbsvcs/CosNamingC.h"
#include <ace/Thread_Semaphore.h>
#include "tao/Messaging/Messaging.h"
#include "tao/PortableServer/PortableServer.h"
#include "tao/AnyTypeCode/TAOA.h"
#include <ace/ARGV.h>

#include <sstream>
#include <stdexcept>
#include <vector>

class Receiver;
class Test
{
public:
	Test( CORBA::ORB_ptr orb )
		: m_orb(orb),
		  m_receiver(0),
		  m_receiverThread(0),
		  m_receiverThreadRunning(false)
	{
	}

	enum ReceiverFlags { // bitfield
		AbortAfterOne = 0x01, // throw Abort when receiving 2nd message, to test rollbacks
		StopOrbOnExit = 0x04, // shutdown orb after "exitAfter" messages received
		ReceiverBusy = 0x10, // sleep in get
		ReceiverInThread = 0x20 // receiver is in a separate thread
	};

	void setup();
	void teardown();
	void testPutTen();
	void testReceiverBusy(int);

	CORBA::ORB_ptr orb() {
		return m_orb;
	}
private:
	void putMessage(int);
	void initReader();
	static void *runReceiverThread(void *);

	QMgr::Reader_var m_reader;

	CORBA::ORB_ptr m_orb;
	Receiver* m_receiver;
	pthread_t m_receiverThread;
	bool m_receiverThreadRunning;
	int m_receiverThreadTotalMessages;
};

Test *test;

class Receiver : public virtual POA_QMgr::Reader
{
public:
	Receiver(CORBA::ORB_ptr orb, int exitAfter, unsigned int receiverFlags)
		: m_messageNumber(0), m_exitAfter(exitAfter), m_receiverFlags(receiverFlags),
		  m_messageReceived(0), m_wakeUpReceiver(0), m_orb(orb)
	{
		// Outputting messages to a file instead of a shared memory buffer
		// makes debugging slightly easier.
		std::ostringstream strm; strm << "received";
		m_outFile = ACE_OS::fopen (strm.str().c_str(), "a");
		if (m_outFile == 0)
			throw (0);

		// Register it
		PortableServer::POA_var poa = ::resolve_init<PortableServer::POA>(orb, "RootPOA");
		PortableServer::POAManager_var mgr = poa->the_POAManager();
		if( mgr->get_state() != PortableServer::POAManager::ACTIVE )
			mgr->activate();
		PortableServer::ObjectId_var oid = poa->activate_object( this );
		CORBA::Object_var obj = poa->id_to_reference( oid.in() );
		CosNaming::NamingContext_var ns = ::resolve_init<CosNaming::NamingContext>(
			orb, "NameService");
		CosNaming::Name n;
		n.length(1);
		n[0].id = CORBA::string_dup("_QUEUES");
		try
		{
			ns->bind_new_context(n);
		}
		catch(const CosNaming::NamingContext::AlreadyBound &) { } // already bound
		n.length(2);
		n[1].id = CORBA::string_dup("TEST");
		ns->rebind(n,obj.in());
		ACE_DEBUG((LM_DEBUG, "Object installed into NamingService with %s / %s\n", n[0].id.in(), n[1].id.in() ));
	}

	ACE_Thread_Semaphore& messageReceived() { return m_messageReceived; }
	ACE_Thread_Semaphore& wakeUpReceiver() { return m_wakeUpReceiver; }

	// Reader interface
	void notify ( const char *seqnum, const char *message ACE_ENV_ARG_DECL )
		ACE_THROW_SPEC (( CORBA::SystemException ))
	{
		ACE_UNUSED_ARG( seqnum );

		if (m_outFile == 0) { // this happened when we didn't throw an exception below
			ACE_DEBUG((LM_WARNING, "WARNING: get() was called even after the ORB was stopped\n"));
			return;
		}
		ACE_DEBUG(( LM_DEBUG, ACE_TEXT("%I %M %D Thread %t %N:%l notify(%s) called\n"), message ));

		if ( m_exitAfter-- == 0 ) {
			if ( m_receiverFlags & Test::StopOrbOnExit ) {
				ACE_OS::fclose( m_outFile );
				m_outFile = 0;
				ACE_DEBUG((LM_DEBUG,"Got all messages, stopping orb\n"));
				if ( m_receiverFlags & Test::ReceiverInThread )
				{
					m_orb->shutdown();
				}
				return; // stop processing messages, and exit worker thread
			} else {
				ACE_DEBUG((LM_DEBUG,"Got all messages\n"));
				// The other Receiver will call stopOrb and exit the worker thread
				return;
			}
		}
		if ( m_exitAfter < 0 )
			ACE_DEBUG((LM_DEBUG,"Huh? Got more messages than expected!\n"));

		if ( m_receiverFlags & Test::ReceiverInThread ) {
			m_messageReceived.release(); // signal main thread
		}

		// log to output file
		fputs( (std::string(message) + "\n").c_str(), m_outFile );
		fflush( m_outFile );

		if ( ++m_messageNumber == 2 && ( m_receiverFlags & Test::ReceiverBusy ) ) {
			ACE_DEBUG((LM_DEBUG, "%t Sleeping receiver thread until wakeup\n"));
			m_wakeUpReceiver.acquire();
			ACE_DEBUG((LM_DEBUG, "%t Waking up\n"));
		}
	}
	// Reader interface
	void ping() throw (CORBA::SystemException) { // unused at this point
		ACE_DEBUG(( LM_DEBUG, ACE_TEXT("%I %M %D Thread %t %N:%l ping()\n") ));
	}

private:
	int m_messageNumber;
	int m_exitAfter;
	unsigned int m_receiverFlags;
	FILE * m_outFile;
	ACE_Thread_Semaphore m_messageReceived;
	ACE_Thread_Semaphore m_wakeUpReceiver;
	CORBA::ORB_ptr m_orb;
};

void Test::setup()
{
	ACE_DEBUG((LM_DEBUG,"setup()\n"));
	ACE_OS::unlink("received");
}

void Test::teardown() {
	ACE_DEBUG((LM_DEBUG,"teardown()\n"));
	delete m_receiver; m_receiver = 0;
}

// returns the contents of the file named "received"
static std::vector<std::string> readFile()
{
	std::ostringstream strm; strm << "received";
	FILE* f = ACE_OS::fopen (strm.str().c_str(), "r");
	assert(f);
	char buf[1000];

	std::vector<std::string> lines;
	while ( fgets( buf, 999, f ) ) {
		lines.push_back( std::string(buf) );
	}

	ACE_OS::fclose(f);
	return lines;
}

static void checkFile( unsigned int expectedNum )
{
	std::vector<std::string> lines = readFile();
	if (lines.size() != expectedNum) {
		ACE_DEBUG((LM_ERROR, "Expected %d lines, got %d\n", expectedNum, lines.size()));
		assert(lines.size() == expectedNum);
	}
	std::ostringstream strm;
	for ( unsigned int i = 0; i < expectedNum; ++i ) {
		strm.str("");
		strm << "m" << (i+1) << "\n"; // "m1\n", "m2\n" etc.
		assert(lines[i] == strm.str());
	}
	ACE_DEBUG((LM_DEBUG, "checkFile(%d): OK.\n", expectedNum ));
}

void Test::initReader()
{
	// look up _QUEUES/queueName and store
	m_reader = ::resolve<QMgr::Reader>(m_orb, "_QUEUES", "TEST");
	if( !CORBA::is_nil(m_reader.in()) ) {
		m_reader->ping(); // ### missing exception handling
		ACE_DEBUG((LM_DEBUG, "found running\n"));
	} else {
		ACE_DEBUG((LM_DEBUG, "not found\n"));
		abort();
	}
}

void Test::testPutTen()
{
	ACE_DEBUG((LM_DEBUG,"======================== testPutTen()\n"));
	setup();

	// set up handling of incoming messages
	assert( !m_receiver );
	m_receiver = new Receiver(m_orb, 10, StopOrbOnExit);
	initReader();

	int numMsg = 11 /*one more, since the last one makes Receiver abort*/;
	for ( int i = 0; i < numMsg; ++i )
		putMessage( i+1 );

	// All in process now, so all received before we get here.
	//runOrb();
	checkFile(10);
	teardown();
}

// Set up a few orb settings we use in our project; doesn't make a difference though.
static void initOrbArgs( ACE_ARGV& orbArgs ) {
	// add "-ORBCollocation per-orb"
	orbArgs.add( "-ORBCollocation" );
	orbArgs.add( "per-orb" );
	// add RW for no reentrancy
	orbArgs.add( "-ORBSvcConfDirective" );
	orbArgs.add( "'static Client_Strategy_Factory \"-ORBClientConnectionHandler RW\"'" );
	// and blocking connect
	orbArgs.add( "-ORBSvcConfDirective" );
	orbArgs.add( "'static Client_Strategy_Factory \"-ORBConnectStrategy blocked\"'" );
}

void* Test::runReceiverThread(void*p)
{
	ACE_DEBUG((LM_DEBUG, "Thread %t created\n"));
	Test* _this = (Test *)p;

	ACE_ARGV orbArgs;
	initOrbArgs( orbArgs );
	int orb_argc = orbArgs.argc();
	ACE_TCHAR** orb_argv = orbArgs.argv();

	//std::cerr << "initialize ORB for receiver thread with arguments >";
	//for(int i=0;i<orb_argc;++i)
	//	std::cerr << "'" << orb_argv[i] << "' "; // use \n for debugging, to separate the args
	//std::cerr << "< " << std::endl;

	std::ostringstream orbName;
	orbName << (unsigned long) pthread_self();
	CORBA::ORB_var orb = CORBA::ORB_init( orb_argc, orb_argv, orbName.str().c_str() );
	assert( orb.in() != _this->m_orb );

	ACE_DEBUG((LM_DEBUG,"%t Thread ORB ready\n"));

	assert( !_this->m_receiver );
	_this->m_receiver = new Receiver(orb.in(), _this->m_receiverThreadTotalMessages,
									 ReceiverBusy | ReceiverInThread | StopOrbOnExit);

	_this->m_receiverThreadRunning = true;

	ACE_DEBUG((LM_DEBUG,"%t Receiver thread running ORB loop\n"));

	orb->run();

	ACE_DEBUG((LM_DEBUG,"%t run returned\n"));
	delete _this->m_receiver; _this->m_receiver = 0;
	orb->destroy();
	_this->m_receiverThreadRunning = false;

	ACE_DEBUG((LM_DEBUG,"%t thread finished\n"));
	return 0;
}

void Test::putMessage(int msgNum)
{
	assert( m_reader.in() );
	std::ostringstream strm;
	static int messageNumber = 0;
	strm << messageNumber++;
	std::ostringstream msgstrm;
	msgstrm << "m" << msgNum;
	std::string msg = msgstrm.str();
	ACE_DEBUG(( LM_DEBUG, "putMessage(%s): Calling notify...\n", msg.c_str() ));
	m_reader->notify(CORBA::string_dup(strm.str().c_str()),
					 CORBA::string_dup(msg.c_str()));
	ACE_DEBUG(( LM_DEBUG, "putMessage(%s): Done calling notify.\n", msg.c_str() ));
}

// Check if the oneways (for qmgr notification) are blocked by a busy receiving thread.
// Result: they block indeed, when the transport queue is full (happens after 1263 messages here),
// and DIOP fixes that. But DIOP breaks the twoway ping().
void Test::testReceiverBusy( int totalNrMessages )
{
	ACE_DEBUG((LM_DEBUG,"======================== testReceiverBusy(%d)\n", totalNrMessages));
	m_receiverThreadTotalMessages = totalNrMessages;
	setup();

	if( pthread_create(&m_receiverThread, 0, runReceiverThread, this) )
		throw std::logic_error("Could not create thread");

	while ( !m_receiverThreadRunning ) { // wait for creation and nameservice registration of receiver
		ACE_DEBUG((LM_DEBUG, "Waiting for thread to be ready...\n" ));
		sleep( 1 );
	}
	initReader();
	putMessage(1); // first one to check that message can be received by thread
	m_receiver->messageReceived().acquire(); // wait for message received
	checkFile(1); // check that message was received
	putMessage(2);
	m_receiver->messageReceived().acquire(); // wait for 2nd message received
	checkFile(2);
	// Now the thread is sleeping. Put all the other messages.
	for ( int i = 3; i <= totalNrMessages; ++i )
		putMessage(i);
	checkFile(2); // still only got two messages, the thread was sleeping, and we were not blocked.
	putMessage( 123456 /*one more, since the last one makes Receiver abort*/);
	ACE_DEBUG((LM_DEBUG, "Waiting for receiver thread...\n" ));
	m_receiver->wakeUpReceiver().release(); // get the thread running again

	// Wait for receiver thread to terminate
	void * v;
	pthread_join(m_receiverThread, &v);

	checkFile(totalNrMessages);
	teardown();
}

// The oneway notifications that we need, must use "always queue, never flush, never block" so that the sender never blocks.
// But I haven't found a way to do that; see below.

static void setup_buffering_constraints(CORBA::ORB_ptr orb)
{
  // Obtain PolicyCurrent.
  CORBA::Object_var object = orb->resolve_initial_references ("PolicyCurrent"
                                                              ACE_ENV_ARG_PARAMETER);
  ACE_CHECK;
  CORBA::PolicyCurrent_var policy_current =
    CORBA::PolicyCurrent::_narrow (object.in ()
                                   ACE_ENV_ARG_PARAMETER);
  ACE_CHECK;

  // Setup the none sync scope policy, i.e., no blocking when sending
  // It doesn't work though.
  //  Messaging::SYNC_NONE makes TAO_Stub::transport_queueing_strategy get has_synchronization==false,
  // which makes it return the default transport queueing strategy, which says false to must_queue,
  // so the message is sent right away and we block when the queue is full.
  // ## Also, it crashes with tao-1.5 !?!?
  // ## And with 1.5.4, notify() is never called in the thread!?

  // New attempt: TAO::SYNC_DELAYED_BUFFERING. But it doesn't work either. We still get to try_sending_first=true...
  // (the queue is empty, as far as TAO can see, and the delayed transport queueing strategy is "queue it unless the queue is empty"

  // Also tried TAO::SYNC_EAGER_BUFFERING, but it seems to be exactly the same as SYNC_NONE.
  //
  // And not calling setup_buffering_constraints at all shows the standard behavior: blocks after 1446 messages.

  Messaging::SyncScope syncScope = TAO::SYNC_DELAYED_BUFFERING;
  CORBA::Any syncScope_any;
  syncScope_any <<= syncScope;

  // Setup the sync scope policy list.
  CORBA::PolicyList syncScope_policy_list (1);
  syncScope_policy_list.length (1);

  // Setup the sync scope policy.
  syncScope_policy_list[0] =
    orb->create_policy (Messaging::SYNC_SCOPE_POLICY_TYPE,
                        syncScope_any
                        ACE_ENV_ARG_PARAMETER);

  // Setup the none sync scope (at the ORB level).
  policy_current->set_policy_overrides (syncScope_policy_list,
                                        CORBA::ADD_OVERRIDE
                                        ACE_ENV_ARG_PARAMETER);

  // We are now done with these policies.
  syncScope_policy_list[0]->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
}

int
main(int argc, char *argv[])
{
	try
	{
		ACE_ARGV orbArgs;
		initOrbArgs( orbArgs );
		// copy cmdline args
		for (int i = 0; i < argc; ++i) {
			if (orbArgs.add(argv[i]) == -1)
				return 1;
		}

		int orb_argc = orbArgs.argc();
		ACE_TCHAR** orb_argv = orbArgs.argv();

		CORBA::ORB_var orb = CORBA::ORB_init(orb_argc, orb_argv);

		setup_buffering_constraints( orb.in() );

		test = new Test( orb.in() );

		// Basic test without using threads: calling ping+notify in the same thread.
		test->testPutTen();
		// Test sending 100 messages to a busy receiver: no problem
		test->testReceiverBusy(100);
		// Test sending 2000 messages to a busy receiver: at some point we get stuck
		test->testReceiverBusy(2000);

		delete test;
		ACE_DEBUG((LM_DEBUG,"All tests ok.\n"));

		orb->destroy();
	}
	catch(CORBA::SystemException &e)
	{
		std::cerr << "CORBA::SystemException: " << e._info() << std::endl;
	}
	return 0;
}
// EOF
