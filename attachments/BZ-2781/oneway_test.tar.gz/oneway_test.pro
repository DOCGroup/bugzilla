TEMPLATE = app
TARGET = oneway_test
INCLUDEPATH += .

# Qt3
CONFIG += console
# Qt4
CONFIG -= app_bundle

INCLUDEPATH += $(ACE_ROOT) $(TAO_ROOT) $(TAO_ROOT)/orbsvcs 
LIBS += -L$(TAO_ROOT)/tao  -L$(ACE_ROOT)/ace -L$(ACE_ROOT)/lib

CONFIG += debug
CONFIG -= qt

macx {
   QMAKE_LFLAGS_SHAPP = -bind_at_load
   LIBS += -lSystem -lTAO_Svc_Utils -lTAO_IORTable -lTAO_CosNaming
   debug:QMAKE_CXXFLAGS += -g3 -O0
   debug:QMAKE_LFLAGS_SHAPP += -g3
}

LIBS += -L$(TAO_ROOT)/orbsvcs/orbsvcs \
		-L$(TAO_ROOT)/tao/PortableServer \
		-L$(TAO_ROOT)/tao/BiDir_GIOP \
		-L$(TAO_ROOT)/tao/Messaging \
		-L$(TAO_ROOT)/tao/IORTable \
		-L$(TAO_ROOT)/tao/DynamicInterface
LIBS += -lTAO_DynamicInterface -lTAO_Messaging -lTAO_BiDirGIOP -lTAO_PortableServer -lTAO_CosNaming -lTAO -lACE  -lstdc++
LIBS += -lTAO_Valuetype -lTAO_IORTable
exists( $(ACE_ROOT)/lib/libTAO_PI.dylib ) {
	LIBS += -lTAO_PI -lTAO_CodecFactory -lTAO_AnyTypeCode
}

HEADERS += QMgr.h
# note: IDL generated files first
SOURCES += \
	.gen/QMgrC.cpp \
	.gen/QMgrS.cpp \
	oneway_test.cpp \

include( .idl-qmake )
