#ifndef RESOLVE_H
#define RESOLVE_H

//   Source code used here has been modified and adapted from the code
//   provided in the book, "Advanced CORBA Programming with C++" by Michi
//   Henning and Steve Vinoski. Copyright 1999. Addison-Wesley, Reading,
//   MA.

#include <iostream>
#include "orbsvcs/orbsvcs/CosNamingC.h"

// helper function
template<class T> typename T::_ptr_type resolve_init(CORBA::ORB_ptr orb, const char *id)
{
	CORBA::Object_var obj;
	try
	{
		obj = orb->resolve_initial_references(id);
	}
	catch(const CORBA::ORB::InvalidName &)
	{
		throw;
	}
	catch(const CORBA::Exception &e)
	{
		std::cerr << "Cannot get initial reference for " << id << ": " << e << std::endl;
		throw 0;
	}
	assert( !CORBA::is_nil(obj.in()) );

	typename T::_var_type ref;
	try
	{
		ref = T::_narrow(obj.in());
	}
	catch(const CORBA::Exception &e)
	{
		std::cerr << "Cannot narrow reference for " << id << ": " << e << std::endl;
		throw 0;
	}
	if( CORBA::is_nil(ref.in()) )
	{
		std::cerr << "Incorrect type of reference for " << id << std::endl;
		throw 0;
	}
	return ref._retn();
}

// Usually you'll want to use resolve<Type> instead.
static CORBA::Object_ptr resolveHelper(CORBA::ORB_ptr orb, const char* s1, const char* s2)
{
	CORBA::Object_var obj;

	CosNaming::NamingContext_var ns = resolve_init<CosNaming::NamingContext>(
		orb, "NameService");
	assert( !CORBA::is_nil(ns.in()) );

	CosNaming::Name n;
	n.length(2);
	n[0].id = CORBA::string_dup(s1);
	n[1].id = CORBA::string_dup(s2);

	obj = ns->resolve(n);

	return obj._retn();
}

// Same functionality as resolve(), but includes the narrow-to-specific-type call
// and catching+printing out of exceptions
template<class T> typename T::_ptr_type resolve(CORBA::ORB_ptr orb, const char* s1, const char* s2)
{
	typename T::_var_type ref = 0;
	try
	{
		CORBA::Object_var obj = resolveHelper( orb, s1, s2 );
		ref = T::_narrow( obj.in() );
	}
	catch(const CORBA::Exception &e)
	{
		std::cerr << "couldn't resolve " << s1 << " / " << s2 << std::endl;
		return 0;
	}
	return ref._retn();
}

#endif /* RESOLVE_H */
