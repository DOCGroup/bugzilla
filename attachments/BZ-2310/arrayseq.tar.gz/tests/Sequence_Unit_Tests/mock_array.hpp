#ifndef guard_mock_array_hpp
#define guard_mock_array_hpp
#include /**/ "ace/pre.h"
/**
 * @file
 *
 * @brief Mock an IDL-generated array
 *
 * $Id$
 *
 * @author Carlos O'Ryan
 */
#include "testing_counters.hpp"

#include <algorithm>

typedef unsigned long my_array[5];
typedef unsigned long my_array_slice;
struct my_array_tag {};

namespace TAO
{

template<typename T, typename T_slice, typename TAG>
struct Array_Traits;

template<>
struct Array_Traits<my_array,my_array_slice,my_array_tag>
{
  static my_array_slice * alloc();
  static void free(my_array_slice * _tao_slice);
  static my_array_slice * dup(my_array_slice const * _tao_source);
  static void copy(
      my_array_slice * _tao_destination,
      my_array_slice const * _tao_source);

  // TODO This is a new function
  static void zero(
      my_array_slice * _tao_slice);

};

}

struct mock_array_traits
{
  typedef unsigned long underlying_type;
  typedef my_array value_type;
  typedef my_array const const_value_type;

  typedef my_array_slice slice_type;
  typedef my_array_tag TAG;

  inline static void zero_range(
      value_type * begin, value_type * end)
  {
    std::for_each(
        begin, end, &TAO::Array_Traits<value_type,slice_type,TAG>::zero);
  }

  inline static void initialize_range(
      value_type * begin, value_type * end)
  {
    std::for_each(
        begin, end, &TAO::Array_Traits<value_type,slice_type,TAG>::zero);
  }

  inline static void copy_range(
      value_type * begin, value_type * end, value_type *dst)
  {
    for(value_type * i = begin; i != end; ++i, ++dst)
    {
      TAO::Array_Traits<value_type,slice_type,TAG>::copy(*dst, *i);
    }
  }

  inline static void release_range(
      value_type * begin, value_type * end, value_type *dst)
  {
    std::for_each(
        begin, end, &TAO::Array_Traits<value_type,slice_type,TAG>::zero);
  }
};

#include /**/ "ace/post.h"
#endif // guard_mock_array_hpp
