#ifndef guard_unbounded_array_sequence_hpp
#define guard_unbounded_array_sequence_hpp
/**
 * @file
 *
 * @brief Implement unbounded sequences for arrays.
 *
 * $Id$
 *
 * @author Carlos O'Ryan
 */
#include "unbounded_value_allocation_traits.hpp"
#include "generic_sequence.hpp"

namespace TAO
{

template<typename array_traits>
class unbounded_array_sequence
{
public:
  typedef typename array_traits::value_type underlying_type;
  typedef typename array_traits::value_type * value_type;
  typedef typename array_traits::value_type const * const_value_type;

  typedef array_traits element_traits;

  // TODO May need a new "unbounded_array_allocation_traits"
  typedef details::unbounded_value_allocation_traits<value_type,true> allocation_traits;

  typedef details::generic_sequence<value_type, allocation_traits, element_traits> implementation_type;

  inline unbounded_array_sequence()
    : impl_()
  {}

  inline CORBA::ULong maximum() const {
    return impl_.maximum();
  }
  inline CORBA::Boolean release() const {
    return impl_.release();
  }
  inline CORBA::ULong length() const {
    return impl_.length();
  }

private:
  implementation_type impl_;
};

} // namespace TAO


#endif // guard_unbounded_array_sequence_hpp
