#include "SimpleClientDriver.h"
#include <iostream>
#include "orbsvcs/CosNamingC.h"
#include <sstream>
#include "SimpleCallbackfunction.h"
#include "simpledefc.h"
#include "simpledefs.h"

SimpleClientDriver::SimpleClientDriver(void) :  
    Active(),
    orb_(CORBA::ORB::_nil()),
    poa_(PortableServer::POA::_nil()),
    m_bOutOfOrder(true),
    pObject_(0)
{
    //do nothing
}

SimpleClientDriver::~SimpleClientDriver(void)
{
    //do nothing
}

bool SimpleClientDriver::initialise(int argc, 
                                    ACE_TCHAR **argv,
                                    const std::string& nName)
{
    try
    {        
        std::cout   <<  "initialising ORB"    <<  std::endl;        
        orb_ = CORBA::ORB_init(argc, argv);
        std::cout   <<  "finished initialising ORB"    <<  std::endl;

        std::cout   <<  "resolving ORB"    <<  std::endl;
        CORBA::Object_var naming_context_object = orb_->resolve_initial_references("NameService");
        std::cout   <<  "finished resolving ORB"    <<  std::endl;
        
        std::cout   <<  "obtaining Naming Service reference"    <<  std::endl;
        CosNaming::NamingContext_var naming_context = CosNaming::NamingContext::_narrow(naming_context_object.in());
        std::cout   <<  "finished obtaining Naming Service reference"    <<  std::endl;
        
        CosNaming::Name name(1);
        name.length(1);
        name[0].id = CORBA::string_dup(nName.c_str());
        std::cout   <<  "resolving client object"    <<  std::endl;
        CORBA::Object_var clientObj = naming_context->resolve(name);
        std::cout   <<  "finished resolving client object"    <<  std::endl;
        
        std::cout   <<  "obtaining client object"    <<  std::endl;        
        pObject_ = interfaces::SimpleServices::_narrow(clientObj.in());
        std::cout   <<  "finished obtaining client object"    <<  std::endl;

        //Now - create callback object and pass it to the server. 
        std::cout   <<  "resolving POA object"    <<  std::endl;
        CORBA::Object_var poa_object = orb_->resolve_initial_references("RootPOA");
        std::cout   <<  "finished resolving POA object"    <<  std::endl;
        
        std::cout   <<  "narrowing POA object"    <<  std::endl;
        poa_ = PortableServer::POA::_narrow(poa_object.in());
        std::cout   <<  "finished narrowing POA object"    <<  std::endl;
        

        PortableServer::POAManager_var poa_manager = poa_->the_POAManager();
        std::cout   <<  "activating POA manager"    <<  std::endl;
        poa_manager->activate();
        std::cout   <<  "finished activating POA manager"    <<  std::endl;
        
        std::cout   <<  "creating callback function"    <<  std::endl;
        PortableServer::Servant_var<SimpleCallbackFunction> servant = 
        new SimpleCallbackFunction();
        std::cout   <<  "finished creating callback function"    <<  std::endl;

        std::cout   <<  "activating callback function"    <<  std::endl;
        PortableServer::ObjectId_var oid = poa_->activate_object(servant.in());                
        naming_context_object = poa_->id_to_reference(oid.in());
        interfaces::SimpleCallbackService_var handler = interfaces::SimpleCallbackService::_narrow(naming_context_object.in());
        std::cout   <<  "finished activating callback function"    <<  std::endl;

        std::cout   <<  "registering callback function to <registerForBroadcasts>"    <<  std::endl;
        pObject_->registerForBroadcasts(handler.in());
        std::cout   <<  "finished registering callback function to <registerForBroadcasts>"    <<  std::endl;                             

        m_bOutOfOrder = false;
    }
    catch ( CORBA::Exception& e)
    {               
        std::cout   <<  e._info()   <<  std::endl;        
        m_bOutOfOrder = true;
    }  

    return (!m_bOutOfOrder);
}

bool SimpleClientDriver::process(void)
{
    try
    {               
        if ( !m_bOutOfOrder )
        {
            std::cout   <<  "running ORB" <<  std::endl;        
            this->orb_->run();  
            std::cout   <<  "finished running ORB" <<  std::endl;        
            m_bOutOfOrder = false;
        }
        else
        {
            std::cout   <<  "ORB out of order" <<  std::endl;
        }
    }
    catch (CORBA::Exception& e)
    {        
        std::cout   <<  e._info()   <<  std::endl;     

        m_bOutOfOrder = true;
    }

    return (!m_bOutOfOrder);
}

bool SimpleClientDriver::shutdown(void)
{
    try
    {       
        if ( CORBA::ORB::_nil() != this->orb_ )
        {
            std::cout   <<  "shutting down ORB" <<  std::endl;        
            this->orb_->shutdown();
            std::cout   <<  "finished shutting down ORB" <<  std::endl;        
        }
        else
        {
            //do nothing
        }

        m_bOutOfOrder = false;
    }
    catch (CORBA::Exception& e)
    {        
        std::cout   <<  e._info()   <<  std::endl;  

        m_bOutOfOrder = true;
    }

    return (!m_bOutOfOrder);
}

bool SimpleClientDriver::destroy(void)
{
    try
    {           
        if ( PortableServer::POA::_nil() != this->poa_ )
        {
            std::cout   <<  "destroying POA" <<  std::endl;        
            this->poa_->destroy(1,1);        
            std::cout   <<  "finished destroying POA" <<  std::endl;        
        }
        else
        {
            //do nothing
        }

        if ( CORBA::ORB::_nil() != this->orb_ )
        {
            std::cout   <<  "destroying ORB" <<  std::endl;        
            this->orb_->destroy();
            std::cout   <<  "finished destroying ORB" <<  std::endl;        
        }
        else
        {
            //do nothing
        }

        m_bOutOfOrder = false;
    }
    catch (CORBA::Exception& e)
    {        
        std::cout   <<  e._info()   <<  std::endl;        

        m_bOutOfOrder = true;
    } 

    return (!m_bOutOfOrder);
}

void SimpleClientDriver::heartbeat()
{

    if ( 0 != pObject_ )
    {
        std::cout   <<  "<heartbeat>"   <<  std::endl;
        pObject_->heartbeat();
    }else {}//do nothing
}

int SimpleClientDriver::run()
{
    while ( !stopRequested() )
    {
        if ( !process() )
        {
            stop();
        }
        else {}//do nothing
        ::Sleep(100);        
    }

    shutdown();

    destroy();
    
    return 0;
}
