#include <stdio.h>
#include <tchar.h>

#pragma once

// The following macros define the minimum required platform.  The minimum required platform
// is the earliest version of Windows, Internet Explorer etc. that has the necessary features to run 
// your application.  The macros work by enabling all features available on platform versions up to and 
// including the version specified.

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef _WIN32_WINNT            // Specifies that the minimum required platform is Windows Vista.
#define _WIN32_WINNT 0x0600     // Change this to the appropriate value to target other versions of Windows.
#endif


#include "SimpleDefC.h"
#include "SimpleServicesC.h"
#include "orbsvcs/CosNamingC.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "SimpleCallbackServicesC.h"
#include "tao/PortableServer/PortableServer.h"

#include "SimpleClientDriver.h"

int _tmain(int argc, _TCHAR* argv[])
{    
    int argc1 = 2;
        
    ACE_TCHAR* argv1[] = {"-ORBInitRef NameService=corbaloc::192.168.10.215:6300/NameService",
                          "-ORBDebugLevel 10",                          
                          NULL};

    SimpleClientDriver driver;
    
    bool bStop = !(driver.initialise(argc1,argv1, "SimpleServices"));

    int nInputKey = 0;

    while ( !bStop )
    {        
        if ( _kbhit() )
        {
            nInputKey = _getch();    
        
            if ( ( nInputKey == 'x' ) || 
                 ( nInputKey == 'X' ) )
            {
                std::cout   <<  "[SYSTEM] STOP REQUEST RECEIVED"  <<  std::endl;                
                bStop = true;
            }
            else if ( ( nInputKey == 's' ) || 
                      ( nInputKey == 'S' ) )
            {
                std::cout   <<  "[SYSTEM] START THREAD"  <<  std::endl;
                driver.start();    
            }
            else if ( ( nInputKey == '1' ) || 
                      ( nInputKey == '1' ) )
            {
                driver.heartbeat();
            }
            else if ( ( nInputKey == '2' ) || 
                      ( nInputKey == '2' ) )
            {
                //TODO
            }
            else if ( ( nInputKey == '9' ) || 
                      ( nInputKey == '9' ) )
            {                
                //TODO
            }
            else {} //do nothing
        } else {} //do nothing

    }
            
    driver.stop();
        
    std::cout   <<  "Press any key to exit" <<  std::endl;
    getch();
	return 0;
}

