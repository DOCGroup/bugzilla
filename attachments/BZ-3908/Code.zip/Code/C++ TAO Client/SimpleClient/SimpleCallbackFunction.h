#ifndef SIMPLECALLBACKFUNCTION_H
#define SIMPLECALLBACKFUNCTION_H

#include "SimpleCallbackServicesS.h"

class SimpleCallbackFunction : public virtual POA_interfaces::SimpleCallbackService
{
public:
    //constructor
    SimpleCallbackFunction(void);
    //destructor
    virtual ~SimpleCallbackFunction(void);
       
    virtual void commonChanged (const ::CORBA::Any & changedEntity,
                                ::CORBA::Short typeOfUpdate);
  
    virtual void heartbeat(void);
};

#endif //SIMPLECALLBACKFUNCTION_H
