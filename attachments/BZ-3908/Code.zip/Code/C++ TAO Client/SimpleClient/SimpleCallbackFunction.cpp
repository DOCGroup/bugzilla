#include "SimpleCallbackFunction.h"
#include <iostream>

SimpleCallbackFunction::SimpleCallbackFunction(void)
{

}

SimpleCallbackFunction::~SimpleCallbackFunction(void)
{

}
       
void SimpleCallbackFunction::commonChanged (const ::CORBA::Any & changedEntity,
                                            ::CORBA::Short typeOfUpdate)
{
    std::cout   <<  "<CALLBACK>commonChanged"    <<  std::endl;
}
  
void SimpleCallbackFunction::heartbeat(void)
{
    std::cout   <<  "<CALLBACK>heartbeat"    <<  std::endl;
}

