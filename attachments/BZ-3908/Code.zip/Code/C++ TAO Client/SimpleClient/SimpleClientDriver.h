#ifndef SIMPLECLIENTDIVER_H
#define SIMPLECLIENTDIVER_H

#include "SimpleServicesS.h"
#include "active.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
#pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

class SimpleClientDriver : //public virtual POA_interfaces::SimpleServices, 
                           public Active
{
public:
    //constructor
    SimpleClientDriver(void);
    //destructor
    virtual ~SimpleClientDriver(void);
    
    //initialise 
    bool initialise(int argc, 
                    ACE_TCHAR **argv, 
                    const std::string& nName);        

    virtual void heartbeat();

protected:
    // Override this function in derived classes 
    //to provide the starting point for the Active object's thread of control.
    virtual int run();
    //process 
    bool process(void);
    //shutdown
    bool shutdown(void);
    //destroy
    bool destroy(void);
private:
    //...
    CORBA::ORB_var              orb_;
    PortableServer::POA_var     poa_;    
    bool                        m_bOutOfOrder;
    //::interfaces::SimpleCallbackService_ptr m_callback;
    interfaces::SimpleServices_ptr pObject_;
};

#endif //SIMPLECLIENTDIVER_H
