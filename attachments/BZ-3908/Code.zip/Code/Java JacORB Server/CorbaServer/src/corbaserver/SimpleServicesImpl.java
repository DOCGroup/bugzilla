/**
*  SimpleServicesImpl.java
*
*
* THIS SOFTWARE IS PROVIDED BY SIMULATION SYSTEMS LTD ``AS IS'' AND
* ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
* TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SIMULATION
* SYSTEMS LTD BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
*
* Copyright 2010 (C) Simulation Systems Ltd. All Rights Reserved.
*
* Java version: JDK 1.6
*
* Product __productName__ __productNumber__
*
*
* Change History:
* Created By: root at 19:05:35 on 05-Oct-2010 First Creation SCJ01
*/

package corbaserver;

import interfaces.SimpleCallbackService;
import interfaces.SimpleServicesPOA;
import java.util.ArrayList;
import java.util.Collection;

import org.jacorb.orb.ORB;
import org.omg.CORBA.Any;
import simple_def.seqObjectHelper;

/**
 *
 * @author root
 */
public class SimpleServicesImpl extends SimpleServicesPOA {

    private static Collection<SimpleCallbackService> obs = new ArrayList<SimpleCallbackService>();

    public void registerForBroadcasts(SimpleCallbackService simpleCallbackMethod) {
        obs.add(simpleCallbackMethod);
        System.out.println("registerForBroadcasts called");
    }

    public static void triggerCallback1(){

        Any callbackInfoHolder = ORB.init().create_any();

        SeqObjectImpl obj = new SeqObjectImpl();
        obj.seq = new SimpleObjectImpl[]{new SimpleObjectImpl()};

        seqObjectHelper.insert(callbackInfoHolder, obj);

        for(SimpleCallbackService service : obs){
            service.commonChanged(callbackInfoHolder, (short)1);
        }
    }

    public static void triggerCallback2(){

        Any callbackInfoHolder = ORB.init().create_any();

        SeqObjectImpl obj = new SeqObjectImpl();
        obj.seq = new SimpleObjectImpl[]{new SimpleObjectImpl(), new SimpleObjectImpl()};

        seqObjectHelper.insert(callbackInfoHolder, obj);

        for(SimpleCallbackService service : obs){
            service.commonChanged(callbackInfoHolder, (short)1);
        }
    }

    public static void sendHeartbeat() {
        for(SimpleCallbackService service : obs){
            service.heartbeat();
        }
    }

    public void heartbeat() {
        System.out.println("heartbeat called");
    }
}
