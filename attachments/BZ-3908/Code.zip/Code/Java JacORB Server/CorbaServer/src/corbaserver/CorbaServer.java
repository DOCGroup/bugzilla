/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package corbaserver;

import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.apache.log4j.Logger;
import org.omg.CORBA.Policy;

import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.IdAssignmentPolicyValue;
import org.omg.PortableServer.ImplicitActivationPolicyValue;
import org.omg.PortableServer.POA;


/**
 *
 * @author root
 */
public class CorbaServer {

    public static final Logger logger = Logger.getLogger(CorbaServer.class);
    private org.omg.CORBA.ORB orb = null;
    private String nameservice = "corbaloc::192.168.10.215:6300/NameService";
    private String localIp = "192.168.10.215";
    private String localPort = "6500";
    private String context = "SimpleServices";
    private ExecutorService threadExecutor = Executors.newSingleThreadExecutor();
    private Future futureObj = null;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         CorbaServer server = new CorbaServer();
    }

    public CorbaServer(){
        CorbaServerThread corbaServerThread = new CorbaServerThread();
        futureObj = threadExecutor.submit(corbaServerThread);
    }


    private class CorbaServerThread implements Runnable {

        private void CorbaServerThread() {
        }

        /**
         *Starts the CORBA Server in order that clients can make requests.
         */
        private void init() {
            String[] args = null;
            logger.trace("Attempting to start CORBA Server");

            // Set system properties is necessary in order to use this ORB in JDK.
            Properties props = System.getProperties();
            props.put("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
            props.put("org.omg.CORBA.ORBSingletonClass", "org.jacorb.orb.ORB");

            // Get the value from the property file.
            //System.setProperties(props);

            props.put("ORBInitRef.NameService", nameservice);
            props.put("OAIAddr", localIp);
            props.put("OAPort", localPort);

            try {
                orb = org.omg.CORBA.ORB.init(args, props);
                org.omg.PortableServer.POA poa = org.omg.PortableServer.POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

                Policy[] _policies;
                _policies = new Policy[]{
                            poa.create_id_assignment_policy(IdAssignmentPolicyValue.USER_ID),
                            //poa.create_lifespan_policy(LifespanPolicyValue.PERSISTENT),
                            poa.create_implicit_activation_policy(ImplicitActivationPolicyValue.NO_IMPLICIT_ACTIVATION)
                        };
                POA myPOA = poa.create_POA("MyPOA", poa.the_POAManager(), _policies);

                logger.trace("Creating MC Services");
                SimpleServicesImpl simpleServices = new SimpleServicesImpl();
                myPOA.activate_object_with_id("SS".getBytes(), simpleServices);

                NamingContextExt nc = NamingContextExtHelper.narrow(orb.resolve_initial_references("NameService"));
                NameComponent[] name_cs = new NameComponent[1];
                name_cs[0] = new NameComponent(context, "");

                logger.trace("Binding " + context + " to the name service");
                nc.rebind(name_cs, myPOA.servant_to_reference(simpleServices));
                poa.the_POAManager().activate();
            } catch (Exception e) {
                logger.trace("Failed to setup the CORBA server ", e);
            }
            logger.trace("CDB CORBA server setup completed");
        }

        public void run() {
            try {
                logger.trace("MC ORB starts successfully");
                init();
                orb.run();
            } catch (Exception ex) {
                logger.trace("Exception when starting MC ORB ", ex);
            } finally {
                orb.destroy();
            }
        }
    }

}
