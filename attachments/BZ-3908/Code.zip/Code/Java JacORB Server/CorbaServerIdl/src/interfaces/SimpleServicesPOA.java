package interfaces;


/**
 * Generated from IDL interface "SimpleServices".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:21:33
 */

public abstract class SimpleServicesPOA
	extends org.omg.PortableServer.Servant
	implements org.omg.CORBA.portable.InvokeHandler, interfaces.SimpleServicesOperations
{
	static private final java.util.Hashtable m_opsHash = new java.util.Hashtable();
	static
	{
		m_opsHash.put ( "registerForBroadcasts", new java.lang.Integer(0));
		m_opsHash.put ( "heartbeat", new java.lang.Integer(1));
	}
	private String[] ids = {"IDL:interfaces/SimpleServices:1.0"};
	public interfaces.SimpleServices _this()
	{
		return interfaces.SimpleServicesHelper.narrow(_this_object());
	}
	public interfaces.SimpleServices _this(org.omg.CORBA.ORB orb)
	{
		return interfaces.SimpleServicesHelper.narrow(_this_object(orb));
	}
	public org.omg.CORBA.portable.OutputStream _invoke(String method, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.ResponseHandler handler)
		throws org.omg.CORBA.SystemException
	{
		org.omg.CORBA.portable.OutputStream _out = null;
		// do something
		// quick lookup of operation
		java.lang.Integer opsIndex = (java.lang.Integer)m_opsHash.get ( method );
		if ( null == opsIndex )
			throw new org.omg.CORBA.BAD_OPERATION(method + " not found");
		switch ( opsIndex.intValue() )
		{
			case 0: // registerForBroadcasts
			{
				interfaces.SimpleCallbackService _arg0=interfaces.SimpleCallbackServiceHelper.read(_input);
				_out = handler.createReply();
				registerForBroadcasts(_arg0);
				break;
			}
			case 1: // heartbeat
			{
				_out = handler.createReply();
				heartbeat();
				break;
			}
		}
		return _out;
	}

	public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte[] obj_id)
	{
		return ids;
	}
}
