package interfaces;


/**
 * Generated from IDL interface "SimpleCallbackService".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 05-Oct-2010 19:04:12
 */

public interface SimpleCallbackServiceOperations
{
	/* constants */
	/* operations  */
	void commonChanged(org.omg.CORBA.Any changedEntity, short typeOfUpdate);
	void heartbeat();
}
