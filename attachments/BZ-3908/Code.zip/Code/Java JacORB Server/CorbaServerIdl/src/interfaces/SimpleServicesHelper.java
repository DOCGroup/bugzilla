package interfaces;


/**
 * Generated from IDL interface "SimpleServices".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:21:33
 */

public final class SimpleServicesHelper
{
	public static void insert (final org.omg.CORBA.Any any, final interfaces.SimpleServices s)
	{
			any.insert_Object(s);
	}
	public static interfaces.SimpleServices extract(final org.omg.CORBA.Any any)
	{
		return unchecked_narrow(any.extract_Object());
	}
	public static org.omg.CORBA.TypeCode type()
	{
		return org.omg.CORBA.ORB.init().create_interface_tc("IDL:interfaces/SimpleServices:1.0", "SimpleServices");
	}
	public static String id()
	{
		return "IDL:interfaces/SimpleServices:1.0";
	}
	public static SimpleServices read(final org.omg.CORBA.portable.InputStream in)
	{
		return unchecked_narrow(in.read_Object(interfaces._SimpleServicesStub.class));
	}
	public static void write(final org.omg.CORBA.portable.OutputStream _out, final interfaces.SimpleServices s)
	{
		_out.write_Object(s);
	}
	public static interfaces.SimpleServices narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof interfaces.SimpleServices)
		{
			return (interfaces.SimpleServices)obj;
		}
		else if (obj._is_a("IDL:interfaces/SimpleServices:1.0"))
		{
			interfaces._SimpleServicesStub stub;
			stub = new interfaces._SimpleServicesStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
		else
		{
			throw new org.omg.CORBA.BAD_PARAM("Narrow failed");
		}
	}
	public static interfaces.SimpleServices unchecked_narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof interfaces.SimpleServices)
		{
			return (interfaces.SimpleServices)obj;
		}
		else
		{
			interfaces._SimpleServicesStub stub;
			stub = new interfaces._SimpleServicesStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
	}
}
