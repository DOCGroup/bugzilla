package interfaces;

import org.omg.PortableServer.POA;

/**
 * Generated from IDL interface "SimpleServices".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:21:33
 */

public class SimpleServicesPOATie
	extends SimpleServicesPOA
{
	private SimpleServicesOperations _delegate;

	private POA _poa;
	public SimpleServicesPOATie(SimpleServicesOperations delegate)
	{
		_delegate = delegate;
	}
	public SimpleServicesPOATie(SimpleServicesOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public interfaces.SimpleServices _this()
	{
		return interfaces.SimpleServicesHelper.narrow(_this_object());
	}
	public interfaces.SimpleServices _this(org.omg.CORBA.ORB orb)
	{
		return interfaces.SimpleServicesHelper.narrow(_this_object(orb));
	}
	public SimpleServicesOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(SimpleServicesOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		return super._default_POA();
	}
	public void registerForBroadcasts(interfaces.SimpleCallbackService simpleCallbackMethod)
	{
_delegate.registerForBroadcasts(simpleCallbackMethod);
	}

	public void heartbeat()
	{
_delegate.heartbeat();
	}

}
