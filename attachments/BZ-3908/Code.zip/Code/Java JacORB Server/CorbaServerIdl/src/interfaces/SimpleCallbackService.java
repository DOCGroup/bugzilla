package interfaces;

/**
 * Generated from IDL interface "SimpleCallbackService".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 05-Oct-2010 19:04:12
 */

public interface SimpleCallbackService
	extends SimpleCallbackServiceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
