package interfaces;


/**
 * Generated from IDL interface "SimpleCallbackService".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 05-Oct-2010 19:04:12
 */

public final class SimpleCallbackServiceHelper
{
	public static void insert (final org.omg.CORBA.Any any, final interfaces.SimpleCallbackService s)
	{
			any.insert_Object(s);
	}
	public static interfaces.SimpleCallbackService extract(final org.omg.CORBA.Any any)
	{
		return unchecked_narrow(any.extract_Object());
	}
	public static org.omg.CORBA.TypeCode type()
	{
		return org.omg.CORBA.ORB.init().create_interface_tc("IDL:interfaces/SimpleCallbackService:1.0", "SimpleCallbackService");
	}
	public static String id()
	{
		return "IDL:interfaces/SimpleCallbackService:1.0";
	}
	public static SimpleCallbackService read(final org.omg.CORBA.portable.InputStream in)
	{
		return unchecked_narrow(in.read_Object(interfaces._SimpleCallbackServiceStub.class));
	}
	public static void write(final org.omg.CORBA.portable.OutputStream _out, final interfaces.SimpleCallbackService s)
	{
		_out.write_Object(s);
	}
	public static interfaces.SimpleCallbackService narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof interfaces.SimpleCallbackService)
		{
			return (interfaces.SimpleCallbackService)obj;
		}
		else if (obj._is_a("IDL:interfaces/SimpleCallbackService:1.0"))
		{
			interfaces._SimpleCallbackServiceStub stub;
			stub = new interfaces._SimpleCallbackServiceStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
		else
		{
			throw new org.omg.CORBA.BAD_PARAM("Narrow failed");
		}
	}
	public static interfaces.SimpleCallbackService unchecked_narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
		{
			return null;
		}
		else if (obj instanceof interfaces.SimpleCallbackService)
		{
			return (interfaces.SimpleCallbackService)obj;
		}
		else
		{
			interfaces._SimpleCallbackServiceStub stub;
			stub = new interfaces._SimpleCallbackServiceStub();
			stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
			return stub;
		}
	}
}
