package interfaces;

/**
 * Generated from IDL interface "SimpleServices".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:21:33
 */

public interface SimpleServices
	extends SimpleServicesOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
