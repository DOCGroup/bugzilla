package interfaces;

/**
 * Generated from IDL interface "SimpleServices".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:21:33
 */

public final class SimpleServicesHolder	implements org.omg.CORBA.portable.Streamable{
	 public SimpleServices value;
	public SimpleServicesHolder()
	{
	}
	public SimpleServicesHolder (final SimpleServices initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return SimpleServicesHelper.type();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = SimpleServicesHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream _out)
	{
		SimpleServicesHelper.write (_out,value);
	}
}
