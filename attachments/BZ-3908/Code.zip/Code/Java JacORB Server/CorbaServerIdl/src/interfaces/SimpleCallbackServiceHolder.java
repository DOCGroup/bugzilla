package interfaces;

/**
 * Generated from IDL interface "SimpleCallbackService".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 05-Oct-2010 19:04:12
 */

public final class SimpleCallbackServiceHolder	implements org.omg.CORBA.portable.Streamable{
	 public SimpleCallbackService value;
	public SimpleCallbackServiceHolder()
	{
	}
	public SimpleCallbackServiceHolder (final SimpleCallbackService initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return SimpleCallbackServiceHelper.type();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = SimpleCallbackServiceHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream _out)
	{
		SimpleCallbackServiceHelper.write (_out,value);
	}
}
