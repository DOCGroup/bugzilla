package interfaces;

import org.omg.PortableServer.POA;

/**
 * Generated from IDL interface "SimpleCallbackService".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 05-Oct-2010 19:04:12
 */

public class SimpleCallbackServicePOATie
	extends SimpleCallbackServicePOA
{
	private SimpleCallbackServiceOperations _delegate;

	private POA _poa;
	public SimpleCallbackServicePOATie(SimpleCallbackServiceOperations delegate)
	{
		_delegate = delegate;
	}
	public SimpleCallbackServicePOATie(SimpleCallbackServiceOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public interfaces.SimpleCallbackService _this()
	{
		return interfaces.SimpleCallbackServiceHelper.narrow(_this_object());
	}
	public interfaces.SimpleCallbackService _this(org.omg.CORBA.ORB orb)
	{
		return interfaces.SimpleCallbackServiceHelper.narrow(_this_object(orb));
	}
	public SimpleCallbackServiceOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(SimpleCallbackServiceOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		return super._default_POA();
	}
	public void commonChanged(org.omg.CORBA.Any changedEntity, short typeOfUpdate)
	{
_delegate.commonChanged(changedEntity,typeOfUpdate);
	}

	public void heartbeat()
	{
_delegate.heartbeat();
	}

}
