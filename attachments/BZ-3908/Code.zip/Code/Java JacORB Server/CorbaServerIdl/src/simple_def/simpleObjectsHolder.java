package simple_def;

/**
 * Generated from IDL alias "simpleObjects".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public final class simpleObjectsHolder
	implements org.omg.CORBA.portable.Streamable
{
	public simple_def.simpleObject[] value;

	public simpleObjectsHolder ()
	{
	}
	public simpleObjectsHolder (final simple_def.simpleObject[] initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return simpleObjectsHelper.type ();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = simpleObjectsHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream out)
	{
		simpleObjectsHelper.write (out,value);
	}
}
