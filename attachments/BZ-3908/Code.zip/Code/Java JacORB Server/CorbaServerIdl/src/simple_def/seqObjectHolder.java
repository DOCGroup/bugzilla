package simple_def;

/**
 * Generated from IDL valuetype "seqObject".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public final class seqObjectHolder
	implements org.omg.CORBA.portable.Streamable
{
	public simple_def.seqObject value;
	public seqObjectHolder () {}
	public seqObjectHolder (final simple_def.seqObject initial)
	{
		value = initial;
	}
	public void _read (final org.omg.CORBA.portable.InputStream is)
	{
		value = simple_def.seqObjectHelper.read (is);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream os)
	{
		simple_def.seqObjectHelper.write (os, value);
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return value._type ();
	}
}
