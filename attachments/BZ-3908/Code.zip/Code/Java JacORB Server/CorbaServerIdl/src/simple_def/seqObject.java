package simple_def;

/**
 * Generated from IDL valuetype "seqObject".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public abstract class seqObject
	implements org.omg.CORBA.portable.StreamableValue
{
	private String[] _truncatable_ids = {"IDL:simple_def/seqObject:1.0"};
	public java.lang.String string4 = "";
	public simple_def.simpleObject[] seq;
	public void _write (org.omg.CORBA.portable.OutputStream os)
	{
		os.write_string(string4);
		simple_def.simpleObjectsHelper.write(os,seq);
	}

	public void _read (final org.omg.CORBA.portable.InputStream os)
	{
		string4=os.read_string();
		seq = simple_def.simpleObjectsHelper.read(os);
	}

	public String[] _truncatable_ids()
	{
		return _truncatable_ids;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return simple_def.seqObjectHelper.type();
	}
}
