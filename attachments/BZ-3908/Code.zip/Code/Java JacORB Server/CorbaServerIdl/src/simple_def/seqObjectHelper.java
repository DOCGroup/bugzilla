package simple_def;

/**
 * Generated from IDL valuetype "seqObject".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public abstract class seqObjectHelper
{
	private static org.omg.CORBA.TypeCode type = null;
	public static void insert (org.omg.CORBA.Any a, simple_def.seqObject v)
	{
		a.insert_Value (v, v._type());
	}
	public static simple_def.seqObject extract (org.omg.CORBA.Any a)
	{
		return (simple_def.seqObject)a.extract_Value();
	}
	public static org.omg.CORBA.TypeCode type()
	{
		if (type == null)
			type = org.omg.CORBA.ORB.init().create_value_tc ("IDL:simple_def/seqObject:1.0", "seqObject", (short)0, null, new org.omg.CORBA.ValueMember[] {new org.omg.CORBA.ValueMember ("", "IDL:string4:1.0", "seqObject", "1.0", org.omg.CORBA.ORB.init().create_string_tc(0), null, (short)1), new org.omg.CORBA.ValueMember ("", "IDL:simple_def/simpleObjects:1.0", "seqObject", "1.0", simple_def.simpleObjectsHelper.type(), null, (short)1)});
		return type;
	}
	public static String id()
	{
		return "IDL:simple_def/seqObject:1.0";
	}
	public static simple_def.seqObject read (org.omg.CORBA.portable.InputStream is)
	{
		return (simple_def.seqObject)((org.omg.CORBA_2_3.portable.InputStream)is).read_value ("IDL:simple_def/seqObject:1.0");
	}
	public static void write (org.omg.CORBA.portable.OutputStream os, simple_def.seqObject val)
	{
((org.omg.CORBA_2_3.portable.OutputStream)os).write_value (val, "IDL:simple_def/seqObject:1.0");
	}
}
