package simple_def;

/**
 * Generated from IDL alias "simpleObjects".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public final class simpleObjectsHelper
{
	private static org.omg.CORBA.TypeCode _type = null;

	public static void insert (org.omg.CORBA.Any any, simple_def.simpleObject[] s)
	{
		any.type (type ());
		write (any.create_output_stream (), s);
	}

	public static simple_def.simpleObject[] extract (final org.omg.CORBA.Any any)
	{
		return read (any.create_input_stream ());
	}

	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_alias_tc(simple_def.simpleObjectsHelper.id(), "simpleObjects",org.omg.CORBA.ORB.init().create_sequence_tc(0, org.omg.CORBA.ORB.init().create_value_tc ("IDL:simple_def/simpleObject:1.0", "simpleObject", (short)0, null, new org.omg.CORBA.ValueMember[] {new org.omg.CORBA.ValueMember ("", "IDL:string1:1.0", "simpleObject", "1.0", org.omg.CORBA.ORB.init().create_string_tc(0), null, (short)1), new org.omg.CORBA.ValueMember ("", "IDL:string2:1.0", "simpleObject", "1.0", org.omg.CORBA.ORB.init().create_string_tc(0), null, (short)1), new org.omg.CORBA.ValueMember ("", "IDL:string3:1.0", "simpleObject", "1.0", org.omg.CORBA.ORB.init().create_string_tc(0), null, (short)1)})));
		}
		return _type;
	}

	public static String id()
	{
		return "IDL:simple_def/simpleObjects:1.0";
	}
	public static simple_def.simpleObject[] read (final org.omg.CORBA.portable.InputStream _in)
	{
		simple_def.simpleObject[] _result;
		int _l_result0 = _in.read_long();
		try
		{
			 int x = _in.available();
			 if ( x > 0 && _l_result0 > x )
				{
					throw new org.omg.CORBA.MARSHAL("Sequence length too large. Only " + x + " available and trying to assign " + _l_result0);
				}
		}
		catch (java.io.IOException e)
		{
		}
		_result = new simple_def.simpleObject[_l_result0];
		for (int i=0;i<_result.length;i++)
		{
			_result[i]=(simple_def.simpleObject)((org.omg.CORBA_2_3.portable.InputStream)_in).read_value ("IDL:simple_def/simpleObject:1.0");
		}

		return _result;
	}

	public static void write (final org.omg.CORBA.portable.OutputStream _out, simple_def.simpleObject[] _s)
	{
		
		_out.write_long(_s.length);
		for (int i=0; i<_s.length;i++)
		{
			((org.omg.CORBA_2_3.portable.OutputStream)_out).write_value (_s[i]);
		}

	}
}
