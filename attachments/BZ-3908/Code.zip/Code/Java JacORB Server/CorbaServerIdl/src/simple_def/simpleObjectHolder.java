package simple_def;

/**
 * Generated from IDL valuetype "simpleObject".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public final class simpleObjectHolder
	implements org.omg.CORBA.portable.Streamable
{
	public simple_def.simpleObject value;
	public simpleObjectHolder () {}
	public simpleObjectHolder (final simple_def.simpleObject initial)
	{
		value = initial;
	}
	public void _read (final org.omg.CORBA.portable.InputStream is)
	{
		value = simple_def.simpleObjectHelper.read (is);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream os)
	{
		simple_def.simpleObjectHelper.write (os, value);
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return value._type ();
	}
}
