package simple_def;

/**
 * Generated from IDL valuetype "simpleObject".
 *
 * @author JacORB IDL compiler V 2.3.1, 27-May-2009
 * @version generated at 06-Oct-2010 15:28:49
 */

public abstract class simpleObject
	implements org.omg.CORBA.portable.StreamableValue
{
	private String[] _truncatable_ids = {"IDL:simple_def/simpleObject:1.0"};
	public java.lang.String string1 = "";
	public java.lang.String string2 = "";
	public java.lang.String string3 = "";
	public void _write (org.omg.CORBA.portable.OutputStream os)
	{
		os.write_string(string1);
		os.write_string(string2);
		os.write_string(string3);
	}

	public void _read (final org.omg.CORBA.portable.InputStream os)
	{
		string1=os.read_string();
		string2=os.read_string();
		string3=os.read_string();
	}

	public String[] _truncatable_ids()
	{
		return _truncatable_ids;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return simple_def.simpleObjectHelper.type();
	}
}
