/**
 * @file Client_Interceptor.cpp
 *
 * $Id: Client_Interceptor.cpp 91652 2010-09-08 14:42:59Z johnnyw $
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */

#include "Client_Interceptor.h"
#include "Shared_Interceptor.h"
#include "tao/OctetSeqC.h"

#include "ace/Log_Msg.h"
#include "ace/OS_NS_string.h"

unsigned long Echo_Client_Request_Interceptor::request_count = 0;
unsigned long Echo_Client_Request_Interceptor::reply_count = 0;
unsigned long Echo_Client_Request_Interceptor::other_count = 0;
unsigned long Echo_Client_Request_Interceptor::exception_count = 0;
PortableInterceptor::SlotId Echo_Client_Request_Interceptor::the_slot = 0;

Echo_Client_Request_Interceptor::
Echo_Client_Request_Interceptor (PortableInterceptor::SlotId theSlot)
{
  Echo_Client_Request_Interceptor::the_slot = theSlot;
}

char *
Echo_Client_Request_Interceptor::name (void) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  return CORBA::string_dup ("Echo_Client_Interceptor");
}

void
Echo_Client_Request_Interceptor::destroy (void) ACE_THROW_SPEC ((::CORBA::SystemException))
{
}

void
Echo_Client_Request_Interceptor::send_poll (
    PortableInterceptor::ClientRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  ACE_ERROR((LM_ERROR,
             "ERROR, unexpected interception point called send_poll()\n"));
  throw CORBA::BAD_PARAM ();
}

void
Echo_Client_Request_Interceptor::send_request (
    PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  IOP::ServiceContext sc;
  sc.context_id = ::service_id;
  sc.context_data.length(100);


  CORBA::Octet *buf = sc.context_data.get_buffer();
  CORBA::Any_var slotData = ri->get_slot(the_slot);
  const char* x;
  bool extractSucceeded = (slotData.in() >>= x);
  CORBA::String_var s = x;
  
  ACE_DEBUG ((LM_DEBUG, "(%P|%t) send_request(%@): gn(%c) data(%s) ri(%@)\n",
              this, extractSucceeded ? 'Y' : 'N', s.in() ? s.in() : "", ri));

  if (s.in())
    {
      size_t len = ACE_OS::strlen(s.in()) + 1;
      ACE_OS::memcpy(buf, s.in(), len);
      sc.context_data.length(len);
    }
  else
    {
      sc.context_data.length(0);
    }

  // Add this context to the service context list.
  ri->add_request_service_context (sc,
                                   true /* replace */);

  // Check that the request service context can be retrieved.
  IOP::ServiceContext_var rc =
    ri->get_request_service_context (::service_id);

  Echo_Client_Request_Interceptor::request_count++;

  ACE_DEBUG ((LM_DEBUG,
              "(%P|%t) send_request(%@): requests=%d, svc context length = %d\n",
              this, request_count, rc->context_data.length()));
}

void
Echo_Client_Request_Interceptor::receive_reply (
    PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  // Check that the request service context can be retrieved.
  IOP::ServiceContext_var rc =
    ri->get_request_service_context (::service_id);

  ++Echo_Client_Request_Interceptor::reply_count;

  ACE_DEBUG ((LM_DEBUG, "(%P|%t) receive_reply(%@): replies=%d, svc context length=%d\n",
              this, reply_count, rc->context_data.length()));
}

void
Echo_Client_Request_Interceptor::receive_other (
    PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  // Check that the request service context can be retrieved.
  IOP::ServiceContext_var rc =
    ri->get_request_service_context (::service_id);

  Echo_Client_Request_Interceptor::other_count++;

  ACE_DEBUG ((LM_DEBUG,
              "(%P|%t) receive_other(%@): others=%d, svc context length=%d\n",
              this, other_count, rc->context_data.length()));

}

void
Echo_Client_Request_Interceptor::receive_exception (
    PortableInterceptor::ClientRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  Echo_Client_Request_Interceptor::exception_count++;
}
