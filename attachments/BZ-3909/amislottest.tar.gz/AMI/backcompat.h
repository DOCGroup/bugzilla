#ifndef BACKCOMPAT_H
#define BACKCOMPAT_H

#include <tao/Version.h>

#if TAO_MINOR_VERSION > 5
#  define ACE_THROW_SPEC(x)
#endif

#endif
