/**
 * @file Client_ORBInitializer.cpp
 *
 * $Id: Client_ORBInitializer.cpp 91652 2010-09-08 14:42:59Z johnnyw $
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */

#include "Client_ORBInitializer.h"
#include "Client_Interceptor.h"

Client_ORBInitializer::Client_ORBInitializer ()
{
}

void
Client_ORBInitializer::pre_init (
    PortableInterceptor::ORBInitInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException))
{
}

void
Client_ORBInitializer::post_init (
    PortableInterceptor::ORBInitInfo_ptr info) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  PortableInterceptor::SlotId id = info->allocate_slot_id();
  PortableInterceptor::ClientRequestInterceptor_var interceptor
    (new Echo_Client_Request_Interceptor(id));

  info->add_client_request_interceptor (interceptor.in ());
}
