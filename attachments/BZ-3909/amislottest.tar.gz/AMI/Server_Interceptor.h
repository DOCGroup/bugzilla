/**
 * @file Server_Interceptor.h
 *
 * $Id: Server_Interceptor.h 81490 2008-04-28 14:32:24Z johnnyw $
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */
#ifndef Server_Interceptor__h_
#define Server_Interceptor__h_

#include "tao/PI_Server/PI_Server.h"
#include "tao/PortableInterceptorC.h"
#include "tao/LocalObject.h"
#include "tao/ORB.h"

#include "backcompat.h"

class Echo_Server_Request_Interceptor
  : public virtual PortableInterceptor::ServerRequestInterceptor
  , public virtual ::CORBA::LocalObject
{
public:
  Echo_Server_Request_Interceptor ();

  virtual char * name (void) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void destroy (void) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void receive_request (PortableInterceptor::ServerRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void receive_request_service_contexts (
        PortableInterceptor::ServerRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void send_reply (PortableInterceptor::ServerRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void send_exception (PortableInterceptor::ServerRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void send_other (PortableInterceptor::ServerRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException));
};

#endif /* Server_Interceptor__h_ */
