/**
 * @file Client_Interceptor.h
 *
 * $Id: Client_Interceptor.h 81490 2008-04-28 14:32:24Z johnnyw $
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */
#ifndef Client_Interceptor__h_
#define Client_Interceptor__h_

#include "backcompat.h"

#include "tao/PI/PI.h"
#include "tao/PortableInterceptorC.h"
#include "tao/LocalObject.h"
#include "tao/ORB.h"

class Echo_Client_Request_Interceptor
  : public virtual PortableInterceptor::ClientRequestInterceptor
  , public virtual ::CORBA::LocalObject
{
 private:
  Echo_Client_Request_Interceptor (void);
  
 public:
  Echo_Client_Request_Interceptor (PortableInterceptor::SlotId theSlot);

  static unsigned long request_count;
  static unsigned long reply_count;
  static unsigned long other_count;
  static unsigned long exception_count;

  static PortableInterceptor::SlotId the_slot;

  virtual char * name (void) ACE_THROW_SPEC ((::CORBA::SystemException));
  // Canonical name of the interceptor.

  virtual void destroy (void) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void send_poll (PortableInterceptor::ClientRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void send_request (PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void receive_reply (PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void receive_other (PortableInterceptor::ClientRequestInfo_ptr) ACE_THROW_SPEC ((::CORBA::SystemException));

  virtual void receive_exception (PortableInterceptor::ClientRequestInfo_ptr ri) ACE_THROW_SPEC ((::CORBA::SystemException));
};

#endif /* Client_Interceptor__h_ */
