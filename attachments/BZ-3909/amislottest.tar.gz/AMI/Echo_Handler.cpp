/**
 * @file Echo_Handler.cpp
 *
 * $Id: Echo_Handler.cpp 91652 2010-09-08 14:42:59Z johnnyw $
 *
 * @author Carlos O'Ryan <coryan@atdesk.com>
 */
#include "Echo_Handler.h"

Echo_Handler::Echo_Handler(void)
  : replies_ (0)
{
}

void
Echo_Handler::echo_operation (char const *) ACE_THROW_SPEC ((::CORBA::SystemException))
{
  ++this->replies_;
}

void
Echo_Handler::echo_operation_excep (::Messaging::ExceptionHolder *) ACE_THROW_SPEC ((::CORBA::SystemException))
{
}

void
Echo_Handler::shutdown (void) ACE_THROW_SPEC ((::CORBA::SystemException))
{
}

void
Echo_Handler::shutdown_excep (::Messaging::ExceptionHolder *) ACE_THROW_SPEC ((::CORBA::SystemException))
{
}

CORBA::ULong
Echo_Handler::replies (void) const
{
  return this->replies_;
}
