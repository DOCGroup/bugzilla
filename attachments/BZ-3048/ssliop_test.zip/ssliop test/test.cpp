#include "tao/ORB.h"
#include "tao/PortableServer/PortableServer.h"
#include "tao/Strategies/advanced_resource.h"
#include "tao/IORTable/IORTable.h"
#include "tao/Messaging/Messaging.h"
#include "orbsvcs/SSLIOP/SSLIOP_Factory.h"

int main (int argc, char **argv)
{
    CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);
    return 0;
}
