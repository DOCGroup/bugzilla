// file Foo_i.h

#ifndef FOO_I_H
#define FOO_I_H

#include "FooS.h"
#include <orbsvcs/CosNamingC.h>

class Foo_i: public POA_Foo
{
	public:

		Foo_i ();
		virtual ~Foo_i ();

		virtual void putOctetSequence (Foo::OctetSequence const & rOctetSequence)
        ACE_THROW_SPEC ((
          CORBA::SystemException
        ));


};

#endif  // FOO_I_H
// end file Foo_i.h
