// file server.cpp

#define CRUD

//#include "tao/TAO.h"
#include "tao/corba.h"
#include "orbsvcs/CosNamingC.h"
#include "orbsvcs/Naming/Naming_Utils.h"
#include "tao/ORB.h"
#include "Foo_i.h"
//#include <tao/POAC.h>
#include <tao/PortableServer/PortableServerC.h>

int
main (int argc, char ** argv)
{

  CORBA::ORB_var orb_var = CORBA::ORB_init(argc, argv, "orb1");

  CORBA::Object_var object_var = orb_var->resolve_initial_references("RootPOA");
  PortableServer::POA_var rootPoa_var = 
    PortableServer::POA::_narrow(object_var.in());

  object_var = orb_var->resolve_initial_references ("NameService");
  if (CORBA::is_nil(object_var.ptr()) == 1)
  {
    cout << "Could not resolve NameService" << endl;
  }

  CosNaming::NamingContext_var namingContext_var = 
    CosNaming::NamingContext::_narrow (object_var.ptr());

  Foo_i foo1;

  try
  {
    PortableServer::ObjectId_var pFoo1ObjectId =
      rootPoa_var->activate_object ((TAO_ServantBase *)&foo1);

    PortableServer::POAManager_ptr poaManager_ptr =
      rootPoa_var->the_POAManager();
    Foo_var fooVar1 = foo1._this();
    poaManager_ptr->activate();

    CosNaming::Name name(1);
    name.length(1);
    name[0].id = CORBA::string_dup("Foo1");

    namingContext_var->rebind(name, fooVar1.in());
  }
  catch (CORBA::Exception const & ex)
  {
    cerr << "Caught exception " << ex._info().c_str() << endl;
  }


  while (1)
  {
    ACE_Time_Value t1(5, 0);
    orb_var->run(&t1);
  }

  return 0;
}

// end file server.cpp
