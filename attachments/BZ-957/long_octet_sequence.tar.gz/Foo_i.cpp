// file Foo_i.cpp

#include "Foo_i.h"

Foo_i::Foo_i ()
{
}

Foo_i::~Foo_i ()
{
}

void
Foo_i::putOctetSequence (
  Foo::OctetSequence const & rOctetSequence)
    ACE_THROW_SPEC ((
      CORBA::SystemException
    ))
{
  cout << "Foo_i::putOctetSequence called, length = " <<
    rOctetSequence.length() << endl;
}

// end file Foo_i.cpp
