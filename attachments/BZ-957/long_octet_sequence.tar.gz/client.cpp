// file client.cpp

#include "FooC.h"
#include "orbsvcs/CosNamingC.h"
#include "Foo_i.h"

void
pause (const char *pChar)
{
  cout << pChar << ", paused, enter to continue..." << endl;
  int c;
  do
  {
    c = cin.get();
  }
  while (c != '\n');
}

int
main (int argc, char **argv)
{
  CORBA::ORB_var orb_var = CORBA::ORB_init(argc, argv, "internet");

  Foo_var remoteFoo_var;

  try
  {
    CosNaming::Name n(1);
    n.length (1);
    n[0].id = CORBA::string_dup ("Foo1");
    CORBA::Object_var object_var = orb_var->resolve_initial_references ("NameService");
    cout << "NameService = " << orb_var->object_to_string(object_var.ptr()) <<
      endl;

    CosNaming::NamingContext_var namingContext_var = 
      CosNaming::NamingContext::_narrow (object_var.ptr());

    if (namingContext_var.ptr() == CosNaming::NamingContext::_nil())
    {
      cout << "NamingContext is nil" << endl;
    }

    object_var = namingContext_var->resolve(n);
    remoteFoo_var = Foo::_narrow(object_var.ptr());
  }
  catch (CORBA::Exception const & ex)
  {
    cerr <<
      "Caught exception " << ex._info().c_str() << endl;
  }

  unsigned long len = 1;
  for (int i = 0; i < 26; ++i)
  {
#ifdef CRUD
    char * pBuffer = new char[len];
    memset(pBuffer, '0', len);

    //--------------------------------------
    // Create an octet sequence from the buffer and let it delete the
    // buffer.
    //
    Foo::OctetSequence octetSequence (len, len,
      reinterpret_cast <CORBA::Octet * >(pBuffer), 1);
#else // CRUD
    Foo::OctetSequence octetSequence;
    octetSequence.length(len);
    for (unsigned long ii = 0; ii < octetSequence.length(); ++ii)
    {
      octetSequence[ii] = 0;
    }
#endif // CRUD

    try
    {
      remoteFoo_var->putOctetSequence(octetSequence);
    }
    catch (CORBA::Exception const & ex)
    {
      cerr << "Caught exception " << ex._info().c_str() << endl;
    }

    len *= 2;
  }

	return 0;
}

// end file Client.cpp
