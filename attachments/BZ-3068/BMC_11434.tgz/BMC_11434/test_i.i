// $Id: test_i.i,v 1.1.2.1 2007/08/01 19:54:41 mesnierp Exp $

ACE_INLINE
Callback_i::Callback_i (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

ACE_INLINE
Simple_Server_i::Simple_Server_i (CORBA::ORB_ptr orb,
                                  int no_iterations)
  :  orb_ (CORBA::ORB::_duplicate (orb)),
     flag_ (0),
     caller_ (0),
     iterations_ (no_iterations)
{
}
