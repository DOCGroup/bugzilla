// $Id: test_i.cpp,v 1.1.2.1 2007/08/01 19:54:41 mesnierp Exp $

#include "test_i.h"

#include "tao/ORB_Core.h"
#include "tao/debug.h"
#include "tao/Transport_Cache_Manager.h"
#include "tao/Thread_Lane_Resources.h"
#include "ace/OS_NS_unistd.h"

#if !defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

ACE_RCSID(BiDirectional, test_i, "$Id: test_i.cpp,v 1.1.2.1 2007/08/01 19:54:41 mesnierp Exp $")

void
Callback_i::shutdown (ACE_ENV_SINGLE_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  ACE_DEBUG ((LM_DEBUG, "Performing clean shutdown\n"));
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}

void
Callback_i::callback_method (const CORBA::OctetSeq &
                             ACE_ENV_ARG_DECL_NOT_USED)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  static int count = 0;
  if (count++ > 0)
    ACE_OS::exit(0);
}


// ****************************************************************

CORBA::Long
Simple_Server_i::test_method (CORBA::Boolean do_callback
                              ACE_ENV_ARG_DECL_NOT_USED )
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (do_callback && this->caller_ != 0)
    {
      this->caller_->go();
    }

  return 0;
}


void
Simple_Server_i::ow_test (void)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  int iter = this->ow_count_++;
  ACE_DEBUG ((LM_DEBUG, "%t: Invoking ow test, iter = %d\n", iter));
}

void
Simple_Server_i::callback_object (Callback_ptr callback
                                  ACE_ENV_ARG_DECL_NOT_USED )
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->caller_ = new Caller (callback, orb_);
}

Caller::Caller (Callback_ptr callback, CORBA::ORB_ptr orb)
  : cbobj_(Callback::_duplicate (callback)),
    orb_(CORBA::ORB::_duplicate(orb))
{
  this->payload_.length(0); //10000);
  this->cond_ = new ACE_Thread_Condition<ACE_Thread_Mutex>(this->lock_);
  this->activate (THR_JOINABLE | THR_NEW_LWP, 4);
  ACE_OS::sleep(1);
  ACE_DEBUG ((LM_DEBUG,"%t returning\n"));
}

void
Caller::go(void)
{
  this->lock_.acquire();
  this->cond_->broadcast();
  this->lock_.release();
}

int
Caller::svc (void)
{
  this->lock_.acquire();
  ACE_DEBUG ((LM_DEBUG, "%t Getting ready to call\n"));
  this->cond_->wait();
  this->lock_.release();
  try
    {
      while (1)
        {
          ACE_DEBUG ((LM_DEBUG, "%t calling, payload len = %d\n", payload_.length()));
          this->cbobj_->callback_method(this->payload_);
          ACE_DEBUG ((LM_DEBUG, "%t callback returned\n"));
          ACE_Time_Value tv(0,100);
          ACE_OS::sleep(tv);
        }
    }
  catch (CORBA::Exception &ex)
    {
      ACE_DEBUG ((LM_DEBUG, "%t caught: %s\n",ex._name()));
    }
  try
    {
      ACE_OS::sleep(1);
      this->orb_->shutdown (0);
    }
  catch (CORBA::Exception &ex)
    {
      ACE_DEBUG ((LM_DEBUG, "%t orb shutdown raised %s\n",ex._name()));
    }
  return 0;
}

void
Simple_Server_i::shutdown (ACE_ENV_SINGLE_ARG_DECL)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}
