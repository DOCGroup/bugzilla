#include "tao/corba.h"
#include "tao/IFR_Client/IFR_BasicC.h"

int main(int argc, char** argv)
{  
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb_ = CORBA::ORB_init (argc, argv, 0 ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      CORBA::Object_var object =
        orb_->resolve_initial_references ("InterfaceRepository" ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      CORBA::Repository_var repo_ = CORBA::Repository::_narrow (object.in ()
                                    ACE_ENV_ARG_PARAMETER);
      
      char in;
      ACE_TRY_CHECK;
      for (int i = 0; i < 20; i++)
       {
          cin >> in;
          cout << "Creating " << i << endl;
          CORBA::InterfaceDefSeq in_bases (1);
          in_bases.length (0);

          CORBA::InterfaceDef_var gp_ivar = repo_->create_interface ("IDL:gp_iface:1.0",
                                           "gp_iface", "1.0", in_bases
                                           ACE_ENV_ARG_PARAMETER);
          ACE_CHECK;
        
          cout << "About to destroy " << i << endl;
          gp_ivar->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
          ACE_CHECK;
          cout << "Destroyed " << i << endl;
          
       }
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception ...");
      return -1;
    }
  ACE_ENDTRY;
  return 0;
}