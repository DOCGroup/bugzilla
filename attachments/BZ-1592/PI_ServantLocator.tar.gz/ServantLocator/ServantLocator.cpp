#include "ServantLocator.h"


ACE_RCSID (ServantLocator,
           ServantLocator,
           "$Id$")


#include "test_i.h"


extern CORBA::Boolean receive_request_service_contexts_called;
extern CORBA::Boolean ending_interception_point_called;


ServantLocator::ServantLocator (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb)),
    servant_ ()
{
}

ServantLocator::~ServantLocator (void)
{
}

PortableServer::Servant
ServantLocator::preinvoke (
    const PortableServer::ObjectId & /* oid */,
    PortableServer::POA_ptr /* adapter */,
    const char * operation,
    PortableServer::ServantLocator::Cookie & /* the_cookie */
    ACE_ENV_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException,
                   PortableServer::ForwardRequest))
{
  if (ACE_OS::strcmp (operation, "shutdown") != 0)
    {
      if (receive_request_service_contexts_called == 0)
        {
          ACE_ERROR ((LM_ERROR,
                      "PortableInterceptor::ServerRequestInterceptor:: "
                      "receive_request_service_contexts() not called\n"
                      "prior to "
                      "PortableServer::ServantLocator::preinvoke().\n"));

          ACE_THROW_RETURN (CORBA::INTERNAL (), 0);
        }

      if (this->servant_.in () == 0)
        {
          test_i * servant;
          
          ACE_NEW_THROW_EX (servant,
                            test_i (this->orb_.in ()),
                            CORBA::NO_MEMORY ());
          ACE_CHECK_RETURN (0);

          this->servant_ = servant;
        }

//       PortableServer::RefCountServantBase * r =
//         dynamic_cast<PortableServer::RefCountServantBase *> (this->servant_.in ());

//       ACE_ASSERT (r != 0);

//       ACE_DEBUG ((LM_DEBUG,
//                   "SERVANT REF COUNT == %d\n",
//                   r->_ref_count ()));
    }

  return this->servant_.in ();
}


void
ServantLocator::postinvoke (
    const PortableServer::ObjectId & /* oid */,
    PortableServer::POA_ptr /* adapter */,
    const char * operation,
    PortableServer::ServantLocator::Cookie /* the_cookie */,
    PortableServer::Servant /* the_servant */
    ACE_ENV_ARG_DECL_NOT_USED)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (ACE_OS::strcmp (operation, "shutdown") != 0)
    {
      // Ending interception points should be called after postinvoke().
      if (::ending_interception_point_called != 0)
        {
          ACE_ERROR ((LM_ERROR,
                      "ERROR: PortableInterceptor::ServerRequestInterceptor"
                      "\n"
                      "ERROR: ending interception point incorrectly "
                      "called prior to\n"
                      "ERROR: "
                      "PortableServer::ServantLocator::postinvoke().\n"));

          // ACE_THROW (CORBA::INTERNAL ());
          ACE_ASSERT (::ending_interception_point_called == 0);
        }
    }
}
