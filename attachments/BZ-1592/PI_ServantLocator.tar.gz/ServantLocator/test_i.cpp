#include "test_i.h"


ACE_RCSID (ServantLocator,
           test_i,
           "$Id$")


extern CORBA::Boolean receive_request_called;

test_i::test_i (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

test_i::~test_i (void)
{
}

void
test_i::op (ACE_ENV_SINGLE_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  // PortableInterceptor::ServerRequestInterceptor::receive_request()
  // should have been invoked.
  if (::receive_request_called == 0)
    {
      ACE_ERROR ((LM_ERROR,
                  "PortableInterceptor::ServerRequestInterceptor::"
                  "receive_request() not called \n"
                  "prior to target operation execution.\n"));

      ACE_THROW (CORBA::INTERNAL ());
    }
}

void
test_i::shutdown (ACE_ENV_SINGLE_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}
