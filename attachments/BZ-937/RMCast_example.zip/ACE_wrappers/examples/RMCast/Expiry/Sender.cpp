#include <string>
#include "ace/RMCast/RMCast_UDP_Reliable_Sender.h"
#include "ace/INET_Addr.h"
#include "ace/FILE_IO.h"
#include "ace/Message_Block.h"
#include "ace/Reactor.h"

ACE_RCSID(tests, RMCast_Examples_Sender, "Sender.cpp,v 1.0")


const int max_messages = 9;
static char* messages[] = {
  "A good programmer can write FORTRAN in any language.\n", 
  "All work and no play make Jack a dull boy. -- Jack\n",
  "The quick brown fox jumped over the lazy programmer.\n",
  "Non co-operation with evil is as much a duty as co-operation with good. -- Mahatma Gandhi\n",
  "Yesterday is history, tomorrow is a mystery, today is a gift. That's why they call it 'the Present'. -- some idiot\n",
  "Me responserliberty be to keep it real. Maximum restpec to you! -- Ali G\n",
  "Law is a bottomless pit; a cormorant, a harpy that devours everthing. -- Arbuthnot\n",
  "Yet who would have thought the old man to have had so much blood in him? -- Shakespeare [Macbeth]\n",
  "Lives of great men all remind us\n"
       "  We can make our lives sublime,\n"
       "  And, departing, leave behind us\n"
       "  Footprints on the sands of time; -- Henry Wadsworth Longfellow [A Psalm of Life]\n" 
};

std::string 
message() {
  static int count = 0;
  
  int message_no = rand() % max_messages;
  
  count++;
  char buf[2028];
  ACE_OS::sprintf(buf, "%i", count);
  return std::string(buf) + " : " + messages[message_no];
}

int
main (int argc, char *argv[])
{
  std::string mcg("224.9.9.2:20001");
  int send  = 100;
  int size  = 5;
  int delay = 1000;
  
  for (int i=0; i<argc-1; i++)
  {
    if (std::string(argv[i]) == "-mcg") {
      mcg = argv[i+1];
    } 
    else if (std::string(argv[i]) == "-send") {
      send = ACE_OS::atoi(argv[i+1]);
    }
    else if (std::string(argv[i]) == "-size") {
      size = ACE_OS::atoi(argv[i+1]);
    }
    else if (std::string(argv[i]) == "-delay") {
      delay = ACE_OS::atoi(argv[i+1]);
    }
  }
  
  ACE_INET_Addr mcast_group;
  if (mcast_group.set (mcg.c_str()) != 0) {
    ACE_ERROR_RETURN ((LM_ERROR,
      "Cannot set mcast group <%s>\n", mcg.c_str()),
      1);
  }

  ACE_RMCast_UDP_Reliable_Sender sender (0);
  
  if (sender.init (mcast_group) == -1)
  {
    ACE_ERROR_RETURN ((LM_ERROR,
      "Cannot init UDP I/O at <%s:%d> %p\n",
      mcast_group.get_host_name (),
      mcast_group.get_port_number (),
      ""),
      1);
  }
  
  // Use the Reactor to demultiplex all the messages
  ACE_Reactor *reactor = ACE_Reactor::instance ();
  
  sender.reactive_incoming_messages (reactor);
  // Resend the messages every now and then...
  ACE_Time_Value tv (0, 1000000);
  sender.reactive_resends (reactor, tv);

  ACE_Time_Value membershipExpirationInterval (1, 0);
  sender.reactive_membership_expiration(
      reactor, 
      membershipExpirationInterval,  // Check for expired members every so often...
      20000                          // Delete members after n milliseconds without an ACK
  );


  ACE_Time_Value messageExpirationInterval (2, 0);
  sender.reactive_message_expiration(
      reactor, 
      messageExpirationInterval,     // Check for expired messages every so often...
      100,                             // Delete messages after n resends
      60000                              // Delete messages after n milliseconds
  );

  
  for (i=0; i<send; i++) {
    std::string msg;
    for (int j=0; j<size; j++) {
      msg = msg + message();
    }
   
    ACE_Message_Block mb(msg.length()+1);
    mb.copy(msg.c_str(), msg.length()+1);
    
    ACE_RMCast::Data data;
    data.payload = &mb;
    
    if (sender.data (data) != 0) {
      ACE_DEBUG((LM_DEBUG, "(%P|%t) Could not send msg\n"));
      break;
    }
        
    // Handle incoming events for "delay" milliseconds
    ACE_Time_Value tv (0, delay*1000);
    while (tv != ACE_Time_Value(0)) {
      reactor->handle_events (&tv);
    }
  }

  ACE_Message_Block mb(1);
  mb.copy("", 1);
    
  ACE_RMCast::Data data;
  data.payload = &mb;
    
  if (sender.data (data) != 0) {
    ACE_DEBUG((LM_DEBUG, "(%P|%t) Could not send end-of-data msg\n"));
  }
  
  // Wait until all the messages are successfully delivered
  do {
    // Try for 50 milliseconds...
    ACE_Time_Value tv (5, 0);
    int r = reactor->handle_events (&tv);
    if (r == -1)
      break;
  } while (sender.has_data () || sender.has_members ());
  
  return 0;
}
