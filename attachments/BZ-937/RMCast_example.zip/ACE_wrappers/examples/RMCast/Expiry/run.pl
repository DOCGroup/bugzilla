eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

use Env qw(ACE_ROOT);
use lib "$ACE_ROOT/bin";

use PerlACE::Run_Test;

$run_r1 = 0;
$run_r2 = 0;
$run_r3 = 0;
$run_r4 = 0;
$send   = 20;

for ($i = 0; $i <= $#ARGV; $i++) {
  SWITCH: {
    if ($ARGV[$i] eq "-h" || $ARGV[$i] eq "-?") {
      print "----------------------------------------------------------------------------------------------\n";
      print "Output Pipe\n";
      print "  Controller options...\n";
      print "   -r1             : Run receiver 1\n";
      print "   -r2             : Run receiver 2\n";
      print "   -r3             : Run receiver 3\n";
      print "   -r4             : Run receiver 4\n";
      print "   -send n         : Number of messages to send [default $send]\n";
      print "----------------------------------------------------------------------------------------------\n";

      print "\n";
      exit;
    }
    if ($ARGV[$i] eq "-r1") { 
      $run_r1 = 1; 
    }
    elsif ($ARGV[$i] eq "-r2") {
      $run_r2 = 1; 
    }
    elsif ($ARGV[$i] eq "-r3") { 
      $run_r3 = 1; 
    }
    elsif ($ARGV[$i] eq "-r4") { 
      $run_r4 = 1; 
    }
    elsif ($ARGV[$i] eq "-send") { 
      $send = $ARGV[$i+1]; 
    }
  }
}



$SENDER = new PerlACE::Process ("./sender", "-send $send -size 1 -delay 1000");
$status = $SENDER->Spawn();

if ($run_r1 == 1) {
  $R1 = new PerlACE::Process ("./receiver", "");
  $R1->Spawn();
}

if ($run_r2 == 1) {
  $R2 = new PerlACE::Process ("./receiver", "");
  $R2->Spawn();
}

if ($run_r3 == 1) {
  $R3 = new PerlACE::Process ("./receiver", "-delay 2000");
  $R3->Spawn();
}

if ($run_r2 == 1) {
  sleep(5);
  $R2->Kill();
  $R2->Wait();
  print "Killed Receiver 2\n";
}

if ($run_r4 == 1) {
  sleep(25);
  $R4 = new PerlACE::Process ("./receiver", "");
  $R4->Spawn();
}


if ($run_r4 == 1) {
  $R4->Wait();
  $R4->Kill();
}

if ($run_r3 == 1) {
  $R3->Wait();
  $R3->Kill();
}

if ($run_r1 == 1) {
  $R1->Wait();
  $R1->Kill();
}

print "All Receivers completed\n";

$SENDER->Wait();
$status = $SENDER->Kill();
print "Sender completed\n";

exit $status
