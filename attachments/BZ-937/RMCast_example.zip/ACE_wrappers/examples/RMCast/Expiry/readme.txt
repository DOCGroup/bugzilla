This example demonstrates the use of RMCast message and membership expiry mechanisms.

Use the perl script run.pl to run the example.

For example:

perl run.pl -?               : help
perl run.pl -r1              : run with a 'normal' receiver
perl run.pl -r2              : run with a receiver that is killed after 5 seconds
perl run.pl -r3              : run with a 'slow' receiver (sleeps 2 seconds for each message)
perl run.pl -r4              : run with a receiver that starts 25 seconds into the test

Typical tests:
--------------

perl run.pl -r1 -r2          : the first receiver should get all the messages.  Receiver r2 is
                               killed 5 seconds into the run and should only get 5 messages.  The sender
                               should retain messages for 20 seconds after the Receiver r2 is killed
                               at which time it should expire the Receiver r2's proxy and then delete all of the
                               retained messages. See test1.txt

perl run.pl -r1 -r3          : the first receiver should get all the messages.  Receiver r3 should slowly get
                               all of the messages which are retained and resent by the sender.
                               See test2.txt

perl run.pl -r1 -r4 send 40  : the first receiver should get all the messages.  Receiver r4 should miss
                               about the first 25 messages and then join and get about the last 15 messages.
                               See test3.txt

All other combination of options should produce some sort of sensible result.

Message Expiry
--------------

This allows a multicast sender to delete messages after:
a) a time period has expired or;
b) the message has been resent a number of times

The user activates message expiration as follows...

  ACE_Time_Value messageExpirationInterval (2, 0);
  sender.reactive_message_expiration(
      reactor, 
      messageExpirationInterval,     // Check for expired messages every so often...
      100,                           // Delete messages after n resends
      60000                          // Delete messages after n milliseconds
  );

The reactor will fire a timer every 2 seconds which will check for messages that have been resent 100 times or have been held for 60 seconds.

Note that messages will also be deleted if there are no receivers.


Membership Expiry
-----------------

This allows a multicast sender to delete a receiver if it has not acknowledged a message for a certiain time period.  This allows the sender to manager the number of messages that it has to resend if a receiver is not able to reply for any reason.

The user activates membership expiration as follows...

  ACE_Time_Value membershipExpirationInterval (1, 0);
  sender.reactive_membership_expiration(
      reactor, 
      membershipExpirationInterval,  // Check for expired members every so often...
      20000                          // Delete members after n milliseconds without an ACK
  );

The reactor will fire a timer every 1 second which will check for receivers that have gone for 20 seconds without sending an ACK.

TODO
----

The Receiver should wait for incomplete or out-of-sequence messages for user specified time and then give up on them.  Requires change to Reordering and Reassembly. This is the other side of sender Message expiry.


