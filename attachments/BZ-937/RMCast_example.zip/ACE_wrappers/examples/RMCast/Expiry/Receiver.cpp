#include <string>
#include "ace/RMCast/RMCast_UDP_Reliable_Receiver.h"
#include "ace/INET_Addr.h"
#include "ace/FILE_IO.h"
#include "ace/Message_Block.h"
#include "ace/Reactor.h"

ACE_RCSID(tests, RMCast_Examples_Receiver, "Receiver.cpp,v 1.0")

class MyReceiverModule : public ACE_RMCast_Module
{
public:
  MyReceiverModule (int delay);

  /// Return 1 if all the data has been received
  int status (void) const;

  int close (void);
  int data (ACE_RMCast::Data &data);
  int ack_join (ACE_RMCast::Ack_Join &ack_join);
  int ack_leave (ACE_RMCast::Ack_Leave &ack_leave);

private:
  /// Set to 1 when the last block is received
  int status_;

  // millseconds to sleep after receiving a message - to simulate a slow
  // receiver
  int delay_;

};

int
main (int argc, char *argv[])
{
  std::string mcg("224.9.9.2:20001");
  int delay = 0;
  
  for (int i=0; i<argc-1; i++)
  {
    if (std::string(argv[i]) == "-mcg") {
      mcg = argv[i+1];
    } 
    else if (std::string(argv[i]) == "-delay") {
      delay = ACE_OS::atoi(argv[i+1]);
    }
  }
  
  ACE_INET_Addr mcast_group;
  if (mcast_group.set (mcg.c_str()) != 0) {
    ACE_ERROR_RETURN ((LM_ERROR,
      "Cannot set mcast group <%s>\n", mcg.c_str()),
      1);
  }


  MyReceiverModule myReceiverModule(delay);
  ACE_RMCast_UDP_Reliable_Receiver receiver (&myReceiverModule);

  if (receiver.init (mcast_group) == -1)
    {
      ACE_ERROR_RETURN ((LM_ERROR,
                         "Cannot init UDP I/O at <%s:%d> %p\n",
                         mcast_group.get_host_name (),
                         mcast_group.get_port_number (),
                         ""),
                        1);
    }

  // Use the Reactor to demultiplex all the messages
  ACE_Reactor *reactor = ACE_Reactor::instance ();
  receiver.reactive_incoming_messages (reactor);

  // Wait until all the messages are successfully delivered
  do {
      // Try for 50 milliseconds...
      ACE_Time_Value tv (5, 0); // 0, 50000);
      int r = reactor->handle_events (&tv);
      if (r == -1)
        break;
    //ACE_DEBUG ((LM_DEBUG, "(%P|%t) Receiver event loop timeout\n"));
  } while (myReceiverModule.status () != 2);

  ACE_DEBUG ((LM_DEBUG, "(%P|%t) Receiver event loop completed\n"));

  return 0;
}

// ****************************************************************

MyReceiverModule::MyReceiverModule (int delay)
  :  status_ (0),
     delay_  (delay)
{
}

int
MyReceiverModule::status (void) const
{
  return this->status_;
}


int
MyReceiverModule::close (void)
{
  ACE_DEBUG ((LM_DEBUG, "(%P|%t) MyReceiverModule closed\n"));
  return 0;
}

int
MyReceiverModule::data (ACE_RMCast::Data &data)
{
  if (this->status_ != 0)
    return -1;

  if (*(data.payload->rd_ptr ()) == '\0') {
    this->status_ = 1;
    return -1;
  }
  
  //ACE_DEBUG((LM_DEBUG, "(%P|%t) %s", data.payload->rd_ptr ()));
  cout << data.payload->rd_ptr ();

  if (delay_) {
    ACE_Time_Value sleep(0, delay_*1000);
    ACE_OS::sleep(sleep);
  }

  return 0;
}

int
MyReceiverModule::ack_join (ACE_RMCast::Ack_Join &)
{
  ACE_DEBUG ((LM_DEBUG,
              "(%P|%t) MyReceiverModule::ack_join\n"));
  return 0;
}

int
MyReceiverModule::ack_leave (ACE_RMCast::Ack_Leave &)
{
  ACE_DEBUG ((LM_DEBUG,
              "(%P|%t) MyReceiverModule::ack_leave\n"));
  this->status_ = 2;
  return 0;
}
