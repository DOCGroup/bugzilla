// RMCast_UDP_Reliable_Receiver.cpp,v 1.2 2000/10/25 16:54:33 coryan Exp

#include "RMCast_UDP_Reliable_Receiver.h"
#include "RMCast_UDP_Event_Handler.h"
#include "ace/Reactor.h"

#if !defined (__ACE_INLINE__)
# include "RMCast_UDP_Reliable_Receiver.i"
#endif /* ! __ACE_INLINE__ */

ACE_RCSID(ace, RMCast_UDP_Reliable_Receiver, "RMCast_UDP_Reliable_Receiver.cpp,v 1.2 2000/10/25 16:54:33 coryan Exp")

ACE_RMCast_UDP_Reliable_Receiver::ACE_RMCast_UDP_Reliable_Receiver (ACE_RMCast_Module *user_module)
  : user_factory_ (user_module)
  , factory_ (&user_factory_)
  , io_udp_ (&factory_)
{
}

ACE_RMCast_UDP_Reliable_Receiver::~ACE_RMCast_UDP_Reliable_Receiver (void)
{
}

void
ACE_RMCast_UDP_Reliable_Receiver::reactive_incoming_messages (ACE_Reactor *reactor)
{
  ACE_RMCast_UDP_Event_Handler *eh;
  ACE_NEW (eh, ACE_RMCast_UDP_Event_Handler (&this->io_udp_));

  /// @@ TODO Make sure it is removed from the Reactor at some point
  (void) reactor->register_handler (eh, ACE_Event_Handler::READ_MASK);

  ACE_RMCast_UDP_MC_Event_Handler *mc_eh;
  ACE_NEW (mc_eh, ACE_RMCast_UDP_MC_Event_Handler (&this->io_udp_));

  /// @@ TODO Make sure it is removed from the Reactor at some point
  (void) reactor->register_handler (mc_eh, ACE_Event_Handler::READ_MASK);
}
