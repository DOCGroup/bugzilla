//
// RMCast_IO_UDP.cpp,v 1.12 2000/12/20 22:00:33 oci Exp
//

#include "RMCast_IO_UDP.h"
#include "RMCast_UDP_Proxy.h"
#include "RMCast_Module_Factory.h"

#include "ace/Handle_Set.h"
#include "ace/Reactor.h"
#include "ace/Message_Block.h"

#if !defined (__ACE_INLINE__)
# include "RMCast_IO_UDP.i"
#endif /* ! __ACE_INLINE__ */

ACE_RCSID(ace, RMCast_IO_UDP, "RMCast_IO_UDP.cpp,v 1.12 2000/12/20 22:00:33 oci Exp")


ACE_HANDLE
ACE_RMCast_IO_UDP::get_handle (void) const
{
  return this->dgram_.get_handle ();
}

int
ACE_RMCast_IO_UDP::data (ACE_RMCast::Data &data)
{
  return this->send_data (data, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::poll (ACE_RMCast::Poll &poll)
{
  return this->send_poll (poll, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::ack_join (ACE_RMCast::Ack_Join &ack_join)
{
  return this->send_ack_join (ack_join, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::ack_leave (ACE_RMCast::Ack_Leave &ack_leave)
{
  return this->send_ack_leave (ack_leave, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::ack (ACE_RMCast::Ack &ack)
{
  return this->send_ack (ack, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::join (ACE_RMCast::Join &join)
{
  return this->send_join (join, this->mcast_group_);
}

int
ACE_RMCast_IO_UDP::leave (ACE_RMCast::Leave &leave)
{
  return this->send_leave (leave, this->mcast_group_);
}

int 
ACE_RMCast_IO_UDP::send_data (ACE_RMCast::Data &, 
                              const ACE_INET_Addr &)
{
  // The ACE_RMCast_IO_UDP_Sender subclass provide an implementation
  // whereas the ACE_RMCast_IO_UDP_Receiver does not ad will abort.
  ACE_OS::abort();
}

int
ACE_RMCast_IO_UDP::send_poll (ACE_RMCast::Poll &,
                              const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_poll - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_POLL;
  return send_reply(header, 1, to);
}

int
ACE_RMCast_IO_UDP::send_ack_join (ACE_RMCast::Ack_Join &ack_join,
                                  const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_ack_join - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_ACK_JOIN;

  ACE_UINT32 tmp = ACE_HTONL (ack_join.next_sequence_number);
  ACE_OS::memcpy (header + 1,
                  &tmp, sizeof(ACE_UINT32));
  return send_reply(header, 1 + sizeof(ACE_UINT32), to);

}

int
ACE_RMCast_IO_UDP::send_ack_leave (ACE_RMCast::Ack_Leave &,
                                   const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_ack_leave - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_ACK_LEAVE;
  return send_reply(header, 1, to);
}

int
ACE_RMCast_IO_UDP::send_ack (ACE_RMCast::Ack &ack,
                              const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_ack - pushing (%d:%d) out to <%s:%d>\n",
              ack.next_expected,
              ack.highest_received,
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_ACK;

  ACE_UINT32 tmp = ACE_HTONL (ack.next_expected);
  ACE_OS::memcpy (header + 1,
                  &tmp, sizeof(ACE_UINT32));
  tmp = ACE_HTONL (ack.highest_received);
  ACE_OS::memcpy (header + 1 + sizeof(ACE_UINT32),
                  &tmp, sizeof(ACE_UINT32));
  return send_reply(header, 1 + 2*sizeof(ACE_UINT32), to);
}

int
ACE_RMCast_IO_UDP::send_join (ACE_RMCast::Join &,
                              const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_join - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_JOIN;
  return send_reply(header, 1, to);
}

int
ACE_RMCast_IO_UDP::send_leave (ACE_RMCast::Leave &,
                               const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP::send_leave - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  char header[16];
  header[0] = ACE_RMCast::MT_LEAVE;
  return send_reply(header, 1, to);
}

ssize_t 
ACE_RMCast_IO_UDP::send_reply (const void *buf,
                                      size_t n,
                                      const ACE_Addr &addr,
                                      int flags)
{
  if (dgram_.send (buf, n, addr, flags) == -1) 
  {
    return -1;
  }

  return 0;
}

//------------------------------------------------------------------------------
// ACE_RMCast_IO_UDP_Sender
//------------------------------------------------------------------------------

int
ACE_RMCast_IO_UDP_Sender::init (const ACE_INET_Addr &mcast_group,
                                const ACE_Addr &local,
                                int protocol_family,
                                int protocol,
                                int reuse_addr)
{
  this->mcast_group_ = mcast_group;
  return dgram_.open (local, protocol_family, protocol, reuse_addr);
}

int
ACE_RMCast_IO_UDP_Sender::handle_input (ACE_HANDLE h)
{
  // @@ We should use a system constant instead of this literal
  const int max_udp_packet_size = 65536;
  char buffer[max_udp_packet_size];
  
  ACE_INET_Addr from_address;
  ssize_t r = this->dgram_.recv (buffer, sizeof(buffer), from_address);

  ACE_DEBUG ((LM_DEBUG,
    "IO_UDP_Sender::handle_input: Message from <%s:%d>\n",
    from_address.get_host_addr (),
    from_address.get_port_number ()));

  if (r == -1)
  {
    // @@ LOG??
    ACE_ERROR ((LM_ERROR,
                "IO_UDP_Sender::handle_input () - error in recv %p\n",
                ACE_TEXT ("")));
    return -1;
  }

  ACE_HEX_DUMP ((LM_DEBUG, buffer, ace_min<int>(r, 32), "IO_UDP_Sender::handle_input"));
  ACE_DEBUG ((LM_DEBUG, "\n"));

  // @@ Locking!

  int type = buffer[0];

  if (type < 0 
  ||  type >= ACE_RMCast::MT_LAST
  ||  type == ACE_RMCast::MT_POLL
  ||  type == ACE_RMCast::MT_ACK_JOIN
  ||  type == ACE_RMCast::MT_ACK_LEAVE
  ||  type == ACE_RMCast::MT_DATA)
  {
    ACE_RMCast_UDP_Proxy *proxy;
    if (this->map_.unbind (from_address, proxy) == 0)
    {
      ACE_DEBUG ((LM_DEBUG,
        "IO_UDP_Sender::process_message - bad message from <%s:%d>\n",
        from_address.get_host_addr (),
        from_address.get_port_number ()));
      ACE_DEBUG ((LM_DEBUG,
        "IO_UDP_Sender::process_message - deleting proxy\n"));
      this->factory_->destroy (proxy->next ());
      delete proxy;
    }
    return 0;
  }

  ACE_RMCast_UDP_Proxy *proxy;
  if (this->map_.find (from_address, proxy) != 0)
    {
      ACE_DEBUG ((LM_DEBUG,
                  "IO_UDP_Sender::handle_input - new proxy for <%s:%d>\n",
                  from_address.get_host_addr (),
                  from_address.get_port_number ()));

      // @@ We should validate the message *before* creating the
      // object, all we need is some sort of validation strategy, a
      // different one for the receiver and another one for the
      // sender.
 
      ACE_RMCast_Module *module = this->factory_->create ();
      if (module == 0)
      {
        // @@ LOG??
        // Try to continue working, maybe the module can be created
        // later.
        return 0;
      }
      // This is necessary to satisfy the xgcc for Lynx on Solaris
      // by including the code directly causes :
      // RMCast_IO_UDP.cpp:202: error: internal error--unrecognizable insn:
      // (insn 1510 1507 524 (set (mem:SI (plus:SI (reg:SI 28 r28)
      //                 (const_int 65536)))
      //         (reg:SI 0 r0)) -1 (insn_list 528 (insn_list 1507 (nil)))
      //     (nil))
      // /usr/lynx/home2/jose/98r2/src/gcc/toplev.c:1489: Internal compiler error in function fatal_insn
      // to be thrown at the end of the function.
      if ((proxy = allocate_proxy(module,from_address)) == 0)
        return 0;  // error

      if (bind_proxy(proxy,from_address) != 0)
        return 0; // error
    }
  
  // Have the proxy process the message and do the right thing.
  if (proxy->receive_message (buffer, r) != 0) {
    (void) this->map_.unbind (from_address);
    this->factory_->destroy (proxy->next ());
    delete proxy;
  }

  return 0;
}

int
ACE_RMCast_IO_UDP_Sender::send_data (ACE_RMCast::Data &data,
                                     const ACE_INET_Addr &to)
{
  ACE_DEBUG ((LM_DEBUG,
              "IO_UDP_Sender::send_data - pushing out to <%s:%d>\n",
              to.get_host_addr (),
              to.get_port_number ()));

  // The first message block contains the header
  // @@ TODO: We could keep the header pre-initialized, and only
  // update the portions that do change...
  ACE_UINT32 tmp;
  char header[1 + 3 * sizeof(ACE_UINT32)];
  header[0] = ACE_RMCast::MT_DATA;

  tmp = ACE_HTONL (data.sequence_number);
  ACE_OS::memcpy (header + 1,
                  &tmp, sizeof(ACE_UINT32));
  tmp = ACE_HTONL (data.total_size);
  ACE_OS::memcpy (header + 1 + sizeof(ACE_UINT32),
                  &tmp, sizeof(ACE_UINT32));
  tmp = ACE_HTONL (data.fragment_offset);
  ACE_OS::memcpy (header + 1 + 2 * sizeof(ACE_UINT32),
                  &tmp, sizeof(ACE_UINT32));

  iovec iov[IOV_MAX];
  int iovcnt = 1;

  iov[0].iov_base = header;
  iov[0].iov_len = sizeof(header);

  ACE_Message_Block *mb = data.payload;

  for (const ACE_Message_Block *i = mb; i != 0; i = i->cont ())
    {
      iov[iovcnt].iov_base = i->rd_ptr ();
      iov[iovcnt].iov_len = i->length ();
      iovcnt++;
      if (iovcnt >= IOV_MAX)
        return -1;
    }

  // @@ This pacing stuff here reduced the number of packet lost in
  // loopback tests, but it should be taken out for real applications
  // (or at least made configurable!)
  //ACE_Time_Value tv (0, 10000);
  //ACE_OS::sleep (tv);

  if (dgram_.send (iov, iovcnt, to) == -1)
    return -1;

  return 0;
}

//------------------------------------------------------------------------------
// Receiver
//------------------------------------------------------------------------------

int
ACE_RMCast_IO_UDP_Receiver::subscribe (const ACE_INET_Addr &mcast_addr,
                                       int reuse_addr,
                                       const ACE_TCHAR *net_if,
                                       int protocol_family,
                                       int protocol)
{
  this->mcast_group_ = mcast_addr;
  return this->mc_dgram_.subscribe (mcast_addr,
                                    reuse_addr,
                                    net_if,
                                    protocol_family,
                                    protocol);
}

int
ACE_RMCast_IO_UDP_Receiver::handle_mc_input (ACE_HANDLE)
{
  // @@ We should use a system constant instead of this literal
  const int max_udp_packet_size = 65536;
  char buffer[max_udp_packet_size];

  ACE_INET_Addr from_address;
  ssize_t r;

  r = this->mc_dgram_.recv (buffer, sizeof(buffer), from_address);
  ACE_DEBUG ((LM_DEBUG,
    "IO_UDP_Receiver::handle_mc_input - message from <%s:%d>\n",
    from_address.get_host_addr (),
    from_address.get_port_number ()));

  return process_message(buffer, r, from_address);
}


int
ACE_RMCast_IO_UDP_Receiver::handle_input (ACE_HANDLE)
{
  // @@ We should use a system constant instead of this literal
  const int max_udp_packet_size = 65536;
  char buffer[max_udp_packet_size];

  ACE_INET_Addr from_address;
  ssize_t r = this->dgram_.recv (buffer, sizeof(buffer), from_address);
  ACE_DEBUG ((LM_DEBUG,
    "IO_UDP_Receiver::handle_input - message from <%s:%d>\n",
    from_address.get_host_addr (),
    from_address.get_port_number ()));

  return process_message(buffer, r, from_address);
}


int 
ACE_RMCast_IO_UDP_Receiver::process_message (char *buffer, size_t size, ACE_INET_Addr from_address)
{
  if (size == -1)
  {
    // @@ LOG??
    ACE_ERROR ((LM_ERROR,
      "IO_UDP_Receiver::process_message () - error in recv %p\n",
      ACE_TEXT ("")));
    return -1;
  }
  
  ACE_HEX_DUMP ((LM_DEBUG, buffer, ace_min<int>(size, 32), "IO_UDP_Receiver::process_message"));
  ACE_DEBUG ((LM_DEBUG, "\n"));
  
  // @@ Locking!
  
  int type = buffer[0];
  
  if (type < 0 
  ||  type >= ACE_RMCast::MT_LAST
  ||  type == ACE_RMCast::MT_ACK
  ||  type == ACE_RMCast::MT_JOIN
  ||  type == ACE_RMCast::MT_LEAVE)
  {
    // All these message types indicate a problem, the should be
    // generated by receivers, not received by them.
    ACE_DEBUG ((LM_DEBUG,
        "IO_UDP_Receiver::process_message - bad message from <%s:%d>\n",
        from_address.get_host_addr (),
        from_address.get_port_number ()));
    this->factory_->destroy (sender_proxy_->next ());
    delete sender_proxy_;
    sender_proxy_ = 0;

    // Abort for now....
    ACE_DEBUG ((LM_DEBUG,
        "IO_UDP_Receiver::process_message - aborting\n"));
    ACE_OS::abort(); 
    return -1;
  }
  
  if (sender_proxy_) 
  {
    if (sender_addr_ != from_address) 
    {
       ACE_DEBUG ((LM_DEBUG,
        "IO_UDP_Receiver::process_message - destroying old proxy for <%s:%d>\n",
        sender_addr_.get_host_addr (),
        sender_addr_.get_port_number ()));

       this->factory_->destroy (sender_proxy_->next ());
       delete sender_proxy_;
       sender_proxy_ = 0;
       sender_addr_ = 0;
    }
  }

  if (!sender_proxy_) 
  {
    ACE_DEBUG ((LM_DEBUG,
      "IO_UDP_Receiver::process_message - new proxy for <%s:%d>\n",
      from_address.get_host_addr (),
      from_address.get_port_number ()));
    
    ACE_RMCast_Module *module = this->factory_->create ();
    if (module == 0)
    {
      // @@ LOG??
      // Try to continue working, maybe the module can be created
      // later.
      return -1;
    }
    if ((sender_proxy_ = allocate_proxy(module,from_address)) == 0)
      return -1;
    sender_addr_ = from_address;
  }
  
  // Have the proxy process the message and do the right thing.
  if (sender_proxy_->receive_message (buffer, size) != 0)
  {
    this->factory_->destroy (sender_proxy_->next ());
    delete sender_proxy_;
    sender_proxy_ = 0;
    return -1;
  }

  return 0;
}

ACE_HANDLE
ACE_RMCast_IO_UDP_Receiver::get_mc_handle (void) const
{
  return this->mc_dgram_.get_handle ();
}

#if defined (ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION)

template class ACE_Hash_Map_Manager<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Null_Mutex>;
template class ACE_Hash_Map_Manager_Ex<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Hash<ACE_INET_Addr>,ACE_Equal_To<ACE_INET_Addr>,ACE_Null_Mutex>;
template class ACE_Hash_Map_Iterator<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Null_Mutex>;
template class ACE_Hash_Map_Iterator_Ex<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Hash<ACE_INET_Addr>,ACE_Equal_To<ACE_INET_Addr>,ACE_Null_Mutex>;
template class ACE_Hash_Map_Reverse_Iterator_Ex<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Hash<ACE_INET_Addr>,ACE_Equal_To<ACE_INET_Addr>,ACE_Null_Mutex>;
template class ACE_Hash_Map_Iterator_Base_Ex<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*,ACE_Hash<ACE_INET_Addr>,ACE_Equal_To<ACE_INET_Addr>,ACE_Null_Mutex>;
template class ACE_Hash_Map_Entry<ACE_INET_Addr,ACE_RMCast_UDP_Proxy*>;

template class ACE_Equal_To<ACE_INET_Addr>;
template class ACE_Hash<ACE_INET_Addr>;

#endif /* ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION */
