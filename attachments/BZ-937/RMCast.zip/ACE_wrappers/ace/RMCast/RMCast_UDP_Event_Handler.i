// RMCast_UDP_Event_Handler.i,v 1.2 2000/08/21 16:09:36 coryan Exp

ACE_INLINE
ACE_RMCast_UDP_Event_Handler::
ACE_RMCast_UDP_Event_Handler (ACE_RMCast_IO_UDP *io)
  :  io_udp_ (io)
{
}

ACE_INLINE
ACE_RMCast_UDP_MC_Event_Handler::
ACE_RMCast_UDP_MC_Event_Handler (ACE_RMCast_IO_UDP_Receiver *io)
  :  io_udp_receiver_ (io)
{
}
