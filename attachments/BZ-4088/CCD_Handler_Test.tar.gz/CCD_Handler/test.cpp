// $Id$

#include <iostream>

#include "Deployment.hpp"
#include "tools/Config_Handlers/CCD_Handler.h"
#include "tools/Config_Handlers/XML_File_Intf.h"
#include "dance/Deployment/Deployment_Packaging_DataC.h"
#include "ace/Get_Opt.h"
#include "tao/ORB.h"
#include "ace/XML_Utils/XML_Typedefs.h"
#include "Utils/Exceptions.h"

static const char *input_file = "Foo.ccd";

static int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "i:");

  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'i':
        input_file = get_opts.opt_arg ();
        break;
      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-i <input file> "
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates successful parsing of the command-line
  return 0;
}

using namespace DAnCE::Config_Handlers;


int ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  try
    {
      if (parse_args (argc, argv) != 0)
        return 1;

      // Initialize an ORB so Any will work
      CORBA::ORB_ptr orb = CORBA::ORB_init (argc, argv);
      ACE_UNUSED_ARG (orb);


      if (xercesc::DOMDocument *doc = XML::XML_Typedef::XML_HELPER.create_dom (input_file))
        {

          XERCES_CPP_NAMESPACE::DOMElement *foo = doc->getDocumentElement ();

          ::XSCRT::XML::Element< ACE_TCHAR > e (foo);
          if (e.name () == ACE_TEXT("componentInterfaceDescription"))
            {
              ::DAnCE::Config_Handlers::ComponentInterfaceDescription r (e);
              ::Deployment::ComponentInterfaceDescription idl_ccd;

              //Convert the XSC to an IDL datatype
              CCD_Handler::component_interface_descr (r, idl_ccd);
              std::cout << "Instance document import succeeded.\n";
            }
          else
            {
              std::cerr << "Config Error : Wrong root element." << std::endl;
            }
        }
      else
        {
          std::cerr << "Parse Error : open " << input_file << " faild\n";
        }
    }
  catch (DAnCE::Config_Handlers::Parse_Error &excep)
    {
      std::cerr << "Parse Error :" << excep.reason_ << std::endl;
    }


  return 0;
}


