#include "Char_GB2312_UTF8_Factory.h"

#if defined (ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION)

template class TAO_Codeset_Translator_Factory_T<GB2312_UTF8>;

#elif defined (ACE_HAS_TEMPLATE_INSTANTIATION_PRAGMA)

#pragma instantiate TAO_Codeset_Translator_Factory_T<GB2312_UTF8>

#endif /* ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION */

ACE_STATIC_SVC_DEFINE (Char_GB2312_UTF8_Factory,
                       ACE_TEXT ("Char_GB2312_UTF8_Factory"),
                       ACE_SVC_OBJ_T,
                       &ACE_SVC_NAME (Char_GB2312_UTF8_Factory),
                       ACE_Service_Type::DELETE_THIS
                       | ACE_Service_Type::DELETE_OBJ,
                       0)
ACE_FACTORY_DEFINE (GB2312_UTF8, Char_GB2312_UTF8_Factory)
