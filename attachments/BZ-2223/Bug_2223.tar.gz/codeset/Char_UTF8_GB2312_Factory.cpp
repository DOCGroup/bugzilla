#include "Char_UTF8_GB2312_Factory.h"

#if defined (ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION)

template class TAO_Codeset_Translator_Factory_T<UTF8_GB2312>;

#elif defined (ACE_HAS_TEMPLATE_INSTANTIATION_PRAGMA)

#pragma instantiate TAO_Codeset_Translator_Factory_T<UTF8_GB2312>

#endif /* ACE_HAS_EXPLICIT_TEMPLATE_INSTANTIATION */

ACE_STATIC_SVC_DEFINE (Char_UTF8_GB2312_Factory,
                       ACE_TEXT ("Char_UTF8_GB2312_Factory"),
                       ACE_SVC_OBJ_T,
                       &ACE_SVC_NAME (Char_UTF8_GB2312_Factory),
                       ACE_Service_Type::DELETE_THIS
                       | ACE_Service_Type::DELETE_OBJ,
                       0)
ACE_FACTORY_DEFINE (UTF8_GB2312, Char_UTF8_GB2312_Factory)
