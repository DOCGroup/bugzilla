#ifndef TAO_CHAR_GB2312_UTF8_TRANSLATOR_H
#define TAO_CHAR_GB2312_UTF8_TRANSLATOR_H
#include /**/ "ace/pre.h"

#include "ace/config-all.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#include "ace/CDR_Stream.h"
#include "GB2312_UTF8_export.h"
#include "iconv.h"

//TAO_BEGIN_VERSIONED_NAMESPACE_DECL

class GB2312_UTF8_Export GB2312_UTF8 
  : public ACE_Char_Codeset_Translator
{
public:
  GB2312_UTF8 (void);
  virtual ~GB2312_UTF8 (void);

  virtual ACE_CDR::Boolean read_char (ACE_InputCDR &,
                                      ACE_CDR::Char &);
  virtual ACE_CDR::Boolean read_string (ACE_InputCDR &,
                                        ACE_CDR::Char *&);
  virtual ACE_CDR::Boolean read_char_array (ACE_InputCDR &,
                                            ACE_CDR::Char *,
                                            ACE_CDR::ULong);
  virtual ACE_CDR::Boolean write_char (ACE_OutputCDR &,
                                       ACE_CDR::Char);
  virtual ACE_CDR::Boolean write_string (ACE_OutputCDR &,
                                         ACE_CDR::ULong,
                                         const ACE_CDR::Char *);
  virtual ACE_CDR::Boolean write_char_array (ACE_OutputCDR &,
                                             const ACE_CDR::Char *,
                                             ACE_CDR::ULong);
  virtual ACE_CDR::ULong tcs () {return 0x05010001;}
  virtual ACE_CDR::ULong ncs () {return 0x10020567;}

private:
  iconv_t gb2312_to_utf8_;
  iconv_t utf8_to_gb2312_;
};

//TAO_END_VERSIONED_NAMESPACE_DECL

#include /**/ "ace/post.h"
#endif /* TAO_CHAR_GB2312_UTF8_TRANSLATOR_H */

