
// -*- C++ -*-
// $Id$
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl GB2312_UTF8
// ------------------------------
#ifndef GB2312_UTF8_EXPORT_H
#define GB2312_UTF8_EXPORT_H

#include "ace/config-all.h"

#if !defined (GB2312_UTF8_HAS_DLL)
#  define GB2312_UTF8_HAS_DLL 1
#endif /* ! GB2312_UTF8_HAS_DLL */

#if defined (GB2312_UTF8_HAS_DLL) && (GB2312_UTF8_HAS_DLL == 1)
#  if defined (GB2312_UTF8_BUILD_DLL)
#    define GB2312_UTF8_Export ACE_Proper_Export_Flag
#    define GB2312_UTF8_SINGLETON_DECLARATION(T) ACE_EXPORT_SINGLETON_DECLARATION (T)
#    define GB2312_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_EXPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  else /* GB2312_UTF8_BUILD_DLL */
#    define GB2312_UTF8_Export ACE_Proper_Import_Flag
#    define GB2312_UTF8_SINGLETON_DECLARATION(T) ACE_IMPORT_SINGLETON_DECLARATION (T)
#    define GB2312_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_IMPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  endif /* GB2312_UTF8_BUILD_DLL */
#else /* GB2312_UTF8_HAS_DLL == 1 */
#  define GB2312_UTF8_Export
#  define GB2312_UTF8_SINGLETON_DECLARATION(T)
#  define GB2312_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#endif /* GB2312_UTF8_HAS_DLL == 1 */

// Set GB2312_UTF8_NTRACE = 0 to turn on library specific tracing even if
// tracing is turned off for ACE.
#if !defined (GB2312_UTF8_NTRACE)
#  if (ACE_NTRACE == 1)
#    define GB2312_UTF8_NTRACE 1
#  else /* (ACE_NTRACE == 1) */
#    define GB2312_UTF8_NTRACE 0
#  endif /* (ACE_NTRACE == 1) */
#endif /* !GB2312_UTF8_NTRACE */

#if (GB2312_UTF8_NTRACE == 1)
#  define GB2312_UTF8_TRACE(X)
#else /* (GB2312_UTF8_NTRACE == 1) */
#  if !defined (ACE_HAS_TRACE)
#    define ACE_HAS_TRACE
#  endif /* ACE_HAS_TRACE */
#  define GB2312_UTF8_TRACE(X) ACE_TRACE_IMPL(X)
#  include "ace/Trace.h"
#endif /* (GB2312_UTF8_NTRACE == 1) */

#endif /* GB2312_UTF8_EXPORT_H */

// End of auto generated file.
