#ifndef CHAR_UTF8_GB2312_FACTORY_H
#define CHAR_UTF8_GB2312_FACTORY_H

#include /**/ "ace/pre.h"
#include "ace/Service_Config.h"
#include "tao/Codeset_Translator_Factory.h"

#include "UTF8_GB2312_export.h"
#include "Char_UTF8_GB2312_Translator.h"

TAO_BEGIN_VERSIONED_NAMESPACE_DECL

typedef TAO_Codeset_Translator_Factory_T<UTF8_GB2312> Char_UTF8_GB2312_Factory;

TAO_END_VERSIONED_NAMESPACE_DECL

ACE_STATIC_SVC_DECLARE_EXPORT (UTF8_GB2312, Char_UTF8_GB2312_Factory)
ACE_FACTORY_DECLARE (UTF8_GB2312, Char_UTF8_GB2312_Factory)

#include /**/ "ace/post.h"
#endif /* TAO_CHAR_UTF8_GB2312_FACTORY_H */
