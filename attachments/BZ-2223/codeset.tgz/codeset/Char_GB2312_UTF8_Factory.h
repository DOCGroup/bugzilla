#ifndef CHAR_GB2312_UTF8_FACTORY_H
#define CHAR_GB2312_UTF8_FACTORY_H

#include /**/ "ace/pre.h"
#include "ace/Service_Config.h"
#include "tao/Codeset_Translator_Factory.h"

#include "GB2312_UTF8_export.h"
#include "Char_GB2312_UTF8_Translator.h"

//TAO_BEGIN_VERSIONED_NAMESPACE_DECL

typedef TAO_Codeset_Translator_Factory_T<GB2312_UTF8> Char_GB2312_UTF8_Factory;

//TAO_END_VERSIONED_NAMESPACE_DECL

ACE_STATIC_SVC_DECLARE_EXPORT (GB2312_UTF8, Char_GB2312_UTF8_Factory)
ACE_FACTORY_DECLARE (GB2312_UTF8, Char_GB2312_UTF8_Factory)

#include /**/ "ace/post.h"
#endif /* TAO_CHAR_GB2312_UTF8_FACTORY_H */

