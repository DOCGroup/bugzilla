#include "Char_UTF8_GB2312_Translator.h"
#include "ace/OS_Memory.h"
#include "ace/OS_NS_string.h"
#include "ace/Auto_Ptr.h"
#include "ace/Log_Msg.h"

//TAO_BEGIN_VERSIONED_NAMESPACE_DECL

UTF8_GB2312::UTF8_GB2312 (void)
{
  gb2312_to_utf8_ = iconv_open("UTF-8","GB2312");
  utf8_to_gb2312_ = iconv_open("GB2312","UTF-8");
}

UTF8_GB2312::~UTF8_GB2312 (void)
{
  iconv_close(gb2312_to_utf8_);
  iconv_close(utf8_to_gb2312_);
}

ACE_CDR::Boolean
UTF8_GB2312::read_char (ACE_InputCDR &in, ACE_CDR::Char &out)
{
  if (out < 0)
    return 0;

  return read_1 (in,reinterpret_cast<ACE_CDR::Octet*>(&out));
}

ACE_CDR::Boolean
UTF8_GB2312::read_string (ACE_InputCDR& in, ACE_CDR::Char *& out)
{
  ACE_CDR::ULong from_len,to_len;
  in.read_ulong (from_len);

  if (from_len == 0)
    return 0;

  to_len = from_len + from_len / 2;
  
  ACE_CDR::Char *to_buf ,*from_buf;

  ACE_NEW_RETURN (to_buf,
                  ACE_CDR::Char[to_len],
                  0);

  ACE_Auto_Array_Ptr<ACE_CDR::Char> auto_free_buf(to_buf);
  from_buf = to_buf + to_len - from_len;

  ACE_CDR::Boolean ra_r = read_array (in,
                                      from_buf,
                                      ACE_CDR::OCTET_SIZE,
                                      ACE_CDR::OCTET_ALIGN,
                                      from_len);
  if (ra_r == 0)
    return 0;

  const char * buf_end = from_buf + from_len;

  size_t iconv_r = iconv (gb2312_to_utf8_,
#if defined (ACE_WIN32)
                          const_cast<const char**>(&from_buf),
#else
                          &from_buf,
#endif
                          &from_len,
                          &to_buf,
                          &to_len); 

  if (iconv_r == (size_t)-1)
    {
      ACE_DEBUG ((LM_DEBUG,
                  "[UTF8_GB2312::read_string] iconv:%m\n"));
      ACE_LOG_MSG->log_hexdump (LM_DEBUG,
                                from_buf,
                                buf_end - from_buf);
      return 0;
    }

  out = auto_free_buf.release();
  return 1;
}

ACE_CDR::Boolean
UTF8_GB2312::read_char_array (ACE_InputCDR& in,
                              ACE_CDR::Char* out,
                              ACE_CDR::ULong len)
{
  ACE_CDR::Boolean ra_r = read_array (in,
                                      out,
                                      ACE_CDR::OCTET_SIZE,
                                      ACE_CDR::OCTET_ALIGN,
                                      len);
  if (ra_r == 0)
    return 0;

  for(ACE_CDR::ULong c = 0; c < len; ++c)
    {
      if(out[c] < 0)
        return 0;
    }

  return 1;
}

ACE_CDR::Boolean
UTF8_GB2312::write_char (ACE_OutputCDR& out, ACE_CDR::Char in)
{
  if (in < 0)
    return 0; 

  return write_1 (out,reinterpret_cast<ACE_CDR::Octet*>(&in));
}

ACE_CDR::Boolean
UTF8_GB2312::write_string ( ACE_OutputCDR& out,
                            ACE_CDR::ULong len, 
                            const ACE_CDR::Char* in)
{
  ACE_CDR::Char * to_buf;
  ACE_CDR::ULong to_len = len + 1;

  int stat = 0;
  for ( ACE_CDR::ULong c = 0; c < len; ++c )
    {
      switch (stat)
        {
          case 0: 
            if (in[c] >= 0)
              break;
            else if ((in[c] & 0xF0) == 0xE0)
              {
                stat = 2;
                --to_len;
              }
            else if ((in[c] & 0xF0) == 0xC0)
              stat = 1;
            else
              return 0;

            break;

          case 1:
          case 2:
            if ((in[c] & 0xC0) != 0x80) 
              return 0;

            --stat;
            break;
        }
    }

  if (stat)
    return 0;

  if(!out.write_ulong (to_len))
    return 0;

  if (this->adjust (out, to_len, 1, to_buf) == -1)
    {
      this->good_bit(out, 0);
      return 0;
    }

  size_t from_len = len;
  size_t iconv_r = iconv (utf8_to_gb2312_,
#if !defined (ACE_WIN32)
                          const_cast<ACE_CDR::Char**>(&in),
#else
                          &in,
#endif
                          &from_len,
                          &to_buf,
                          &to_len);

  if ((size_t)(-1) == iconv_r)
    {
      this->good_bit(out, 0);
      ACE_DEBUG ((LM_DEBUG,
                  "[UTF8_GB2312::write_string] iconv:%m\n"));
      ACE_LOG_MSG->log_hexdump (LM_DEBUG,
                                in,
                                len - from_len);

      this->good_bit(out, 0);
      return 0;
    }

  if (to_len)
    {
      to_buf[0] = 0;
      return 1;
    }
  else
    {
      ACE_DEBUG((LM_DEBUG,"to_len too small.\n"));
      this->good_bit(out,0);
      return 0;
    }
}

ACE_CDR::Boolean
UTF8_GB2312::write_char_array ( ACE_OutputCDR & out,
                                const ACE_CDR::Char * in, 
                                ACE_CDR::ULong len)
{
  char *buf = NULL;

  for (ACE_CDR::ULong c = 0; c < len; ++c)
    {
      if (in[c] < 0) 
        return 0;
    }

  if (this->adjust (out, len, 1, buf) == 0)
    {
      ACE_OS::memcpy (buf, in, len);
      return 1;
    }
  else 
    {
      this->good_bit(out, 0);
      return 0;
    }
}

//TAO_END_VERSIONED_NAMESPACE_DECL

