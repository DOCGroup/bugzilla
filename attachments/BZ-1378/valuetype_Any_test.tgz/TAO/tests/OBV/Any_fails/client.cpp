// client.cpp,v 1.2 2002/01/29 20:21:08 okellogg Exp

#include "ace/Get_Opt.h"

#include <orbsvcs/CosEventCommS.h>
#include <orbsvcs/CosEventChannelAdminS.h>

#include "AnyC.h"
#include "OrocosObjectC.h"
#include "OrocosObject_i.h"

#include "TimeValue2_i.h"

// valuetype implementation.

#include "Any_i.h"

//using namespace OROCOS;

ACE_RCSID(Any, client, "client.cpp,v 1.2 2002/01/29 20:21:08 okellogg Exp")

const char *ior = "file://test.ior";
const char *eCior = "file://ec.ior";

// magic values used for tests
const CORBA::ULong magic = 3145;
const CORBA::ULong magic2 = 0xAABBCCDD;
const CORBA::ULong magic3 = 0x11223344;


void printAny(const CORBA::Any & event)
{
  OROCOS::TimeValue * tv = 0;
  OROCOS::TimeValue2 * tv2 = 0;
  OBV_AnyTest::VA * vatmp = 0;
  OBV_AnyTest::VB * vbtmp = 0;
  OBV_AnyTest::VZ * vztmp = 0;
  if (event >>= tv2) {
//    cout << " received TimeValue2: ";
//    tv2->dump();
//    cout << endl;
  }else if (event >>= tv) {
//    cout << " received TimeValue: ";
//    tv->dump();
//    cout << endl;
  } else if (event >>= vbtmp) {
//    cout << " received VB: ";
//    vbtmp->do_print();
//    cout << endl;
  } else if (event >>= vatmp) {
//    cout << " received VA: ";
//    vatmp->do_print();
//    cout << endl;
  } else if (event >>= vztmp) {
//    cout << " received VZ: ";
//    vztmp->do_print();
//    cout << endl;
  } else {
//    cout << "Consumer: extract failed! any: ";
    CORBA::TypeCode *tc = event.type();
    if (tc) {
      ACE_DEBUG((LM_DEBUG, "type:%s, id:%s\n", tc->name(),  tc->id()));
    } else {
      ACE_DEBUG((LM_DEBUG,"could not get typecode\n"));
    }
  }
}

class Consumer : public POA_CosEventComm::PushConsumer
{
  // = TITLE
  //   Simple consumer object
  //
  // = DESCRIPTION
  //   This class is a consumer of events.
  //

  int event_count;

public:

  Consumer()
    : event_count(0) {};
  void push (const CORBA::Any & event
	     ACE_ENV_ARG_DECL_NOT_USED)
    ACE_THROW_SPEC ((CORBA::SystemException))
    {
      printAny(event);

      this->event_count ++;
      if (this->event_count % 100 == 0)
      {
	ACE_DEBUG ((LM_DEBUG,
		    "Consumer (%P|%t): %d events received\n",
		    this->event_count));
      }
    };

  void
  Consumer::disconnect_push_consumer (ACE_ENV_SINGLE_ARG_DECL)
    ACE_THROW_SPEC ((CORBA::SystemException))
    {
      // In this example we shutdown the ORB when we disconnect from the
      // EC (or rather the EC disconnects from us), but this doesn't have
      // to be the case....
//      this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
      cerr << "consumer: disconnect_push_consumer" << endl;
    };

};

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "k:e:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'k':
        ior = get_opts.optarg;
        break;
      case 'e':
        eCior = get_opts.optarg;
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-k <ior>  OBV_Any Servant"
                           "-e <ior>  Event channel"
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}

void ecTest(CORBA::ORB_var & orb)
{
  // connect to eventchannel

  Consumer my_consumer;

  CORBA::Object_var object =
    orb->resolve_initial_references ("RootPOA" ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;
  PortableServer::POA_var poa =
    PortableServer::POA::_narrow (object.in () ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;
  PortableServer::POAManager_var poa_manager =
    poa->the_POAManager (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;
  poa_manager->activate (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;
  // Obtain the event channel, we could use a naming service, a
  // command line argument or resolve_initial_references(), but
  // this is simpler...
  object =
    orb->string_to_object(eCior ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  ACE_DEBUG ((LM_DEBUG, "(%P|%t) client - got potential EC from file.\n"));

  CosEventChannelAdmin::EventChannel_var event_channel =
    CosEventChannelAdmin::EventChannel::_narrow (object.in ()
						 ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

      // The canonical protocol to connect to the EC
  CosEventChannelAdmin::ConsumerAdmin_var consumer_admin =
    event_channel->for_consumers (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;

  ACE_DEBUG ((LM_DEBUG, "(%P|%t) client - it is a EC object.\n"));

  CosEventChannelAdmin::ProxyPushSupplier_var supplier =
    consumer_admin->obtain_push_supplier (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;

  CosEventComm::PushConsumer_var consumer =
    my_consumer._this (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;

  supplier->connect_push_consumer (consumer.in () ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  ACE_DEBUG ((LM_DEBUG, "(%P|%t) client - consumer connected.\n"));

  orb->run();
}

int directTest(CORBA::ORB_var & orb)
{

  // Obtain reference to the object

  CORBA::Object_var tmp =
    orb->string_to_object(ior ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  OBV_AnyTest::Test_var test =
    OBV_AnyTest::Test::_narrow(tmp.in () ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  if (CORBA::is_nil (test.in ()))
  {
    ACE_ERROR_RETURN ((LM_DEBUG,
		       "Nil OBV_AnyTest::Test reference <%s>\n",
		       ior),
		      1);
  }

  ACE_DEBUG((LM_DEBUG, "Running remote tests\n"));
  // Now do remote test
  // STEP 1.
  OBV_AnyTest::VA * dst = 0;
  CORBA::Any_var result = test->get_something (
    0
    ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  if (!(*result >>= dst) || dst->id () != magic)
  {
    ACE_ERROR_RETURN ((LM_DEBUG,
		       "(%P|%t) client - test failed.\n"),
		      1);
  }

  // STEP 2.
  OBV_AnyTest::VB* dst_vb = 0;
  result = test->get_something (
    1
    ACE_ENV_ARG_PARAMETER);
  ACE_TRY_CHECK;

  if (!(*result >>= dst_vb) || dst_vb->id () != magic)
  {
    ACE_ERROR_RETURN ((LM_DEBUG,
		       "(%P|%t) client - test failed.\n"),
		      1);
  }

    {
    // STEP 3.
    // TimeValue2 -- works
    OROCOS::TimeValue2* dst_tv = 0;
    result = test->get_something (
      3
      ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;

    if (!(*result >>= dst_tv) )
    {
      CORBA::TypeCode *tc = result->type();
      if (tc) {
	ACE_DEBUG((LM_DEBUG, "type:%s, id:%s\n", tc->name(),  tc->id()));
      } else {
	ACE_DEBUG((LM_DEBUG, "Could not obtain typecode"));
      }
      ACE_ERROR_RETURN ((LM_DEBUG,
			 "(%P|%t) client - test failed: Any >>= TimeValue2\n"),
			1);
    } else {

      if ( (dst_tv->seconds () != magic2 ) || (dst_tv->useconds() != magic3 ) ) {
	ACE_ERROR_RETURN ((LM_DEBUG,
			   "(%P|%t) client - test failed: Any >>= TimeValue2: wrong value\n"),
			  1);
      }
    }
  }

  
  {
    // STEP 4.
    // TimeValue -- failes
    OROCOS::TimeValue* dst_tv = 0;
    result = test->get_something (
      2
      ACE_ENV_ARG_PARAMETER);
    ACE_TRY_CHECK;

    if (!(*result >>= dst_tv) )
    {
      CORBA::TypeCode *tc = result->type();
      if (tc) {
	ACE_DEBUG((LM_DEBUG, "type:%s, id:%s\n", tc->name(),  tc->id()));
      } else {
	ACE_DEBUG((LM_DEBUG, "Could not obtain typecode"));
      }
      ACE_ERROR_RETURN ((LM_DEBUG,
			 "(%P|%t) client - test failed: Any >>= TimeValue\n"),
			1
		 );
    } else {

      if ( (dst_tv->seconds () != magic2) || (dst_tv->useconds() != magic3 ) ) {
	ACE_ERROR_RETURN((LM_DEBUG,
			  "(%P|%t) client - test failed: Any >>= TimeValue: wrong value"),
			 1);
      }
    }
  }



  test->shutdown (ACE_ENV_SINGLE_ARG_PARAMETER);
  ACE_TRY_CHECK;
}


int
main (int argc, char *argv[])
{

  bool testCosEC = false;
  ACE_TRY_NEW_ENV
    {

      ACE_DEBUG ((LM_DEBUG, "(%P|%t) client - test started.\n"));

      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "" ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      // Create and register factories.


      VZ_init *vz_factory = 0;
      ACE_NEW_RETURN (vz_factory,
                      VZ_init,
                      1); // supplied by mapping

      orb->register_value_factory (vz_factory->tao_repository_id (),
                                   vz_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      vz_factory->_remove_ref (); // release ownership


      VA_init_i *va_factory = 0;
      ACE_NEW_RETURN (va_factory,
                      VA_init_i,
                      1); // supplied by mapping

      orb->register_value_factory (va_factory->tao_repository_id (),
                                   va_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      va_factory->_remove_ref (); // release ownership


      VB_init_i *vb_factory = 0;
      ACE_NEW_RETURN (vb_factory,
                      VB_init_i,
                      1); // supplied by mapping

      orb->register_value_factory (vb_factory->tao_repository_id (),
                                   vb_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      vb_factory->_remove_ref (); // release ownership

      // register simple value factory
      TimeValue2_init_i *tv2_factory = 0;
      ACE_NEW_RETURN (tv2_factory,
                      TimeValue2_init_i,
                      1);

      orb->register_value_factory (tv2_factory->tao_repository_id (),
                                   tv2_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      tv2_factory->_remove_ref (); // release ownership


      // TimeValue
      TimeValue_init_i *tv_factory = 0;
      ACE_NEW_RETURN (tv_factory,
                      TimeValue_init_i,
                      1); // supplied by mapping

//      orb->register_value_factory(OROCOS::_tc_TimeValue->id(),
//				  tv_factory);
      orb->register_value_factory (tv_factory->tao_repository_id (),
                                   tv_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      tv_factory->_remove_ref (); // release ownership

      // orocos object
      OrocosObject_init_i *oo_factory = 0;
      ACE_NEW_RETURN (oo_factory,
                      OrocosObject_init_i,
                      1); // supplied by mapping

      orb->register_value_factory (oo_factory->tao_repository_id (),
                                   oo_factory
                                   ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;
      oo_factory->_remove_ref (); // release ownership


      // Do local test

      OBV_AnyTest::VB_var va1, va2;
      ACE_NEW_RETURN (va1, VB_i, 1);
      ACE_NEW_RETURN (va2, VB_i, 1);


      va1->id (magic);
      va2->id (magic);

      CORBA::Any a1, a2;

      // Test both copying and non-copying version of operator<<=
      a1 <<= va1.in ();

      OBV_AnyTest::VB *pva = va2._retn();
      a2 <<= &pva;

      OBV_AnyTest::VB * dst = 0;

      if (!(a1 >>= dst) || dst->id () != magic)
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - test failed.\n"),
                            1);
        }

      if (!(a2 >>= dst) || dst->id () != magic)
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - test failed.\n"),
                            1);
        }

      {
	// test TimeValue
	OROCOS::TimeValue_var voo1, voo2;
	ACE_NEW_RETURN (voo1, TimeValue_i, 1);
	ACE_NEW_RETURN (voo2, TimeValue_i, 1);
//      voo1->origin("oo1");
//      voo2->origin("oo2");
	OROCOS::TimeValue * oodst = 0;
	CORBA::Any a3,a4;
	a3 <<= voo1.in();
//      OROCOS::TimeValue *tval = new TimeValue_i();
	OROCOS::TimeValue *pvoo = voo2._retn();
	a4 <<= pvoo;
	oodst = 0;
	if (! (a3 >>= oodst))
        {
	  CORBA::TypeCode *tc = a3.type();
	  if (tc) {
	    ACE_DEBUG((LM_DEBUG, "type:%s, id:%s\n", tc->name(),  tc->id()));
	  } else {
	    ACE_DEBUG((LM_DEBUG, "Could not obtain typecode"));
	  }
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - local extraction of TimeValue failed.\n"),
                            1);
        }

	if (!(a4 >>= oodst))
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - TimeValue test failed.\n"),
                            1);
        }
      }

      {
	// test TimeValue2
	OROCOS::TimeValue2_var voo1, voo2;
	ACE_NEW_RETURN (voo1, TimeValue2_i, 1);
	ACE_NEW_RETURN (voo2, TimeValue2_i, 1);
	CORBA::Any a3,a4;
	a3 <<= voo1.in();
	OROCOS::TimeValue2 *pvoo = voo2._retn();
	a4 <<= pvoo;
	OROCOS::TimeValue2_ptr oodst;
	if (! (a3 >>= oodst))
        {
	  CORBA::TypeCode *tc = a3.type();
	  if (tc) {
	    ACE_DEBUG((LM_DEBUG, "type:%s, id:%s\n", tc->name(),  tc->id()));
	  } else {
	    cout << "could not get typecode" << endl;
	  }
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - local extraction of TimeValue2 failed.\n"),
                            1);
        }

	if (!(a4 >>= oodst))
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "(%P|%t) client - local extract of TimeValue2 2 test failed.\n"),
                            1);
        }
      }

      if (testCosEC) {
	// will not return.
	ecTest(orb);
      } else {
	directTest(orb);
      }

      orb->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "(%P|%t) client - test finished.\n"));
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}
