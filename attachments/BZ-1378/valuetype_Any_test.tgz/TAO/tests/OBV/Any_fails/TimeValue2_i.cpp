// TimeValue2_i.cpp
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
//

#include "TimeValue2_i.h"

using namespace OROCOS;

TimeValue2_i::TimeValue2_i()
{
  seconds(0xAABBCCDD);
  useconds(0x11223344);
}

TimeValue2_i::TimeValue2_i(CORBA::Long sec, CORBA::Long usec)
{
  seconds(sec);
  useconds(usec);
}


void
TimeValue2_i::dump() throw(CORBA::SystemException)
{
  cout << "Dump TimeValue2_i: timestamp: " << seconds() << "." << useconds() << endl;
}


//=============================================================================


TAO_OBV_CREATE_RETURN_TYPE (OBV_OROCOS::TimeValue2)
TimeValue2_init_i::create_for_unmarshal (void) {
  OBV_OROCOS::TimeValue2 * v = new TimeValue2_i();
  return v;
}


TimeValue2 * TimeValue2_init_i::create_default()
{
  return new TimeValue2_i();
}


TimeValue2*
TimeValue2_init_i::create(CORBA::Long sec, CORBA::Long usec)
{
  return new TimeValue2_i(sec, usec);
}
