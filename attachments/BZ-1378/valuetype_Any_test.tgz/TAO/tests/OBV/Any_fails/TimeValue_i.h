// TimeValue2_i.hh
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
//

#ifndef OROCOS_TIME_VALUE_I_H
#define OROCOS_TIME_VALUE_I_H

#include "TimeValueC.h"

class TimeValue_i : public virtual OBV_OROCOS::TimeValue,
		     public virtual CORBA::DefaultValueRefCountBase
{
public:
  TimeValue_i();
  TimeValue_i(CORBA::Long sec, CORBA::Long usec);
  virtual void dump() throw(CORBA::SystemException);
private:
};

// try ValueFactoryBase here as well!
class TimeValue_init_i : public virtual OROCOS::TimeValue_init
{
public:
//  virtual ~TimeValue_init_i();
  virtual OROCOS::TimeValue * create_default();
  virtual OROCOS::TimeValue * create (CORBA::Long sec, CORBA::Long usec);
  TAO_OBV_CREATE_RETURN_TYPE (OBV_OROCOS::TimeValue) create_for_unmarshal(void);
};

#endif //__TIMEVALUE2_I_H
