// TimeValue_i.cpp
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
//

#include "TimeValue_i.h"

using namespace OROCOS;

TimeValue_i::TimeValue_i()
{
  seconds(0xAABBCCDD);
  useconds(0x11223344);
}

TimeValue_i::TimeValue_i(CORBA::Long sec, CORBA::Long usec)
{
  seconds(sec);
  useconds(usec);
}


void
TimeValue_i::dump() throw(CORBA::SystemException)
{
  cout << "Dump TimeValue_i: timestamp: " << seconds() << "." << useconds() << endl;
}


//=============================================================================


TAO_OBV_CREATE_RETURN_TYPE (OBV_OROCOS::TimeValue)
TimeValue_init_i::create_for_unmarshal (void) {
  OBV_OROCOS::TimeValue * v = new TimeValue_i();
  return v;
}


TimeValue * TimeValue_init_i::create_default()
{
  return new TimeValue_i();
}


TimeValue*
TimeValue_init_i::create(CORBA::Long sec, CORBA::Long usec)
{
  return new TimeValue_i(sec, usec);
}
