// TimeValue2_i.hh
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
//

#ifndef OROCOS_TIME_VALUE_2_I_H
#define OROCOS_TIME_VALUE_2_I_H

#include "TimeValue2C.h"

class TimeValue2_i : public virtual OBV_OROCOS::TimeValue2,
		     public virtual CORBA::DefaultValueRefCountBase
{
public:
  TimeValue2_i();
  TimeValue2_i(CORBA::Long sec, CORBA::Long usec);
  virtual void dump() throw(CORBA::SystemException);
private:
};

// try ValueFactoryBase here as well!
class TimeValue2_init_i : public virtual OROCOS::TimeValue2_init
{
public:
//  virtual ~TimeValue2_init_i();
  virtual OROCOS::TimeValue2 * create_default();
  virtual OROCOS::TimeValue2 * create (CORBA::Long sec, CORBA::Long usec);
  TAO_OBV_CREATE_RETURN_TYPE (OBV_OROCOS::TimeValue2) create_for_unmarshal(void);
};

#endif //__TIMEVALUE2_I_H
