// Any_i.cpp
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
// Last change: Time-stamp: <02-Nov-2002 17:06:23 pablo@dyna218.nada.kth.se>
//
//

#include "Any_i.h"


VZ_i::VZ_i ()
{
};


void VZ_i::do_print ()
{
  cerr << "VZ_i::do_print()" << endl;
};



VZ_init::VZ_init (void)
{
}

VZ_init::~VZ_init (void)
{
}

const char*
VZ_init::tao_repository_id (void)
{
  return OBV_AnyTest::VZ::_tao_obv_static_repository_id ();
}


//=============================================================================

VA_i::VA_i()
{
  this->origin(CORBA::string_dup("VA_Impl()"));
};


VA_i::~VA_i()
{
};


void VA_i::do_print()
{
  cerr << "VA::do_print(), origin=" << origin() << " id=" << id() << endl;
};


//=============================================================================

VB_i::VB_i()
{
  origin(CORBA::string_dup("VB_Impl()"));
};


VB_i::~VB_i()
{
};

void VB_i::do_print()
{
  cerr << "VB::do_print(), origin=" << origin() << " id=" << id() << endl;
};
