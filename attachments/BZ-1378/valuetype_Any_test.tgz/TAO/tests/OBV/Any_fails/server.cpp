// server.cpp,v 1.2 2002/01/29 20:21:08 okellogg Exp


#include "AnyS_impl.h"
#include "Any_i.h"
#include "ace/Get_Opt.h"

#include "orbsvcs/CosEventCommS.h"
#include <orbsvcs/CosEventChannelAdminS.h>

#include "OrocosObject_i.h"
#include "TimeValue2_i.h"

#include <string>

ACE_RCSID(Any, server, "server.cpp,v 1.2 2002/01/29 20:21:08 okellogg Exp")


const char *ior_output_file = "test.ior";

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "o:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'o':
        ior_output_file = get_opts.optarg;
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-o <iorfile>"
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}




class Supplier : public POA_CosEventComm::PushSupplier

{
private:
  string ior_output_file;
  string eCior;

public:

  Supplier()
    {
      ior_output_file = "test.ior";
      eCior = "file://ec.ior";
    };

  int
  parse_args (int argc, char *argv[])
    {
      ACE_Get_Opt get_opts (argc, argv, "o:");
      int c;

      while ((c = get_opts ()) != -1)
	switch (c)
	{
	case 'o':
	  ior_output_file = get_opts.optarg;
	  break;
	case 'e':
	  eCior = get_opts.optarg;
	  break;

	case '?':
	default:
	  ACE_ERROR_RETURN ((LM_ERROR,
			     "usage:  %s "
			     "-o <iorfile>"
			     "\n",
			     argv [0]),
			    -1);
	}
      // Indicates sucessful parsing of the command line
      return 0;
    };

  int run (int argc, char *argv[])
    {
      ACE_TRY_NEW_ENV
	{
	  CORBA::ORB_var orb =
	    CORBA::ORB_init (argc, argv, "" ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  CORBA::Object_var poa_object =
	    orb->resolve_initial_references("RootPOA" ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  PortableServer::POA_var root_poa =
	    PortableServer::POA::_narrow (poa_object.in () ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  if (CORBA::is_nil (root_poa.in ()))
	    ACE_ERROR_RETURN ((LM_ERROR,
			       " (%P|%t) Panic: nil RootPOA\n"),
			      1);

	  PortableServer::POAManager_var poa_manager =
	    root_poa->the_POAManager (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  if (parse_args (argc, argv) != 0)
	    return 1;

	  Test_impl *test_impl;
	  ACE_NEW_RETURN (test_impl,
			  Test_impl (orb.in ()),
			  1);

	  PortableServer::ServantBase_var owner_transfer(test_impl);

	  OBV_AnyTest::Test_var test =
	    test_impl->_this (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  CORBA::String_var ior =
	    orb->object_to_string (test.in () ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  // If the ior_output_file exists, output the ior to it
	  FILE *output_file= ACE_OS::fopen (ior_output_file.c_str(), "w");
	  if (output_file == 0)
	    ACE_ERROR_RETURN ((LM_ERROR,
			       "Cannot open output file for writing IOR: %s.",
			       ior_output_file.c_str()),
                              1);
	  ACE_OS::fprintf (output_file, "%s", ior.in ());
	  ACE_OS::fclose (output_file);

	  poa_manager->activate (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;


	  // Obtain the event channel, we could use a naming service, a
	  // command line argument or resolve_initial_references(), but
	  // this is simpler...
	  CORBA::Object_var object =
	    orb->string_to_object (eCior.c_str() ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  CosEventChannelAdmin::EventChannel_var event_channel =
	    CosEventChannelAdmin::EventChannel::_narrow (object.in ()
							 ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  // The canonical protocol to connect to the EC
	  CosEventChannelAdmin::SupplierAdmin_var supplier_admin =
	    event_channel->for_suppliers (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  CosEventChannelAdmin::ProxyPushConsumer_var consumer =
	    supplier_admin->obtain_push_consumer (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  CosEventComm::PushSupplier_var supplier =
	    this->_this (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  consumer->connect_push_supplier (supplier.in () ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  // end of EC init

	  // Push the events...
	  ACE_Time_Value sleep_time (0, 100000); // 10 milliseconds

	  CORBA::Any event;
	  OrocosObject_i orObj;
	  TimeValue_i tvObj;
	  VA_i va;
	  VB_i vb;
	  VZ_i vz;
	  TimeValue2_i tv2Obj;


	  for (int i = 0; i != -1; ++i)
	  {
	    switch (i%6) {
	    case 0:
	      event <<= & va;
	      break;
	    case 1:
	      event <<= & vb;
	      break;
	    case 2:
	      event <<= & vz;
	      break;
	    case 3:
	      event <<= & tvObj;
	      break;
	    case 4:
	      event <<= & orObj;
	      break;
	    case 5:
	      event <<= & tv2Obj;
	      break;
	    }
	    consumer->push (event ACE_ENV_ARG_PARAMETER);
	    ACE_TRY_CHECK;
	    ACE_OS::sleep (sleep_time);
	  }

	  // Disconnect from the EC
	  consumer->disconnect_push_consumer (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  // Destroy the EC....
	  event_channel->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  // Deactivate this object...
	  PortableServer::ObjectId_var id =
	    root_poa->servant_to_id (this ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;
	  root_poa->deactivate_object (id.in () ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;


	  // run the other tests.

	  ACE_DEBUG ((LM_DEBUG, "(%P|%t) server - event loop started.\n"));

	  orb->run (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  ACE_DEBUG ((LM_DEBUG, "(%P|%t) server - event loop finished.\n"));

	  root_poa->destroy (1, 1 ACE_ENV_ARG_PARAMETER);
	  ACE_TRY_CHECK;

	  orb->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
	  ACE_TRY_CHECK;
	}
      ACE_CATCHANY
	{
	  ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
			       "Exception caught:");
	  return 1;
	}
      ACE_ENDTRY;

      return 0;
    }


  void
  disconnect_push_supplier (ACE_ENV_SINGLE_ARG_DECL_NOT_USED)
    ACE_THROW_SPEC ((CORBA::SystemException))
    {
      cerr << "Supplier: disconnect_push_supplier " << endl;
    }

};

int runServant(int argc, char **argv)
{
      ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "" ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA" ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in () ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (root_poa.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Panic: nil RootPOA\n"),
                          1);

      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      Test_impl *test_impl;
      ACE_NEW_RETURN (test_impl,
                      Test_impl (orb.in ()),
                      1);

      PortableServer::ServantBase_var owner_transfer(test_impl);
      OBV_AnyTest::Test_var test =
        test_impl->_this (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      CORBA::String_var ior =
        orb->object_to_string (test.in () ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      // If the ior_output_file exists, output the ior to it
      FILE *output_file= ACE_OS::fopen (ior_output_file, "w");
      if (output_file == 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot open output file for writing IOR: %s.",
                           ior_output_file),
                              1);
      ACE_OS::fprintf (output_file, "%s", ior.in ());
      ACE_OS::fclose (output_file);

      poa_manager->activate (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "(%P|%t) server - event loop started.\n"));

      orb->run (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "(%P|%t) server - event loop finished.\n"));
      root_poa->destroy (1, 1 ACE_ENV_ARG_PARAMETER);
      ACE_TRY_CHECK;

      orb->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

int
main (int argc, char *argv[])
{
    bool testEvent = false;
    if (testEvent) {
	Supplier sp;
	return sp.run(argc, argv);
    } else {
	// setup Corba object Any
	runServant(argc, argv);
    }
}
