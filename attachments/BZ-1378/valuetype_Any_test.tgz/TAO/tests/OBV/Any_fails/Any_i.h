// Any_i.h
//
// Pablo d'Angelo <pablo@mathematik.uni-ulm.de>
// Last change: Time-stamp: <02-Nov-2002 17:07:30 pablo@dyna218.nada.kth.se>
//
//

#ifndef MY_ANY_I_H
#define MY_ANY_I_H

#include "AnyC.h"

#include <tao/corba.h>


class VZ_i : public virtual OBV_OBV_AnyTest::VZ,
	     public virtual CORBA::DefaultValueRefCountBase
{
public:
  VZ_i ();
  virtual ~VZ_i () {};
  virtual void do_print ();
  // Implementation of the do_print () operation the valuetype should have.
  // All operations in valuetypes are virtual.
};


class VZ_init : public virtual CORBA_ValueFactoryBase
  {
  public:
    virtual ~VZ_init (void);
//    virtual VZ* create (
//      ) = 0;

    VZ_init ();
    static VZ_init* _downcast (CORBA_ValueFactoryBase* );

    TAO_OBV_CREATE_RETURN_TYPE (VZ) create_for_unmarshal () {
      OBV_OBV_AnyTest::VZ * v = new VZ_i();
      return v;
    }

    // TAO-specific extensions
  public:
    virtual const char* tao_repository_id (void);

  protected:
  };


class VA_i : public virtual OBV_OBV_AnyTest::VA,
	     public virtual VZ_i
{
public:
  VA_i();
  virtual ~VA_i();

  virtual void do_print();
};

class VA_init_i : public virtual OBV_AnyTest::VA_init
//		  public virtual CORBA::DefaultValueRefCountBase
{
//  friend class VA;
public:
  // create (...) would go here
  OBV_AnyTest::VA * create() {
    return new VA_i();
  };

//  private:
//    virtual ~VA_factory ();
  TAO_OBV_CREATE_RETURN_TYPE (VA) create_for_unmarshal () {
    OBV_AnyTest::VA * v = new VA_i();
    v->origin(CORBA::string_dup("VA_factory::create_for_unmarshal()"));
    return v;
  }
};


class VB_i : public virtual OBV_OBV_AnyTest::VB,
		    public virtual VA_i
{
public:
  VB_i();
  virtual ~VB_i();
  virtual void do_print();
};

class VB_init_i : public virtual OBV_AnyTest::VB_init
//		  public virtual CORBA::DefaultValueRefCountBase
{
//  friend class VB;
public:
  // create (...) would go here
  OBV_AnyTest::VB * create() {
    return new VB_i();
  };

//  private:
  TAO_OBV_CREATE_RETURN_TYPE (OBV_AnyTest::VB) create_for_unmarshal () {
    OBV_OBV_AnyTest::VB * v = new VB_i();
    v->origin(CORBA::string_dup("VB_factory::create_for_unmarshal()"));
    return v;
  }
};

#endif // ANY_I_H
