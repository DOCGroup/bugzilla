// AnyS_impl.cpp,v 1.3 2002/01/29 20:21:08 okellogg Exp

#include "AnyS_impl.h"
#include "Any_i.h"
#include "TimeValue2_i.h"
#include "OrocosObject_i.h"

ACE_RCSID(Any, AnyS_impl, "AnyS_impl.cpp,v 1.3 2002/01/29 20:21:08 okellogg Exp")

Test_impl::Test_impl (CORBA::ORB_ptr orb)
    : orb_ (CORBA::ORB::_duplicate (orb))
{
}

CORBA::Any*
Test_impl::get_something (
    CORBA::Long type
    ACE_ENV_ARG_DECL_NOT_USED)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  CORBA::Any_var ret_val;
  ACE_NEW_RETURN (ret_val, CORBA::Any, 0);

  const CORBA::ULong magic = 3145;

  switch (type) {
  case 0:
    {
      OBV_AnyTest::VA_var va;
      ACE_NEW_RETURN (va, VA_i, 0);

      va->id (magic);

      OBV_AnyTest::VA *va_ptr = va._retn ();
      *ret_val <<= &va_ptr;

      //*ret_val <<= va.in ();
    }
    break;
  case 1:
    {
      OBV_AnyTest::VB_var vb;
      ACE_NEW_RETURN (vb, VB_i, 0);

      vb->id (magic);

      *ret_val <<= vb.in ();
    }
    break;
  case 2:
    {
      OROCOS::TimeValue_var tv;
      ACE_NEW_RETURN (tv, TimeValue_i, 0);

      // magic is set in TimeValue_i()
      *ret_val <<= tv.in ();
    }
    break;
  case 3:
    {
      OROCOS::TimeValue2_var tv;
      ACE_NEW_RETURN (tv, TimeValue2_i, 0);

      // magic is set in TimeValue2_i()
      *ret_val <<= tv.in ();
    }
    break;
  case 4:
    {
      OROCOS::OrocosObject_var tv;
      ACE_NEW_RETURN (tv, OrocosObject_i, 0);

      // magic is set in TimeValue2_i()
      *ret_val <<= tv.in ();
    }
    break;
  }

  return ret_val._retn();
}

void
Test_impl::shutdown (ACE_ENV_SINGLE_ARG_DECL)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}
