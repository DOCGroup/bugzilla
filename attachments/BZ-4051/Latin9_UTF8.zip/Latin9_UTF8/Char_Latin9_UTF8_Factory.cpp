// -*- C++ -*-

//=============================================================================
/**
 *  @file    Char_Latin9_UTF8_Factory.cpp
 *
 *  $Id: Char_Latin9_UTF8_Factory.cpp 93650 2011-03-28 08:44:53Z johnnyw $
 *
 *  A tempate instantiation of the codeset translator factory from TAO. This
 *  one loads a modified version of ACE's ISO8859-1 (Latin 1) to UTF-8
 *  translator.
 *
 *
 *  @author   Daniel van den Ouden <daniel.van.den.ouden@syntel.nl>
 */
//=============================================================================


#include "Char_Latin9_UTF8_Factory.h"
#include "ace/Log_Msg.h"

ACE_STATIC_SVC_DEFINE (Char_Latin9_UTF8_Factory,
                       ACE_TEXT ("Char_Latin9_UTF8_Factory"),
                       ACE_SVC_OBJ_T,
                       &ACE_SVC_NAME (Char_Latin9_UTF8_Factory),
                       ACE_Service_Type::DELETE_THIS
                       | ACE_Service_Type::DELETE_OBJ,
                       0)
ACE_FACTORY_DEFINE (Latin9_UTF8, Char_Latin9_UTF8_Factory)
