
// -*- C++ -*-
// $Id$
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl Latin9_UTF8
// ------------------------------
#ifndef LATIN9_UTF8_EXPORT_H
#define LATIN9_UTF8_EXPORT_H

#include "ace/config-all.h"

#if defined (ACE_AS_STATIC_LIBS) && !defined (LATIN9_UTF8_HAS_DLL)
#  define LATIN9_UTF8_HAS_DLL 0
#endif /* ACE_AS_STATIC_LIBS && LATIN9_UTF8_HAS_DLL */

#if !defined (LATIN9_UTF8_HAS_DLL)
#  define LATIN9_UTF8_HAS_DLL 1
#endif /* ! LATIN9_UTF8_HAS_DLL */

#if defined (LATIN9_UTF8_HAS_DLL) && (LATIN9_UTF8_HAS_DLL == 1)
#  if defined (LATIN9_UTF8_BUILD_DLL)
#    define Latin9_UTF8_Export ACE_Proper_Export_Flag
#    define LATIN9_UTF8_SINGLETON_DECLARATION(T) ACE_EXPORT_SINGLETON_DECLARATION (T)
#    define LATIN9_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_EXPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  else /* LATIN9_UTF8_BUILD_DLL */
#    define Latin9_UTF8_Export ACE_Proper_Import_Flag
#    define LATIN9_UTF8_SINGLETON_DECLARATION(T) ACE_IMPORT_SINGLETON_DECLARATION (T)
#    define LATIN9_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_IMPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  endif /* LATIN9_UTF8_BUILD_DLL */
#else /* LATIN9_UTF8_HAS_DLL == 1 */
#  define Latin9_UTF8_Export
#  define LATIN9_UTF8_SINGLETON_DECLARATION(T)
#  define LATIN9_UTF8_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#endif /* LATIN9_UTF8_HAS_DLL == 1 */

// Set LATIN9_UTF8_NTRACE = 0 to turn on library specific tracing even if
// tracing is turned off for ACE.
#if !defined (LATIN9_UTF8_NTRACE)
#  if (ACE_NTRACE == 1)
#    define LATIN9_UTF8_NTRACE 1
#  else /* (ACE_NTRACE == 1) */
#    define LATIN9_UTF8_NTRACE 0
#  endif /* (ACE_NTRACE == 1) */
#endif /* !LATIN9_UTF8_NTRACE */

#if (LATIN9_UTF8_NTRACE == 1)
#  define LATIN9_UTF8_TRACE(X)
#else /* (LATIN9_UTF8_NTRACE == 1) */
#  if !defined (ACE_HAS_TRACE)
#    define ACE_HAS_TRACE
#  endif /* ACE_HAS_TRACE */
#  define LATIN9_UTF8_TRACE(X) ACE_TRACE_IMPL(X)
#  include "ace/Trace.h"
#endif /* (LATIN9_UTF8_NTRACE == 1) */

#endif /* LATIN9_UTF8_EXPORT_H */

// End of auto generated file.
