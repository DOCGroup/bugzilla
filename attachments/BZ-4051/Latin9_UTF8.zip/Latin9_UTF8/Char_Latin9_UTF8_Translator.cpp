// -*- C++ -*-

//=============================================================================
/**
 *  @file    Char_Latin9_UTF8_Translator.cpp
 *
 *  $Id: Char_Latin9_UTF8_Translator.cpp 93650 2011-03-28 08:44:53Z johnnyw $
 *
 *  @author Daniel van den Ouden (daniel.van.den.ouden@syntel.nl)
 */
//=============================================================================


#include "Char_Latin9_UTF8_Translator.h"
#include "ace/OS_Memory.h"
#include "ace/OS_NS_string.h"

// ****************************************************************

Latin9_UTF8::Latin9_UTF8 (void)
{
}

Latin9_UTF8::~Latin9_UTF8 (void)
{
}

ACE_CDR::Boolean
Latin9_UTF8::read_char (ACE_InputCDR &in,
                            ACE_CDR::Char &x)
{
  // We cannot have a codepoint > 0x7F at this point, since we are expecting
  // only one single char.
  ACE_CDR::Octet ox;
  if (this->read_1 (in, &ox))
    {
      if (ox < 0x80)
        {
          x = ox;
          return true;
        }
    }
  return false;
}

ACE_CDR::ULong
Latin9_UTF8::read_char_i (ACE_InputCDR &cdr, ACE_CDR::Char &x)
{
  // Properly read an UTF-8 character
  ACE_CDR::ULong l = 0;

  // Read first byte
  ACE_CDR::Octet first;
  if (!this->read_1 (cdr, &first))
    return 0;

  int len = 0;
  if ((first & 0x80) == 0) // 0xxx xxxx
    {
      // early exit for single byte characters
      x = first;
      return 1;
    }
  else if ((first & 0xE0) == 0xC0) // 110x xxxx
    {
      len = 1;
      l = first & ~0xE0; // 0001 1111
    }
  else if ((first & 0xF0) == 0xE0) // 1110 xxxx
    {
      len = 2;
      l = first & ~0xF0; // 0000 1111
    }
  else if ((first & 0xF8) == 0xF0) // 1111 0xxx
    {
      len = 3;
      l = first & ~0xF8; // 0000 0111
    }
  else if ((first & 0xFC) == 0xF8) // 1111 10xx
    {
      len = 4;
      l = first & ~0xFC; // 0000 0011
    }
  else if ((first & 0xFE) == 0xFC) // 1111 110x
    {
      len = 5;
      l = first & ~0xFE; // 0000 0001
    }
  else
    return 0; // invalid/unexpected byte, invalid UTF-8 stream

  // read following bytes for multibyte sequence
  for (int i = 0; i < len; ++i)
    {
      ACE_CDR::Octet o;
      if (!this->read_1 (cdr, &o))
        return 0;

      if ((o & 0xC0) != 0x80)
        return 0; // unexpected byte, invalid UTF-8 stream

      l = (l << 6) | (o & ~0xC0);
    }

  // convert unicode codepoint to ISO 8859-15
  // any codepoint up to 0xFF translates directly to ISO 8859-15 except for eight cases
  if (l <= 0xFF)
    {
      if (l == 0xA4 ||
          l == 0xA6 ||
          l == 0xA8 ||
          l == 0xB4 ||
          l == 0xB8 ||
          l == 0xBC ||
          l == 0xBD ||
          l == 0xBE)
         return 0; // these have been replaced by other codepoints in ISO 8859-15
       x = static_cast<ACE_CDR::Char>(l);
       return len + 1;
    }
  else if (l == 0x20AC) // Euro Sign
    {
      x = 0xA4;
      return len + 1;
    }
  else if (l == 0x0160) // capital S with caron
    {
      x = 0xA6;
      return len + 1;
    }
  else if (l == 0x0161) // s with caron
    {
      x = 0xA8;
      return len + 1;
    }
  else if (l == 0x017D) // capital Z with caron
    {
      x = 0xB4;
      return len + 1;
    }
  else if (l == 0x017E) // z with caron
    {
      x = 0xB8;
      return len + 1;
    }
  else if (l == 0x0152) // Capital ligature of OE
    {
      x = 0xBC;
      return len + 1;
    }
  else if (l == 0x0153) // ligature of oe
    {
      x = 0xBD;
      return len + 1;
    }
  else if (l == 0x0178) // capital Y with umlaut (diaeresis)
    {
      x = 0xBE;
      return len + 1;
    }

   // unsupported codepoint
   return 0;
}

ACE_CDR::Boolean
Latin9_UTF8::read_string (ACE_InputCDR& in,
                              ACE_CDR::Char *& x)
{
  ACE_CDR::ULong len;
  if (!in.read_ulong (len))
    return 0;
    
  // A check for the length being too great is done later in the
  // call to read_char_array but we want to have it done before
  // the memory is allocated.
  if (len > 0 && len <= in.length())
    {
      ACE_NEW_RETURN (x,
                      ACE_CDR::Char [len],
                      0);
      // pos keeps track of the character position, it will never be
      // greater than len
      size_t pos = 0;
      ACE_CDR::ULong incr = 1;
      for (ACE_CDR::ULong i = 0; incr > 0 && i < len; i += incr)
        {
          incr = this->read_char_i(in,x[pos++]);
        }
      if (incr > 0)
        return 1;
      delete [] x;
    }
  else if (len == 0)
    {
      // Convert any null strings to empty strings since empty
      // strings can cause crashes. (See bug 58.)
      ACE_NEW_RETURN (x,
                      ACE_CDR::Char[1],
                      0);
      x[0] = '\x00';
      return 1;
    }
  x = 0;
  return 0;
}

ACE_CDR::Boolean
Latin9_UTF8::read_char_array (ACE_InputCDR& in,
                                  ACE_CDR::Char* x,
                                  ACE_CDR::ULong len)
{
  if (len == 0)
    return 1;

  for (size_t i = 0; i < len; ++i)
    if (!this->read_char(in,x[i]))
      return 0;

  return 1;
}

ACE_CDR::Boolean
Latin9_UTF8::write_char (ACE_OutputCDR& out,
                             ACE_CDR::Char x)
{
  ACE_CDR::Octet ox = x;
  if (ox < 0x80)
    return this->write_1 (out,&ox);
  else
    { // character cannot be represented in a single octet
      errno = EINVAL;
      return 0;
    }
}

ACE_CDR::Boolean
Latin9_UTF8::write_char_i (ACE_OutputCDR &out,
                                      ACE_CDR::Char x)
{
  // translate ISO 8859-15 character to Unicode
  // ISO 8859-15 maps straight to Unicode, except for eight characters
  ACE_CDR::ULong l;

  // possible optimization is to use a lookup table
  switch (static_cast<ACE_CDR::Octet>(x))
  {
  case 0xA4: // Euro sign
    l = 0x20AC;
    break;

  case 0xA6: // capital S with caron
    l = 0x0160;
    break;

  case 0x0A8: // s with caron
    l = 0x0161;
    break;

  case 0xB4: // capital Z with caron
    l = 0x017D;
    break;

  case 0xB8: // z with caron
    l = 0x017E;
    break;

  case 0xBC: // Capital ligature of OE
    l = 0x0152;
    break;

  case 0xBD: // ligature of oe
    l = 0x0153;
    break;

  case 0xBE: // capital Y with umlaut (diaeresis)
    l = 0x0178;
    break;

  default:
    l = static_cast<ACE_CDR::ULong>(x);
    break;
  }

  // write the Unicode codepoint using UTF-8
  int len;
  ACE_CDR::Octet o;
  if (l < 0x80)
    {
      o = static_cast<ACE_CDR::Octet>(l); // 0xxx xxxx
      len = 0;
    }
  else if (l < 0x800)
    {
      o = static_cast<ACE_CDR::Octet>(0xC0 | (l >> 6)); // 110x xxxx
      len = 1;
    }
  else if (l < 0x10000)
    {
      o = static_cast<ACE_CDR::Octet>(0xE0 | (l >> 12)); // 1110 xxxx
      len = 2;
    }
  else if (l < 0x200000)
    {
      o = static_cast<ACE_CDR::Octet>(0xF0 | (l >> 18)); // 1111 0xxx
      len = 3;
    }
  else if (l < 0x4000000)
    {
      o = static_cast<ACE_CDR::Octet>(0xF8 | (l >> 24)); // 1111 10xx
      len = 4;
    }
  else
    {
      o = static_cast<ACE_CDR::Octet>(0xFC | (l >> 30)); // 1111 110x
      len = 5;
    }

  if (!this->write_1(out, &o))
    return 0;

  while (len > 0)
    {
      --len;
      o = static_cast<ACE_CDR::Octet>(0x80 | ((l >> (len * 6)) & 0x3F)); // 10xx xxxx
      if (!this->write_1(out, &o))
        return 0;
    }
  return 1;
}

ACE_CDR::Boolean
Latin9_UTF8::write_string (ACE_OutputCDR& out,
                               ACE_CDR::ULong len,
                               const ACE_CDR::Char* x)
{
  // we'll accept a null pointer but only for an empty string
  if (x == 0 && len != 0)
    return 0;

  ACE_CDR::ULong l = 0;
  // Compute the real buffer size by adding in multi-byte codepoints.
  for (ACE_CDR::ULong i = 0; i < len; i++)
    {
      // It would be prettier to actually convert to unicode and
      // calculate the length of the resulting UTF-8 string...
      ACE_CDR::Octet o = static_cast<ACE_CDR::Octet>(x[i]);
      if (o < 0x80)
        ++l; // everything below 0x80 is a one byte character
      else if (o == 0xA4)
        l += 3; // only the Euro sign is a three byte character
      else
        l += 2; // the rest are two byte characters
    }

  // Always add one for the nul
  l++;
  if (out.write_ulong (l))
    {
      for (ACE_CDR::ULong i = 0; i < len; ++i)
        {
          if (this->write_char_i (out,x[i]) == 0)
            return 0;
        }
      ACE_CDR::Octet s = 0;
      return this->write_1 (out, &s);
    }
  return 0;
}

ACE_CDR::Boolean
Latin9_UTF8::write_char_array (ACE_OutputCDR& out,
                                   const ACE_CDR::Char* x,
                                   ACE_CDR::ULong len)
{
  if (len == 0)
    return true;

  for (size_t i = 0; i < len; ++i)
    // We still have to write each char individually, as any translated
    // value may fail to fit in a single octet.
    if (this->write_char (out, x[i]) == 0)
      return false;

  return true;
}

