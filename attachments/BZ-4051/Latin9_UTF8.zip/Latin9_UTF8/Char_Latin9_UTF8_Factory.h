// -*- C++ -*-

//=============================================================================
/**
 *  @file    Char_Latin9_UTF8_Factory.h
 *
 *  $Id: Char_Latin9_UTF8_Factory.h 93650 2011-03-28 08:44:53Z johnnyw $
 *
 *  A tempate instantiation of the codeset translator factory from TAO. This
 *  one loads a modified version of ACE's ISO8859-1 (Latin 1) to UTF-8
 *  translator.
 *
 *
 *  @author   Daniel van den Ouden <daniel.van.den.ouden@syntel.nl>
 */
//=============================================================================


#ifndef CHAR_LATIN9_UTF8_FACTORY_H
#define CHAR_LATIN9_UTF8_FACTORY_H

#include /**/ "ace/pre.h"
#include "ace/Service_Config.h"
#include "tao/Codeset/Codeset_Translator_Factory.h"

#include "Char_Latin9_UTF8_Translator.h"

typedef TAO_Codeset_Translator_Factory_T<Latin9_UTF8> Char_Latin9_UTF8_Factory;

ACE_STATIC_SVC_DECLARE_EXPORT (Latin9_UTF8, Char_Latin9_UTF8_Factory)
ACE_FACTORY_DECLARE (Latin9_UTF8, Char_Latin9_UTF8_Factory)

#include /**/ "ace/post.h"
#endif /* CHAR_LATIN9_UTF8_FACTORY_H */
