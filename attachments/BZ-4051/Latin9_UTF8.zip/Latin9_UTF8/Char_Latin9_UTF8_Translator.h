// -*- C++ -*-

//=============================================================================
/**
 *  @file    Char_Latin9_UTF8_Translator.h
 *
 *  $Id: Char_Latin9_UTF8_Translator.h 81391 2008-04-23 14:09:49Z johnnyw $
 *
 *  @author Daniel van den Ouden (daniel.van.den.ouden@syntel.nl)
 */
//=============================================================================


#ifndef TAO_CHAR_LATIN9_UTF8_TRANSLATOR_H
#define TAO_CHAR_LATIN9_UTF8_TRANSLATOR_H
#include /**/ "ace/pre.h"

#include "ace/config-all.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#include "ace/CDR_Stream.h"
#include "Latin9_UTF8_export.h"


// ****************************************************************

/**
 * @class ACE_Char_UTF8_Latin9
 *
 * @brief Codeset translation specialization.
 *
 * This class performs the codeset translation:
 *   - Native:        ISO-8859-15 (i.e. Latin 9)
 *   - Stream:        UTF-8 (8 bit Unicode mapping)
 */
class Latin9_UTF8_Export Latin9_UTF8 : public ACE_Char_Codeset_Translator
{
public:
  /// A do nothing constructor.
  Latin9_UTF8 (void);

  /// Virtual destruction
  virtual ~Latin9_UTF8 (void);

  // = Documented in $ACE_ROOT/ace/CDR_Stream.h
  virtual ACE_CDR::Boolean read_char (ACE_InputCDR &, ACE_CDR::Char &);
  virtual ACE_CDR::Boolean read_string (ACE_InputCDR &, ACE_CDR::Char *&);
  virtual ACE_CDR::Boolean read_char_array (ACE_InputCDR &,
                                            ACE_CDR::Char *,
                                            ACE_CDR::ULong);
  virtual ACE_CDR::Boolean write_char (ACE_OutputCDR &, ACE_CDR::Char);
  virtual ACE_CDR::Boolean write_string (ACE_OutputCDR &,
                                         ACE_CDR::ULong,
                                         const ACE_CDR::Char *);
  virtual ACE_CDR::Boolean write_char_array (ACE_OutputCDR &,
                                             const ACE_CDR::Char *,
                                             ACE_CDR::ULong);
  virtual ACE_CDR::ULong ncs () {return 0x0001000FU;}
  virtual ACE_CDR::ULong tcs () {return 0x05010001U;}
  
private:
  ACE_CDR::ULong read_char_i (ACE_InputCDR &,
                                ACE_CDR::Char &);

  ACE_CDR::Boolean write_char_i (ACE_OutputCDR &,
                                 ACE_CDR::Char);
};

#include /**/ "ace/post.h"
#endif /* TAO_CHAR_LATIN9_UTF8_TRANSLATOR_H */
