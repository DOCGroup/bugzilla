// $Id: TestClientRequestInterceptorImpl_T.h,v 1.1 2007/03/05 16:20:17 vz Exp $

// ================================================================
//  ClientRequestInterceptor implementation
// ================================================================

#ifndef _TESTCLIENTREQUESTINTERCEPTORIMPL_T_H_
#define _TESTCLIENTREQUESTINTERCEPTORIMPL_T_H_

#include "tao/PI/PI.h"

class TestClientRequestInterceptorImpl_T
  : public virtual PortableInterceptor::ClientRequestInterceptor
{
public:
  // constructor
  TestClientRequestInterceptorImpl_T ();

  // destructor
  ~TestClientRequestInterceptorImpl_T ();

  // destroy
  /* virtual */ void destroy ()
     throw (CORBA::SystemException);

  // name
  /* virtual */ char * name ()
     throw (CORBA::SystemException);

  // receive_exception
  /* virtual */ void receive_exception (PortableInterceptor::ClientRequestInfo_ptr ri)
     throw (CORBA::SystemException, PortableInterceptor::ForwardRequest);

  // receive_other
  /* virtual */ void receive_other (PortableInterceptor::ClientRequestInfo_ptr ri)
     throw (CORBA::SystemException, PortableInterceptor::ForwardRequest);

  // receive_reply
  /* virtual */ void receive_reply (PortableInterceptor::ClientRequestInfo_ptr ri)
     throw (CORBA::SystemException);

  // send_poll
  /* virtual */ void send_poll (PortableInterceptor::ClientRequestInfo_ptr ri)
     throw (CORBA::SystemException);

  // send_request
  /* virtual */ void send_request (PortableInterceptor::ClientRequestInfo_ptr ri)
     throw (CORBA::SystemException, PortableInterceptor::ForwardRequest);
};

#endif /* _TESTCLIENTREQUESTINTERCEPTORIMPL_T_H_ */
