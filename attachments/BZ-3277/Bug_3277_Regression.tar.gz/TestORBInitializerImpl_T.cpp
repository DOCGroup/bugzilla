// $Id: TestORBInitializerImpl_T.cpp,v 1.1 2007/03/05 16:20:17 vz Exp $

// ================================================================
//  ORBInitializer implementation
// ================================================================

#include "TestORBInitializerImpl_T.h"
#include "TestClientRequestInterceptorImpl_T.h"

// constructor
TestORBInitializerImpl_T::TestORBInitializerImpl_T ()
{
   // no-op
}

// destructor
TestORBInitializerImpl_T::~TestORBInitializerImpl_T ()
{
   // no-op
}

// pre_init
void TestORBInitializerImpl_T::pre_init (PortableInterceptor::ORBInitInfo_ptr /* info */)
   throw (CORBA::SystemException)
{
   // no-op
}

// post_init
void TestORBInitializerImpl_T::post_init (PortableInterceptor::ORBInitInfo_ptr info)
   throw (CORBA::SystemException)
{
  try
    {
      PortableInterceptor::ClientRequestInterceptor_var clientInterceptor =
        new TestClientRequestInterceptorImpl_T();

      // register client interceptor
      info->add_client_request_interceptor (clientInterceptor.in ());

      ACE_DEBUG ((LM_DEBUG, "Client interceptor registered.\n"));
    }
  catch (...)
    {
      ACE_DEBUG ((LM_DEBUG, "Caught exception while registering client interceptor.\n"));
    }
}
