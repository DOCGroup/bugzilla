// $Id: TestORBInitializerImpl_T.h,v 1.1 2007/03/05 16:20:17 vz Exp $

// ================================================================
//  ORBInitializer implementation
// ================================================================

#ifndef _TESTORBINITIALIZERIMPL_T_H_
#define _TESTORBINITIALIZERIMPL_T_H_

#include "tao/PI/PI.h"

class TestORBInitializerImpl_T
  : public virtual PortableInterceptor::ORBInitializer
{
public:
  // constructor
  TestORBInitializerImpl_T();

  // destructor
  ~TestORBInitializerImpl_T();

  // pre_init
  /* virtual */ void pre_init (PortableInterceptor::ORBInitInfo_ptr info)
     throw (CORBA::SystemException);

  // post_init
  /* virtual */ void post_init (PortableInterceptor::ORBInitInfo_ptr info)
     throw (CORBA::SystemException);
};

#endif /* _TESTORBINITIALIZERIMPL_T_H_ */
