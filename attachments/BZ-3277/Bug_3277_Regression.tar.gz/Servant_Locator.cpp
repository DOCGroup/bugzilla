// $Id: Servant_Locator.cpp,v 1.2 2008/03/17 16:44:56 vz Exp $

#include "Servant_Locator.h"
#include "ace/Log_Msg.h"
#include "testC.h"
#include "ace/OS_NS_string.h"

ACE_RCSID(Forwarding, Servant_Locator, "$Id: Servant_Locator.cpp,v 1.2 2008/03/17 16:44:56 vz Exp $")

PortableServer::Servant
Servant_Locator::preinvoke (const PortableServer::ObjectId & /* oid */,
                            PortableServer::POA_ptr /* poa_ptr */,
                            const char * /* op */,
                            PortableServer::ServantLocator::Cookie & /* cookie */)
{
  ACE_DEBUG ((LM_DEBUG,
              "About to throw forward request exception for target...\n"));
  // Throw a nil forward.
  throw PortableServer::ForwardRequest (CORBA::Object::_nil ());
}

void
Servant_Locator::postinvoke (const PortableServer::ObjectId &,
                             PortableServer::POA_ptr ,
                             const char *,
                             PortableServer::ServantLocator::Cookie ,
                             PortableServer::Servant)
{
}
