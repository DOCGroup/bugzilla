// $Id: TestClientRequestInterceptorImpl_T.cpp,v 1.1 2007/03/05 16:20:17 vz Exp $

// ================================================================
//  ClientRequestInterceptor implementation
// ================================================================

#include "TestClientRequestInterceptorImpl_T.h"

// constructor
TestClientRequestInterceptorImpl_T::TestClientRequestInterceptorImpl_T ()
{
   ACE_DEBUG ((LM_DEBUG, "Client interceptor constructed.\n"));
}

// destructor
TestClientRequestInterceptorImpl_T::~TestClientRequestInterceptorImpl_T ()
{
   // no-op
}

// destroy
void TestClientRequestInterceptorImpl_T::destroy ()
   throw (CORBA::SystemException)
{
   // no-op
}

// name
char * TestClientRequestInterceptorImpl_T::name ()
   throw (CORBA::SystemException)
{
   return CORBA::string_dup ("myName");
}

// receive_exception
void TestClientRequestInterceptorImpl_T::receive_exception (PortableInterceptor::ClientRequestInfo_ptr /* ri */)
   throw (CORBA::SystemException, PortableInterceptor::ForwardRequest)
{
   // no-op
}

// receive_other
void TestClientRequestInterceptorImpl_T::receive_other (PortableInterceptor::ClientRequestInfo_ptr /* ri */)
   throw (CORBA::SystemException, PortableInterceptor::ForwardRequest)
{
   // no-op
}

// receive_reply
void TestClientRequestInterceptorImpl_T::receive_reply (PortableInterceptor::ClientRequestInfo_ptr /* ri */)
   throw (CORBA::SystemException)
{
   // no-op
}

// send_poll
void TestClientRequestInterceptorImpl_T::send_poll (PortableInterceptor::ClientRequestInfo_ptr /* ri */)
   throw (CORBA::SystemException)
{
   // no-op
}

// send_request
void TestClientRequestInterceptorImpl_T::send_request (PortableInterceptor::ClientRequestInfo_ptr /* ri */)
   throw (CORBA::SystemException, PortableInterceptor::ForwardRequest)
{
   ACE_DEBUG ((LM_DEBUG, "ClientInterceptor::send_request invoked!\n"));
}
