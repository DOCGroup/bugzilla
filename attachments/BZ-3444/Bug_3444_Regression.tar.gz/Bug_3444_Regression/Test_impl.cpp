// $Id: Test_impl.cpp,v 1.1 2008-10-08 15:23:30 vz Exp $

#include "Test_impl.h"

ACE_RCSID(Bug_3444_Regression, Test_impl, "$Id: Test_impl.cpp 77008 2007-02-12 11:52:38Z johnnyw $")

Server_impl::Server_impl (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

void Server_impl::shutdown ()
{
  this->orb_->shutdown (0);
}
