// $Id: test.cpp,v 1.1 2006/01/31 16:47:47 sm Exp $

#include "testC.h"

int
main (int , char *[])
{
  return 0;
}
