#include <iostream>
#include <dlfcn.h>
#include <pthread.h>
#include <assert.h>


static void * dllHandle;
typedef void (* dosomething)(void);

static dosomething   capi_dosomething = 0;


void * loadDll(void *)
{
  std::cout << "loadDll - entered" << std::endl;
  dllHandle = dlopen("libcapi.so", RTLD_NOW);
  if (dllHandle == 0)
  {
    std::cerr << "unable to load library: " << dlerror() << std::endl;
    assert(dllHandle != 0);
  }
  
  capi_dosomething = (dosomething) dlsym(dllHandle, "capi_dosomething");
  if (capi_dosomething == 0)
  {
    std::cerr << "unable to resolve symbol: " << dlerror() << std::endl;
    assert(capi_dosomething != 0);
  }
  
  std::cout << "loadDll - leaving" << std::endl;
  
  return 0;
}


int main(int argc, char ** argv)
{
  int result = 0;
  
  std::cout << "main - entered" << std::endl;
  
#ifdef USE_THREAD
  pthread_t tid;
  int code = pthread_create(&tid, NULL, &loadDll, 0);
  if (code != 0)
  {
    std::cerr << "pthread_create() failed: " << code << std::endl;
    return 1;
  }
  pthread_join(tid, 0);
  std::cout << "loadDll thread finished" << std::endl;
#else
  loadDll(0);
  std::cout << "loadDll finished" << std::endl;
#endif
  
  assert(capi_dosomething != 0);
  
  capi_dosomething();
  
  std::cout << "main - leaving" << std::endl;
  
  return 0;
}
