//
// $Id: Hello.cpp,v 1.3 2002/01/29 20:21:07 okellogg Exp $
//
#include "Hello.h"
#include "tao/debug.h"

ACE_RCSID(Hello, Hello, "$Id: Hello.cpp,v 1.3 2002/01/29 20:21:07 okellogg Exp $")

Hello::Hello (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

void
Hello::take_sequence (
  const Test::long_seq & longs ACE_ENV_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (TAO_debug_level > 4) {
    ACE_DEBUG ((LM_DEBUG, "(%P|%t) Hello::take_sequence: sleeping.\n"));
  }
  ACE_OS::sleep(1);

  if (TAO_debug_level > 4) {
    ACE_DEBUG ((LM_DEBUG, "(%P|%t) Hello::take_sequence: looping.\n"));
    ACE_DEBUG ((LM_DEBUG, "(%P|%t) Hello::take_sequence: "
                          "length of long_seq = %d.\n", longs.length()));
  }
  if (TAO_debug_level > 6) {
    for (CORBA::ULong i=0; i<longs.length(); ++i) {
      ACE_DEBUG ((LM_DEBUG, "(%P|%t) longs[%d] = %d.\n", i, longs[i]));
    }
  }
}

void
Hello::shutdown (ACE_ENV_SINGLE_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}
