//
// $Id: Callback.cpp 77008 2007-02-12 11:52:38Z johnnyw $
//
#include "Callback.h"

ACE_RCSID(Callback, Callback, "$Id: Callback.cpp 77008 2007-02-12 11:52:38Z johnnyw $")

Callback::Callback (void)
  : received_callback_ (false)
{
}

void
Callback::test_oneway (void)
{
  received_callback_ = true;

  ACE_DEBUG ((LM_DEBUG,
              "(%P|%t) Callback - test_oneway!\n"));
}

bool
Callback::received_callback (void)
{
  return received_callback_;
}
