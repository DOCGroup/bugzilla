// $Id:$


#include "MessageFactory.h"
#include "MessageC.h"
#include "tao/corba.h"
#include "tao/AnyTypeCode/TypeCode.h"


int
main(
  int    argc,
  char** argv)
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

      MessageFactory *mf = new MessageFactory ();
      CORBA::String_var id = _tc_Message->id ();

      ACE_DEBUG ((LM_DEBUG, "Registering factory reference\n"));
      orb->register_value_factory (id.in (), mf);

      ACE_DEBUG ((LM_DEBUG, "Unregistering factory reference\n"));
      orb->unregister_value_factory (id.in ());

      ACE_DEBUG ((LM_DEBUG, "Value factory destructor flag: %i\n", MessageFactory::destructorInvoked_));

      ACE_DEBUG ((LM_DEBUG, "Actively removing reference\n"));
      mf->_remove_ref ();

      ACE_DEBUG ((LM_DEBUG, "Value factory destructor flag: %i\n", MessageFactory::destructorInvoked_));

      ACE_DEBUG ((LM_DEBUG, "Shutting down / destroying ORB\n"));
      orb->shutdown (true);
      orb->destroy ();

      if (MessageFactory::destructorInvoked_ == 1)
        {
          ACE_DEBUG ((LM_ERROR, "Test passed: value factory destructor was invoked as expected\n"));
          return 0;
        }
      else
        {
          ACE_DEBUG ((LM_ERROR, "Test failed: value factory destructor was not invoked\n"));
          return 1;
        }
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION, "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;
}
