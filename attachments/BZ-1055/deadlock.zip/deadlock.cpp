#include "lockS.h"

#include "tao/TAO_Internal.h"
#include "ace/Thread_Manager.h"

CORBA::ORB_ptr orb;
PortableServer::POA_ptr poa;

class DeadlockImpl : public POA_deadlock
{
public:
	DeadlockImpl()
	{
	}

  virtual void pause()
  {
	  fprintf( stderr, "pause() starting\n" ); fflush( stderr );
	  fprintf( stderr, "pause() ending\n" ); fflush( stderr );
  }

	virtual void probe1( deadlock_ptr d )
	{
		fprintf( stderr, "probe1() starting\n" ); fflush( stderr );
		d->probe2();
		fprintf( stderr, "probe1() ending\n" ); fflush( stderr );
	}

	virtual void probe2()
	{
		fprintf( stderr, "probe2\n" ); fflush( stderr );
	}
} ;

void writeior( const char* fname, const char* ior )
{
	FILE* f = fopen( fname, "w" );
	if ( f == NULL )
	{
		fprintf( stderr, "can't open %s for writing\n", fname );
		return;
	}
	fwrite( (char*) ior, 1, strlen( (char*) ior ), f );
	fclose( f );
}

void readior( const char* fname, char*& res )
{
	FILE* f = fopen( fname, "r" );
	if ( f == NULL )
	{
		fprintf( stderr, "can't open %s for reading\n", fname );
		return;
	}

	res = new char[ 4096 ];

	fgets( res, 4000, f );

	char *p;
	for ( p = res; *p; p++ )
	{
		if ( *p == '\n' )
		{
			*p = 0;
		}
	}

	fclose( f );
}

// 
// OrbRunProc
//

void* OrbRunProc( void* param )
{
	orb->run();

	return 0;
}

//
// main
//

int main( int argc, char* argv[] )
{
	CORBA::String_var ior;

  static const char* resource_factory_args = 
		"static Resource_Factory \""
		    "-ORBConnectionCacheMax 5 "
				"-ORBConnectionCachePurgePercentage 20 "
				"\"";
  static const char* server_strategy_args = "";
  static const char* client_strategy_args  = "";
  TAO_Internal::default_svc_conf_entries(
					 resource_factory_args,
					 server_strategy_args,
					 client_strategy_args );

  orb = CORBA::ORB_init( argc, argv );

	char *role = argv[ 1 ];

	if ( strcmp( role, "a" ) == 0 )
	{
		CORBA::Object_var cw;
		deadlock_var c;

		readior( "c.ior", ior.out() );
		cw = orb->string_to_object( ior.in() );
		c = deadlock::_narrow( cw );

		fprintf( stderr, "a calling c\n" ); fflush( stderr );
		c->pause();
		fprintf( stderr, "a done\n" ); fflush( stderr );

		ACE_OS::sleep( 30 );
	}
	else if ( strcmp( role, "b" ) == 0 )
	{
		CORBA::Object_var cw;
		deadlock_var c;

		readior( "c.ior", ior.out() );
		cw = orb->string_to_object( ior.in() );
		c = deadlock::_narrow( cw );

		CORBA::Object_var dw;
		deadlock_var d;

		readior( argv[ 2 ], ior.out() );
		dw = orb->string_to_object( ior.in() );
		d = deadlock::_narrow( dw );

		fprintf( stderr, "b calling c\n" ); fflush( stderr );
		c->probe1( d );
		fprintf( stderr, "b done\n" ); fflush( stderr );
	}
	else
	{
    CORBA::Object_var poaWide = orb->resolve_initial_references( "RootPOA" );
		poa = PortableServer::POA::_narrow( poaWide );
		PortableServer::POAManager_var poaManager = poa->the_POAManager();
		poaManager->activate();

		DeadlockImpl* deadlockServant = new DeadlockImpl();
		PortableServer::ObjectId_var objID = poa->activate_object( deadlockServant );
		deadlock_var dl = deadlockServant->_this();
		ior = orb->object_to_string( dl );

		if ( strcmp( role, "c" ) == 0 )
		{
			writeior( "c.ior", ior.in() );
			fprintf( stderr, "c ready\n" ); fflush( stderr );
		}
		else
		{
			writeior( argv[ 2 ], ior.in() );
			fprintf( stderr, "d ready\n" ); fflush( stderr );
		}
		// Create a 2-member thread pool.
		ACE_Thread_Manager* mgr = ACE_Thread_Manager::instance();
		( void ) mgr->spawn( OrbRunProc, NULL );
		( void ) mgr->spawn( OrbRunProc, NULL );

		ACE_OS::sleep( 9999999 );
	}

	return 0;
}
