@rem *** Start a bunch of "b" servers:
start deadlock d d1.ior
start deadlock d d2.ior
start deadlock d d3.ior
start deadlock d d4.ior

@rem *** Start the "c" server.
start deadlock c 

@echo When all servers are ready, press a key
@pause

@rem *** Setup connections from "c" to 3 of the "b" servers:
deadlock b d1.ior
deadlock b d2.ior
deadlock b d3.ior

@rem *** Start a client ("a"), which will hold a connection open to the "c" server for 30 seconds

start deadlock a

@echo *** Once server "c" has reported "pause() ending", press a key.
@pause

@rem *** Try to setup a connection from "c" to the last of the "b" servers:
start deadlock b d4.ior

@echo *** The "c" process should become deadlocked shortly (within one minute).

