TAO Bug #1055 - Deadlock involving transport cache mgr lock and reactor token.
=============================================================================
                                 Test Program
                                 ============

For details of the deadlock condition that this test program demonstrates,
see TAO Bug #1055.

TO RUN THE TEST
---------------
  1.  Add the following ACE_OS::sleep() call to TAO (version 1.2) and build it;
      ACE_wrappers/TAO/tao/Transport_Cache_Manager.inl:
          ACE_INLINE int
          TAO_Transport_Cache_Manager::purge (void)
          {
            ACE_MT (ACE_GUARD_RETURN (ACE_Lock, ace_mon, *this->cache_lock_, 0));
            ...
            if (sorted_set != 0)
              {
                ACE_OS::sleep( 60 );          /***** ADD THIS LINE *****/
                this->close_entries (sorted_set, size);
              }
            ...
          }
  2.  Build the stubs (mk_stubs.bat).
  2.  Build the test program (deadlock.dsw).
  3.  Run testit.bat.

DESCRIPTION
-----------

In this test, there are two types of clients, A and B, and two types of 
servers, C and D.

Each server hosts a single CORBA object of type "deadlock".  The methods of 
"deadlock" are:
  pause()               - prints some messages and returns immediately 
                          (somewhat misnamed)
  probe1( deadlock d )  - calls d->probe2().
  probe2()              - prints a message

Client A invokes the "pause()" method on c's object, sleeps for 30 seconds,
then exits.

Client B invokes the "probe1()" method on c's object, passing it an object
reference for the object hosted by one of the D servers.

The servers are configured with a maximum transport cache size of 5, i.e.
static Resource_Factory "-ORBConnectionCacheMax 5".

The test is run with a modified version of TAO, in which a sleep() call 
is added in the transport cache manager's purge() method in 

The steps of the test are:
  1.  Create one C server and 4 D servers (D1-D4).
  2.  Run the B client 3 times, causing C to establish a connection to each 
      of D1, D2, and D3.
  3.  Start the A client.  This establishes a connection from A to C to do 
      the invocation.  The invocation completes, and A begins its
      30-second sleep.
  4.  Run the B client once more, causing C to attempt to establish a 
      connection to D4.  At the time that C tries to open the new connection,
      there are already 5 connections in its transport cache (to D1, D2, 
      D3, A, and B [Note 1]).  This causes C to purge its transport cache, 
      which begins the 60-second sleep that was added to
      TAO_Transport_Cache_manager::purge().  At this point, the sleeping
      thread ("Thread 1") holds the transport cache manager lock.
  5.  A finishes sleeping and exits.  This closes the connection from A to C.
      This causes the leader thread ("Thread 2") in C to wake up and attempt to
      remove the handler from the reactor. This causes the thread to first
      acquire the reactor token (in ACE_Select_Reactor_T::remove_handler()),
      then while holding this token to try to get the transport cache 
      manager lock (in TAO_Transport::purge_entry()).  It blocks because 
      Thread 1 holds this lock.
  6.  Thread 1 completes its 60-second sleep.  It then tries to purge one 
      (or more) of the connections it found, which eventually results in 
      a call to ACE_Reactor::remove_handler().  This attempts to acquire
      the reactor token, owned by Thread 2.  Threads 1 and 2 are now 
      deadlocked.  [Note 2]

[Note 1] I'm not entirely sure that the incoming connections from A and B are considered
         part of the transport cache, but in any case the cache is considered full at this
         point, so that a purge() is done.

[Note 2] The deadlock involves process C only.  The client B and the servers D1-D4 may
         all be terminated and C will remain stuck.

Thread 1 Stack Trace:
---------------------
    NTDLL! 77f682db()
    KERNEL32! 77f04f37()
    ACE_Semaphore::acquire() line 276 + 9 bytes
    ACE_Token::ACE_Token_Queue_Entry::wait(ACE_Time_Value * 0x00000000, ACE_Thread_Mutex & {...}) line 105 + 17 bytes
    ACE_Token::shared_acquire(void (void *)* 0x00000000, void * 0x00000000, ACE_Time_Value * 0x00000000, ACE_Token::ACE_Token_Op_Type WRITE_TOKEN) line 260 + 19 bytes
    ACE_Token::acquire(ACE_Time_Value * 0x00000000) line 337
    ACE_Guard<ACE_Select_Reactor_Token_T<ACE_Token> >::acquire() line 9 + 13 bytes
    ACE_Guard<ACE_Select_Reactor_Token_T<ACE_Token> >::ACE_Guard<ACE_Select_Reactor_Token_T<ACE_Token> >(ACE_Select_Reactor_Token_T<ACE_Token> & {...}) line 36
    ACE_Select_Reactor_T<ACE_Select_Reactor_Token_T<ACE_Token> >::remove_handler(ACE_Event_Handler * 0x00deb6f0, unsigned long 0x000003ff) line 367 + 17 bytes
    ACE_Reactor::remove_handler(ACE_Event_Handler * 0x00deb6f0, unsigned long 0x000003ff) line 316
    TAO_Transport::close_connection_i() line 680
    TAO_Transport_Cache_Manager::close_entries(ACE_Hash_Map_Entry<TAO_Cache_ExtId,TAO_Cache_IntId> * * & 0x00deceb0, int 0x00000005) line 489
    TAO_Transport_Cache_Manager::purge() line 113
    TAO_IIOP_Connector::connect(TAO_GIOP_Invocation * 0x011ce7b0, TAO_Transport_Descriptor_Interface * 0x011ce5c0, CORBA_Environment & {...}) line 183
    TAO_Connector_Registry::connect(TAO_GIOP_Invocation * 0x011ce7b0, TAO_Transport_Descriptor_Interface * 0x011ce5c0, CORBA_Environment & {...}) line 285
    TAO_GIOP_Invocation::perform_call(TAO_Transport_Descriptor_Interface & {...}, CORBA_Environment & {...}) line 253 + 20 bytes
    TAO_Default_Endpoint_Selector::select_endpoint(TAO_GIOP_Invocation * 0x011ce7b0, CORBA_Environment & {...}) line 49 + 16 bytes
    TAO_GIOP_Invocation::start(CORBA_Environment & {...}) line 214
    TAO_GIOP_Twoway_Invocation::start(CORBA_Environment & {...}) line 805
    _TAO_deadlock_Remote_Proxy_Impl::probe2(CORBA_Object * 0x00deda60) line 908 + 18 bytes
    deadlock::probe2() line 1244 + 51 bytes
    DeadlockImpl::probe1(deadlock * 0x00deda50) line 25 + 13 bytes
    POA_deadlock::probe1_skel(TAO_ServerRequest & {...}, void * 0x00de89b0, void * 0x011cf074, CORBA_Environment & {...}) line 852 + 34 bytes
    TAO_ServantBase::synchronous_upcall_dispatch(TAO_ServerRequest & {...}, void * 0x011cf074, void * 0x00de89b0, CORBA_Environment & {...}) line 225 + 19 bytes
    POA_deadlock::_dispatch(TAO_ServerRequest & {...}, void * 0x011cf074, CORBA_Environment & {...}) line 1092 + 56 bytes
    TAO_Default_Servant_Dispatcher::dispatch(TAO_Object_Adapter::Servant_Upcall & {...}, TAO_ServerRequest & {...}, CORBA_Environment & {...}) line 21
    TAO_Object_Adapter::dispatch_servant(const TAO_ObjectKey & {...}, TAO_ServerRequest & {...}, CORBA_Object_out {...}, CORBA_Environment & {...}) line 329
    TAO_Object_Adapter::dispatch(TAO_ObjectKey & {...}, TAO_ServerRequest & {...}, CORBA_Object_out {...}, CORBA_Environment & {...}) line 740 + 48 bytes
    TAO_Adapter_Registry::dispatch(TAO_ObjectKey & {...}, TAO_ServerRequest & {...}, CORBA_Object_out {...}, CORBA_Environment & {...}) line 117 + 53 bytes
    TAO_GIOP_Message_Base::process_request(TAO_Transport * 0x00dea830, TAO_InputCDR & {...}, TAO_OutputCDR & {...}) line 781
    TAO_GIOP_Message_Base::process_request_message(TAO_Transport * 0x00dea830, TAO_Queued_Data * 0x011cf87c) line 597 + 26 bytes
    TAO_Transport::process_parsed_messages(TAO_Queued_Data * 0x011cf87c, TAO_Resume_Handle & {...}) line 1357 + 51 bytes
    TAO_Transport::handle_input_i(TAO_Resume_Handle & {...}, ACE_Time_Value * 0x00000000, int 0x00000000) line 888 + 22 bytes
    TAO_IIOP_Connection_Handler::handle_input(void * 0x0000015c) line 349 + 33 bytes
    ACE_TP_Reactor::dispatch_socket_event(ACE_EH_Dispatch_Info & {...}) line 573 + 10 bytes
    ACE_TP_Reactor::handle_socket_events(int & 0x00000001, ACE_TP_Token_Guard & {...}) line 375 + 12 bytes
    ACE_TP_Reactor::dispatch_i(ACE_Time_Value * 0x00000000, ACE_TP_Token_Guard & {...}) line 201 + 16 bytes
    ACE_TP_Reactor::handle_events(ACE_Time_Value * 0x00000000) line 134 + 16 bytes
    ACE_Reactor::handle_events(ACE_Time_Value * 0x00000000) line 158
    TAO_ORB_Core::run(ACE_Time_Value * 0x00000000, int 0x00000000, CORBA_Environment & {...}) line 1807 + 15 bytes
    CORBA_ORB::run(ACE_Time_Value * 0x00000000, CORBA_Environment & {...}) line 250
    CORBA_ORB::run(CORBA_Environment & {...}) line 234
    OrbRunProc(void * 0x00000000) line 78 + 30 bytes
    ACE_Thread_Adapter::invoke_i() line 148 + 7 bytes
    ACE_Thread_Adapter::invoke() line 91 + 11 bytes
    ace_thread_adapter(void * 0x00deae00) line 127 + 10 bytes
    _threadstartex(void * 0x00dead60) line 212 + 13 bytes
    KERNEL32! 77f04ede()

Thread 2 Stack Trace:
---------------------
    NTDLL! 77f682db()
    NTDLL! 77f67586()
    ACE_Thread_Mutex::acquire() line 507 + 9 bytes
    ACE_Lock_Adapter<ACE_Thread_Mutex>::acquire() line 194
    ACE_Guard<ACE_Lock>::acquire() line 9 + 15 bytes
    ACE_Guard<ACE_Lock>::ACE_Guard<ACE_Lock>(ACE_Lock & {...}) line 36
    TAO_Transport_Cache_Manager::purge_entry(ACE_Hash_Map_Entry<TAO_Cache_ExtId,TAO_Cache_IntId> * & 0x00dea3d0) line 122 + 15 bytes
    TAO_Transport::purge_entry() line 620
    TAO_IIOP_Connection_Handler::handle_close_i() line 248
    TAO_IIOP_Connection_Handler::handle_close(void * 0x0000013c, unsigned long 0x00000001) line 214
    ACE_Select_Reactor_Handler_Repository::unbind(void * 0x0000013c, unsigned long 0x00000001) line 308
    ACE_Select_Reactor_T<ACE_Select_Reactor_Token_T<ACE_Token> >::remove_handler_i(void * 0x0000013c, unsigned long 0x00000001) line 958
    ACE_Select_Reactor_T<ACE_Select_Reactor_Token_T<ACE_Token> >::remove_handler(void * 0x0000013c, unsigned long 0x00000001) line 378 + 22 bytes
    ACE_TP_Reactor::dispatch_socket_event(ACE_EH_Dispatch_Info & {...}) line 579 + 19 bytes
    ACE_TP_Reactor::handle_socket_events(int & 0x00000000, ACE_TP_Token_Guard & {...}) line 375 + 12 bytes
    ACE_TP_Reactor::dispatch_i(ACE_Time_Value * 0x00000000, ACE_TP_Token_Guard & {...}) line 201 + 16 bytes
    ACE_TP_Reactor::handle_events(ACE_Time_Value * 0x00000000) line 134 + 16 bytes
    ACE_Reactor::handle_events(ACE_Time_Value * 0x00000000) line 158
    TAO_ORB_Core::run(ACE_Time_Value * 0x00000000, int 0x00000000, CORBA_Environment & {...}) line 1807 + 15 bytes
    CORBA_ORB::run(ACE_Time_Value * 0x00000000, CORBA_Environment & {...}) line 250
    CORBA_ORB::run(CORBA_Environment & {...}) line 234
    OrbRunProc(void * 0x00000000) line 78 + 30 bytes
    ACE_Thread_Adapter::invoke_i() line 148 + 7 bytes
    ACE_Thread_Adapter::invoke() line 91 + 11 bytes
    ace_thread_adapter(void * 0x00deafc0) line 127 + 10 bytes
    _threadstartex(void * 0x00deaf20) line 212 + 13 bytes
    KERNEL32! 77f04ede()
    
    
Graeme Clark
Open Text Corporation
gclark@opentext.com


