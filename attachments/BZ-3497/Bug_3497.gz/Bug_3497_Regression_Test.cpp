/**
 * @file Bug_3497_Regression_Test.cpp
 *
 * Reproduces the problems reported in bug 3497
 *   http://deuce.doc.wustl.edu/bugzilla/show_bug.cgi?id=3497
 *
 * @author mark.johnson@configuresoft.com
 */

#include "test_config.h"
#include "ace/OS.h"
#include "ace/Atomic_Op.h"

ACE_RCSID (tests,
           Bug_3497_Regression_Test,
           "Bug_3497_Regression_Test.cpp")

class Test_SharedEntity
{
public:
  Test_SharedEntity( void ) :
	_count(0)
  {
    if (ACE_OS::event_init(&_event) != 0)
    {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: event_init failed\n")));
	exit (1);
    }
  }

  void Signal()
  {
    ++_count;
    if (ACE_OS::event_signal(&_event) != 0)
    {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: event_signal failed\n")));
	exit (1);
    }
  }

  void WaitAndCheck()
  {
    if (ACE_OS::event_wait(&_event) != 0)
    {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: 1st event_wait failed\n")));
	exit (1);
    }

    long count_after_wait = _count.value();

    if (ACE_OS::event_wait(&_event) != 0)
    {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: 2nd event_wait failed\n")));
	exit (1);
    }

    if (_count != (count_after_wait + 1))
    {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: Event is signaled again, but count isn't incremented\n")));
	exit (1);
    }

  }

private:
  ACE_event_t _event;
  ACE_Atomic_Op<ACE_Thread_Mutex,long> _count;
};

extern "C" ACE_THR_FUNC_RETURN Signaller(void * args)
{
	Test_SharedEntity * entity = static_cast<Test_SharedEntity*>(args);
	entity->Signal();
	ACE_OS::sleep(30);
	entity->Signal();
	return 0;
}

extern "C" ACE_THR_FUNC_RETURN Waiter(void * args)
{
	ACE_OS::sleep(10);
	Test_SharedEntity * entity = static_cast<Test_SharedEntity*>(args);
	entity->WaitAndCheck();
	return 0;
}
	
int
run_main (int, ACE_TCHAR *[])
{
  ACE_START_TEST (ACE_TEXT ("Bug_3497_Regression_Test"));

  Test_SharedEntity share;

  ACE_thread_t thread1_id;
  ACE_hthread_t hthread1_id;

  if ( ACE_OS::thr_create(Signaller, &share, THR_JOINABLE, &thread1_id, &hthread1_id) != 0)
  {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: 1st thr_create failed\n")));
	exit (1);
  }

  ACE_thread_t thread2_id;
  ACE_hthread_t hthread2_id;

  if ( ACE_OS::thr_create(Waiter, &share, THR_JOINABLE, &thread2_id, &hthread2_id) != 0)
  {
        ACE_ERROR ((LM_ERROR,
                    ACE_TEXT ("Error: 2nd thr_create failed\n")));
	exit (1);
  }

  ACE_THR_FUNC_RETURN thread1_status;
  ACE_OS::thr_join(hthread1_id, &thread1_status);

  ACE_THR_FUNC_RETURN thread2_status;
  ACE_OS::thr_join(hthread2_id, &thread2_status);

  ACE_END_TEST;

  return 0;
}
