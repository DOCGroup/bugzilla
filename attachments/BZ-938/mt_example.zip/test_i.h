// test_i.h,v 1.1 1999/06/19 22:39:53 coryan Exp

// ============================================================================
//
// = LIBRARY
//   TAO/tests/MT_Server
//
// = FILENAME
//   test_i.h
//
// = AUTHOR
//   Carlos O'Ryan
//
// ============================================================================

#ifndef TAO_MT_SERVER_TEST_I_H
#define TAO_MT_SERVER_TEST_I_H

#include "testS.h"

class Simple_Server_i : public POA_Simple_Server
{
  // = TITLE
  //   Simpler Server implementation
  //
  // = DESCRIPTION
  //   Implements the Simple_Server interface in test.idl
  //
public:
  Simple_Server_i (CORBA::ORB_ptr orb, ACE_Thread_Semaphore& signal);
  // ctor

  // = The Simple_Server methods.
  CORBA::Long test_method (CORBA::Long x, CORBA::Environment&)
    ACE_THROW_SPEC (());

  void shutdown (CORBA::Environment&)
    ACE_THROW_SPEC (());

private:
  CORBA::ORB_var orb_;
	ACE_Thread_Semaphore& signal_;
  // The ORB
};

#if defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

#endif /* TAO_MT_SERVER_TEST_I_H */
