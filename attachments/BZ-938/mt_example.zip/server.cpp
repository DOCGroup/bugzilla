// server.cpp,v 1.4 2001/03/04 21:59:13 coryan Exp

#include "test_i.h"
#include "ace/Get_Opt.h"
#include "ace/Task.h"
#include "tao/ORB_Core.h"

ACE_RCSID(MT_Server, server, "server.cpp,v 1.4 2001/03/04 21:59:13 coryan Exp")

const char *ior_output_file = 0;

int nthreads = 4;

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "o:n:");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'o':
	ior_output_file = get_opts.optarg;
	break;

      case 'n':
	nthreads = ACE_OS::atoi (get_opts.optarg);
	break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
			   "-o <iorfile>"
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}

class Worker : public ACE_Task_Base
{
  // = TITLE
  //   Run a server thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run server threads
  //
public:
  Worker (CORBA::ORB_ptr orb);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

//
//		class CtrlCHandler
//

class CtrlCHandler : public ACE_Event_Handler
{
public:
	CtrlCHandler(ACE_Thread_Semaphore& semaphore);
	~CtrlCHandler();
	int handle_signal (int, siginfo_t *, ucontext_t *);
	int handle_close (ACE_HANDLE handle, ACE_Reactor_Mask mask);
private:
	ACE_Sig_Set m_signals;
	ACE_Thread_Semaphore& m_semaphore;
};

CtrlCHandler::CtrlCHandler(ACE_Thread_Semaphore& semaphore)
 : m_semaphore(semaphore)
{
	ACE_OS::sigaddset(m_signals, SIGINT);
	if (TAO_ORB_Core_instance()->reactor()->register_handler(&m_signals, this) == -1) {
    cerr << "Could not register SIGINT handler!" << endl;
	}
}

CtrlCHandler::~CtrlCHandler()
{
	if (TAO_ORB_Core_instance()->reactor()->remove_handler(&m_signals) == -1) {
    cerr << "Could not remove SIGINT handler!" << endl;
	}
}

int
CtrlCHandler::handle_signal(int signal, siginfo_t *, ucontext_t *)
{
	if (signal == SIGINT) {
		m_semaphore.release();
		return -1;
	}

	return 0;
}

int
CtrlCHandler::handle_close (ACE_HANDLE handle, ACE_Reactor_Mask mask)
{
	delete this;
	return 0;
}


//
//		class ShutdownTask
//

class ShutdownTask : public ACE_Task_Base
{
public:
	ShutdownTask(CORBA::ORB_ptr orb);
	int svc();
	ACE_Thread_Semaphore& semaphore();
private:
	CORBA::ORB_var m_orb;
	ACE_Thread_Semaphore m_semaphore;
};

ShutdownTask::ShutdownTask(CORBA::ORB_ptr orb)
 : m_orb(orb), m_semaphore(0)
{
}

ACE_Thread_Semaphore&
ShutdownTask::semaphore()
{
	return m_semaphore;
}

int
ShutdownTask::svc()
{
	try {
		m_semaphore.acquire();
		// ACE_OS::sleep(3); - tried this to see if a race condition was involved
    // - it made no difference
		std::cout << "Shutting down ORB..." << std::endl;
		m_orb->shutdown(0);
		std::cout << "Shutdown complete." << std::endl;
	} catch (const CORBA::Exception& ex) {
		ACE_PRINT_EXCEPTION(ACE_ANY_EXCEPTION, "ShutdownTask::svc");
	} catch (...) {
		cerr << "Unknown exception in ShutdownTask:svc" << endl;
	}
	return 0;
}

int
main (int argc, char *argv[])
{
  ACE_TRY_NEW_ENV
	{
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "", ACE_TRY_ENV);
      ACE_TRY_CHECK;

			ShutdownTask shutdown(orb);
			shutdown.activate();

			CtrlCHandler ctrlcHandler(shutdown.semaphore());

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA", ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (poa_object.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Unable to initialize the POA.\n"),
                          1);

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in (), ACE_TRY_ENV);
      ACE_TRY_CHECK;

      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      Simple_Server_i server_impl (orb.in (), shutdown.semaphore());

      Simple_Server_var server =
        server_impl._this (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA::String_var ior =
			orb->object_to_string (server.in (), ACE_TRY_ENV);
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "Activated as <%s>\n", ior.in ()));

      // If the ior_output_file exists, output the ior to it
      if (ior_output_file != 0)
	{
	  FILE *output_file= ACE_OS::fopen (ior_output_file, "w");
	  if (output_file == 0)
	    ACE_ERROR_RETURN ((LM_ERROR,
			       "Cannot open output file for writing IOR: %s",
			       ior_output_file),
			      1);
	  ACE_OS::fprintf (output_file, "%s", ior.in ());
	  ACE_OS::fclose (output_file);
	}

      poa_manager->activate (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      Worker worker (orb.in ());
      if (worker.activate (THR_NEW_LWP | THR_JOINABLE,
                           nthreads) != 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);

      worker.thr_mgr ()->wait ();

      ACE_DEBUG ((LM_DEBUG, "event loop finished\n"));
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

// ****************************************************************

Worker::Worker (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
Worker::svc (void)
{
  ACE_DECLARE_NEW_CORBA_ENV;
  ACE_TRY
    {
			cout << "About to run ORB" << endl;
      this->orb_->run (ACE_TRY_ENV);
			cout << "ORB has been shutdown" << endl;
      ACE_TRY_CHECK;
    }
  ACE_CATCHANY
    {
    }
  ACE_ENDTRY;
  return 0;
}
