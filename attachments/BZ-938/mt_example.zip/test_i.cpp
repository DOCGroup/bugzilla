// test_i.cpp,v 1.3 2001/03/26 21:17:09 coryan Exp

#include "test_i.h"
#include "tao/debug.h"

#if !defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

ACE_RCSID(MT_Server, test_i, "test_i.cpp,v 1.3 2001/03/26 21:17:09 coryan Exp")

CORBA::Long
Simple_Server_i::test_method (CORBA::Long x, CORBA::Environment&)
    ACE_THROW_SPEC (())
{
  if (TAO_debug_level > 0)
    ACE_DEBUG ((LM_DEBUG, "Request in thread %t\n"));
  ACE_Time_Value tv (0, 15000);
  ACE_OS::sleep (tv);
  return x;
}

void
Simple_Server_i::shutdown (CORBA::Environment& ACE_TRY_ENV)
    ACE_THROW_SPEC (())
{
	signal_.release();
  //this->orb_->shutdown (0, ACE_TRY_ENV);
}
