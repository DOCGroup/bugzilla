//$Id: Events.cpp 94802 2011-10-20 09:46:10Z mcorino $

#include "ace/Arg_Shifter.h"
#include "ace/Get_Opt.h"
#include "tao/debug.h"
#include "StructuredEventPackaging.h"


/***************************************************************************/
StructuredEventPackaging::StructuredEventPackaging (void) 
: extractedTrueCorrectly(false), extractedFalseCorrectly(false)
{
}

StructuredEventPackaging::~StructuredEventPackaging (void)
{
}

int
StructuredEventPackaging::init (int argc,
                   ACE_TCHAR* argv [])
{
  // Initialize the base class.
  Notify_Test_Client::init (argc,
                            argv);

  return 0;
}

void 
StructuredEventPackaging::packageAndExtract(bool value)
{
  // Structured event.
  CosNotification::StructuredEvent event;
  CORBA::Boolean bExtract=false;
  CORBA::Any aBool;

  aBool<<=CORBA::Any::from_boolean(value);


  // EventHeader.

  // FixedEventHeader.
  // EventType.
  // string.
  event.header.fixed_header.event_type.domain_name = CORBA::string_dup("testdomain");
  // string
  event.header.fixed_header.event_type.type_name = CORBA::string_dup("testtype");
  // string
  event.header.fixed_header.event_name = CORBA::string_dup("testeventname");

  // No optionalHeaderFields.
  event.header.variable_header.length(0);

  // FilterableEventBody
  // PropertySeq of one element only
  // sequence<Property>: string name, any value
  event.filterable_data.length (1);
  event.filterable_data[0].name = CORBA::string_dup("anyname");
  event.filterable_data[0].value <<= aBool;

  // reextract bool value
  event.filterable_data[0].value>>=CORBA::Any::to_boolean(bExtract);

  ACE_DEBUG ((LM_DEBUG,
              "StructuredEventPackaging packaged %d and extracted %d\n",
              value, bExtract
  ));

  // remember result
  if (value)
    {
       extractedTrueCorrectly=bExtract;
    }
  else
    {
       extractedFalseCorrectly=!bExtract;
    }
}

void
StructuredEventPackaging::run_test (void)
{
  // package and extract false value
  packageAndExtract(false);

  // package and extract true value
  packageAndExtract(true);
}

void
StructuredEventPackaging::end_test (void)
{
  consumer_done( 0 );
}

int
StructuredEventPackaging::check_results (void)
{
  if (extractedTrueCorrectly && extractedFalseCorrectly)
    {
      ACE_DEBUG ((LM_DEBUG,
                  "StructuredEventPackaging test success\n"));
      return 0;
    }
  else
    {
      ACE_DEBUG ((LM_DEBUG,
                  "StructuredEventPackaging test failed!\n"));
      if (!extractedTrueCorrectly)
        {
          ACE_DEBUG ((LM_DEBUG,
                      "True value was not extracted correctly\n"));
        }

      if (!extractedFalseCorrectly)
        {
          ACE_DEBUG ((LM_DEBUG,
                      "False value was not extracted correctly\n"));
        }

      return 1;
    }
}

/***************************************************************************/

int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  StructuredEventPackaging instance;

  try
    {
      instance.init (argc,
                   argv);

      instance.run_test ();

    }
  catch (const CORBA::Exception& se)
    {
      se._tao_print_exception ("Error: ");
      return 1;
    }

  int status = 0;

  try
    {
      status = instance.check_results ();
    }
  catch (const CORBA::Exception& se)
    {
      se._tao_print_exception ("Error: ");
      status = 1;
    }

  return status;
}
