/* -*- C++ -*- */
//=============================================================================
/**
 *  @file   StructuredEventPackaging.h
 *
 *  $Id: StructuredEventPackaging.h 
 *
 * Test to check if boolean value packaged in CORBA::Any and inserted in 
 * CosNotification::StructuredEvent is extracted as expected.
 *
 *
 *  @author Markus Manck <Markus.Manck@philotech.de>
 */
//=============================================================================


#ifndef NOTIFY_TESTS_StructuredEventPackaging_H
#define NOTIFY_TESTS_StructuredEventPackaging_H

#include "Notify_Test_Client.h"
#include "Notify_StructuredPushConsumer.h"
#include "Notify_StructuredPushSupplier.h"

#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4250)
#endif /* _MSC_VER */


/***************************************************************************/

class StructuredEventPackaging : public Notify_Test_Client
{
public:
  // Initialization and termination code.
  StructuredEventPackaging (void);
  virtual ~StructuredEventPackaging (void);

  /// Initialization.
  int init (int argc,
            ACE_TCHAR *argv []);

  /// Run the test.
  void run_test (void);

  /// End the test.
  void end_test (void);

  /// check if we got the expected results.
  int check_results (void);

protected:
  // indicator for correct bool extraction
  bool extractedTrueCorrectly;
  bool extractedFalseCorrectly;
  // packaging and extraction of bool value
  void packageAndExtract(bool value);

private:
};

/***************************************************************************/

#if defined(_MSC_VER)
#pragma warning(pop)
#endif /* _MSC_VER */

#endif /* NOTIFY_TESTS_StructuredEventPackaging_H */
