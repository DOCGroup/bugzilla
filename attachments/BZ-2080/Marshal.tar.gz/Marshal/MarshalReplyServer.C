// server.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp

#include "marshal_impl.h"
#include <tao/corba.h>
#include "ace/CORBA_macros.h"
#include "tao/PortableServer/PortableServer.h"
#include <ace/OS_NS_stdio.h>

ACE_RCSID(Marshal, server, "server.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp")

const char *ior_output_file = "/tmp/marshalReplyServer.ior";;

using namespace MARSHAL;

int
main (int argc, char *argv[])
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "");
      ACE_TRY_CHECK;

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA");
      if (CORBA::is_nil (poa_object.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Unable to initialize the POA.\n"),
                          1);

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in ());
      ACE_TRY_CHECK;

      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager ();
      ACE_TRY_CHECK;

      MARSHAL_Marshal_ReplyServer_i server_impl;

      Marshal_ReplyServer_var server = server_impl._this ();
      ACE_TRY_CHECK;

      CORBA::String_var ior =
	orb->object_to_string (server.in ());
      ACE_TRY_CHECK;

      ACE_DEBUG ((LM_DEBUG, "\nMarshalReplyServer: %s    \n", ior.in ()));

      // If the ior_output_file exists, output the ior to it
      if (ior_output_file != 0)
	{
	  FILE *output_file= ACE_OS::fopen (ior_output_file, "w");
	  if (output_file == 0)
	    ACE_ERROR_RETURN ((LM_ERROR,
			       "Cannot open output file for writing IOR: %s",
			       ior_output_file),
			      1);
	  ACE_OS::fprintf (output_file, "%s", ior.in ());
	  ACE_OS::fclose (output_file);
	}

      poa_manager->activate ();
      ACE_TRY_CHECK;

      orb->run ();
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Catched exception:");
      return 1;
    }
  ACE_ENDTRY;
  return 0;
}
