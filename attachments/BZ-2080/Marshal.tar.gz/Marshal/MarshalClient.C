// client.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp

#include "marshalC.h"
#include "ace/Get_Opt.h"
// #include "tao/TimeBaseC.h"
#include <iostream.h>
// #include "Messaging/Messaging_RT_PolicyC.h"

ACE_RCSID(Marshal, client, "client.cpp,v 1.2 2000/04/30 02:49:28 coryan Exp")

const char * pIOR_Handler = "file://marshalHandler.ior";
const char * pIOR_ReplyServer = "file://marshalReplyServer.ior";

using namespace MARSHAL;

bool findIor(CORBA::String_var & ior, const char* file)
{
    if (!file || !(*file))
	return 0;

    FILE *pFile = fopen(file, "rb");

    if (!pFile){
	cout << endl << "Could not open ior file!";
	return 0;
    }

    unsigned long ulLen = 10000;
    char* pszBuff = new char[ulLen];
    pszBuff[0] = '\0';
    ulLen = fread((void*)(pszBuff), 1, ulLen, pFile);
    cout << endl << "ior length: " << ulLen;
    pszBuff[ulLen] = '\0';

    ior = ((const char*)strstr(strtok(pszBuff, " \t\n\r"), "IOR:"));

    cout  << endl << "Using IOR: " << file << endl;

    fclose(pFile);
    //delete [] pszBuff;

    return ulLen > 100UL;
}


int main (int argc, char* argv[])
{
  ACE_TRY_NEW_ENV
    {

      const char* iorFileHandler = "/tmp/marshalHandler.ior";
      const char* iorFileReplyServer = "/tmp/marshalReplyServer.ior";

      CORBA::String_var iorMarshalHandler;
      CORBA::String_var iorMarshalReplyServer;

      if ( !findIor(iorMarshalHandler, iorFileHandler) )
      {
         cout << endl << "Could not read IOR file "
              <<  "marshalHandler.ior" << endl << flush;
         return 1;
      }

      if ( !findIor(iorMarshalReplyServer, iorFileReplyServer) )
      {
         cout << endl << "Could not read IOR file "
              <<  "marshalReplyServer.ior" << endl << flush;
         return 1;
      }

      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "");
      ACE_TRY_CHECK;

//        if (parse_args (argc, argv) != 0)
//          return 1;

      //JRo:
      CORBA::Object_var object =
        orb->string_to_object (iorMarshalHandler);
      ACE_TRY_CHECK;

      Marshal_Handler_var marshalHandler =
        Marshal_Handler::_narrow (object.in ());
      ACE_TRY_CHECK;

      if (CORBA::is_nil (marshalHandler.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Object reference <%s> is nil\n",
                             pIOR_Handler),
                            1);
        }



      CORBA::Object_var object2 =
        orb->string_to_object (iorMarshalReplyServer);
      ACE_TRY_CHECK;

      Marshal_ReplyServer_var marshalReplyServer =
        Marshal_ReplyServer::_narrow (object2.in ());
      ACE_TRY_CHECK;

      if (CORBA::is_nil (marshalReplyServer.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Object reference <%s> is nil\n",
                             pIOR_ReplyServer),
                            1);
        }


//        CORBA::Marshal_ptr tmpMarshal;
//        tmpMarshal = orb->create_alias_tc("IDL:NWI3/SDH_TP/LoopType:1.0", //RepositoryID
//  					  "LoopType", // LoopType
//  					  CORBA::_tc_short);


      CORBA::Any any;
      LoopType value = 42;

      any <<= value;
      any.type(_tc_LoopType);


//        AttributeVal attrVal;
//        attrVal.shortVal =  value;
//        attrVal.laserModeVal = value;
//        attrVal.anyVal  = any;

      marshalHandler->sendRequest(any, marshalReplyServer);
      ACE_TRY_CHECK;


    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION, "Catched exception:");
      return 1;
    }
  ACE_ENDTRY;
  return 0;
}
