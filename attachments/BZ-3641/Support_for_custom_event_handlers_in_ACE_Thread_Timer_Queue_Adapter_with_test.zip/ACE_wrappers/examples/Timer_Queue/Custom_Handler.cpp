// ============================================================================
// = LIBRARY
//    examples
//
// = FILENAME
//    Custom_Handler.cpp
//
// = DESCRIPTION
//    This is a custom event handler to be used with the thread timer queue 
//    adapter, and its appropriate upcall.
//
// = AUTHOR
//    Alon Diamant <diamant.alon@gmail.com
//
// ============================================================================

#if !defined (_CUSTOM_HANDLER_CPP_)
#define _CUSTOM_HANDLER_CPP_

#include "Custom_Handler.h"
#include "ace/OS_NS_stdio.h"

Custom_Handler::Custom_Handler(const ACE_Time_Value &expiration_time)
  :  expires_ (expiration_time),
     id_ (0)
{
}

Custom_Handler::~Custom_Handler (void)
{
}

void
Custom_Handler::set_id (int id)
{
  this->id_ = id;
}

// This is the method invoked when the Timer expires.
int
Custom_Handler::on_timeout (const ACE_Time_Value &current_time,
                            const void *)
{
  ACE_Time_Value delay = current_time - this->expires_;

  // No need to protect this printf is always called from a Async safe
  // point.
  ACE_OS::printf ("\nexpiring timer %d at %lu.%7.7lu secs\n"
                  "\tthere was a %lu.%7.7lu secs delay\n",
                  this->id_,
                  current_time.sec (),
                  current_time.usec (),
                  delay.sec (),
                  delay.usec ());
                  
  // Notice this delete is protected.
  delete this;
  
  return 0;
}

int Custom_Handler_Upcall::registration(TTimerQueue& timer_queue, Custom_Handler* handler, const void* arg)
{
    ACE_TRACE(ACE_TEXT ("registration"));
    
    return 0;
}

int Custom_Handler_Upcall::preinvoke(TTimerQueue& timer_queue, Custom_Handler* handler, const void* arg, int recurring_timer, const ACE_Time_Value& cur_time, const void*& upcall_act)
{
    ACE_TRACE(ACE_TEXT ("preinvoke"));
    
    return 0;
}

int Custom_Handler_Upcall::timeout(TTimerQueue& timer_queue, Custom_Handler* handler, const void* arg, int recurring_timer, const ACE_Time_Value& cur_time)
{
    ACE_TRACE(ACE_TEXT ("timeout"));

    // Do the actual timer call
    handler->on_timeout(cur_time, arg);       

    return 0;
}

int Custom_Handler_Upcall::postinvoke(TTimerQueue& timer_queue, Custom_Handler* handler, const void* arg, int recurring_timer, const ACE_Time_Value& cur_time, const void* upcall_act)
{
    ACE_TRACE(ACE_TEXT ("postinvoke"));
    
    return 0;
}

int Custom_Handler_Upcall::cancel_type(TTimerQueue& timer_queue, Custom_Handler* handler, int dont_call, int& requires_reference_counting)
{
    ACE_TRACE(ACE_TEXT ("cancel_type"));
    
    return 0;
}

int Custom_Handler_Upcall::cancel_timer(TTimerQueue& timer_queue, Custom_Handler* handler, int dont_call, int requires_reference_counting)
{
    ACE_TRACE(ACE_TEXT ("cancel_timer"));
    delete handler;
    return 0;
}

int Custom_Handler_Upcall::deletion(TTimerQueue& timer_queue, Custom_Handler* handler, const void* arg)
{
    ACE_TRACE(ACE_TEXT ("deletion"));
    delete handler;
    return 0;
}
#endif /* _CUSTOM_HANDLER_CPP_ */

