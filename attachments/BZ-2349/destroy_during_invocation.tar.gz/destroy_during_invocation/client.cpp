// $Id: client.cpp,v 1.5 2002/01/29 20:21:07 okellogg Exp $

#include "fooC.h"
#include "ace/Log_Msg.h"

const char* ior = "file://server.ior";

int
main (int argc, char** argv)
{
  try
    {
      CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

      CORBA::Object_var tmp = orb->string_to_object(ior);

      foo_var server = foo::_narrow(tmp.in ());

      if (CORBA::is_nil (server.in ()))
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                             "Nil foo reference <%s>\n",
                             ior),
                            1);
        }

      server->shutdown (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;

      orb->destroy (ACE_ENV_SINGLE_ARG_PARAMETER);
      ACE_TRY_CHECK;
    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("CORBA::Exception");
    }

  return 0;
}
