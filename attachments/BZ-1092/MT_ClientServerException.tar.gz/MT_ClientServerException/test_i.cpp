// test_i.cpp,v 1.4 2001/05/20 15:46:57 sbetterm Exp

#include "test_i.h"
#include "tao/debug.h"
#include <sstream>

#if !defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

ACE_RCSID(MT_Server, test_i, "test_i.cpp,v 1.4 2001/05/20 15:46:57 sbetterm Exp")

CORBA::Long
Simple_Server_i::test_method (CORBA::Long x)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  if (TAO_debug_level > 0)
    ACE_DEBUG ((LM_DEBUG, "Request in thread %t\n"));
//  ACE_Time_Value tv (0, 15000);
//  ACE_OS::sleep (tv);
  return x;
}


CORBA::Long
Simple_Server_i::test_raise (CORBA::Long x)
ACE_THROW_SPEC ((
  CORBA::SystemException,
  Simple_Server::Failure
))
{
  ACE_UNUSED_ARG (x);
  throw Simple_Server::Failure ();

#if defined (WIN32) || defined (__HP_aCC)
  return x;
#endif /*WIN32 & HP */
}


void
Simple_Server_i::collect (
  OctetSeq_out payload,
  CORBA::String_out key,
  const OctetSeq & who,
  CORBA::Long length
)
ACE_THROW_SPEC ((
  CORBA::SystemException,
  Simple_Server::Failure,
  Simple_Server::Timeout
))
{
	if ( length > 0 )
	{
		CORBA::ULong i=0;

		// Populate the payload.
		payload = new OctetSeq;
		payload->length( length );
		CORBA::Octet j=(length%0x100);
		for ( i=0; i<CORBA::ULong( length ); ++i, ++j )
		{
			payload[i] = j;
		}

		// Populate the key.
		std::stringstream string;
		string << "Key[" << length << "]={ " << std::hex << std::setw( 2 ) << std::setfill( '0' );
		for ( i=0; i<who.length()-1; ++i )
			string << "0x" << who[i] << ", ";
		string << "0x" << who[i] << " }";
		key = CORBA::string_dup( string.str().c_str() );
	}
	else if ( length < 0 )
	{
		throw Simple_Server::Failure( "Negative length" );
	}
	else
	{
		throw Simple_Server::Timeout( "Simulated timeout" );
	}
}


void
Simple_Server_i::shutdown ()
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0);
}
