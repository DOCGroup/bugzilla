// client.cpp,v 1.3 2000/09/13 22:22:36 sbetterm Exp

#include "ace/Get_Opt.h"
#include "tao/debug.h"
#include "ace/Task.h"
#include "testC.h"

ACE_RCSID(MT_ClientServerException, client, "client.cpp,v 1.3 2000/09/13 22:22:36 sbetterm Exp")

const char *ior = "file://test.ior";
int niterations = 5;
int nthreads = 4;
int do_shutdown = 0;
int do_exceptions = 0;
int do_arguments = 0;

int
parse_args (int argc, char *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, "xk:i:n:ea");
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'x':
        do_shutdown = 1;
        break;

      case 'k':
        ior = get_opts.optarg;
        break;

      case 'i':
        niterations = ACE_OS::atoi (get_opts.optarg);
        break;

      case 'n':
        nthreads = ACE_OS::atoi (get_opts.optarg);
        break;

      case 'e':
        do_exceptions = 1;
        break;

      case 'a':
        do_arguments = 1;
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                              "usage:  %s "
                              "-k <ior> "
                              "-i <niterations> "
                              "-n <threads> "
                              "-e "
                              "-a "
                              "-x "
                              "\n",
                              argv [0]),
                              -1);
      }
  // Indicates sucessful parsing of the command line
  return 0;
}

class Client : public ACE_Task_Base
{
  // = TITLE
  //   Run the client thread
  //
  // = DESCRIPTION
  //   Use the ACE_Task_Base class to run the client threads.
  //
public:
  Client (Simple_Server_ptr server, int niterations, int exceptions, int arguments);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  void validate_connection (CORBA::Environment &);
  // Validate the connection

private:
  Simple_Server_var server_;
  // The server.

  int niterations_;
  // The number of iterations on each client thread.
  int exceptions_;
  // Whether to call exception method.
  int arguments_;
  // Whether to pass arguments.
};

int
main (int argc, char *argv[])
{
  ACE_TRY_NEW_ENV
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv, "", ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (parse_args (argc, argv) != 0)
        return 1;

      CORBA::Object_var object =
        orb->string_to_object (ior, ACE_TRY_ENV);
      ACE_TRY_CHECK;

      Simple_Server_var server =
        Simple_Server::_narrow (object.in (), ACE_TRY_ENV);
      ACE_TRY_CHECK;

      if (CORBA::is_nil (server.in ()))
        {
          ACE_ERROR_RETURN ((LM_ERROR,
                             "Object reference <%s> is nil\n",
                             ior),
                            1);
        }

      Client client (server.in (), niterations, do_exceptions, do_arguments);
      if (client.activate (THR_NEW_LWP | THR_JOINABLE,
                           nthreads) != 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                           "Cannot activate client threads\n"),
                          1);

      client.thr_mgr ()->wait ();

      ACE_DEBUG ((LM_DEBUG, "threads finished\n"));

      if (do_shutdown)
        {
          server->shutdown ();
          ACE_TRY_CHECK;
        }
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                           "Exception caught:");
      return 1;
    }
  ACE_ENDTRY;

  return 0;
}

// ****************************************************************

Client::Client (Simple_Server_ptr server,
                int niterations,
				int exceptions,
				int arguments)
  :  server_ (Simple_Server::_duplicate (server)),
     niterations_ (niterations),
	 exceptions_ (exceptions),
	 arguments_ (arguments)
{
}

void
Client::validate_connection (CORBA::Environment &ACE_TRY_ENV)
{
  // Ping the object 100 times, ignoring all exceptions.
  // It would be better to use validate_connection() but the test must
  // run on minimum CORBA builds too!
  for (int j = 0; j != 100; ++j)
    {
      ACE_TRY
        {
          this->server_->test_method (j);
          ACE_TRY_CHECK;
        }
      ACE_CATCHANY {} ACE_ENDTRY;
    }
}

int
Client::svc (void)
{
  ACE_TRY_NEW_ENV
    {
      this->validate_connection (ACE_TRY_ENV);
      ACE_TRY_CHECK;

      CORBA_String_var  key;
      OctetSeq_var      payload;
      OctetSeq          who;

      const char * me = "Client";
  		who.length( strlen( me ) );
      memcpy( who.get_buffer(), me, strlen( me ) );
      CORBA::ULong      j=0;
      CORBA::Octet      o=0;

      for (int i = 0; i < this->niterations_; ++i)
      {
        if (this->server_->test_method (i) != i)
        {
          ACE_ERROR ((LM_ERROR,
            "Unexpected result from test_method\n"));
        }

        if (this->exceptions_)
        {
          try
          {
            this->server_->test_raise (i);
            ACE_ERROR ((LM_ERROR,
              "The test_raise call didn't raise\n"));
          }
          catch (const Simple_Server::Failure &fail)
          {
            ACE_UNUSED_ARG (fail);
            // Do nothing, this is the normal behavior...
          }
        }

        if (this->arguments_)
        {
          try
          {
            this->server_->collect (payload, key, who, i );
          }
          catch (const Simple_Server::Timeout &)
          {
            if ( i != 0 )
              ACE_ERROR ((LM_ERROR,
                "collect() raised an unexpected Timeout exception\n"));
          }
          catch (const Simple_Server::Failure&)
          {
            if ( i >= 0 )
              ACE_ERROR ((LM_ERROR,
                "collect() raised an unexpected Failure exception\n"));
          }
          catch (const CORBA::Exception&)
          {
              ACE_ERROR ((LM_ERROR,
                "collect() raised an unexpected corba exception collecting %d\n", i ));
          }

          // Verify the returned data.
          if ( payload->length() != CORBA::ULong( i ) )
              ACE_ERROR ((LM_ERROR,
                "collect() returned payload of unexpected length\n"));

          o=(i%0x100);
		      for ( j=0; j<CORBA::ULong( i ); ++j, ++o )
		      {
            if ( payload[j] != o )
            {
              ACE_ERROR ((LM_ERROR,
                "collect() returned payload of unexpected contents\n"));
              break;
            }
		      }
        }

        if (TAO_debug_level > 0 && i % 100 == 0)
          ACE_DEBUG ((LM_DEBUG, "(%P|%t) iteration = %d\n",
            i));
       }
    }
    ACE_CATCHANY
    {
    ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
      "MT_ClientServerException: exception raised");
    }

  ACE_ENDTRY;
  return 0;
}
