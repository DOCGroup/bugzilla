// test_i.h,v 1.2 2001/05/20 15:46:57 sbetterm Exp

// ============================================================================
//
// = LIBRARY
//   TAO/tests/MT_Server
//
// = FILENAME
//   test_i.h
//
// = AUTHOR
//   Carlos O'Ryan
//
// ============================================================================

#ifndef TAO_MT_SERVER_TEST_I_H
#define TAO_MT_SERVER_TEST_I_H

#include "testS.h"

class Simple_Server_i : public POA_Simple_Server
{
  // = TITLE
  //   Simpler Server implementation
  //
  // = DESCRIPTION
  //   Implements the Simple_Server interface in test.idl
  //
public:
  Simple_Server_i (CORBA::ORB_ptr orb);
  // ctor

  // = The Simple_Server methods.
  CORBA::Long test_method (CORBA::Long x)
    ACE_THROW_SPEC ((CORBA::SystemException));

  CORBA::Long test_raise (CORBA::Long x)
    ACE_THROW_SPEC ((
      CORBA::SystemException,
      Simple_Server::Failure
    ));

  void collect (
      OctetSeq_out payload,
      CORBA::String_out key,
      const OctetSeq & who,
      CORBA::Long length
    )
    ACE_THROW_SPEC ((
      CORBA::SystemException,
      Simple_Server::Failure,
      Simple_Server::Timeout
    ));

  void shutdown ()
    ACE_THROW_SPEC ((CORBA::SystemException));

private:
  CORBA::ORB_var orb_;
  // The ORB
};

#if defined(__ACE_INLINE__)
#include "test_i.i"
#endif /* __ACE_INLINE__ */

#endif /* TAO_MT_SERVER_TEST_I_H */
