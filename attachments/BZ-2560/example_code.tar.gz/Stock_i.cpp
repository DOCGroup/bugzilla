//
// $Id: Stock_i.cpp,v 1.1 1999/11/28 17:41:12 coryan Exp $
//

#include <unistd.h>

#include "Stock_i.h"

PortableServer::POA_ptr Quoter_Stock_i::_poa ;

Quoter_Stock_i::Quoter_Stock_i (const char *symbol,
                                const char *full_name,
                                CORBA::Double price)
  : symbol_ (symbol)
  , full_name_ (full_name)
  , price_ (price)
{
}

char *
Quoter_Stock_i::symbol () throw (CORBA::SystemException)
{
  return CORBA::string_dup (this->symbol_.c_str ());
}

char *
Quoter_Stock_i::full_name () throw (CORBA::SystemException)
{
  return CORBA::string_dup (this->full_name_.c_str ());
}

CORBA::Double
Quoter_Stock_i::price () throw (CORBA::SystemException)
{
  return this->price_;
}

Quoter::Stock::StockHistory* 
Quoter_Stock_i::history () throw (CORBA::SystemException) 
{
  Quoter::Stock::StockHistory_var hist = new Quoter::Stock::StockHistory ;

  // delay a little bit so we have chance to kill client 
  // before this method returns
  sleep(5) ;

  const unsigned hsize = 200000 ;
  hist->length(hsize) ;
  for ( unsigned int i = 0 ; i < hsize ; ++ i ) {
    hist[i] = double(i+1) ;
  }

  return hist._retn() ;
}
