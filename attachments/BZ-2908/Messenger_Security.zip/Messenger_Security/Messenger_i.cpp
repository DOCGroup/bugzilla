/* -*- C++ -*- $Id$ */

#include "Messenger_i.h"
#include <orbsvcs/CosNamingC.h>
#include <pthread.h>

Messenger_var messenger;

void *monThread(void* ptr)
{
    try
      {
        // call message
        messenger->call_message("user");
      }
    catch(const CORBA::NO_PERMISSION ex)
      {
        ACE_ERROR((LM_ERROR, "ERROR: "));
        ex._tao_print_exception ("Caught CORBA::NO_PERMISSION exception");
      }
    catch(const CORBA::Exception &ex)
      {
        ex._tao_print_exception ("Caught exception:");
      }
}

// Implementation skeleton constructor
Messenger_i::Messenger_i (CORBA::ORB_var orb)
  : orb_ (orb)
{
}

// Implementation skeleton destructor
Messenger_i::~Messenger_i (void)
{
}

CORBA::Boolean Messenger_i::send_message (
    const char * user_name,
    const char * subject,
    char *& message
  )
  throw(CORBA::SystemException)

{
  ACE_DEBUG((LM_DEBUG, "\nInside send_message()...."));
  const char *ior = "file://server.ior";
  CORBA::Object_var obj =
    orb_->string_to_object (ior);

  // Narrow the Messenger object reference
  messenger = Messenger::_narrow(obj.in());
  if (CORBA::is_nil(messenger.in()))
  {
    ACE_ERROR((LM_ERROR, "ERROR: Not a Messenger reference\n"));
    return 1;
  }


  int nRet = 0;
  pthread_t pThread;
  nRet = pthread_create( &pThread, NULL, monThread,NULL);

  return 1;
}

CORBA::Boolean Messenger_i::call_message (
    const char * user_name
  )
  throw(CORBA::SystemException)

{
    ACE_DEBUG((LM_DEBUG, "\nInside call_message()...."));
    ACE_DEBUG((LM_DEBUG, "\nMessage from: %s", user_name));
    return 1;
}
