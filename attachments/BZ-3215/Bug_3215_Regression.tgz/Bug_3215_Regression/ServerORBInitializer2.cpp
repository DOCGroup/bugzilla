// -*- C++ -*-
//
// $Id: ServerORBInitializer2.cpp,v 1.2 2007-03-06 16:53:16 sm Exp $

#include "ServerORBInitializer2.h"
#include "ServerRequest_Interceptor2.h"
#include "tao/ORB_Constants.h"
#include "tao/Exception.h"


void
Server_ORBInitializer2::pre_init (
    PortableInterceptor::ORBInitInfo_ptr
    )
  ACE_THROW_SPEC ((CORBA::SystemException))
{

}

void
Server_ORBInitializer2::post_init (
    PortableInterceptor::ORBInitInfo_ptr info
    )
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->register_server_request_interceptors (info
                                              );
  
}

void
Server_ORBInitializer2::register_server_request_interceptors (
    PortableInterceptor::ORBInitInfo_ptr info
    )
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  PortableInterceptor::ServerRequestInterceptor_ptr sri =
    PortableInterceptor::ServerRequestInterceptor::_nil ();

  ACE_NEW_THROW_EX (sri,
                    TAO249_ServerRequest_Interceptor2,
                    CORBA::NO_MEMORY ());

  PortableInterceptor::ServerRequestInterceptor_var
    server_interceptor = sri;

  info->add_server_request_interceptor (server_interceptor.in ()
                                        );
  
}


