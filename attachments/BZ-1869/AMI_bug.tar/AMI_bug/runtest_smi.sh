#!/bin/sh

make clean
make AMI=0

echo starting server
./server -ORBEndPoint iiop://127.0.0.1:4711 &

serverpid=$!


echo starting client
./client &
clientpid=$!

sleep 5

echo killing server
kill $serverpid

sleep 5

echo restarting server
./server -ORBEndPoint iiop://127.0.0.1:4711 &
serverpid=$!

sleep 5

kill $clientpid $serverpid




