#include "AMIS.h"
#include "ace/Task.h"
#include <iostream>




#if AMI

class AdderCallback
  : public POA_AMI_test::AMI_adderHandler,
    public ACE_Task_Base {

  public:

    AdderCallback(CORBA::ORB_ptr orb)
      : orb(CORBA::ORB::_duplicate(orb)) {
      activate();
    }
    
    virtual void add (
        CORBA::Long ami_return_val
      )
      ACE_THROW_SPEC ((
        CORBA::SystemException
      )) {
        std::cout << ami_return_val << std::endl;
      }
      
    virtual void add_excep (
        AMI_test::AMI_adderExceptionHolder * excep_holder
      )
      ACE_THROW_SPEC ((
        CORBA::SystemException
      )) {
        std::cerr << "Exception" << std::endl;
      }

    virtual int svc() {
      orb->run();

      return 0;
    }

    CORBA::ORB_var orb;
    
};

#endif



int main (int argc, char* argv[]) {

  try {

    CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);


    // Get reference to Root POA
    CORBA::Object_var obj
      = orb->resolve_initial_references ("RootPOA");

    PortableServer::POA_var rootPOA = PortableServer::POA::_narrow (obj.in ());

    // Activate POA manager
    PortableServer::POAManager_var mgr
      = rootPOA->the_POAManager ();

    mgr->activate();

    // Resolve Adder Reference
    obj = orb->string_to_object("corbaloc:iiop:127.0.0.1:4711/Adder");
    AMI_test::adder_var adder = AMI_test::adder::_narrow(obj);
  

#if AMI

    AdderCallback cb_servant(orb);

    while(true) {
      try {
	std::cout << "3 + 2 = ";
        adder->sendc_add(cb_servant._this(), 3, 2);
      } catch(...) {
        std::cerr << "Failed!"<< std::endl;
      }
      sleep(1);
    }

#else // no AMI

    while(true) {
      try {
        std::cout << "3 + 2 = " << adder->add(3, 2) << std::endl;
      } catch (...) {
        std::cerr << "Failed!" << std::endl;
      }
      sleep(1);
    }

#endif // AMI

  } catch(...) {
    std::cerr << "Something went wrong, server not running?" << std::endl;
  }
}



