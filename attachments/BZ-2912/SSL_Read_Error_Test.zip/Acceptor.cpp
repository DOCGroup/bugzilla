#include "stdafx.h"
#include "Acceptor.h"
#include "ace/Log_Msg.h"

Acceptor::Acceptor(
    ) : 
    accept_cnt_(0),
    cancel_flag_(0),
    service_handler_(0)
{
}

Acceptor::~Acceptor()
{
}

int Acceptor::cancel()
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    cancel_flag_ = 1;
    reissue_accept(0);

    ACE_HANDLE h = this->get_handle();
    if (h != ACE_INVALID_HANDLE)
    {
        ACE_Asynch_Acceptor<Server_Service_Handler>::cancel();

        ACE_OS::closesocket(h);
        handle(ACE_INVALID_HANDLE);
    }

    return 0;
}

int Acceptor::safe_to_delete(
    ) const
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);
    return (cancel_flag_ != 0 && accept_cnt_ == 0) ? 1 : 0;
}

void Acceptor::prepare_for_connection(
    Server_Service_Handler *service_handler
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);
    service_handler_ = service_handler;
}

int Acceptor::validate_connection(
        const ACE_Asynch_Accept::Result& result,
        const ACE_INET_Addr & /*remote*/,
        const ACE_INET_Addr& /*local*/
        )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    if (0 != service_handler_ && result.success())
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

Server_Service_Handler* Acceptor::make_handler()
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_ASSERT(0 != service_handler_);
    Server_Service_Handler *service_handler = service_handler_;
    service_handler_ = 0;
    return service_handler;
}

int Acceptor::accept(
    size_t bytes_to_read, 
    const void *act
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    if  (cancel_flag_!= 0)
      return -1;

    accept_cnt_++;
    int rc = ACE_Asynch_Acceptor<Server_Service_Handler>::accept(bytes_to_read, act);
    if (rc != 0)
      accept_cnt_--;

    return rc;
}

void Acceptor::handle_accept(
    const ACE_Asynch_Accept::Result &result
    )
{   
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_Asynch_Acceptor<Server_Service_Handler>::handle_accept(result);

    --accept_cnt_;
}
