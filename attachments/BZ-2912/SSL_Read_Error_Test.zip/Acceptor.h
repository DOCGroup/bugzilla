#ifndef ACCEPTOR_H
#define ACCEPTOR_H

#include "Server_Service_Handler.h"

class Acceptor : public ACE_Asynch_Acceptor<Server_Service_Handler>
{
public:
    Acceptor(
        );

    virtual ~Acceptor(
        );

    virtual int cancel(
        );

    virtual int validate_connection(
        const ACE_Asynch_Accept::Result& result,
        const ACE_INET_Addr &remote,
        const ACE_INET_Addr& local
        );

    virtual Server_Service_Handler *make_handler(
        );    

    virtual int accept(
        size_t bytes_to_read = 0, 
        const void *act = 0
        );

    virtual void handle_accept(
        const ACE_Asynch_Accept::Result &result
        );

    int safe_to_delete(
        ) const;

    void prepare_for_connection(
        Server_Service_Handler *service_handler
        );

    mutable ACE_Recursive_Thread_Mutex  mtx_;
    int accept_cnt_;
    int cancel_flag_;
    Server_Service_Handler *service_handler_;
};

typedef ACE_Singleton<Acceptor, ACE_Recursive_Thread_Mutex> Acceptor_Singleton;
#define ACCEPTOR Acceptor_Singleton::instance()

#endif // ACCEPTOR_H
