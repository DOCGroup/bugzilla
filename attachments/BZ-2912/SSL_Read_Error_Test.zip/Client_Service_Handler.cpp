#include "stdafx.h"
#include "Client_Service_Handler.h"
#include "SSL_Read_Error_Test.h"
#include "ace/Log_Msg.h"

Client_Service_Handler::Client_Service_Handler(
    ) :
    ssl_stream_(ACE_SSL_Asynch_Stream::ST_CLIENT),
    read_successful_(0),
    pending_writes_(0),
    pending_reads_(0),
    handle_wakeup_expected_(0),
    handle_wakeup_received_(0),
    completed_reads_(0),
    closing_(0)
{
}

Client_Service_Handler::~Client_Service_Handler(
    )
{
    if (ACE_INVALID_HANDLE != handle())
    {
        ACE_OS::closesocket(handle());
        handle(ACE_INVALID_HANDLE);
    }
}

void Client_Service_Handler::open(
    ACE_HANDLE h, 
    ACE_Message_Block&
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    if (ssl_stream_.open(*this, h, 0, proactor()) != 0)
    {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::open: ACE_SSL_Asynch_Stream::open failed, %d\n"), (int)errno));
        cancel_and_close();
    }
    else
    {
        ACE_Message_Block *mb;    
        ACE_NEW_NORETURN(mb, ACE_Message_Block(DATA_SIZE));

        if (read_data() < 0)
        {
            cancel_and_close();
        }
        else if (write_data() < 0)
        {
            cancel_and_close();
        }
    }
}

void Client_Service_Handler::handle_read_stream(
    const ACE_Asynch_Read_Stream::Result &result
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    pending_reads_--;

    if (!result.success() || 0 == result.bytes_transferred())
    {
        // Error or remote disconnect

        result.message_block().release();

        if (!closing_)
        {
            // No error message when shutting down

            if (!result.success())
                ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::handle_read_stream: error: %d\n"), result.error()));
            else
                ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::handle_read_stream: remote disconnect\n")));
        }

        read_completed_.signal();

        cancel_and_close();
    }
    else if (result.bytes_transferred() < result.bytes_to_read())
    {
        // More to read...

        if (read(result.message_block(), result.bytes_to_read() - result.bytes_transferred()) < 0)
        {
            result.message_block().release();

            cancel_and_close();
        }
    }
    else
    {
        // Read it all

        completed_reads_++;
        
        result.message_block().release();        

        // We now have sent and received data in the proactor thread.  Signal the main
        // thread to try sending data in the main thread.
        if (completed_reads_ == 1)
        {
            ready_for_external_write_.signal();
        }
        else
        {
            // The main thread wrote data that was echoed back to us on our
            // second read.  If we get here, the test was successful in that
            // the main thread successfully sent data to the server.
            read_successful_ = 1;
            read_completed_.signal();
        }

        // Next read
        if (read_data() < 0)
        {
            cancel_and_close();
        }
    }
}

void Client_Service_Handler::handle_write_stream(
    const ACE_Asynch_Write_Stream::Result &result
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    pending_writes_--;

    if (!result.success() || 0 == result.bytes_transferred())
    {
        // Error

        result.message_block().release();
        
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::handle_write_stream: error: %d\n"), result.error()));

        cancel_and_close();
    }
    else if (result.bytes_transferred() < result.bytes_to_write())
    {
        // More to write...

        if (write(result.message_block(), result.bytes_to_write() - result.bytes_transferred()) < 0)
        {
            result.message_block().release();

            cancel_and_close();
        }
    }
    else
    {
        // Wrote it all

        result.message_block().release();
    }
}

void Client_Service_Handler::handle_wakeup(
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    handle_wakeup_received_ = 1;
}

void Client_Service_Handler::cancel_and_close(
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    closing_ = 1;
    ssl_stream_.cancel();
    handle_wakeup_expected_ = -1 == ssl_stream_.close();
}

int Client_Service_Handler::read_data(
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_Message_Block *mb;    
    ACE_NEW_NORETURN(mb, ACE_Message_Block(DATA_SIZE));

    int ret = read(*mb, DATA_SIZE);
    if (ret < 0)
    {
        mb->release();
        return -1;
    }
    else
    {
        return 0;
    }
}

int Client_Service_Handler::write_data(
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_Message_Block *mb;    
    ACE_NEW_NORETURN(mb, ACE_Message_Block(DATA_SIZE));
    ACE_OS::memcpy(mb->wr_ptr(), DATA, DATA_SIZE);
    mb->wr_ptr(DATA_SIZE);

    int ret = write(*mb, DATA_SIZE);
    if (ret < 0)
    {
        mb->release();
        return -1;
    }
    else
    {
        return 0;
    }
}

int Client_Service_Handler::read(
    ACE_Message_Block &mb,
    size_t bytes_to_read
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    int ret;
    if ((ret = ssl_stream_.read(mb, bytes_to_read)) < 0)
    {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::read: read failed: %d\n"), (int)errno));
    }
    else
    {
        pending_reads_++;
    }
    return ret;
}

int Client_Service_Handler::write(
    ACE_Message_Block &mb,
    size_t bytes_to_write
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    int ret;
    if ((ret = ssl_stream_.write(mb, bytes_to_write)) < 0)
    {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client_Service_Handler::write: write failed: %d\n"), (int)errno));        
    }
    else
    {
        pending_writes_++;
    }
    return ret;
}

int Client_Service_Handler::safe_to_delete(
    ) const
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    return 0 == pending_writes_ && 
        0 == pending_reads_ &&
        (!handle_wakeup_expected_ || handle_wakeup_received_);
}



