#include "stdafx.h"
#include "Test_Proactor.h"

int Client_Proactor_Task::svc()
{
    CLIENT_PROACTOR->proactor_reset_event_loop();
    CLIENT_PROACTOR->proactor_run_event_loop();
    return 0;
}

int Server_Proactor_Task::svc()
{
    SERVER_PROACTOR->proactor_reset_event_loop();
    SERVER_PROACTOR->proactor_run_event_loop();
    return 0;
}
