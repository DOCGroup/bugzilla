#include "stdafx.h"
#include "SSL_Read_Error_Test.h"
#include "disable_signal.h"
#include "Init_SSL.h"
#include "Test_Proactor.h"
#include "Connector.h"
#include "Acceptor.h"
#include "ace/Log_Msg.h"

// Unresolved external compile problems for WIN32 ace/aced.dll
#ifdef WIN32
const ssize_t ACE_String_Base_Const::npos = -1;
const ACE_Time_Value ACE_Time_Value::zero;
const ACE_Time_Value ACE_Time_Value::max_time (LONG_MAX,
                                    ACE_ONE_SECOND_IN_USECS - 1);
const ACE_Addr ACE_Addr::sap_any (AF_ANY, -1);
ACE_thread_t ACE_OS::NULL_thread;
int ACE_OutputCDR::wchar_maxbytes_ = sizeof (ACE_CDR::WChar);
ACE_hthread_t ACE_OS::NULL_hthread;

ACE_THR_DESC_LOG_MSG_HOOK ACE_Base_Thread_Adapter::thr_desc_log_msg_hook_ = 0;
ACE_SYNC_LOG_MSG_HOOK     ACE_Base_Thread_Adapter::sync_log_msg_hook_ = 0;
ACE_INIT_LOG_MSG_HOOK     ACE_Base_Thread_Adapter::init_log_msg_hook_ = 0;
ACE_INHERIT_LOG_MSG_HOOK  ACE_Base_Thread_Adapter::inherit_log_msg_hook_ = 0;
ACE_CLOSE_LOG_MSG_HOOK    ACE_Base_Thread_Adapter::close_log_msg_hook_ = 0;
const int ACE_SString::npos = -1;
unsigned int ACE_High_Res_Timer::global_scale_factor_;
int ACE_High_Res_Timer::global_scale_factor_status_;
#endif

/******************************************************************************
 This test duplicates a bug in ACE_SSL_Asynch_Stream where do_SSL_read fails
 when in fact it should succeed.

 do_SSL_read calls SSL_read after which SSL_get_error returns SSL_ERROR_SYSCALL
 when it should return SSL_ERROR_WANT_READ since we have an outstanding read.

 This bug can be fixed by adding ERR_clear_error() prior to SSL_read after
 which SSL_ERROR_WANT_READ is correctly returned by SSL_get_error.

 This bug seems dependent on the following activities related to threads:

 ACE_TMAIN          Client proactor          Server proactor
 thread             dispatcher thread        dispatcher thread
 ----------------   -------------------      --------------------

 init_ssl
 connect
                    SH::open                 SH::open
                    SH::read                 SH::read
                    SH::write
                                             SH::handle_read_stream
                                             SH::write
                                             SH::read
                    SH::handle_read_stream
                    SH::read
 SH::write (causes do_SSL_read to fail)

 *****************************************************************************/

int ACE_TMAIN (int argc, ACE_TCHAR *argv[]) 
{
    ACE_UNUSED_ARG(argc);
    ACE_UNUSED_ARG(argv);

    ACE::init();

    /**************************************************************************
     * Initialize DH keys
     *************************************************************************/
    init_ssl();

    int ret = 0;
    Client_Service_Handler client_handler;
    Server_Service_Handler server_handler;
    //ACE_Time_Value wait_time(10, 0);
    ACE_Time_Value wait_time(600, 0);
    
    /**************************************************************************
     * Disable signals
     *************************************************************************/
    disable_signal (ACE_SIGRTMIN, ACE_SIGRTMAX);
    disable_signal (SIGPIPE, SIGPIPE);
    disable_signal (SIGIO, SIGIO);

    /**************************************************************************
     * Client and Server will utilize different proactors since this test
     * depends on SSL thread error state behavior.
     *************************************************************************/
    
    CLIENT_PROACTOR_TASK->activate();
    SERVER_PROACTOR_TASK->activate();

    /**************************************************************************
     * Open server acceptor and client connector
     *************************************************************************/

    if (0 == ret)
    {
        ret = ACCEPTOR->open(
            ACE_INET_Addr(ACE_DEFAULT_SERVER_PORT), 
            0, 
            0,
            ACE_DEFAULT_ASYNCH_BACKLOG,
            1,
            SERVER_PROACTOR,
            1);

        if (-1 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("ACE_Asynch_Acceptor::open failed, %d\n"), (int)errno));
        }
    }

    if (0 == ret)
    {
        ret = CONNECTOR->open(0, CLIENT_PROACTOR, 1);

        if (-1 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("ACE_Asynch_Connector::open failed, %d\n"), (int)errno));
        }
    }

    /**************************************************************************
     * Supply server_handler and client_handler to acceptor and connector and
     * connect client to the server.
     *************************************************************************/

    if (0 == ret)
    {
        ACCEPTOR->prepare_for_connection(&server_handler);
        CONNECTOR->prepare_for_connection(&client_handler);

        ret = CONNECTOR->connect(ACE_INET_Addr(ACE_DEFAULT_SERVER_PORT, ACE_LOCALHOST));

        if (-1 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("ACE_Asynch_Connector::connect failed, %d\n"), (int)errno));
        }
    }

    if (0 == ret)
    {
        ret = client_handler.ready_for_external_write_.wait(&wait_time, 0);
        if (-1 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Timed out waiting for client's write readiness\n")));
        }
    }

    /**************************************************************************
     * Client sends data to server
     *************************************************************************/

    if (0 == ret)
    {
        ret = client_handler.write_data();
    }

    /**************************************************************************
     * Client waits for echo reply from server
     *************************************************************************/

    if (0 == ret)
    {
        ret = client_handler.read_completed_.wait(&wait_time, 0);

        if (-1 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Timed out waiting for client's read to complete\n")));
        }
    }

    if (0 == ret)
    {
        ret = client_handler.read_successful_ == 1 ? 0 : -1;
        if (0 == ret)
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Success\n")));
        }
        else
        {
            ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Client's read failed\n")));
        }
    }

    /**************************************************************************
     * Cleanup and shutdown
     *************************************************************************/

    ACCEPTOR->cancel();
    while (!ACCEPTOR->safe_to_delete())
        ACE_OS::sleep(ACE_Time_Value(0, 500000));

    CONNECTOR->cancel();
    while (!CONNECTOR->safe_to_delete())
        ACE_OS::sleep(ACE_Time_Value(0, 500000));

    client_handler.cancel_and_close();
    while (!client_handler.safe_to_delete())
        ACE_OS::sleep(ACE_Time_Value(0, 500000));

    server_handler.cancel_and_close();
    while (!server_handler.safe_to_delete())
        ACE_OS::sleep(ACE_Time_Value(0, 500000));

    CLIENT_PROACTOR->proactor_end_event_loop();
    CLIENT_PROACTOR_TASK->wait();

    SERVER_PROACTOR->proactor_end_event_loop();
    SERVER_PROACTOR_TASK->wait();

    /**************************************************************************
     * Keep console window open when running from VC debugger
     *************************************************************************/
#if defined(WIN32) && defined(_DEBUG)
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Press any key to exit")));
    getc(stdin);
#endif

    ACE::fini();
    return 0;
}







