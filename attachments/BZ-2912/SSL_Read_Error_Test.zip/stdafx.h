#ifndef STDAFX_H
#define STDAFX_H

#if defined (ACE_NLOGGING)
// From AL: ACE_NLOGGING must not be set if the tests are to produce any output.
#undef ACE_NLOGGING
#endif /* ACE_NLOGGING */

// From AL: This first #undef protects against command-line definitions.
#undef ACE_NDEBUG

#include "ace/ACE.h"
#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Synch.h"
#include "ace/Method_Request.h"
#include "ace/Recursive_Thread_Mutex.h"
#include "ace/Task.h"
#include "ace/Activation_Queue.h"
#include "ace/SString.h"
#include "ace/Timer_Queue_Adapters.h"
#include "ace/Timer_Heap.h"
#include "ace/Time_Value.h"
#include "ace/INET_Addr.h"
#include "ace/OS_NS_Thread.h"
#include "ace/UUID.h"
#include "ace/Atomic_Op.h"
#include "ace/Asynch_Connector.h"
#include "ace/Asynch_Acceptor.h"
#include "ace/Singleton.h"
#include "ace/CDR_Stream.h"
#include "ace/Proactor.h"
#include "ace/Asynch_IO.h"
#include "ace/Manual_Event.h"
#include "ace/Thread_Semaphore.h"
#include "ace/SSL/SSL_Asynch_Stream.h"
#include "ace/Log_Msg.h"
#include "ace/High_Res_Timer.h"

// From AL: The second #undef protects against being reset in a config.h file.
#undef ACE_NDEBUG

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#endif

#endif // STDAFX_H
