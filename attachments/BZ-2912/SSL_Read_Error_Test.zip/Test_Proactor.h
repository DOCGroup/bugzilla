#ifndef TEST_PROACTOR_H
#define TEST_PROACTOR_H

class Client_Proactor : public ACE_Proactor {};
typedef ACE_Singleton<Client_Proactor, ACE_Recursive_Thread_Mutex> Client_Proactor_Singleton;
#define CLIENT_PROACTOR Client_Proactor_Singleton::instance()

class Client_Proactor_Task : public ACE_Task_Base
{
public:
    virtual int svc();
};

typedef ACE_Singleton<Client_Proactor_Task, ACE_Recursive_Thread_Mutex> Client_Proactor_Task_Singleton;
#define CLIENT_PROACTOR_TASK Client_Proactor_Task_Singleton::instance()

class Server_Proactor : public ACE_Proactor {};
typedef ACE_Singleton<Server_Proactor, ACE_Recursive_Thread_Mutex> Server_Proactor_Singleton;
#define SERVER_PROACTOR Server_Proactor_Singleton::instance()

class Server_Proactor_Task : public ACE_Task_Base
{
public:
    virtual int svc();
};

typedef ACE_Singleton<Server_Proactor_Task, ACE_Recursive_Thread_Mutex> Server_Proactor_Task_Singleton;
#define SERVER_PROACTOR_TASK Server_Proactor_Task_Singleton::instance()

#endif // TEST_PROACTOR_H
