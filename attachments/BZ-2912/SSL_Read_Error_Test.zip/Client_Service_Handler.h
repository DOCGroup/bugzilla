#ifndef CLIENT_SERVICE_HANDLER_H
#define CLIENT_SERVICE_HANDLER_H

class SSL_Read_Error_Test;

class Client_Service_Handler : public ACE_Service_Handler
{
public:
    Client_Service_Handler(
        );

    virtual ~Client_Service_Handler(
        );

    virtual void open(
        ACE_HANDLE h, 
        ACE_Message_Block&
        );

    virtual void handle_read_stream(
        const ACE_Asynch_Read_Stream::Result &result
        );

    virtual void handle_write_stream(
        const ACE_Asynch_Write_Stream::Result &result
        );
    
    virtual void handle_wakeup(
        );

    void cancel_and_close(
        );

    int read_data(
        );

    int write_data(
        );

    int read(
        ACE_Message_Block &mb,
        size_t bytes_to_read
        );

    int write(
        ACE_Message_Block &mb,
        size_t bytes_to_write
        );

    int safe_to_delete(
        ) const;

    mutable ACE_Recursive_Thread_Mutex  mtx_;
    ACE_SSL_Asynch_Stream ssl_stream_;
    ACE_Manual_Event ready_for_external_write_;
    ACE_Manual_Event read_completed_;
    int read_successful_;
    int pending_writes_;
    int pending_reads_;
    int handle_wakeup_expected_;
    int handle_wakeup_received_;
    int completed_reads_;
    int closing_;
};

#endif // CLIENT_SERVICE_HANDLER_H
