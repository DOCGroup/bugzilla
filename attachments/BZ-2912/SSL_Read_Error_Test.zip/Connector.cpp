#include "stdafx.h"
#include "Connector.h"
#include "ace/Log_Msg.h"

Connector::Connector(
    ) : 
    service_handler_(0)
{
}

Connector::~Connector()
{
}

int Connector::connect(
    const ACE_INET_Addr &remote_sap,
    const ACE_INET_Addr &local_sap,
    int reuse_addr,
    const void *act
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    connecting_ = 1;

    return ACE_Asynch_Connector<Client_Service_Handler>::connect(
        remote_sap, local_sap, reuse_addr, act);
}

int Connector::validate_connection(
    const ACE_Asynch_Connect::Result& result,
    const ACE_INET_Addr &remote,
    const ACE_INET_Addr& local
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_UNUSED_ARG(result);
    ACE_UNUSED_ARG(remote);
    ACE_UNUSED_ARG(local);

    if (!result.success())
    {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT("Connector::validate_connection failed: %d\n"), result.error()));
        return -1;
    }
    else
    {
        return 0;
    }
}

void Connector::handle_connect(
    const ACE_Asynch_Connect::Result &result
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_Asynch_Connector<Client_Service_Handler>::handle_connect(result);

    connecting_ = 0;
}

Client_Service_Handler* Connector::make_handler(
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    ACE_ASSERT(0 != service_handler_);
    Client_Service_Handler *service_handler = service_handler_;
    service_handler_ = 0;
    return service_handler;
}

int Connector::safe_to_delete(
    ) const
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);

    return 0 == connecting_;
}

void Connector::prepare_for_connection(
    Client_Service_Handler *service_handler
    )
{
    ACE_Guard<ACE_Recursive_Thread_Mutex> guard(mtx_);
    service_handler_ = service_handler;
}

