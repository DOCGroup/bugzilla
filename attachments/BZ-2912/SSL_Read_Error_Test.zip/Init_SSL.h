#ifndef INIT_SSL_H
#define INIT_SSL_H


bool init_ssl();
DH *get_dh512();
DH *get_dh1024();
DH *tmp_dh_callback(SSL *s, int is_export, int keylength);

#endif // INIT_SSL_H
