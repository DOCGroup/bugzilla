#ifndef CONNECTOR_H
#define CONNECTOR_H

#include "Client_Service_Handler.h"

class Connector : public ACE_Asynch_Connector<Client_Service_Handler>
{
public:
    Connector(
        );

    virtual ~Connector(
        );

    virtual int connect(
        const ACE_INET_Addr &remote_sap,
        const ACE_INET_Addr &local_sap =
            (const ACE_INET_Addr &)ACE_Addr::sap_any,
        int reuse_addr = 1,
        const void *act = 0
        );

    virtual int validate_connection(
        const ACE_Asynch_Connect::Result& result,
        const ACE_INET_Addr &remote,
        const ACE_INET_Addr& local
        ); 

    int safe_to_delete(
        ) const;

    void prepare_for_connection(
        Client_Service_Handler *service_handler
        );

protected:
    virtual void handle_connect(
        const ACE_Asynch_Connect::Result &result
        );

    virtual Client_Service_Handler* make_handler(
        );

    mutable ACE_Recursive_Thread_Mutex  mtx_;
    Client_Service_Handler *service_handler_;
    int connecting_;
};

typedef ACE_Singleton<Connector, ACE_Recursive_Thread_Mutex> Connector_Singleton;
#define CONNECTOR Connector_Singleton::instance()

#endif // CONNECTOR_H
