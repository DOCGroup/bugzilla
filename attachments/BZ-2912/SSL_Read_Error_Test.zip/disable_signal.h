// Borrowed from Alex Libman for this test

#ifndef DISABLE_SIGNAL_H
#define DISABLE_SIGNAL_H

int disable_signal (int sigmin, int sigmax);

#endif // DISABLE_SIGNAL_H