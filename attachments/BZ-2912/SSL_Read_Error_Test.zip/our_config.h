#define ACE_HAS_ICMP_SUPPORT 1

#ifdef NXI_USE_DLL
  #ifdef NXI_USE_MFC_SHARED   // build dll with dynamic mfc link
    #define ACE_HAS_MFC 1        
    #define ACE_DOESNT_INSTANTIATE_NONSTATIC_OBJECT_MANAGER 1   
  #endif // NXI_USE_MFC_SHARED
  #define ACE_BUILD_DLL
  #define ACE_OS_BUILD_DLL 
  #ifdef NXI_USE_SSL
    #define ACE_SSL_HAS_DLL 1
    #define ACE_SSL_BUILD_DLL
  #endif // NXI_USE_SSL
#endif // NXI_USE_DLL

#include "ace/config-win32.h"

#ifdef ACE_HAS_WCHAR
#undef ACE_HAS_WCHAR
#endif
 
