
#include <sstream>
#include <iostream>
#include "ace/TSS_T.h"

static std::stringstream ss;


struct A
{
  A()
  :
    _a(42)
  {
    std::cout << "A @" << this << std::endl;
    ss << "A";
  }

  ~A()
  {
    std::cout << "~A @" << this << std::endl;
    ss << "~A";
  }

  int _a;
};


struct B
{
  B()
  {
    std::cout << "B @" << this << std::endl;
    // create TSS instance
    _a->_a;
    //std::cout << "_a->_a=" << _a->_a << std::endl;
    ss << "B";
  }

  ~B()
  {
    std::cout << "~B @" << this << std::endl;
    ss << "~B";
  }

  ACE_TSS < A > _a;
};


int main (int, char **)
{
  if(true)
  {
    B b;
  }

  std::cout << "ss=" << ss.str() << std::endl;

  if(ss.str() == "AB~B~A")
  {
    std::cout << "OK" << std::endl;
    return 0;
  }
  else
  {
    std::cout << "FAIL" << std::endl;
    return 1;
  }
}
