// $Id$

#include "Middle_Impl.hpp"

#include "tao/Utils/PolicyList_Destroyer.h"
#include "tao/Utils/Servant_Var.h"
#include "tao/Messaging/Messaging.h"
#include "tao/AnyTypeCode/Any.h"
#include "ace/Get_Opt.h"
#include "ace/OS_NS_stdio.h"

ACE_RCSID (Bug_3647_Regression,
           middle_server,
           "$Id$")

bool verbose = false;
const ACE_TCHAR *ior_output_file = ACE_TEXT ("middle.ior");
const ACE_TCHAR *ior = ACE_TEXT ("file://backend.ior");
Messaging::SyncScope scope = Messaging::SYNC_NONE;

int
parse_args (int argc, ACE_TCHAR *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, ACE_TEXT("vo:k:s:"));
  int c;
  const ACE_TCHAR *sname = "NONE";

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'v':
        verbose = true;
        break;

      case 'o':
        ior_output_file = get_opts.opt_arg ();
        break;

      case 'k':
        ior = get_opts.opt_arg ();
        break;

      case 's':
        sname = get_opts.opt_arg ();
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-v "
                           "-k <ior> "
                           "-o <iorfile> "
                           "-s <NONE|TRANSPORT|SERVER|TARGET|DELAYED> "
                           "\n",
                           argv [0]),
                          -1);
      }

  if (ACE_OS::strcmp(sname, "NONE") == 0) {
    scope = Messaging::SYNC_NONE;
  } else if (ACE_OS::strcmp(sname, "TRANSPORT") == 0) {
    scope = Messaging::SYNC_WITH_TRANSPORT;
  } else if (ACE_OS::strcmp(sname, "SERVER") == 0) {
    scope = Messaging::SYNC_WITH_SERVER;
  } else if (ACE_OS::strcmp(sname, "TARGET") == 0) {
    scope = Messaging::SYNC_WITH_TARGET;
  } else if (ACE_OS::strcmp(sname, "DELAYED") == 0) {
    scope = TAO::SYNC_DELAYED_BUFFERING;
  }

  // Indicates sucessful parsing of the command line
  return 0;
}

int
ACE_TMAIN(int argc, ACE_TCHAR *argv[])
{
  try
    {
      CORBA::ORB_var orb =
        CORBA::ORB_init (argc, argv);

      CORBA::Object_var poa_object =
        orb->resolve_initial_references("RootPOA");

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in ());

      if (CORBA::is_nil (root_poa.in ()))
      {
        ACE_ERROR_RETURN ((LM_ERROR,
                "backend_server(%P|%t) - panic: nil RootPOA\n"),
            1);
      }

      PortableServer::POAManager_var poa_manager =
          root_poa->the_POAManager ();

      if (parse_args (argc, argv) != 0)
        return 1;

      CORBA::Object_var tmp = orb->string_to_object(ior);

      CORBA::Any timeout_as_any;
      // two seconds in TimeT units, the idea is to make the timeout for
      // the middle tier server higher than the timeout for the client.
      // The middle tier server should never block, as it should always
      // wait in a nested event loop.
      timeout_as_any <<= TimeBase::TimeT(20 * 1000000);

      CORBA::Any scope_as_any;
      scope_as_any <<= scope;

      TAO::Utils::PolicyList_Destroyer plist(1);
      plist.length(2);
      plist[0] =
          orb->create_policy(Messaging::RELATIVE_RT_TIMEOUT_POLICY_TYPE,
              timeout_as_any);
      plist[1] =
          orb->create_policy(Messaging::SYNC_SCOPE_POLICY_TYPE,
              scope_as_any);

      tmp = tmp->_set_policy_overrides(plist, CORBA::SET_OVERRIDE);

      Bug_3647_Regression::Backend_var backend =
          Bug_3647_Regression::Backend::_narrow(tmp.in ());

      if (CORBA::is_nil (backend.in ()))
        {
          ACE_ERROR_RETURN ((LM_DEBUG,
                  "middle_server(%P|%t) - nil backend reference <%s>\n",
                  ior),
              1);
        }

      using namespace Bug_3647_Regression;
      TAO::Utils::Servant_Var<Middle_Impl> impl(
          new Middle_Impl(backend.in(), orb.in(), verbose));

      PortableServer::ObjectId_var id =
          root_poa->activate_object (impl.in());

      CORBA::Object_var object = root_poa->id_to_reference (id.in ());


      Bug_3647_Regression::Middle_var middle =
          Bug_3647_Regression::Middle::_narrow (object.in ());

      CORBA::String_var ior = orb->object_to_string (middle.in ());

      // Output the IOR to the <ior_output_file>
      FILE *output_file= ACE_OS::fopen (ior_output_file, "w");
      if (output_file == 0)
        ACE_ERROR_RETURN ((LM_ERROR,
                "middle_server(%P|%t) - Cannot open output file "
                "for writing IOR: %s\n",
                ior_output_file),
            1);
      ACE_OS::fprintf (output_file, "%s", ior.in ());
      ACE_OS::fclose (output_file);

      poa_manager->activate ();

      orb->run ();

      ACE_DEBUG ((LM_DEBUG,
              "middle_server(%P|%t) - event loop finished\n"));

      root_poa->destroy (1, 1);

      orb->destroy ();
    }
  catch (const CORBA::Exception& ex)
    {
      ACE_DEBUG ((LM_DEBUG,
              "middle_server"));
      ex._tao_print_exception ("Exception caught:");
      return 1;
    }

  return 0;
}
