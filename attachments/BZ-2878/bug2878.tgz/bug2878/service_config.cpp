#include "ace/Service_Config.h"
#include "ace/Task.h"


class ServiceConfigUser : public ACE_Task_Base {

private:

  ACE_Service_Config * pAceSrvCfg;

public:

  ServiceConfigUser(ACE_Service_Config * srvcfg) : pAceSrvCfg(srvcfg) {}

  int runTest()
  {
    // load the service

    if (pAceSrvCfg->process_directive(
                                      ACE_DYNAMIC_SERVICE_DIRECTIVE("module1",
                                                                    "mod1", "_make_MOD1_Module1", "")) != 0)
      {
        ACE_ERROR_RETURN((LM_ERROR,
                          "\t(%P|%t): Failed to load the service.\n"),
                         -1);
      }

    // suspend the service.

    if (pAceSrvCfg->suspend("module1") != 0)
      {
        ACE_ERROR_RETURN((LM_ERROR,
                          "\t(%P|%t): Failed to suspend the service.\n"),
                         -1);
      }

    // resume the service.

    if (pAceSrvCfg->resume("module1") != 0)
      {
        ACE_ERROR_RETURN((LM_ERROR,
                          "\t(%P|%t): Failed to resume the service.\n"),
                         -1);
      }

    // remove the service.

    if (pAceSrvCfg->remove("module1") != 0)
      {
        ACE_ERROR_RETURN((LM_ERROR,
                          "\t(%P|%t): Failed to remove the service.\n"),
                         -1);
      }

    return 0;
  }

  int svc()
  {
    ACE_DEBUG((LM_INFO,
               "\n(%P|%t): Calling runTest in Worker Thread. \n"));

    if (runTest() != 0)
      {
        ACE_ERROR_RETURN((LM_ERROR,
                          "(%P|%t): Service Config Test Failed in Worker Thread.\n"),
                         -1);
      }
  }
};

int main(int argc, char * argv[])
{
  ACE_Service_Config * pAceSrvCfg = new ACE_Service_Config();

  // Call open on Ace Service config class.
  // Program Name = NULL.
  // logger key = NULL.
  // ignore static services = 1
  // ignore default svc conf = 1
  // ignore debug flag = 1

  if (pAceSrvCfg->open(0, 0, 1, 1, 1) == -1)
    {
      ACE_ERROR_RETURN((LM_ERROR,
                        "\t(%P|%t): Failed to initialize Service Config.\n"),
                       -1);
    }

  ServiceConfigUser suser(pAceSrvCfg);

  ACE_DEBUG((LM_INFO,
             "\n(%P|%t): Calling runTest in Main Thread.\n"));

  if (suser.runTest() != 0)
    {
      ACE_ERROR_RETURN((LM_ERROR,
                        "(%P|%t): Service Config Test Failed in Main Thread.\n"),
                       -1);
    }

  // Run the test in worker thread.

  suser.activate();

  // Wait for worker thread to finish.
  suser.wait();

  delete pAceSrvCfg;

  return 0;
}
