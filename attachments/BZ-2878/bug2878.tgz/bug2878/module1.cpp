#include "module1.h"

int
MOD1::Module1::init(int argc, ACE_TCHAR * argv[])
{
  ACE_DEBUG((LM_INFO,"(%P|%t): MOD1::Module1::init called.\n"));
  return 0;
}

int
MOD1::Module1::fini()
{
  ACE_DEBUG((LM_INFO,"(%P|%t): MOD1::Module1::fini called.\n"));
  return 0;
}

int
MOD1::Module1::suspend()
{
  ACE_DEBUG((LM_INFO,"(%P|%t): MOD1::Module1::suspend called.\n"));
  return 0;
}

int
MOD1::Module1::resume()
{
  ACE_DEBUG((LM_INFO,"(%P|%t): MOD1::Module1::resume called.\n"));
  return 0;
}


ACE_FACTORY_NAMESPACE_DEFINE(MOD1, MOD1_Module1, MOD1::Module1)

  
