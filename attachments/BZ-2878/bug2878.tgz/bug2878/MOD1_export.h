
// -*- C++ -*-
// $Id$
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl MOD1
// ------------------------------
#ifndef MOD1_EXPORT_H
#define MOD1_EXPORT_H

#include "ace/config-all.h"

#if defined (ACE_AS_STATIC_LIBS) && !defined (MOD1_HAS_DLL)
#  define MOD1_HAS_DLL 0
#endif /* ACE_AS_STATIC_LIBS && MOD1_HAS_DLL */

#if !defined (MOD1_HAS_DLL)
#  define MOD1_HAS_DLL 1
#endif /* ! MOD1_HAS_DLL */

#if defined (MOD1_HAS_DLL) && (MOD1_HAS_DLL == 1)
#  if defined (MOD1_BUILD_DLL)
#    define MOD1_Export ACE_Proper_Export_Flag
#    define MOD1_SINGLETON_DECLARATION(T) ACE_EXPORT_SINGLETON_DECLARATION (T)
#    define MOD1_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_EXPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  else /* MOD1_BUILD_DLL */
#    define MOD1_Export ACE_Proper_Import_Flag
#    define MOD1_SINGLETON_DECLARATION(T) ACE_IMPORT_SINGLETON_DECLARATION (T)
#    define MOD1_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK) ACE_IMPORT_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#  endif /* MOD1_BUILD_DLL */
#else /* MOD1_HAS_DLL == 1 */
#  define MOD1_Export
#  define MOD1_SINGLETON_DECLARATION(T)
#  define MOD1_SINGLETON_DECLARE(SINGLETON_TYPE, CLASS, LOCK)
#endif /* MOD1_HAS_DLL == 1 */

// Set MOD1_NTRACE = 0 to turn on library specific tracing even if
// tracing is turned off for ACE.
#if !defined (MOD1_NTRACE)
#  if (ACE_NTRACE == 1)
#    define MOD1_NTRACE 1
#  else /* (ACE_NTRACE == 1) */
#    define MOD1_NTRACE 0
#  endif /* (ACE_NTRACE == 1) */
#endif /* !MOD1_NTRACE */

#if (MOD1_NTRACE == 1)
#  define MOD1_TRACE(X)
#else /* (MOD1_NTRACE == 1) */
#  if !defined (ACE_HAS_TRACE)
#    define ACE_HAS_TRACE
#  endif /* ACE_HAS_TRACE */
#  define MOD1_TRACE(X) ACE_TRACE_IMPL(X)
#  include "ace/Trace.h"
#endif /* (MOD1_NTRACE == 1) */

#endif /* MOD1_EXPORT_H */

// End of auto generated file.
