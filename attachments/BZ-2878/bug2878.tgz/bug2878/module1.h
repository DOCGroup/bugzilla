#ifndef _MODULE1_H
#define _MODULE1_H

#include "ace/Service_Object.h"
#include "MOD1_export.h"

namespace MOD1 {

  class MOD1_Export Module1 : public ACE_Service_Object {
  private:

  public:

    Module1() {}

    ~Module1() {}

    virtual int init(int argc, ACE_TCHAR * argv[]);

    virtual int fini();

    virtual int suspend();

    virtual int resume();

  };
};

ACE_FACTORY_DECLARE (MOD1, MOD1_Module1)
#endif
