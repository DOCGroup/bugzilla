#include <iostream>
#include "ace/Task.h"
#include <CosNamingC.h>
#include <PortableServer.h>
#include "testS.h"

using namespace std;

CORBA::ORB_var g_oOrbVar;

static int nCount = 0;

class TestImpl : public POA_TestIF
{
public:
   /**
    * Constructor
    */
   TestImpl(){}

   /**
    * Destructor
    */
   ~TestImpl(){}
   
   bool activate(const CORBA::ORB_var &p_pOrb,
      const std::string &p_sServerName)
   {
      try
      {
         // Get RootPOA
         CORBA::Object_var pPoaObj = p_pOrb->resolve_initial_references("RootPOA");
         if(CORBA::is_nil(pPoaObj.in()))
         {
            return false;
         }
         PortableServer::POA_var pPoa =
                 PortableServer::POA::_narrow(pPoaObj.in());

         // Look up nameservice
         CORBA::Object_var pNamingObj =
                 p_pOrb->resolve_initial_references("NameService");
         if(CORBA::is_nil(pNamingObj.in()))
         {
            return false;
         }
         CosNaming::NamingContextExt_var pNaming =
                 CosNaming::NamingContextExt::_narrow(pNamingObj.in());

         // Activate ourselves and get reference
         PortableServer::ObjectId_var pThisId =
                 pPoa->activate_object(this);
         CORBA::Object_var pThisObj = pPoa->id_to_reference(pThisId.in());

         // Bind to name service
         CosNaming::Name_var pName = pNaming->to_name(p_sServerName.c_str());
         pNaming->rebind(pName.in(), pThisObj.in());

         fprintf(stderr,"Activated Director %s\n", p_sServerName.c_str());      
      }
      catch(const CORBA::Exception &)
      {
         return false;
      }
      return true;
   }
   

   void TestMessage(const  TestData & poTestData)
   {
      printf("Received TestMessage: %d\n", ++nCount);   
   }
   
};


class OrbWorker : public ACE_Task_Base
{
public:
  OrbWorker (CORBA::ORB_ptr orb);

  virtual int svc (void);

private:
  CORBA::ORB_var orb_;
};

OrbWorker::OrbWorker (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
OrbWorker::svc (void)
{

   try
   {
      g_oOrbVar->run();
   }
   catch(...)
   {
   }
  return 0;
}


int main(int argc, char *argv[])
{
    try
   {
      cout <<"Init CORBA ORB\n";
      
      g_oOrbVar =
        CORBA::ORB_init (argc, argv);

      CORBA::Object_var poa_object =
        g_oOrbVar->resolve_initial_references("RootPOA");

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in ());

      if (CORBA::is_nil (root_poa.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Panic: nil RootPOA\n"),
                          1);
      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager ();
     poa_manager->activate ();
      
      

      OrbWorker oOrbWorker(g_oOrbVar.in ());
      if (oOrbWorker.activate (THR_NEW_LWP | THR_JOINABLE,
                          1) != 0)
      {
         printf("Cannot activate ORB threads\n");
      }
      
      // create client
      TestImpl oImpl;
      oImpl.activate(g_oOrbVar, "TestIF");
      
       oOrbWorker.thr_mgr()->wait();            

    }
    catch(CORBA::SystemException &e)
    {
    	cout << e._info();
    }
    catch(...)
    {
    cout <<  "catch all" << endl;
    }
    
    
 
	return 0;

}
