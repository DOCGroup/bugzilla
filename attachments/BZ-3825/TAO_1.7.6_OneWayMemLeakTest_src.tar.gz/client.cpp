#include <iostream>
#include <CosNamingC.h>

#include "ace/Task.h"
#include <PortableServer.h>
#include "tao/Messaging/Messaging.h"
#include "testC.h"




int gLongCount =0;
int gShortCount =0;
bool gRealTimeThreads = false;
CORBA::ORB_var g_oOrbVar;

using namespace CORBA;
using namespace PortableServer;
using namespace std;


class OrbWorker : public ACE_Task_Base
{
public:
  OrbWorker (CORBA::ORB_ptr orb);
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  CORBA::ORB_var orb_;
  // The orb
};

OrbWorker::OrbWorker (CORBA::ORB_ptr orb)
  :  orb_ (CORBA::ORB::_duplicate (orb))
{
}

int
OrbWorker::svc (void)
{

   try
   {
     g_oOrbVar->run();
   }
   catch(...)
   {
   }
  return 0;
}



class ClientWorker : public ACE_Task_Base
{
public:
  ClientWorker(int priority, int sleepTime):m_id(0), m_Pri(priority), m_Sleep(sleepTime)
  {}
  // ctor

  virtual int svc (void);
  // The thread entry point.

private:
  ACE_Thread_Mutex m_oMutex;
  int m_id;
  int m_Pri;
  int m_Sleep;
  TestIF_var m_oClient;
};


int ClientWorker::svc (void)
{
   int id;
   m_oMutex.acquire();
   id = ++m_id;
   m_oMutex.release();
   
  printf("Enter clientThread %d\n", id);
  
  ACE_Time_Value oTimeDiff = ACE_OS::gettimeofday();
  TestIF_var oClient;              
  
  try
  {
      // Resolve Name Service from ORB
      CORBA::Object_var pNamingObj =
         g_oOrbVar->resolve_initial_references("NameService");

      CosNaming::NamingContextExt_var pNaming =
         CosNaming::NamingContextExt::_narrow(pNamingObj.in());
         
      CosNaming::Name_var pName = pNaming->to_name("TestIF");
      CORBA::Object_var pServerObj;
      pServerObj = pNaming->resolve(pName.in());
       oClient = TestIF::_narrow(pServerObj.in());

      
  }
  catch(...)
  {
     printf("Activation Failed\n");
  }
  
  ACE_OS::sleep(5);
  
  int nCount = 0;
   while (nCount < 100)
   {
      try 
      {
      

      	TestData oTestData;
         oClient->TestMessage(oTestData);
         printf("Sent TestMessage %d\n", nCount+1);                   

      }

      catch(...)
      {
         printf("Exception occurred, try again\n");
      }
      ACE_OS::sleep(ACE_Time_Value(0,50000));
      
      ++nCount;

   }  

   return 0;
}


int main(int argc, char *argv[])
{

    try
   {
      
      g_oOrbVar =
        CORBA::ORB_init (argc, argv);

      CORBA::Object_var poa_object =
        g_oOrbVar->resolve_initial_references("RootPOA");

      PortableServer::POA_var root_poa =
        PortableServer::POA::_narrow (poa_object.in ());

      if (CORBA::is_nil (root_poa.in ()))
        ACE_ERROR_RETURN ((LM_ERROR,
                           " (%P|%t) Panic: nil RootPOA\n"),
                          1);

      PortableServer::POAManager_var poa_manager =
        root_poa->the_POAManager ();


      poa_manager->activate ();
      
      
      OrbWorker oOrbWorker(g_oOrbVar.in ());
      if (oOrbWorker.activate (THR_NEW_LWP | THR_JOINABLE,
                          1) != 0)
      {
         printf("Cannot activate ORB threads\n");
      }
            
      
      ClientWorker oLRClientWorker(20, 3);
      oLRClientWorker.activate (THR_NEW_LWP | THR_JOINABLE,1);
      oLRClientWorker.thr_mgr()->wait();            
      
      oOrbWorker.thr_mgr()->wait();    
     

    }
    catch(CORBA::SystemException &e)
    {
    	cout << e._info();
    }
    catch(...)
    {
    cout <<  "catch all" << endl;
    }
    
      

	return 0;

}
