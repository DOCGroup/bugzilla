//
// Program to demonstrate Bugzilla #925.
//
// Tom Moog (tmoog@polhode.com)
//
// This problem was first reported under RedHat 7.x using ACE 5.1.13.
// This additional documentation is based on Win NT 4.0 SP6 with
// ACE 5.1.16.

#if 0

    ACE VERSION: 5.1.16

    HOST MACHINE and OPERATING SYSTEM: Win NT 4 SP 6
    TARGET MACHINE and OPERATING SYSTEM, if different from HOST:
    COMPILER NAME AND VERSION (AND PATCHLEVEL): MSVC 6 (SP 4 ?)

    AREA/CLASS/EXAMPLE AFFECTED: ACE_MMAP_MEMORY_POOL

    DOES THE PROBLEM AFFECT:
        COMPILATION? No
        LINKING? No
        EXECUTION? Yes

    SYNOPSIS:

		Bugzilla #925: AACE_MMap_Memory_Pool fails to restore
		previous map on expansion failure.

    DESCRIPTION:

In class ACE_MMap_Memory_Pool when there is a request for an allocation which 
cannot be satisfied by the existing pool the class attempts to grow the
region by calling acquire (defined at Memory_Pool.cpp:324). After expanding the
mapping file (calling commit_backing_store_name near line 335) there is a call
to ACE_MMap_Memory_Pool::map_file (defined at Memory_Pool:282).  The first
thing map_file does it to unmap the existing region and then attempt to
map the expanded region.  If the call to map fails, map_file simply returns an
error status while leaving the region unmapped.  The simple fix is to restore
the old map.  However, this is not sufficient since each call to acquire results
in the file being expanded repeatedly while the map call fails.  In other words,
asking for 1k bytes 100 times would result in a file expanded by 100kBytes   A 
slightly better fix is to add a member variable which remembers the size of the last
previous expansion which failed. A new request which is larger than this value
immediately returns failure.  For a new request which is smaller than this value
it should search the free list and return failure if no suitable chunk is found
- but not call map_file in either case.

The reason the attempt to map the expanded region fails is because there is
another mapped region immediately above it in the virtual address space.

#endif

#include <stdio.h>
#include <stdlib.h>
#include "ace/PI_Malloc.h"

typedef 
ACE_Malloc_T<ACE_MMAP_MEMORY_POOL, ACE_Null_Mutex, ACE_PI_Control_Block>
PoolAllocatorBaseClass;


class PoolAllocator : public PoolAllocatorBaseClass
{
public:
  PoolAllocator(const char * fileName,
                const char * lockName = NULL,
                size_t minimumSize = 0);
  virtual ~PoolAllocator();
};


PoolAllocator::PoolAllocator(const char * fileName,
                             const char * lockName,
                             size_t minimumSize) :
  PoolAllocatorBaseClass(fileName,
                         lockName,
                         &ACE_MMAP_Memory_Pool_Options(
                                0 /* default base addr */,
                                0 /* use fixed addr ? */,
				  			    1 /* write each page ? */,
								minimumSize))
{
}

PoolAllocator::~PoolAllocator()
{
}
 
int
main(int argc, char **argv)
{
    fprintf(stderr, "Test Behavior when shared memory pool is exhausted (Bugzilla #925)\n");

	// If there are existing backing files delete them so that each 
	// time the program starts with the backing files in a known state.

	PoolAllocator * pool1a = new PoolAllocator("pool1", NULL, 128*1024);
    PoolAllocator * pool2a = new PoolAllocator("pool2", NULL, 128*1024);
    pool1a->remove();
    pool2a->remove();

	// Allocate brand new backing files.

    PoolAllocator * pool1b = new PoolAllocator("pool1", NULL, 128*1024);
    PoolAllocator * pool2b = new PoolAllocator("pool2", NULL, 128*1024);
    PoolAllocator * pool1 = NULL;
    PoolAllocator * pool2 = NULL;

    char * base1 = (char *) pool1b->base_addr();
    char * base2 =  (char *) pool2b->base_addr();

	// Use pool1 for the one at the lower address and pool2 for the one 
	// at the higher address.

    if (base2 > base1) {
 	    pool1 = pool1b;
        pool2 = pool2b;
    }
    else {
  	    pool1 = pool2b;
        pool2 = pool1b;
        char * temp = base1;
        base1 = base2;
        base2 = temp;
    }
    fprintf(stderr,"Pool 1 base address is at %p\n"
                   "Pool 2 base address is at %p\n"
                   "Difference is 0x%x (%d dec)\n"
                   "%s\n",
  			        base1,
                    base2,
			        base2-base1, base2-base1,
                    (base1 == base2 ? "EQUAL" : "NOT EQUAL"));
    void * p = NULL;
    int counter = 0;

	// Allocation #1 will succeed.
	// Allocation #2 will fail and the loop will be exited.

    do {
	  counter++;
	  p = pool1->malloc(100000);
      if (p != NULL) {
		fprintf(stderr, "OK #%d allocation request.\n", counter);
      }
      else {
		fprintf(stderr, "Failed #%d allocation request.\n", counter);
	  }
	} while (p != NULL);
    
    // The allocation has failed, but it has left pool1 unmapped !
	// This fails with a sement fault even though it it the base
	// address of pool1 and should be valid.

    char c = *base1;
    fprintf(stderr, "At base address of pool1 after alloc failure %d\n", c);

	// This code is reacheable only with a temporary fix. 

    fprintf(stderr, "Try another allocation and see if the file grows.\n");
    counter++;
    p = pool1->malloc(100000);
    if (p != NULL) {
		fprintf(stderr, "OK #%d allocation request.\n", counter);
    }
    else {
	  fprintf(stderr, "Failed #%d allocation request.\n", counter);
	}

    // The allocation has failed.

    char c2 = *base1;
    fprintf(stderr, "At base address of pool1 after alloc failure %d\n", c2);

    exit(EXIT_SUCCESS);
}
