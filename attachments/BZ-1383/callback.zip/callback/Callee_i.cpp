#include "Callee_i.h"

void Callee_i::callback (const char * message) throw (CORBA::SystemException)
{
	cout << "Callee_i::callback: message is " << message << endl;
}
