#include <tao/corba.h>
#include "simpleC.h"
#include "Callee_i.h"
#include "tao/IORManipulation/IORManip_Loader.h"

#include <iostream>

using namespace std;
using namespace CORBA;

ORB_var orb;

ACE_THR_FUNC_RETURN RunFunc(void * ptr) {
	cout << "running the orb" << endl;
	orb->run();
	cout << "done running orb" << endl;
	return 0;
}

int main(int argc, char * argv[])
{
	// initialize the ORB
	orb = CORBA::ORB_init(argc, argv);

	// Get the "RootPOA"
	Object_var obj = orb->resolve_initial_references("RootPOA");
	PortableServer::POA_var poa = PortableServer::POA::_narrow(obj);

	// activate its managers so it can handle incoming requests
	poa->the_POAManager()->activate();

	// get a thread going to handle incoming requests
	ACE_Thread::spawn(RunFunc);

	// we could also use the corbaloc syntax to get a reference to the
	// object. This will cause the orb to talk directly to the other
	// orb with no name service or common file involved.
	obj = orb->string_to_object("corbaloc::moth:9999/Simple");

	if (is_nil(obj)) {
		cerr << "could not get reference" << endl;
		return 1;
	}

	// narrow the reference to the particular type we wish to deal with
	Simple_var simple = Simple::_narrow(obj);
	if (is_nil(simple)) {
		cout << "could not get reference" << endl;
		return 1;
	}

	// create an object reference that has a bogus value for the first
	// profile
	obj = orb->resolve_initial_references("IORManipulation");
	TAO_IOP::TAO_IOR_Manipulation_var iorm =
		TAO_IOP::TAO_IOR_Manipulation::_narrow(obj.in());

	// Status: The following scenarios appear to work:
	// - first profile invalid host name, second profile valid.
	// - first profile invalid ip number, second profiel valid.
	// - first profiel invalid port number, second profile valid.
	//
	// The following causes a core dump of the server:
	// - first and second invalid
	// 
	// Note that he iormanip is being used since it is not practical
	// to have a test case that depends on a VPN being present.
	//
	Object_var name1 =
        orb->string_to_object ("corbaloc:iiop:10.0.2.3:6060/xyz");
	Object_var name2 =
		orb->string_to_object ("corbaloc:iiop:daisnot:7070/xyz");
	String_var name1_ior = orb->object_to_string(name1.in());
	String_var name2_ior = orb->object_to_string(name2.in());

	// create a callback object
	Callee_i * callee_i = new Callee_i;
	// get the CORBA reference
	Callee_var callee = callee_i->_this(); 
	if (is_nil(callee)) {
		cerr << "could not get callback object" << endl;
		exit(1);
	} else {
		String_var str = orb->object_to_string(callee);
		// dump the ior out to a file
		ofstream file("ior");
		file << str.in() << endl;
		file.close();
	}

	// create a reference with two profiles with the first on being
	// bogus. If things work as they should the callback should be
	// succesful with the ORB trying the second profile.
	TAO_IOP::TAO_IOR_Manipulation::IORList iors (2);
	iors.length (2);
	iors [0] = name1;
	iors [1] = name2;

	Object_var merged = iorm->merge_iors(iors);
	Callee_var doubleCallee = Callee::_unchecked_narrow(merged.in());

	cout << "profile count is: " << iorm->get_profile_count(merged.in())
		 << endl;
	
	simple->registerCallee(doubleCallee);
	
	// uncomment this when working over a VPN to get the same error.
	// simple->registerCallee(callee);

	ACE_OS::sleep(3000);
	cout << "done sleeping" << endl;
	orb->shutdown(1);

	return 0;
}
