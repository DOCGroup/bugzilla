#include <ace/OS.h>
#include <tao/corba.h>
#include <tao/IORTable/IORTable.h>
#include "Simple_i.h"

#include <iostream>

using namespace std;
using namespace CORBA;

ORB_var orb;

void advertise(Object_ptr obj)
{
	// "advertise" its object reference in the file "ior".
	ofstream outfile("ior");
	String_var str = orb->object_to_string(obj);
	outfile << (const char *)str << endl; 

	// also advertise our object in the IORTable so that it can be
	// accessed by a client using the "cobaloc" syntax
	Object_var tmp = orb->resolve_initial_references("IORTable");
	IORTable::Table_var iorTable = IORTable::Table::_narrow(tmp);
	if (is_nil(iorTable)) {
		cerr << "could not get the IORTable, will not register" << endl;
	} else {
		iorTable->rebind("Simple", str.in());
		cout << "registered Simple" << endl;
	}
	// we could also advertise the object reference to a naming and/or
	// trading service
}

int main(int argc, char * argv[])
{
	// Initialize the orb.
	orb = ORB_init(argc, argv);

	// Get the "RootPOA"
	Object_var obj = orb->resolve_initial_references("RootPOA");
	PortableServer::POA_var poa = PortableServer::POA::_narrow(obj);

	// activate its managers so it can handle incoming requests
	poa->the_POAManager()->activate();

	// Create a CORBA object that can be called by a client. Note that
	// this does not create the CORBA object. It creates the object
	// that does the real work behind the CORBA object.
	Simple_i * simple = new Simple_i(orb);

	// This call creates the CORBA object and returns a reference to
	// it. It uses the "RootPOA" for dispatching its calls. There are
	// a number of ways this can be done different. Refer to "Advanced
	// CORBA Programming with C++" chapter 11 for more information.
	Simple_var simpleRef = simple->_this();

	advertise(simpleRef.in());

	// give the ORB control for only 30 seconds
	cout << "ready to run" << endl;
	for (int i = 0; i < 1000; ++i) {
		ACE_Time_Value runTime(3);
		orb->run(runTime);
		for (int i = 0; i < 10000000; ++i) {} 
		
	}
	cout << "done running" << endl;

	// For more information on what the ORB can do please refer to the
	// VERITAS CORBA web page at
	// http://www.min.veritas.com/int-training/platform/corba.htm
	return 0;
}
