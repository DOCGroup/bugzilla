#include "Simple_i.h"
#include <tao/ORB_Core.h>

Simple_i::Simple_i(CORBA::ORB_ptr orb)
	: m_orb(orb->_duplicate(orb))
{
}

void Simple_i::registerCallee(Callee_ptr value) throw (CORBA::SystemException)
{
	cout << "registerCallee invoked" << endl;
	// retain a reference so we can callback later
	m_callee = value->_duplicate(value);

	// register a callback with the reactor so we can invoke the
	// callback method
	m_orb->orb_core()->reactor()->schedule_timer(this, 0, 5);
}

int Simple_i::handle_timeout(
	const ACE_Time_Value & currentTime,
	const void * data
	)
{
	cout << "timer expired" << endl;
	m_callee->callback("got timeout");
	return 0;
}
