
package demo.bidir;

import java.util.Properties;
import javax.swing.JApplet;
import javax.swing.JTextArea;
import org.jacorb.orb.ParsedIOR;
import org.omg.BiDirPolicy.BIDIRECTIONAL_POLICY_TYPE;
import org.omg.BiDirPolicy.BOTH;
import org.omg.BiDirPolicy.BidirectionalPolicyValueHelper;
import org.omg.CORBA.Any;
import org.omg.CORBA.Policy;
import org.omg.CORBA.PolicyError;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.IOP.TaggedProfile;
import org.omg.PortableServer.IdAssignmentPolicyValue;
import org.omg.PortableServer.ImplicitActivationPolicyValue;
import org.omg.PortableServer.LifespanPolicyValue;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.AdapterAlreadyExists;
import org.omg.PortableServer.POAPackage.InvalidPolicy;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

/**
 * Client.java Created: Mon Sep 3 19:28:34 2001
 * 
 * @author Nicolas Noffke
 * @version $Id: Client.java,v 1.2 2003/12/01 12:36:00 simon.mcqueen Exp $
 */
public class AppletBiDirectionalClient extends JApplet
{
   private JTextArea m_textArea;
   private org.omg.CORBA.ORB m_orb;
   private Server m_server;

   class IMPL extends ClientCallbackPOA
   {
      public void hello(String message)
      {
         m_textArea.append("Client callback object received hello message >" + message + '<');
      }
   }

   @Override
   public void init() 
   {
      try
      {
         m_textArea = new JTextArea();
         add(m_textArea);
         Properties props = new Properties();
         props.put("org.omg.PortableInterceptor.ORBInitializerClass.bidir_init",
                   "org.jacorb.orb.giop.BiDirConnectionInitializer");
         props.put("ORBInitRef.NameService",
                   "http://goshawk/Teamphone/TPDir/public/ns.ior");
         props.put("jacorb.dns.enable", "on");
         m_orb = org.omg.CORBA.ORB.init(this, props);
         NamingContextExt nc = NamingContextExtHelper.narrow(m_orb.resolve_initial_references("NameService"));
         org.omg.CORBA.Object o = nc.resolve(nc.to_name("callback"));
         m_server = ServerHelper.narrow(o);
         Any any = m_orb.create_any();
         BidirectionalPolicyValueHelper.insert(any, BOTH.value);
         POA root_poa = (POA) m_orb.resolve_initial_references("RootPOA");
         Policy[] policies = new Policy[4];
         policies[0] = root_poa.create_lifespan_policy(LifespanPolicyValue.TRANSIENT);
         policies[1] = root_poa.create_id_assignment_policy(IdAssignmentPolicyValue.SYSTEM_ID);
         policies[2] = root_poa.create_implicit_activation_policy(ImplicitActivationPolicyValue.IMPLICIT_ACTIVATION);
         policies[3] = m_orb.create_policy(BIDIRECTIONAL_POLICY_TYPE.value, any);
         POA bidir_poa = root_poa.create_POA("BiDirPOA", root_poa.the_POAManager(), policies);
         bidir_poa.the_POAManager().activate();
         ClientCallback ccb = ClientCallbackHelper.narrow(bidir_poa.servant_to_reference(new IMPL()));
         m_server.register_callback(ccb);
         final ParsedIOR parsedIOR = new ParsedIOR(m_orb.object_to_string(ccb), m_orb, 
            ((org.jacorb.orb.ORB)m_orb).getConfiguration().getNamedLogger("applet_somethingorother"));

         TaggedProfile[] x1 = parsedIOR.getIOR().profiles;
         for(TaggedProfile t : x1)
         {
            System.out.println("tag = " + t.tag + ", " + new String(t.profile_data));
         }
      }
      catch (InvalidName e)
      {
         e.printStackTrace();
      }
      catch (NotFound e)
      {
         e.printStackTrace();
      }
      catch (CannotProceed e)
      {
         e.printStackTrace();
      }
      catch (org.omg.CosNaming.NamingContextPackage.InvalidName e)
      {
         e.printStackTrace();
      }
      catch (PolicyError e)
      {
         e.printStackTrace();
      }
      catch (AdapterAlreadyExists e)
      {
         e.printStackTrace();
      }
      catch (InvalidPolicy e)
      {
         e.printStackTrace();
      }
      catch (AdapterInactive e)
      {
         e.printStackTrace();
      }
      catch (ServantNotActive e)
      {
         e.printStackTrace();
      }
      catch (WrongPolicy e)
      {
         e.printStackTrace();
      }
   }

   @Override
   public void start()
   {
      m_server.callback_hello("A test string");
   }

   @Override
   public void stop()
   {
      m_orb.shutdown(true);
   }

   public static void main(String[] args) throws Exception
   {
   }
}// Client
