#include "CallBackServer.h"
#include <string>
#include <iostream>
#include "ace/SString.h"

CallBackServer::CallBackServer()
{
   //no-op
}

CallBackServer::~CallBackServer()
{
   //no-op
}

void CallBackServer::register_callback ( demo::bidir::ClientCallback_ptr cc )
         throw(CORBA::SystemException)
{
   try
   {
      m_callback = demo::bidir::ClientCallback::_duplicate( cc );
   }     
   catch (CORBA::Exception const & e) {
      std::cerr << "CORBA exception raised! <" << e._info().c_str() << ">" << std::endl;
   }
}

void CallBackServer::callback_hello ( const char * message )
         throw(CORBA::SystemException)
{
   try
   {
      std::string m = "this was added by server, original client message <" + std::string(message) + ">";
      m_callback->hello(m.c_str());
   }     
   catch (CORBA::Exception const & e) {
      std::cerr << "CORBA exception raised! <" << e._info().c_str() << ">" << std::endl;
   }
}
