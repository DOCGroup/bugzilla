//
// $Id: server.cpp,v 1.5 2003/07/23 18:21:59 dhinton Exp $
//

//#pragma warning( push )
//#pragma warning( disable : 4245 )
#include "CallBackServer.h"
#include <iostream>
//#include "ace/streams.h"
//#pragma warning( pop )
#include "orbsvcs/CosNamingS.h"
#include "ace/SString.h"
#include "tao/BiDir_GIOP/BiDirGIOP.h"

int main (int argc, char* argv[])
{
  try {
    // First initialize the ORB, that will remove some arguments...
    CORBA::ORB_var orb =
      CORBA::ORB_init (argc, argv,
                       "" /* the ORB name, it can be anything! */);

    CORBA::Object_var poa_object =
      orb->resolve_initial_references ("RootPOA");
      PortableServer::POA_var poa =
        PortableServer::POA::_narrow (poa_object.in ());
      CORBA::Any any;
      any <<= BiDirPolicy::BOTH;
      CORBA::Policy_var generic_policy = orb->create_policy(BiDirPolicy::BIDIRECTIONAL_POLICY_TYPE, any);
      CORBA::PolicyList policy_list;
      policy_list.length (1);
//      policy_list[0] = poa->create_lifespan_policy (PortableServer::TRANSIENT);   
//      policy_list[1] = poa->create_id_assignment_policy (PortableServer::SYSTEM_ID);
//      policy_list[2] = poa->create_implicit_activation_policy (PortableServer::IMPLICIT_ACTIVATION);
      policy_list[0] = BiDirPolicy::BidirectionalPolicy::_narrow( generic_policy );            //lint !e1037 ambiguous reference to conversion function 
//      policy_list[4] = poa->create_servant_retention_policy(PortableServer::RETAIN);
//      policy_list[5] = poa->create_request_processing_policy(PortableServer::USE_ACTIVE_OBJECT_MAP_ONLY);

    PortableServer::POAManager_var poa_manager =
      poa->the_POAManager ();

    PortableServer::POA_var bidir_poa = poa->create_POA( "BiDirPOA", poa_manager, policy_list); //lint !e1037 ambiguous reference to conversion function 

    PortableServer::POAManager_var bidir_poa_manager = bidir_poa->the_POAManager();
    bidir_poa_manager->activate();


    // Create the servant
    CallBackServer callbackserver;
    (void) bidir_poa->activate_object(&callbackserver);

    CORBA::Object_var o = bidir_poa->servant_to_reference(&callbackserver);

    // Activate it to obtain the object reference

    CORBA::Object_var naming_context_object =
      orb->resolve_initial_references ("NameService");
    CosNaming::NamingContext_var naming_context =
      CosNaming::NamingContext::_narrow (naming_context_object.in ());

    // Create and initialize the name.
    CosNaming::Name name (1);
    name.length (1);
    name[0].id = CORBA::string_dup ("callback");

    // Bind the object
    naming_context->bind (name, o);   //lint !e1037 ambiguous reference to conversion function 
    
    // Put the object reference as an IOR string
    CORBA::String_var ior = orb->object_to_string (o); //lint !e1037 ambiguous reference to conversion function
    // Print it out!
    std::cout << ior.in () << std::endl;

    orb->run ();

    // Destroy the POA, waiting until the destruction terminates
    poa->destroy (1, 1);
    orb->destroy ();
  }
  catch (CORBA::Exception const & e) {
    std::cerr << "CORBA exception raised! <" << e._info().c_str() << ">" << std::endl;
  }
  return 0;
}
