//
// $Id: Stock_Factory_i.h,v 1.1 1999/11/28 17:41:12 coryan Exp $
//

#ifndef CALL_BACK_SERVER_H
#define CALL_BACK_SERVER_H

#include "servers.h"

class CallBackServer : public POA_demo::bidir::Server 
{
   public:
      CallBackServer ();
      ~CallBackServer ();

      virtual void register_callback ( demo::bidir::ClientCallback_ptr cc )
         throw(CORBA::SystemException);

      virtual void callback_hello ( const char * message )
         throw(CORBA::SystemException);

   private:
      ::demo::bidir::ClientCallback_var m_callback;
};

#endif /* CALL_BACK_SERVER_H */
