#include <iostream>
#include "TestC.h"

using namespace std;

int
main(int argc, char* argv[]) 
{
  try 
  {
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

    CORBA::Object_var obj = orb->string_to_object("file://Server1.ior");
    Test::Server_var server1 = Test::Server::_narrow(obj.in());

    if (CORBA::is_nil(server1)) {
      std::cout << "could not narrow server1" << endl;
      return 1;
    }

    obj = orb->string_to_object("file://Server2.ior");
    Test::Server_var server2 = Test::Server::_narrow(obj.in());

    if (CORBA::is_nil(server2)) {
      std::cout << "could not narrow server2" << endl;
      return 1;
    }

    server1->op();
    server1->release();

    server2->op();

  } 
  catch (const CORBA::Exception& ex ) {
    ACE_PRINT_EXCEPTION(ex, "Exception");
    return -1;  
  } 
  catch (...) {
    std::cout << "C++ exception in client main" << endl;
    return -1;
  }
  return 0;
}
