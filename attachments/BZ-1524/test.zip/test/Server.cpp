#include <iostream>
#include <string>
#include <fstream>
#include <list>
#include "TestS.h"
#include "tao/Strategies/advanced_resource.h"
#include "ace/Task.h"
#include "ArgVec.h"


class ORBThreadPool : public ACE_Task_Base
{
public:
  ORBThreadPool(CORBA::ORB_var& orb);
  virtual int svc();
  
private:
  ACE_Thread_Manager m_threadMgr;
  CORBA::ORB_var&    m_orb;
};


class Server_impl : public POA_Test::Server, public PortableServer::RefCountServantBase 
{
public:
  Server_impl(CORBA::ORB_var& orb, PortableServer::POA_var& poa, const std::string& name)
  : m_orb(orb), m_poa(poa), m_name(name)
  {
    std::cout << "Server_impl::Server_impl " << m_name << std::endl;
  }

  ~Server_impl()
  {
    std::cout << "Server_impl::~Server_impl entry " << m_name << std::endl;
    int* a = 0;
    int b = 1 / *a;
    std::cout << "Server_impl::~Server_impl exit " << m_name << std::endl;
  }

  void activate() 
  {
    Test::Server_var server_var = _this(); // activate under RootPoa
    PortableServer::ObjectId_var oid = m_poa->reference_to_id(server_var);
    _remove_ref();

    CORBA::String_var s = m_orb->object_to_string(server_var);
    std::cout << m_name << " " << s.in() << std::endl;

    std::string filename(m_name);
    filename += ".ior";
    std::ofstream iorfile(filename.c_str());
    iorfile << s.in();
    iorfile.close();    
  }
  
  // CORBA operations
  virtual void release()
  {
    try {
      std::cout << "Server_impl::Release " << m_name << std::endl;
      Test::Server_var server_var = _this();
      PortableServer::ObjectId_var oid = m_poa->reference_to_id(server_var);
      m_poa->deactivate_object(oid);
    } 
    catch (const CORBA::Exception& ex) {
      ACE_PRINT_EXCEPTION(ex, "Exception");
    } 
    catch (...) {
      std::cout << "Unexpected exception in " << m_name  << std::endl;
    }
  }

  virtual void op()
  {
      std::cout << "Server_impl::op " << m_name << std::endl;
  }

private:
  CORBA::ORB_var          m_orb;
  PortableServer::POA_var m_poa;
  std::string             m_name;
};


int
main(int argc, char* argv[]) 
{
  std::cout << "Server started" << std::endl;
  try 
  {
    ArgList argList;
    //argList.push_back("-ORBDebug");
    //argList.push_back("-ORBDebugLevel");
    //argList.push_back("10");

    argList.push_back("-ORBSvcConfDirective");
    //argList.push_back("static Advanced_Resource_Factory \"-ORBReactorType select_mt\"");
    //argList.push_back("static Advanced_Resource_Factory \"-ORBReactorType tp -ORBConnectionCacheMax 50\"");
    argList.push_back("static Advanced_Resource_Factory \"-ORBReactorType tp\"");

    //argList.push_back("-ORBSvcConfDirective");
    //argList.push_back("static Server_Strategy_Factory \"-ORBConcurrency thread-per-connection\"");
    
    //argList.push_back("-ORBSvcConfDirective");
    //argList.push_back("static Client_Strategy_Factory \"-ORBTransportMuxStrategy exclusive\"");
    //argList.push_back("static Client_Strategy_Factory \"-ORBTransportMuxStrategy muxed\"");

    ArgumentVector args(argList);

    // ORB initialization boiler plate...
    CORBA::ORB_var orb = CORBA::ORB_init(args.argc(), args.argv(), "");    
  
    CORBA::Object_var obj = orb->resolve_initial_references("RootPOA");

    PortableServer::POA_var rootPOA = PortableServer::POA::_narrow(obj);    

    PortableServer::POAManager_var mgr = rootPOA->the_POAManager();
    mgr->activate();    

    Server_impl* server1 = new Server_impl(orb, rootPOA, "Server1");
    server1->activate();

    Server_impl* server2 = new Server_impl(orb, rootPOA, "Server2");
    server2->activate();

    ORBThreadPool threadPool(orb);
    threadPool.activate(THR_NEW_LWP | THR_JOINABLE, 10);
    threadPool.wait();
    
    //orb->run();
    
  } 
  catch (const CORBA::Exception& ex) {
    ACE_PRINT_EXCEPTION(ex, "Exception");
    return -1;  
  } 
  catch (...) {
    std::cout << "Unexpected exception in Server" << std::endl;
    return -1;
  }
  
  std::cout << "Server finished" << std::endl;
  return 0;
}


ORBThreadPool::ORBThreadPool(CORBA::ORB_var& orb) : ACE_Task_Base(&m_threadMgr), m_orb(orb) 
{}

int
ORBThreadPool::svc()
{
  try {
    m_orb->run();
  } 
  catch (const CORBA::Exception& ex) {
    ACE_PRINT_EXCEPTION (ex, "ORBThreadPool");
  }
  catch (...) {
    // no action
  }
  return 0;
}


