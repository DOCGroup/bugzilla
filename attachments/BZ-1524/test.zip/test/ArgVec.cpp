#include "ArgVec.h"

ArgumentVector::ArgumentVector(const ArgList& args)
: m_argc(args.size()+1), m_argcRef(m_argc)
{
  mp_argv = new char*[m_argc];
  
  // add empty first argument - no executable for these hand-crafted arg lists
  mp_argv[0] = new char[12];
  strcpy(mp_argv[0], "PLACEHOLDER");
  
  // fill the rest of the args with args[0] to args[argc-1]
  for (int i=0; i<m_argc-1; i++) {
    mp_argv[i+1] = new char[args[i].size()+1];
    strcpy(mp_argv[i+1], args[i].c_str());
  }
}

ArgumentVector::~ArgumentVector() {
  for (int i=0; i<m_argc; i++) {
    delete[] mp_argv[i];
  }
  delete[] mp_argv;
}

ArgumentVector::operator char**() {
  return mp_argv;
}

int& ArgumentVector::argc() {
  return m_argcRef;
}

char** ArgumentVector::argv() {
  return mp_argv;
}

