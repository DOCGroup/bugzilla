#pragma warning (disable:4786)
#include <iostream>
#include <string>
#include <vector>

typedef std::vector<std::string> ArgList;

class ArgumentVector  {
  public:
    ArgumentVector(const ArgList& args);
    virtual ~ArgumentVector();
    int& argc();
    char** argv();
    operator char**();
    
  private:
    ArgumentVector(const ArgumentVector&);
    ArgumentVector& operator=(const ArgumentVector&);
    
    char** mp_argv;
    int    m_argc;
    int    m_argcRef;
  };