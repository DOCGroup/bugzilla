// -*- C++ -*-

//=============================================================================
/**
 *  @file    client.cpp
 *
 *  $Id: client.cpp 93650 2011-03-28 08:44:53Z johnnyw $
 *
 * A simple client to demonstrate the use of codeset translation
 *
 *
 *  @author   Phil Mesnier <mesnier_p@ociweb.com>
 */
//=============================================================================

// IDL generated headers
#include "simpleC.h"
#include "ace/ace_wchar.h"

// FUZZ: disable check_for_streams_include
#include "ace/streams.h"

#include "ace/OS_NS_string.h"
#include "ace/Log_Msg.h"
#include "ace/Get_Opt.h"

const ACE_TCHAR *ior = ACE_TEXT ("file://test.ior");

int
parse_args (int argc, ACE_TCHAR *argv[])
{
  ACE_Get_Opt get_opts (argc, argv, ACE_TEXT("k:"));
  int c;

  while ((c = get_opts ()) != -1)
    switch (c)
      {
      case 'k':
        ior = get_opts.opt_arg ();
        break;

      case '?':
      default:
        ACE_ERROR_RETURN ((LM_ERROR,
                           "usage:  %s "
                           "-k <ior> "
                           "\n",
                           argv [0]),
                          -1);
      }
  // Indicates successful parsing of the command line
  return 0;
}


// ------------------------------------------------------------
// Client
// ------------------------------------------------------------
int ACE_TMAIN (int argc, ACE_TCHAR *argv[])
{
  int error_count = 0;

  try
    {
      // Init the orb
      CORBA::ORB_var orb= CORBA::ORB_init (argc, argv);

      // Get IOR from command line (or file)
      if (parse_args (argc, argv) != 0)
        return 1;

      // The first arg should be the IOR
      CORBA::Object_var object =
        orb->string_to_object (ior);

      // Get the server
      simple_var server = simple::_narrow (object.in ());

      char ascii[(128 - 32) + 1] = {0};
      for (int i = 0; i < (128 - 32); ++i)
        {
          ascii[i] = i + 32;
        }
      char iso8859_1[(128 * 2) + 1] = {0};
      for (int i = 0; i < 128; ++i)
        {
          // UTF-8 encode it
          int c = i + 128;
          iso8859_1[i * 2] = 0xC0 | (c >> 6);
          iso8859_1[i * 2 + 1] = 0x80 | (c & 0x3F);
        }

      // test ASCII codepoints
      ACE_DEBUG ((LM_DEBUG,
                 "Testing ASCII codepoints\n\n") );
      {
        CORBA::Any inarg;
        inarg <<= ascii;
        CORBA::Any_var outarg;

        // Invoke the call.
        CORBA::String_var reply =
          server->op1 (ascii,
                       inarg,
                       outarg.out ());

        const char *any_reply;
        outarg >>= any_reply;

        if (ACE_OS::strcmp (ascii, reply.in ()) != 0)
          {
            ACE_DEBUG ((LM_DEBUG,
                   "Error: Client sent  \n%C\ngot\n%C\n", ascii, reply.in ()) );
            ++error_count;
          }


        if (ACE_OS::strcmp (ascii, any_reply) != 0)
          {
	  ACE_DEBUG ((LM_DEBUG,
                   "Error: Client sent  \n%C\ngot\n%C\n", ascii, any_reply) );

            ++error_count;
          }
      }
      
      // test additional ISO8859-1 codepoints
      ACE_DEBUG ((LM_DEBUG,
                 "Testing ISO8859-1 codepoints\n\n") );
      {
        CORBA::Any inarg;
        inarg <<= iso8859_1;
        CORBA::Any_var outarg;

        // Invoke the call.
        CORBA::String_var reply =
          server->op1 (iso8859_1,
                       inarg,
                       outarg.out ());

        const char *any_reply;
        outarg >>= any_reply;

        if (ACE_OS::strcmp (iso8859_1, reply.in ()) != 0)
          {
            ACE_DEBUG ((LM_DEBUG,
                   "Error: Client sent  \n%C\ngot\n%C\n", iso8859_1, reply.in ()) );
            ++error_count;
          }


        if (ACE_OS::strcmp (iso8859_1, any_reply) != 0)
          {
	  ACE_DEBUG ((LM_DEBUG,
                   "Error: Client sent  \n%C\ngot\n%C\n", iso8859_1, any_reply) );

            ++error_count;
          }
      }
      if (error_count == 0)
        ACE_DEBUG ((LM_DEBUG,
                   "Completed succesfully\n\n") );

      server->shutdown ();
    }
  catch (const CORBA::Exception& ex)
    {
      ex._tao_print_exception ("Exception caught in client:");
      return 1;
    }

  return error_count;
}
