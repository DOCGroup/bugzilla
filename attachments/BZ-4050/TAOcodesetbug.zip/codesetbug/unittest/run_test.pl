eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
     & eval 'exec perl -S $0 $argv:q'
     if 0;

# $Id: run_test.pl 88314 2009-12-23 12:02:42Z vzykov $
# -*- perl -*-

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

my $server = PerlACE::TestTarget::create_target (1) || die "Create target 1 failed\n";
my $client = PerlACE::TestTarget::create_target (2) || die "Create target 2 failed\n";

my $iorbase = "server.ior";
my $server_iorfile = $server->LocalFile ($iorbase);
my $client_iorfile = $client->LocalFile ($iorbase);
$server->DeleteFile($iorbase);
$client->DeleteFile($iorbase);

my $client_trans_conf = $client->LocalFile ("cs_test_client.conf");
my $server_trans_conf = $server->LocalFile ("cs_test_server_trans.conf");

$SV = $server->CreateProcess ("server", "-ORBDebugLevel 0 -o $server_iorfile -ORBDottedDecimalAddresses 1 -ORBSvcConf $server_trans_conf");
$CL = $client->CreateProcess ("client", "-ORBDebugLevel 0 -k file://$client_iorfile -ORBSvcConf $client_trans_conf");

$status = 0;

print STDOUT "Server using char translator\n\n";

$server_status = $SV->Spawn ();
if ($server_status != 0) {
    print STDERR "ERROR: Starting server returned $server_status\n";
    exit 1;
}
if ($server->WaitForFileTimed ($iorbase,
                               $server->ProcessStartWaitInterval()) == -1) {
    print STDERR "ERROR: cannot find file <$server_iorfile>\n";
    $SV->Kill (); $SV->TimedWait (1);
    exit 1;
}

$client_status = $CL->SpawnWaitKill ($client->ProcessStartWaitInterval ());
if ($client_status != 0) {
    print STDERR "ERROR: client returned $client_status\n";
    $status = 1;
}

$server_status = $SV->WaitKill ($server->ProcessStopWaitInterval ());
if ($server_status != 0) {
    print STDERR "ERROR: server returned $server_status\n";
    $status = 1;
}

$server->DeleteFile($iorbase);
$client->DeleteFile($iorbase);


exit $status;
