// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#if !defined(AFX_STDAFX_H__A03956F5_499E_11D7_97F6_0048541354D8__INCLUDED_)
#define AFX_STDAFX_H__A03956F5_499E_11D7_97F6_0048541354D8__INCLUDED_


////////////////////
#ifdef WIN32
////////////////////

#if _MSC_VER > 1000 && !defined(_IVX)
#pragma once
#pragma warning(disable:4786)
#pragma warning(disable:4503)
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// STD:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <sys/timeb.h>
#include <iomanip>

// STL:
#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <list>
#include <set>
#include <deque>
#include <fstream>
#include <iostream>
#include <sstream>
#include <ostream>

// ACE:
#include <ace/ACE.h>
#include <ace/OS.h>
#include <ace/FILE.h>
#include <ace/FILE_Addr.h>
#include <ace/FILE_Connector.h>
#include <ace/Synch.h>
#include <ace/INET_Addr.h>
#include <ace/SOCK_Dgram.h>
#include <ace/Sock_Connect.h>
#include <ace/SOCK_Connector.h>
#include <ace/SOCK_Stream.h>
#include <ace/System_Time.h>
#include <ace/Env_Value_T.h>
#include <ace/ace_wchar.h>
#include <ace/Message_Block.h>
#include <ace/Thread.h>
#include <ace/SString.h>
#include <ace/pre.h>
#include <ace/Shared_Object.h>
#include <ace/Event_Handler.h>
#include <ace/Service_Object.h>
#include <ace/Time_Value.h> 


////////////////////
#endif //win32
////////////////////


#define DELETE_AND_NULL(arg) \
{\
	if (arg) delete (arg);\
	(arg) = NULL;\
}

#define DELETE_AND_NULL_ARRAY(arg) \
{\
	delete[] (arg);\
	(arg) = NULL;\
}

#include "CLogger.h"




//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A03956F5_499E_11D7_97F6_0048541354D8__INCLUDED_)
