// TimerQueueTest.cpp : Defines the entry point for the console application.
//

#include "StdAfx.h"
#include <ace/OS.h>
#include "ace/Timer_Heap_T.h"
#include "ace/Timer_Queue_Adapters.h"




//ACE timer classes
typedef ACE_Event_Handler_Handle_Timeout_Upcall<ACE_Recursive_Thread_Mutex> tTimeoutUpcall;
typedef ACE_Timer_Heap_T<ACE_Event_Handler*, tTimeoutUpcall, ACE_Recursive_Thread_Mutex> tTimerQueue;
typedef ACE_Thread_Timer_Queue_Adapter<tTimerQueue> tThreadTimerQueue;
typedef std::vector<long> tTransactionMap;
class TimerQueueTest;
static TimerQueueTest* pTimerQueue;


class TimerQueueTest:public tThreadTimerQueue {
public:
	TimerQueueTest(){
		this->activate();
	}
	//timeout event handler function
	virtual int handle_timeout(const ACE_Time_Value& time,const void *arg = 0){
		cout <<  "handle_timeout" << std::endl;
		return 0;
	}
};




static void ScheduleTimer(){

	
	//int timeout = ((rand()+3200)*360);
	ACE_Time_Value rel_timeout(2,123456);
	
	cout <<  "ACE trying to schedule" << std::endl;
	long id = pTimerQueue->schedule(pTimerQueue, NULL, ACE_OS::gettimeofday()+rel_timeout);
	cout <<  "scheduled timer: " << id << std::endl; // <<". timeout microsec: "<< timeout << std::endl)
	//tTimerQueue& pQ = pTimerQueue->timer_queue();
	//pQ.dump();
	if (id < 0) {
		cout <<  "ERROR scheduling timer!!!!!\n";
	}
		

}
int main(int argc, char* argv[])
{
	ACE::init();
	
	pTimerQueue = new TimerQueueTest();

	
	ACE_OS::sleep(1);
	ACE_Time_Value wait(0,300000);
	
	while (true){
		ScheduleTimer();
		ACE_OS::sleep(wait);
	}
	ACE_OS::sleep(wait);
	ACE::fini();
	return 0;
}

