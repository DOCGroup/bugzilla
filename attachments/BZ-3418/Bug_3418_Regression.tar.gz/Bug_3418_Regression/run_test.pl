eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
     & eval 'exec perl -S $0 $argv:q'
     if 0;

# $Id: run_test.pl 81685 2008-05-13 07:43:59Z johnnyw $
# -*- perl -*-

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::Run_Test;

if (PerlACE::is_vxworks_test()) {
    $t1 = new PerlACE::ProcessVX ("Test");
}
else {
    $t1 = new PerlACE::Process ("Test");
}

my $status = $t1->SpawnWaitKill ($PerlACE::wait_interval_for_process_creation);
if ($status != 0) {
    print STDERR "ERROR: test failed, status=$status\n";
}

exit $status;
