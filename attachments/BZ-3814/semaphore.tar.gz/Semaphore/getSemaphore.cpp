#include "Semaphore.h"
#include "ace/svc_export.h"

using namespace std;

extern "C" ACE_Svc_Export Semaphore *getSemaphore (void);

Semaphore* getSemaphore()
{
	Semaphore* mySemaphore = new Semaphore();
	return mySemaphore;
}
