//#include <iostream>
#include "Semaphore.h"
//#include <string.h>
#include "ace/OS.h"

//using namespace std;

int Semaphore::run()
{
	//cout<<"Going to start a new thread"<<endl;
	ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Going to start a new thread \n")));

	activate(THR_NEW_LWP, 1);

	return 1;
}

int Semaphore::svc()
{
	ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Semaphore : Thread started \n")));

	int k=30;
	ACE_Time_Value flushIntv(k);


startAgain:

	ACE_Time_Value currTime=ACE_OS::gettimeofday();
	long secDiff=currTime.sec()%k;
		 secDiff=k-secDiff;

	ACE_Time_Value FLUSH_TIME(currTime.sec()+secDiff);       // Next Flushing time
	timeReset=false;                            
	errorTime=0;

	while(1)
	{
		ACE_Time_Value cpOfFlushTime=FLUSH_TIME;

		int res=semaphore.acquire(cpOfFlushTime);

		if(res==-1)    // Timed out 
		{
			currTime=ACE_OS::gettimeofday();

			if(abs((int)(currTime.sec()-FLUSH_TIME.sec()))>10)
			{
				timeReset=true;
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Problem occurred ... curr time > flush time \n")));
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Errno %s \n"), ACE_OS::strerror(errno)));
				//cout<<"Problem occurred ... curr time > flush time "<<strerror(errno)<<endl;
			}
			else if(FLUSH_TIME.sec()>currTime.sec())
			{
				//cout<<"Everything fine... Flush time > curr time "<<strerror(errno)<<endl;
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Running fine... curr time < flush time \n")));
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Errno %s \n"), ACE_OS::strerror(errno)));
				continue;
			}
			else
			{
				//cout<<"Everything is fine... Flush time = curr time "<<strerror(errno)<<endl;
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Running fine ... curr time = flush time \n")));
				ACE_DEBUG((LM_DEBUG, ACE_TEXT ("Errno %s \n"), ACE_OS::strerror(errno)));
			}
			
			errorTime=currTime.sec()-FLUSH_TIME.sec();			
		}

		if(res!=-1  || semaphore.tryacquire()!=-1)
		{
			//cout<<"Problem occurred in res = -1 or tryacquire"<<endl;
			return 0;
		}

		FLUSH_TIME+=flushIntv;

		if(timeReset)
		{
			goto startAgain;
		}			
	}
}


