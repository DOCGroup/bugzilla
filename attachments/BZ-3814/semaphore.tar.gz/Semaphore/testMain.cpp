//#include <iostream>
#include "Semaphore.h"
#include "ace/DLL.h"
#include "ace/Auto_Ptr.h"
#include "tests/test_config.h"

//using namespace std;

typedef Semaphore* (*Semaphore_Creator) (void);

int main()
{
	ACE_DLL dll;

	int retval = dll.open(ACE_DLL_PREFIX ACE_TEXT("Sem"));
	if(retval != 0)
	{
		//cout<<"Error in opening DLL"<<endl;
		ACE_ERROR((LM_ERROR, ACE_TEXT ("Error in opening dll !\n")));
		return -1;
	}

	Semaphore_Creator sem;

	void *ptr = dll.symbol(ACE_TEXT("getSemaphore"));
	ptrdiff_t tmp = reinterpret_cast<ptrdiff_t> (ptr);
	sem = reinterpret_cast<Semaphore_Creator>(tmp);

	if(sem == 0)
	{
		//cout<<"Reinterpret cast failed"<<endl;
		ACE_ERROR((LM_ERROR, ACE_TEXT ("Reinterpret cast failed.\n")));
		return -1;
	}

	auto_ptr <Semaphore> sema(sem ());
	sema->run();

	ACE_Thread_Manager::instance()->wait();
	return 1;
}

