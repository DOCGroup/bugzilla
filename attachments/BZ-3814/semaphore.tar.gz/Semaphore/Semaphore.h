#include "ace/String_Base.h"
#include "ace/ACE.h"
#include "ace/Recursive_Thread_Mutex.h"
#include "ace/Task_T.h"
#include "ace/Date_Time.h"
#include "ace/Singleton.h"
#include "ace/String_Base.h"
#include "ace/OS.h"
#include "ace/Hash_Map_Manager_T.h"
#include "ace/Lock_Adapter_T.h"
#include "ace/Null_Mutex.h"
#include "ace/Recursive_Thread_Mutex.h"
#include "ace/Semaphore.h"

class Semaphore : public ACE_Task<ACE_MT_SYNCH>
{
	public :
		Semaphore() : semaphore(0)
		{
		}

		virtual int run();
		int svc();

	private :
		bool timeReset;
		long errorTime;
		ACE_Semaphore  semaphore;
};
