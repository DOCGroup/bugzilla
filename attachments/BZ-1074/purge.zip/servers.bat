start purge b  -ORBDebugLevel 10 >b.out 2>&1
start /b purge c0 -ORBDebugLevel 10 >c0.out 2>&1
start /b purge c1 -ORBDebugLevel 10 >c1.out 2>&1
start /b purge c2 -ORBDebugLevel 10 >c2.out 2>&1
start /b purge c3 -ORBDebugLevel 10 >c3.out 2>&1
start /b purge c4 -ORBDebugLevel 10 >c4.out 2>&1
