$| = 1;

&background( 'purge b'  );
&background( 'purge c0' );
&background( 'purge c1' );
&background( 'purge c2' );
&background( 'purge c3' );
&background( 'purge c4' );

sleep( 10 );

system( 'purge a -ORBDebugLevel 10' );



sub background
{
    my( $cmd ) = @_;
    
    if ( $^O =~ /Win32/ )
    {
        system( 'start ' . $cmd );;
    }
    else
    {
        system( $cmd . '&' );
    }
}

