#include "lockS.h"

#include "tao/TAO_Internal.h"
#include "ace/Thread_Manager.h"

ACE_Export int handle_socket_events_sleep_flag;

CORBA::ORB_ptr orb;
PortableServer::POA_ptr poa;

class ReboundImpl : public POA_rebound
{
public:
	ReboundImpl( char* r )
	{
		role = r;
	}

	virtual void ping ( const char* data, CORBA::Long sleep_time )
  {
	  fprintf( stderr, "ping: role=%s\n", role );
	  ACE_OS::sleep( sleep_time );
  }

  char* role;
} ;

void writeior( const char* fname, const char* ior )
{
	FILE* f = fopen( fname, "w" );
	if ( f == NULL )
	{
		fprintf( stderr, "can't open %s for writing\n", fname );
		return;
	}
	fwrite( (char*) ior, 1, strlen( (char*) ior ), f );
	fclose( f );
}

void readior( const char* fname, char*& res )
{
	FILE* f = fopen( fname, "r" );
	if ( f == NULL )
	{
		fprintf( stderr, "can't open %s for reading\n", fname );
		return;
	}

	res = new char[ 4096 ];

	fgets( res, 4000, f );

	char *p;
	for ( p = res; *p; p++ )
	{
		if ( *p == '\n' )
		{
			*p = 0;
		}
	}

	fclose( f );
}

rebound_ptr read_rebound( const char* fname )
{
	rebound_var res;
	CORBA::String_var ior;

	readior( fname, ior.out() );

	CORBA::Object_var wide;

	wide = orb->string_to_object( ior.in() );

	res = rebound::_narrow( wide );

	return res._retn();
}

class PingParam
{
public:
	rebound_ptr obj;
	int sleep_time;
} ;

void* PingThreadProc( void *par )
{
	PingParam* param = (PingParam*) par;

	ACE_OS::sleep( param->sleep_time + 20 );

	param->obj->ping( "ping_c", 1 );

	delete param;

	return 0;
}

void ping_c( rebound_ptr c, int sleep_time )
{
	PingParam *par = new PingParam;
	par->obj = c;
	par->sleep_time = sleep_time;

	ACE_Thread_Manager::instance()->spawn( PingThreadProc, ( void* ) par );
}

void* ShutdownOrbProc( void *par )
{
	ACE_OS::sleep( 20 );

	orb->shutdown();

	return 0;
}

int main( int argc, char* argv[] )
{
	static const char* resource_factory_args = 
		"static Resource_Factory \""
		"-ORBConnectionCacheMax 3 "
		"-ORBConnectionCachePurgePercentage 50 "
		"\"";
	static const char* server_strategy_args  = "";
	static const char* client_strategy_args  = "";

	TAO_Internal::default_svc_conf_entries(
					 resource_factory_args,
					 server_strategy_args,
					 client_strategy_args );

	orb = CORBA::ORB_init( argc, argv );

	char *role = argv[ 1 ];
	if ( role == NULL )
	{
		role = "no role specified";
	}

	{
	    CORBA::Object_var poaWide = orb->resolve_initial_references( "RootPOA" );
		poa = PortableServer::POA::_narrow( poaWide );

		PortableServer::POAManager_var poaManager = poa->the_POAManager();
		poaManager->activate();
	}

	ReboundImpl* reboundServant = new ReboundImpl( role );

	PortableServer::ObjectId_var objID;

	objID = poa->activate_object( reboundServant );

	rebound_var a = reboundServant->_this();

	CORBA::String_var ior( orb->object_to_string( a ) );

	if ( strcmp( role, "a" ) == 0 )
	{
		rebound_var b = read_rebound( "b.ior" );
		rebound_var c[ 5 ];
		int i;
		for ( i = 0; i < 5; ++i )
		{
			char fname[ 80 ];
			sprintf( fname, "c%d.ior", i );
			c[ i ] = read_rebound( fname );
		}

		// ping b to establish a connection
		b->ping( "grab connection to b", 0 );

		fprintf( stderr, "giving b a chance to shut down...\n" );

		ACE_OS::sleep( 20 );

		fprintf( stderr, "a finished sleep, now pinging c\n" );

		for ( i = 0; i < 5; i++ )
		{
			ping_c( c[ i ], i + 1 );
		}

		handle_socket_events_sleep_flag = 1;

		orb->run();
	}
	else if ( strcmp( role, "b" ) == 0 )
	{
		// Play the role of "B", the server which will terminate in 5 sec.
		writeior( "b.ior", ior.in() );
		fprintf( stderr, "b ready\n" );

		ACE_Thread_Manager::instance()->spawn( ShutdownOrbProc, 0 );

		orb->run();
	}
	else if ( role[ 0 ] == 'c' )
	{
		// Play the role of "C<n>", a server which does not terminate.
		char fname[ 80 ];
		sprintf( fname, "%s.ior", role );
		writeior( fname, ior.in() );
		fprintf( stderr, "c ready\n" );

		orb->run();
	}
	else
	{
		fprintf( stderr, "I don't know how to play the role '%s'\n", role );
		return 0;
	}

	return 0;
}
