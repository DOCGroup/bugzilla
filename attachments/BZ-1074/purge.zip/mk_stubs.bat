tao_idl -Cw -Ge 0 lock.idl

