This example program demonstrates a TAO bug involving a race between threads closing
or purging an IIOP connection.

SUMMARY:
--------

In responding to a socket event indicating the closure of an outgoing connection, 
the TP_Reactor may attempt to access the IIOP connection handler during a time in
which the connection handler and its associated Transport object are not 
locked or marked busy in any way.  A failure can occur if the transport cache
manager concurrently selects this connection for purging.


FAILURE SCENARIO:
-----------------

1.  Server "A" establishes a connection to some remote server "B".
2.  B decides to close the connection at a time when it is quiescent.
3.  The closure of the connection causes the socket to become ready
    for reading.
4.  The leader thread returns from select() and calls
      ACE_TP_Reactor::handle_socket_events().
5.  handle_socket_events() locates the IIOP_Connection_Handler associated
    with the ready file handle.
6.  handle_socket_events() releases the reactor token.
7.  Another thread makes a method invocation on a remote object, causing
    the transport cache manager to purge the connection found in step 5.
    This deletes the IIOP_Connection_Handler.
8.  handle_socket_events() tries to invoke a callback method on the deleted
    IIOP_Connection_Handler.

   
REPRODUCING THE BUG:
--------------------
1.  Make the following changes to ACE_wrappers/ace/TP_Reactor.cpp.  (These
    enable a conditional sleep in the reactor, allowing us to force
    the desired order of events):
  (a)  Near the top of file, after the line "ACE_RCSID( ... )", add the line:
        ACE_Export int handle_socket_events_sleep_flag = 0;
  (b) In ACE_TP_Reactor::handle_socket_events(), after 
      the line "guard.release_token ();", add the lines:
          if ( handle_socket_events_sleep_flag )
          {
        	  ACE_OS::sleep( 60 );
          }

2.  Build ACE, TAO, PortableServer, and the purge example (mk_stubs.bat and purge.dsw).

3.  Run testit.pl.  Several processes are started.
    In about 90 seconds, one of the processes should terminate with an 
    access violation.


DETAILED TIMELINE OF EVENTS:
----------------------------

Time    Events
(sec)
-----   -----------------------------------------
0       Start up B and C servers.
10      Start A client.     
        A pings B server.
        A sleeps (20 sec).
20      B server shuts down.
30      A awakes.
        A starts 5 pinger threads.
        A calls orb->run().
        This thread becomes the leader (holds the reactor token).
        Leader picks up the close event for the connection to B.
        Leader calls ACE_TP_Reactor::handle_socket_events().
        handle_socket_events() finds the event handler for the closed connection.
        handle_socket_events() releases the reactor token.
        handle_socket_events() sleeps (60 sec).
51      First pinger thread awakes.
        Pinger calls C0->ping().
        New connection established to C0.
52      Second pinger thread awakes.
        Pinger calls C1->ping().
        New connection established to C1.
53      Third pinger thread awakes.
        Pinger calls C2->ping().
        Transport Cache manager notices that the cache has now reached its
           max size of 3 (connections to B, C0, and C1).
        Cache manager purges the connection to B, deleting the associated
          transport and event handler objects.
90      handle_socket_events() awakes.
        handle_socket_events() calls dispatch_socket_event(), passing it a
           pointer to the (now deleted) event handler.
        dispatch_socket_event() tries to invoke a callback method on the 
          deleted event handler, causing a crash.
