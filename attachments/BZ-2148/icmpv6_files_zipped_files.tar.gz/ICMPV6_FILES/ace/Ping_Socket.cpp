// $Id: Ping_Socket.cpp,v 1.8 2005/05/19 22:59:40 shuston Exp $

#include "ace/Ping_Socket.h"

#if defined (ACE_HAS_ICMP_SUPPORT) && (ACE_HAS_ICMP_SUPPORT == 1)

#include "ace/INET_Addr.h"
#include "ace/Log_Msg.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/OS_NS_sys_socket.h"
#include "ace/ACE.h"
#if !defined (__ACE_INLINE__)
# include "ace/Ping_Socket.inl"
#endif  /* !__ACE_INLINE__ */


ACE_RCSID (ace,
           Ping_Socket,
           "$Id: Ping_Socket.cpp,v 1.8 2005/05/19 22:59:40 shuston Exp $")

ACE_ALLOC_HOOK_DEFINE (ACE_Ping_Socket)

//---------------------------------------------------------------------------
// Better to arrange some os_include/netinet/ip.h and
// os_include/netinet/icmp.h files ?
//---------------------------------------------------------------------------

#if !defined (ACE_WIN32)

/*
 * This is where ICMP-related stuff is defined on any sane system...
 */
#include /**/ <netinet/in.h>
#include /**/ <netinet/in_systm.h>
#include /**/ <netinet/ip.h>
#include /**/ <netinet/ip_icmp.h>

// When defined ACE_HAS_IPV6 we are still may willing to use icmp-v4, when
// e.g. the operating system not configured to use ipv6.
//
#if defined (ACE_HAS_IPV6)
#include /**/ <netinet/ip6.h>
#include /**/ <netinet/icmp6.h>
#endif /*ACE_HAS_IPV6 */

#else  /* #if ! defined (ACE_WIN32) */

/*
 * This was a surpise to me...  This stuff is not defined anywhere under MSVC.
 * These values have only been checked for NT4 and Win2K.  They were taken from
 * the MSDN ping.c program and modified.
 */

#if !defined (ICMP_ECHO)
#define ICMP_ECHO       8
#endif /* ICMP_ECHO */

#if !defined (ICMP_ECHOREPLY)
#define ICMP_ECHOREPLY  0
#endif /* ICMP_ECHOREPLY */

struct ip
{
  unsigned int    ip_hl:4;            // length of the header
  unsigned int    version:4;          // Version of IP
  unsigned char   tos;                // Type of service
  unsigned short  total_len;          // total length of the packet
  unsigned short  ident;              // unique identifier
  unsigned short  frag_and_flags;     // flags
  unsigned char   ip_ttl;             // Time to live
  unsigned char   proto;              // protocol (TCP, UDP etc)
  unsigned short  checksum;           // IP checksum
  unsigned int    sourceIP;
  unsigned int    destIP;
};

struct icmp
{
  unsigned char  icmp_type;
  unsigned char  icmp_code;      // type sub code
  unsigned short icmp_cksum;
  unsigned short icmp_id;
  unsigned short icmp_seq;
  unsigned long  icmp_data;      // time data
};


#if defined (ACE_HAS_IPV6)

//
// From RFC 3542 structure of IPv6 header
//
struct ip6_hdr 
{
  union 
  {
    struct ip6_hdrctl 
    {
        ACE_UINT32 ip6_un1_flow; // 4 bits version, 8 bits TC, 20 bits flow-ID
        ACE_UINT16 ip6_un1_plen; // payload length
        ACE_UINT8  ip6_un1_nxt;    // next header
        ACE_UINT8  ip6_un1_hlim;   // hop limit
     } ip6_un1;
          
      ACE_UINT8 ip6_un2_vfc;     // 4 bits version, top 4 bits tclass
  } ip6_ctlun;
        
    struct in6_addr ip6_src;   // source address
    struct in6_addr ip6_dst;   // destination address
};
#define ip6_vfc   ip6_ctlun.ip6_un2_vfc
#define ip6_flow  ip6_ctlun.ip6_un1.ip6_un1_flow
#define ip6_plen  ip6_ctlun.ip6_un1.ip6_un1_plen
#define ip6_nxt   ip6_ctlun.ip6_un1.ip6_un1_nxt
#define ip6_hlim  ip6_ctlun.ip6_un1.ip6_un1_hlim
#define ip6_hops  ip6_ctlun.ip6_un1.ip6_un1_hlim


//
// From RFC 3542 structure of ICMPv6 header
//
struct icmp6_hdr 
{
    ACE_UINT8     icmp6_type;      // type field
    ACE_UINT8     icmp6_code;     // code field
    ACE_UINT16    icmp6_cksum;  // checksum field
  union 
  {
      ACE_UINT32  icmp6_un_data32[1]; // type-specific field
      ACE_UINT16  icmp6_un_data16[2]; // type-specific field
      ACE_UINT8   icmp6_un_data8[4];    // type-specific field
  } icmp6_dataun;
};
#define icmp6_data32    icmp6_dataun.icmp6_un_data32
#define icmp6_data16    icmp6_dataun.icmp6_un_data16
#define icmp6_data8     icmp6_dataun.icmp6_un_data8
#define icmp6_pptr      icmp6_data32[0]  // parameter prob
#define icmp6_mtu       icmp6_data32[0]  // packet too big
#define icmp6_id        icmp6_data16[0]    // echo request/reply
#define icmp6_seq       icmp6_data16[1]  // echo request/reply
#define icmp6_maxdelay  icmp6_data16[0]  // mcast group membership



/* Remove it, if some header on wins defines it */
#if !defined (ICMP6_ECHO_REQUEST)
#define ICMP6_ECHO_REQUEST          128
#endif /* ICMP6_ECHO_REQUEST*/

/* Remove it, if some header on wins defines it */
#if !defined (ICMP6_ECHO_REPLY)
#define ICMP6_ECHO_REPLY            129
#endif /* ICMP6_ECHO_REPLY */

/* Remove it, if some header on wins defines it */
#if !defined (IPPROTO_ICMPV6)
#define IPPROTO_ICMPV6   58
#endif /* IPPROTO_ICMPV6 */

/* Remove it, if some header on wins defines it */
struct icmp6_filter 
{
  ACE_UINT32 icmp6_filt[8];  /* 8*32 = 256 bits */
};

/* Remove it, if some header on wins defines it */
#if !defined (ICMP6_FILTER)
#define ICMP6_FILTER 18
#endif /* ICMP6_FILTER */

/* Remove it, if some header on wins defines it */
#if !defined (ICMP6_FILTER_SETPASS)
#define ICMP6_FILTER_SETPASS(type, filterp) \
        ((((filterp)->icmp6_filt[(type) >> 5]) |= \
          (1 << ((type) & 31))))
#endif /* ICMP6_FILTER_SETPASS */

/* Remove it, if some header on wins defines it */
#if !defined (ICMP6_FILTER_SETBLOCKALL)
#define ICMP6_FILTER_SETBLOCKALL(filterp) \
        memset((filterp), 0, sizeof(struct icmp6_filter))
#endif /* ICMP6_FILTER_SETBLOCKALL */

/* Remove it, if some header on wins defines it */
#if !defined (IN6_IS_ADDR_V4MAPPED)
#define IN6_IS_ADDR_V4MAPPED(_addr) \
	(   (((const u_long *)(_addr))[0] == 0)		\
	 && (((const u_long *)(_addr))[1] == 0)		\
	 && (((const u_long *)(_addr))[2] == 0xffff0000)) /* Note byte order reversed */
/* 	    (((const u_long *)(_addr))[2] == ntohl(0x0000ffff))) */
#endif /* IN6_IS_ADDR_V4MAPPED */

/* Remove it, if some header on wins defines it */
#if !defined (IN6_IS_ADDR_V4COMPAT)
#define IN6_IS_ADDR_V4COMPAT(_addr) \
	(   (((const u_long *)(_addr))[0] == 0)		\
	 && (((const u_long *)(_addr))[1] == 0)		\
	 && (((const u_long *)(_addr))[2] == 0)		\
	 && (((const u_long *)(_addr))[3] != 0)		\
	 && (((const u_long *)(_addr))[3] != 0x01000000)) /* Note byte order reversed */
/*           (ntohl (((const u_long *)(_addr))[3]) > 1 ) */
#endif /* IN6_IS_ADDR_V4COMPAT */

#endif  /* ACE_HAS_IPV6 */

#endif /* #if defined (ACE_WIN32) */


int const ICMP_MIN = 8;  // Minimal size of ICMP packet, header only
int const ICMP_DATA_LENGTH = 56;  // For ICMP data with Echo request

ACE_Time_Value const ACE_Ping_Socket::time_default_ (0, 500000);

void
ACE_Ping_Socket::dump (void) const
{
  ACE_TRACE ("ACE_Ping_Socket::dump");
}

ACE_Ping_Socket::ACE_Ping_Socket (void)
  : process_id_ (getpid ()),
    sequence_number_ (0),
    connected_socket_ (0)
{
  ACE_TRACE ("ACE_Ping_Socket::ACE_Ping_Socket");
}

ACE_Ping_Socket::ACE_Ping_Socket (ACE_Addr const & local,
                                  int protocol,
                                  int reuse_addr)
  : process_id_ (getpid ()),
    sequence_number_ (0),
    connected_socket_ (0)
{
  ACE_TRACE ("ACE_Ping_Socket::ACE_Ping_Socket");

  ACE_OS::memset (icmp_send_buff_, 0, sizeof (icmp_send_buff_));
  ACE_OS::memset (icmp_recv_buff_, 0, sizeof (icmp_recv_buff_));

  if (this->open (local, protocol, reuse_addr) == -1)
    {
      ACE_DEBUG ((LM_DEBUG,
                  ACE_LIB_TEXT ("ACE_Ping_Socket::ACE_Ping_Socket: %p\n"),
                  ACE_LIB_TEXT ("open")));
    }
}

ACE_Ping_Socket::~ACE_Ping_Socket (void)
{
  ACE_TRACE ("ACE_Ping_Socket::~ACE_Ping_Socket");
}

int
ACE_Ping_Socket::open (ACE_Addr const & local,
                       int protocol,
                       int reuse_addr)
{
  ACE_TRACE ("ACE_Ping_Socket::open");

  if (inherited::open (local, 
                       protocol, 
                       reuse_addr) == -1)
    {
        ACE_ERROR_RETURN
            ((LM_ERROR,
              ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
              ACE_LIB_TEXT ("open ")
              ACE_LIB_TEXT ("- inherited infrustructure returns error.\n")),
             -1);
    }

  // Trying to increase the size of socket receive buffer - certain
  // protection from multiple responces e.g., when falling to the
  // multi-cast address
  int size = 64 * 1024;
  ACE_SOCK::set_option (SOL_SOCKET,
                        SO_RCVBUF,
                        (void *) &size,
                        sizeof (size));

#if defined (ACE_HAS_IPV6)

  /*
   * ICMPV6 raw socket can potentially receive huge amount of 
   * messages of different protocols and types. To limit the flow, we 
   * are using here an application specific filter to get only ICMPv6 
   * protocol and only ICMP6_ECHO_REPLY.
   *
   * For example, the filter enables us not to see 
   * ICMP6_ECHO_REQUEST messages, while pinging loopback interface.
   */

  icmp6_filter echo_reply_filter;
  if (this->effective_v4_ == 0)
    {
        // block all messages in the filter
        ICMP6_FILTER_SETBLOCKALL (&echo_reply_filter);

        // enable only ICMP6_ECHO_REPLY
        ICMP6_FILTER_SETPASS ( ICMP6_ECHO_REPLY, &echo_reply_filter);

        if (ACE_SOCK::set_option (IPPROTO_ICMPV6,
                                  ICMP6_FILTER,
                                  (void *) &echo_reply_filter,
                                  sizeof (echo_reply_filter)) == -1)
          {
              ACE_DEBUG ((LM_DEBUG,
                          ACE_LIB_TEXT ("ACE_Ping_Socket::open:  %p\n"),
                          ACE_LIB_TEXT ("set_option ICMP6_FILTER failed\n")));
          }
    }

#endif /* ACE_HAS_IPV6 */

  return 0;
}

int
ACE_Ping_Socket::receive_echo_reply (ACE_Time_Value const * timeout)
{
  ACE_TRACE ("ACE_Ping_Socket::receive_echo_reply");

  ACE_Time_Value before = ACE_OS::gettimeofday ();
  ACE_Time_Value after;
  ACE_Time_Value time_left;
  ACE_Time_Value *wait_time = const_cast<ACE_Time_Value *> (timeout);
  const ACE_Time_Value half_millisec (0, 500);

  ACE_OS::memset (icmp_recv_buff_, 0, sizeof icmp_recv_buff_);

  do
    {
      int rval_recv = inherited::recv (icmp_recv_buff_,
                                       sizeof (icmp_recv_buff_),
                                       0,
                                       wait_time);
      if (rval_recv < 0)
        {
          if (errno == EINTR)
            {
              after = ACE_OS::gettimeofday ();
              time_left = *timeout - after + before;

              // If more than .5 ms left, wait on select()
              if (time_left > half_millisec)
                {
                  wait_time = &time_left; // coming back to wait on select()
                  continue;
                }
              else
                {
                  break;
                }
            }
          return -1;
        }
      else if (this->process_incoming_dgram (icmp_recv_buff_, 
                                             rval_recv) == 0)
        {
          return 0; //= success
        }
      else
        {
          after = ACE_OS::gettimeofday ();
          if ((after - before) >= *timeout)
            {
              break;
            }
          // new timeout, we are coming back to sit on select
          *wait_time = *timeout - after + before;
        }
    } while (*wait_time >= half_millisec);

  errno = ETIMEDOUT;
  return -1;
}

int
ACE_Ping_Socket::process_incoming_dgram (char * ptr, ssize_t len)
{
#if defined (ACE_HAS_IPV6)
  if (this->effective_v4_)
    {
        return this->process_ipv4 (ptr, len);
    }
  else
    {
        return this->process_ipv6 (ptr, len);
    }
#else
  return this->process_ipv4 (ptr, len);  
#endif /* ACE_HAS_IPV6 */
}

int
ACE_Ping_Socket::process_ipv4 (char * ptr, ssize_t len)
{
  unsigned char hlen1;
  int icmplen;
  icmp * _icmp = 0;  
  ip * _ip = (ip *) ptr;                 // start of IP header

  // The first byte of the IPv4-header has the IP-version in the left-most 4 bits and 
  // the length in the other 4 bits.

  hlen1 = static_cast<unsigned char>(*ptr);
  hlen1 <<= 4;                            // Bump the version off
  hlen1 >>= 4;                            // Zero-extended length remains
  hlen1 <<= 2;                            // Now it counts bytes, not words

  _icmp = (icmp *) (ptr + hlen1);   // start of ICMP header

  if ((icmplen = len - hlen1) < ICMP_MIN)
    {
      ACE_DEBUG
        ((LM_DEBUG,
          ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_ipv4")
          ACE_LIB_TEXT (" - ICMP length is %d < 8.\n"),
          icmplen));
      ACE_ERROR_RETURN
        ((LM_ERROR,
          ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_ipv4 - ")
          ACE_LIB_TEXT ("The ICMP header either not received or is corrupted.\n")),
         -1);
    }

  if (_icmp->icmp_type == ICMP_ECHOREPLY)
    {
      ACE_DEBUG
        ((LM_DEBUG,
          ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_ipv4")
          ACE_LIB_TEXT (" - ICMP_ECHOREPLY received.\n")));

      if (_icmp->icmp_id != this->process_id_)
        {
          ACE_ERROR_RETURN
            ((LM_ERROR,
              ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
              ACE_LIB_TEXT ("process_ipv4 ")
              ACE_LIB_TEXT ("- The ICMP header received is a reply")
              ACE_LIB_TEXT (" to request of another process.\n")),
             -1);
        }
      if (icmplen < 16)
        {
          ACE_ERROR_RETURN
            ((LM_ERROR,
              ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
              ACE_LIB_TEXT ("process_ipv4 - ICMP length ")
              ACE_LIB_TEXT ("is %d < 16.\n"),
              icmplen),
             -1);
        }

      ACE_DEBUG
        ((LM_DEBUG,
          ACE_LIB_TEXT ("(%P|%t) ACE::Ping_Socket::process_ipv4 - ")
          ACE_LIB_TEXT ("received ")
          ACE_LIB_TEXT ("ICMP datagram with length of %d bytes (not counting ")
          ACE_LIB_TEXT ("IP-header): seq=%u, ttl=%d.\n"),
          icmplen, _icmp->icmp_seq, _ip->ip_ttl));

      return 0; //= success
    }

  ACE_DEBUG
    ((LM_DEBUG,
      ACE_LIB_TEXT ("(%P|%t) ACE::Ping_Socket::process_ipv4 - ")
      ACE_LIB_TEXT ("received datagram that is not ICMP_ECHOREPLY.\n")));

  return -1;
}

#if defined (ACE_HAS_IPV6)

int
ACE_Ping_Socket::process_ipv6 (char * ptr, ssize_t len)
{
  /*
   * Surprisingly for me, on linux systems (at least when pinging loopback) we get 
   * here only ICMP part without IPv6 header, although <len> reports the full 64 byte length. 
   * Great ping6 utility is aware about such behavior and takes care about the input 
   * without IPv6 header as well as with the header.
   *
   * Is there any specific reason not follow this practice?
   */

#if 0
  char obuf [256];
  ACE_OS::memset (obuf, 0, sizeof (obuf));
  ACE::format_hexdump (ptr, len, obuf, sizeof (obuf));
  fprintf (stderr, "buffer is %s.\n", obuf);
#endif /* 0 or 1*/

  int icmp6len = 0;
  icmp6_hdr * icmp6 = 0;
  unsigned char hlen1 = sizeof (ip6_hdr);

  if ((icmp6len = len - hlen1) < ICMP_MIN)
    {
        ACE_DEBUG
            ((LM_DEBUG,
              ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_ipv6")
              ACE_LIB_TEXT (" - ICMP6 length is %d < 8.\n"),
              icmp6len));
        ACE_ERROR_RETURN
        ((LM_ERROR,
          ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_ipv6 - ")
          ACE_LIB_TEXT ("The ICMP6 header either not received or is corrupted.\n")),
         -1);
    }

  icmp6 = reinterpret_cast<icmp6_hdr *> (ptr);
  if (icmp6->icmp6_type == ICMP6_ECHO_REPLY) // the first case
    {
      //= Trying the case without IPv6 header, when only ICMPv6 
      //= header comes.
      return process_icmp6_echo_reply (icmp6, icmp6len);
    }
  else // the second case
    {  
      //= Attempting the case with both IPv6 header and ICMPv6
      //= headers

      ip6_hdr * ip6 = reinterpret_cast<ip6_hdr *> (ptr); // start of IPv6 header
      
      if (ip6->ip6_nxt != IPPROTO_ICMPV6)
        {
          ACE_ERROR_RETURN
              ((LM_DEBUG,
                ACE_LIB_TEXT ("(%P|%t) ACE::Ping_Socket::process_ipv6 - ")
                ACE_LIB_TEXT ("received IP-datagram that is not ICMP6_ECHO_REPLY.\n")),
               -1);
        }

      // start of the ICMPv6 header after 40 byte IPv6 header offset
      // What about potential IPv6 options? Neither Richard Stevens,
      // nor ping6 pay attention to that.
      icmp6 = reinterpret_cast<icmp6_hdr *> (ptr + hlen1);

      return process_icmp6_echo_reply (icmp6, icmp6len);
    }
  return -1;
}

int
ACE_Ping_Socket::process_icmp6_echo_reply (icmp6_hdr * _icmp6,
                                           int _icmp6len)
{
  ACE_DEBUG
      ((LM_DEBUG,
        ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::process_icmp_echo_reply ")
        ACE_LIB_TEXT (" - ICMP6_ECHO_REPLY received.\n")));

  if (_icmp6->icmp6_id != this->process_id_)
    {
      ACE_ERROR_RETURN
          ((LM_ERROR,
            ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
            ACE_LIB_TEXT ("process_icmp_echo_reply ")
            ACE_LIB_TEXT ("- The ICMP header received is a reply")
            ACE_LIB_TEXT (" to request of another process.\n")),
           -1);
    }

  if (_icmp6len < 16)
    {
      ACE_ERROR_RETURN
          ((LM_ERROR,
            ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
            ACE_LIB_TEXT ("process_icmp_echo_reply - ICMP length is %d < 16.\n"),
            _icmp6len),
           -1);
    }

  ACE_DEBUG
      ((LM_DEBUG,
        ACE_LIB_TEXT ("(%P|%t) ACE::Ping_Socket::process_ipv6 - ")
        ACE_LIB_TEXT ("received ICMP datagram with length of %d bytes ")
        ACE_LIB_TEXT (" (not counting) IP-header: seq=%u.\n"),
        _icmp6len, _icmp6->icmp6_seq));
  
  return 0;
}
#endif /* ACE_HAS_IPV6 */


int
ACE_Ping_Socket::send_echo_check (ACE_INET_Addr &remote_addr,
                                  int to_connect)
{
  if (this->get_handle () == ACE_INVALID_HANDLE)
    {
      errno = EBADF;
      return -1;
    }

  sockaddr * addr_connect = 0;
  int sending_icmp_v4 = 1;

#if defined (ACE_HAS_IPV6)

  const int is_remote_addr_ipv6 = remote_addr.get_type () == PF_INET6;

  sockaddr_in6 * sock6_addr = 0;

  if (is_remote_addr_ipv6)
    {
        sock6_addr = static_cast<sockaddr_in6 *> (remote_addr.get_addr ());
    }

  /*
   * When both the raw socket is initialized to use PF_INET6 
   * family (IPv6) and the remote address is IPv6, we still need 
   * to ensure, that the remote address is not an IPv4 mapped to IPv6.
   * Should we check for IN6_IS_ADDR_V4COMPAT also ?
   */
  const int is_remote_addr_ipv4_mapped_ipv6 = 
      (is_remote_addr_ipv6 &&
       IN6_IS_ADDR_V4MAPPED (sock6_addr->sin6_addr.s6_addr));

  if ((is_remote_addr_ipv6 && is_remote_addr_ipv4_mapped_ipv6 == 0) 
      && this->effective_v4_)
    {
      ACE_ERROR_RETURN
          ((LM_ERROR,
            ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
            ACE_LIB_TEXT ("send_echo_check - error, the remote address provided ")
            ACE_LIB_TEXT ("is IPv6, but not IPV4 mapped to IPV6, while the local ")
            ACE_LIB_TEXT ("ACE_Ping_Socket is initialized for PF_INET (IPv4).\n")),
           -1);
    }

   if (is_remote_addr_ipv6 == 0 && this->effective_v4_ == 0)
    {
      ACE_ERROR_RETURN
          ((LM_ERROR,
            ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
            ACE_LIB_TEXT ("send_echo_check - error, the remote address provided ")
            ACE_LIB_TEXT ("is IPv4, while the local ACE_Ping_Socket is initialized ")
            ACE_LIB_TEXT ("for PF_INET6 (IPv6).\n")),
           -1);
    }

  if (this->effective_v4_ == 0 && is_remote_addr_ipv6)
    {
      /*
       * When the remote address is an IPv4 mapped IPv6 address, 
       * we can use, according to Richard Stevens, only IPv4 to ping on it.
       */
      if (is_remote_addr_ipv4_mapped_ipv6)
        {
          ACE_ERROR_RETURN
              ((LM_ERROR,
                ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::")
                ACE_LIB_TEXT ("send_echo_check - the remote address provided ")
                ACE_LIB_TEXT ("is an IPv4 mapped IPv6 address. In order to ping such address, ")
                ACE_LIB_TEXT ("please, use ACE_Ping_Socket, constructed or ")
                ACE_LIB_TEXT ("initialized, using non-default protocol family PF_INET (IPv4).\n")),
               -1);
        }
      else
      {
         // nulling port field
        sock6_addr->sin6_port = 0;
        
        // The socket initialized to use PF_INET6 family (IPv6) and the remote 
        // address is IPv6 (and not IPv4 mapped to IPv6), so we can use ICMPv6.
        //
        addr_connect = reinterpret_cast<sockaddr *> (sock6_addr);
        
        sending_icmp_v4 = 0; // sending IPv6, not IPv4
      }
    }

  // TODO: Attention !!! I am not sure, what will happen in the case, when
  //
  // if (this->effective_v4_&& is_remote_addr_ipv4_mapped_ipv6)
  //  {
  // ACE_HAS_IPV6 defined, local ACE_Ping_Socket constructed as INET
  // and remote address is IPV4 mapped to IPV6
  // It should be a separate test case for that.
  // 

#endif /* ACE_HAS_IPV6 */

  if (addr_connect == 0)
  {
    /*
     * If coming here, we are working IPv4 and ICMP protocols, 
     * whatever is the reason, and even, if the flag ACE_HAS_IPV6
     * is defined.
     */
    sockaddr_in * sock4_addr = 
        static_cast<sockaddr_in *> (remote_addr.get_addr ());
    
    /*
     * Nulling port field to prevent strange behavior, when a raw
     * socket is "connected" to a sockaddr_in with a non-nulled port.
     */
    sock4_addr->sin_port = 0;
    addr_connect = reinterpret_cast<sockaddr *> (sock4_addr);
    sending_icmp_v4 = 1;
  }

  // connecting the socket
  if (to_connect && ! this->connected_socket_)
    {
      if (ACE_OS::connect (this->get_handle (),
                           addr_connect,
                           remote_addr.get_size ()) == -1)
        {
          if (errno != EINTR)
            return -1;
        }
      this->connected_socket_ = 1;
    }

  ACE_OS::memset (this->icmp_send_buff_, 0, sizeof this->icmp_send_buff_);

  const int length_icmp = ICMP_MIN + ICMP_DATA_LENGTH;

  if (sending_icmp_v4)
    {
      // sending ICMP over IPv4

      icmp *_icmp = 0;
      
      _icmp = reinterpret_cast<icmp *> (this->icmp_send_buff_);
      _icmp->icmp_type = ICMP_ECHO;
      _icmp->icmp_code = 0;
      _icmp->icmp_id = this->process_id_;
      _icmp->icmp_seq = sequence_number_++;
      
#if defined (ACE_WIN32)
      _icmp->icmp_data = GetTickCount ();
#else  /* #if defined (ACE_WIN32) */
      gettimeofday (reinterpret_cast<timeval *> (&_icmp->icmp_data), 0);
#endif  /* #if defined (ACE_WIN32) */
      
      // checksum ICMP header and data.
      _icmp->icmp_cksum = 0;
      _icmp->icmp_cksum = inherited::calculate_checksum (
          reinterpret_cast<u_short *> (_icmp),
          length_icmp);
    }
  else
  {
    // sending ICMPv6 over IPv6 
    
#if defined (ACE_HAS_IPV6)

    icmp6_hdr * _icmp6 = 0;
    _icmp6 = (icmp6_hdr *) this->icmp_send_buff_;
    _icmp6->icmp6_type = ICMP6_ECHO_REQUEST;
    _icmp6->icmp6_code = 0;
    _icmp6->icmp6_id = this->process_id_;
    _icmp6->icmp6_seq = sequence_number_++;
    
#if defined (ACE_WIN32)
    _icmp6->icmp6_data32[1] = (unsigned int )GetTickCount ();
#else  /* #if defined (ACE_WIN32) */
    gettimeofday (reinterpret_cast<timeval *> (_icmp6 + 1), 0);
#endif  /* #if defined (ACE_WIN32) */
    
   // By default kernel calculates the checksum in ICMPv6
    
#endif /* ACE_HAS_IPV6 */     
  }

  int rval_send = -1;
  if ((rval_send = send (static_cast <void const *> (icmp_send_buff_),
                         length_icmp,
                         remote_addr)) != length_icmp)
    {
      return -1;
    }
  return 0;
}

int
ACE_Ping_Socket::make_echo_check (ACE_INET_Addr & remote_addr,
                                  int to_connect,
                                  ACE_Time_Value const * timeout)
{
  int rval_send = -1;

  if ((rval_send = this->send_echo_check (remote_addr,
                                          to_connect)) == -1)
    {
      return -1;
    }

  ACE_DEBUG
    ((LM_DEBUG,
      ACE_LIB_TEXT ("(%P|%t) ACE_Ping_Socket::make_echo_check - sent %d.\n"),
      rval_send));

  return this->receive_echo_reply (timeout);
}

#endif  /* ACE_HAS_ICMP_SUPPORT == 1 */
