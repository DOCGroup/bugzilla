// -*- C++ -*-

//=============================================================================
/**
 *  @file    Ping_Socket.h
 *
 *  $Id: Ping_Socket.h,v 1.6 2005/05/19 22:52:41 shuston Exp $
 *
 *  @author Robert Iakobashvili <coroberti@gmail.com> <coroberti@bezeqint.net>
 *  @author Gonzalo A. Diethelm <gonzalo.diethelm@aditiva.com>
 */
//=============================================================================

#ifndef ACE_PING_SOCKET_H
#define ACE_PING_SOCKET_H

#include /**/ "ace/pre.h"

#include "ace/ACE_export.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#if defined (ACE_HAS_ICMP_SUPPORT) && (ACE_HAS_ICMP_SUPPORT == 1)

#include "ace/ICMP_Socket.h"

// forward declarations
class ACE_INET_Addr;
struct icmp6_hdr;

/**
 * @class ACE_Ping_Socket
 *
 * @brief This class is useful to perform ICMP or ICMPv6 echo 
 * checks (pinging) of the party of your interest.
 * It may be used as well to check LAN-adapters against 3rd parties.
 */
class ACE_Export ACE_Ping_Socket : public ACE_ICMP_Socket
{
  typedef ACE_ICMP_Socket inherited;

public:

  // = Initialization and termination methods.

  /// Default constructor.
  ACE_Ping_Socket (void);

  /// Constructor. 
  /// To make echo-checks of an IPv4 mapped IPv6 address, when 
  /// ACE_HAS_IPV6 defined, pass IPPROTO_ICMP, and not 
  /// IPPROTO_ICMPV6.
  ACE_Ping_Socket (ACE_Addr const & local,
                   int protocol =
#if defined (ACE_HAS_IPV6)
                   IPPROTO_ICMPV6,
#else
                   IPPROTO_ICMP,
#endif /*ACE_HAS_IPV6 */
                   int reuse_addr  = 0);

  /// Destructor.
  ~ACE_Ping_Socket (void);

  /// Wrapper around the BSD-style @c socket system call (no QoS).
  /// To make echo-checks of an IPv4 mapped IPv6 address, when 
  /// ACE_HAS_IPV6 defined, pass IPPROTO_ICMP, and not the default 
  /// IPPROTO_ICMPV6.
  int open (ACE_Addr const & local = ACE_Addr::sap_any,
            int protocol = 
#if defined (ACE_HAS_IPV6)
            IPPROTO_ICMPV6,
#else
            IPPROTO_ICMP,
#endif /*ACE_HAS_IPV6 */
            int reuse_addr = 0);

  /// @a toConnect = 1 - makes connect to remote address
  int send_echo_check (ACE_INET_Addr & remote_addr,
                       int to_connect = 0);

  /// To receive @c ICMP/ICMP6 ECHO_REPLY. To be called after successfully
  /// sending @c ICMP/ICMP6 ECHO_REQUEST.
  int process_incoming_dgram (char * ptr, ssize_t len);

  /// Makes echo check of the @a remote_addr limited by @a timeout. 
  /// When @a to_connect = 1, connects the raw socket to @a remote_addr
  int make_echo_check (ACE_INET_Addr & remote_addr,
                       int to_connect = 0,
                       ACE_Time_Value const * timeout = &time_default_);

  /// Access to the receive buffer
  char * icmp_recv_buff (void);

  /// Dump the state of an object.
  void dump (void) const;

  /// Declare the dynamic allocation hooks.
  ACE_ALLOC_HOOK_DECLARE;

public:

  enum
    {
      PING_BUFFER_SIZE = (1024)
    };

  static ACE_Time_Value const time_default_;

private:

  /// Processes input to the raw socket in search for
  /// ICMP_ECHO_REPLY messages
  int process_ipv4 (char * ptr, ssize_t len);

#if defined (ACE_HAS_IPV6)

  /// Processes input to the raw socket in search for
  /// ICMP6_ECHO_REPLY messages
  int process_ipv6 (char * ptr, ssize_t len);

  int process_icmp6_echo_reply (icmp6_hdr * _icmp6,
                                int _icmp6len);
#endif /* ACE_HAS_IPV6 */
  
  /// Waits for @a timeout to receive ICMP/ICMP6 ECHO_REPLY messages.
  int receive_echo_reply (ACE_Time_Value const * timeout);

  /// Do not allow this function to percolate up to this interface.
  int get_remote_addr (ACE_INET_Addr &addr) const;

  /// The process-id. Used as the identity in ICMP/ICMPV6 
  /// messages.
  const ACE_UINT16 process_id_;

  /// Buffer used to send echo requests
  char icmp_send_buff_[PING_BUFFER_SIZE];

  /// Buffer used to receive echo responses
  char icmp_recv_buff_[(4 * PING_BUFFER_SIZE)];

  /// Incremented counter used to mark outbound echo requests.
  ACE_UINT16 sequence_number_;

  /// Whether the raw socket is connected to the remote address.
  int connected_socket_;

};

#if defined (__ACE_INLINE__)
# include "ace/Ping_Socket.inl"
#endif /* __ACE_INLINE__ */

#endif  /* ACE_HAS_ICMP_SUPPORT == 1 */

#include /**/ "ace/post.h"

#endif /* ACE_PING_SOCKET_H */
