// $Id: ICMP_Socket.cpp,v 1.6 2005/05/19 22:59:49 shuston Exp $

#include "ace/ICMP_Socket.h"

#if defined (ACE_HAS_ICMP_SUPPORT) && (ACE_HAS_ICMP_SUPPORT == 1)

#include "ace/ACE.h"
#include "ace/Log_Msg.h"
#include "ace/OS_NS_netdb.h"
#include "ace/OS_NS_sys_socket.h"

#if !defined (__ACE_INLINE__)
# include "ace/ICMP_Socket.inl"
#endif  /* !__ACE_INLINE__ */


ACE_RCSID (ace,
           ICMP_Socket,
           "$Id: ICMP_Socket.cpp,v 1.6 2005/05/19 22:59:49 shuston Exp $")

ACE_ALLOC_HOOK_DEFINE (ACE_ICMP_Socket)

void
ACE_ICMP_Socket::dump (void) const
{
  ACE_TRACE ("ACE_ICMP_Socket::dump");
}

ACE_ICMP_Socket::ACE_ICMP_Socket (void)
#if defined (ACE_HAS_IPV6)
    : effective_v4_ (0)
#endif /*ACE_HAS_IPV6 */
{
  ACE_TRACE ("ACE_ICMP_Socket::ACE_ICMP_Socket");
}

ssize_t
ACE_ICMP_Socket::send (void const * buf,
                       size_t n,
                       ACE_Addr const & addr,
                       int flags) const
{
  ACE_TRACE ("ACE_ICMP_Socket::send");

  return ACE_OS::sendto (this->get_handle (),
                         static_cast<char const *> (buf),
                         n,
                         flags,
                         static_cast<sockaddr const *> (addr.get_addr ()),
                         addr.get_size ());
}

ssize_t
ACE_ICMP_Socket::recv (void * buf,
                       size_t n,
                       ACE_Addr & addr,
                       int flags) const
{
  ACE_TRACE ("ACE_ICMP_Socket::recv");

  int addr_len = addr.get_size ();
  ssize_t status = ACE_OS::recvfrom (this->get_handle (),
                                     static_cast<char *> (buf),
                                     n,
                                     flags,
                                     static_cast<sockaddr *> (addr.get_addr ()),
                                     &addr_len);
  addr.set_size (addr_len);

  return status;
}

ssize_t
ACE_ICMP_Socket::recv (void * buf,
                       size_t n,
                       int flags,
                       ACE_Time_Value const * timeout) const
{
  ACE_TRACE ("ACE_ICMP_Socket::recv");

  return ACE::recv (this->get_handle (),
                    buf,
                    n,
                    flags,
                    timeout);
}

int
ACE_ICMP_Socket::open (ACE_Addr const & local,
                       int protocol,
                       int reuse_addr)
{
  ACE_TRACE ("ACE_ICMP_Socket::open");

  int use_ipv6 = 0;

#if defined (ACE_HAS_IPV6)

  if ( protocol == IPPROTO_ICMP)
    {
      // This is a hint for us to run IPv4, even when IPv6 is configured
      this->effective_v4_ = 1;
      use_ipv6 = 0;
    }
  else
    {
      // Correcting the protocol, when e.g. ACE configured to support IPV6,
      // but the operating system is not.
      protocol = (use_ipv6 = ACE::ipv6_enabled ()) ? IPPROTO_ICMPV6 : IPPROTO_ICMP;

      this->effective_v4_ = ! use_ipv6;
    }

#endif /*ACE_HAS_IPV6 */

  if (ACE_SOCK::open (SOCK_RAW,
                      use_ipv6 ? PF_INET6 : PF_INET,
                      protocol,
                      reuse_addr) == -1)
    {
      ACE_ERROR_RETURN 
          ((LM_ERROR,
            ACE_LIB_TEXT ("ACE_ICMP_Socket::open: %p\n"),
            ACE_LIB_TEXT ("open raw socket")),
           -1);
    }

  return this->shared_open (local);
}

int
ACE_ICMP_Socket::shared_open (ACE_Addr const & local)
{
  ACE_TRACE ("ACE_ICMP_Socket::shared_open");

  int error = 0;
  if (local == ACE_Addr::sap_any)
    {
#if !defined (ACE_HAS_IPV6)
        if (ACE::bind_port (this->get_handle ()) == -1)
        {
          error = 1;
        }
#endif /* !ACE_HAS_IPV6 */
    }
  else if (ACE_OS::bind (this->get_handle (),
                         static_cast<sockaddr *> (local.get_addr ()),
                         local.get_size ()) == -1)
    {
      error = 1;
    }

  if (error != 0)
    {
      this->close ();
    }

  return error ? -1 : 0;
}

unsigned short
ACE_ICMP_Socket::calculate_checksum (unsigned short * paddress,
                                     int len)
{
  int nleft = len;
  int sum = 0;
  unsigned short * w = paddress;
  unsigned short answer = 0;
  while (nleft > 1)
    {
      sum += *w++;
      nleft -= 2;
    }

  if (nleft == 1)
    {
      *(reinterpret_cast<unsigned char *> (&answer)) = 
          *(reinterpret_cast<unsigned char *> (w));
      sum += answer;
    }

  // add back carry outs from top 16 bits to low 16 bits
  sum = (sum >> 16) + (sum & 0xffff); // add hi 16 to low 16
  sum += (sum >> 16);                 // add carry
  answer = ~sum;                      // truncate to 16 bits

  return (answer);
}

#endif  /* ACE_HAS_ICMP_SUPPORT == 1 */
