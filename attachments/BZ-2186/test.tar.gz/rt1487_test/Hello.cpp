//
// $Id: Hello.cpp,v 1.3 2002/01/29 20:21:07 okellogg Exp $
//
#include "Hello.h"

ACE_RCSID(Hello, Hello, "$Id: Hello.cpp,v 1.3 2002/01/29 20:21:07 okellogg Exp $")

Hello::Hello (CORBA::ORB_ptr orb)
  : orb_ (CORBA::ORB::_duplicate (orb))
{
}

char *
Hello::get_string (ACE_ENV_SINGLE_ARG_DECL_NOT_USED)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  ACE_DEBUG ((LM_DEBUG, "(%P|%t) - Received call back !!!\n"));
  return CORBA::string_dup ("Hello there!");
}

void
Hello::shutdown (ACE_ENV_SINGLE_ARG_DECL)
  ACE_THROW_SPEC ((CORBA::SystemException))
{
  this->orb_->shutdown (0 ACE_ENV_ARG_PARAMETER);
}

void
Hello::request_callback (Test::Hello_ptr call_me ACE_ENV_ARG_DECL)
    ACE_THROW_SPEC ((CORBA::SystemException))
{
  ACE_DEBUG ((LM_DEBUG, "(%P|%t) - Making call back !!!\n"));
  ACE_TRY
    {
      CORBA::String_var result = call_me->get_string ();
    }
  ACE_CATCHANY
    {
      ACE_PRINT_EXCEPTION (ACE_ANY_EXCEPTION,
                               "Exception attempting to callback client obj ref: \n");
      ACE_RE_THROW;
    }
  ACE_ENDTRY;
  ACE_DEBUG ((LM_DEBUG, "(%P|%t) - Call back succeeded !!!\n"));
}
