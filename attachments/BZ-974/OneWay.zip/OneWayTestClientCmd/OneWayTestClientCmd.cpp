// OneWayTestClientCmd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "client.h"
#include "..\OneWayServer_c.hh"
#include "..\OneWayClient_s.hh"
#include "time.h"
#include "conio.h"

CORBA::ORB_var  m_Orb;
PortableServer::POA_var		rootPOA;
PortableServer::POA_var		poa;

TestServer::OneWayTestServer*	m_Server;
OneWayClient*       m_Client;

/* Pauses for a specified number of milliseconds. */
void sleep( clock_t wait )
{
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() )
      ;
}

int main(int argc, char* argv[])
{
	m_Orb = CORBA::ORB_init(argc,argv,"");
	
	CORBA_Object_var obj = m_Orb->resolve_initial_references("RootPOA");
	rootPOA = PortableServer::POA::_narrow(obj);
	try
	{
		PortableServer::POAManager_var mgr = rootPOA->the_POAManager();
		CORBA::PolicyList policies;
		poa = rootPOA->create_POA("OneWayClientPOA",mgr,policies);
	}
	catch(CORBA_Exception& e)
	{
		printf("CORBA Exception on POA: %s\n",e._id());
	}

	m_Client = new OneWayClient();

	PortableServer::ObjectId_var clientId =
		PortableServer::string_to_ObjectId("OneWayClient");
	try
	{
		poa->activate_object_with_id(clientId,m_Client);
	}
	catch(CORBA_Exception& e)
	{
		printf("CORBA Exception on POA: %s\n",e._id());
	}

	FILE *in = fopen("C:\\tao_OneWay.ior","r");
	char ior[2000];
	fscanf(in,"%s",ior);
	CORBA_Object_var objServer = m_Orb->string_to_object(ior);
	m_Server = TestServer::OneWayTestServer::_narrow(objServer);

	try
	{
		m_Server->register_Client(m_Client);
	}
	catch(CORBA_Exception& e)
	{
		printf("CORBA Exception on register: %s\n",e._id());
	}
	catch(...)
	{
		printf("general Exception on register\n");
	}
	printf("Ready\n");

	return 0;
}
