#include "client.h"

void OneWayClient::CallTest(const char* Text)
{
	printf("%s\r",Text);
}

OneWayClient::OneWayClient()
{
}

