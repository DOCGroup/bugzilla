// OneWayServerCmd.cpp : Defines the entry point for the console application.
//
#include "server.h"
#include "time.h"
#include "conio.h"

CORBA::ORB_var m_Orb;
PortableServer::POA_var		rootPOA;
PortableServer::POA_var		poa;

OneWayServer* m_Server;

/* Pauses for a specified number of milliseconds. */
void sleep( clock_t wait )
{
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() )
      ;
}


int main(int argc, char* argv[])
{
	m_Orb = CORBA::ORB_init(argc,argv,"");
	
	CORBA_Object_var obj = m_Orb->resolve_initial_references("RootPOA");
	rootPOA = PortableServer::POA::_narrow(obj);
	PortableServer::POAManager_var mgr = rootPOA->the_POAManager();
	CORBA::PolicyList policies;
	poa = rootPOA->create_POA("OneWayServerPOA",mgr,policies);

	m_Server = new OneWayServer();
	
	PortableServer::ObjectId_var serverId =
		PortableServer::string_to_ObjectId("OneWayServer");
	poa->activate_object_with_id(serverId,m_Server);

	printf("Ready\n");

	FILE *out = fopen("C:\\tao_OneWay.ior","w+");
	CORBA_String_var ior = m_Orb->object_to_string(m_Server->_this());
	fprintf(out,"%s",ior);
	fclose(out);

	for (;;)
	{
		sleep(20);
		m_Server->SendToClient();
		if (_kbhit())
			return 0;
	}

	return 0;
}
